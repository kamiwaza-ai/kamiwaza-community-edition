#!/bin/bash
set -ex

# Set the environment variable
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python'

# Get the directory of the BASH_SOURCE
dir=$(dirname "${BASH_SOURCE[0]}")
dir=$(realpath "${dir}")

# Change to the notebooks directory
cd "${dir}/notebooks"

# Get PIDs of JupyterLab processes
jupyter_pids=$(ps auxwww | grep '[p]ython' | grep jupyter-lab | awk '{print $2}')

# If PIDs were found, kill the processes
if [ ! -z "$jupyter_pids" ]; then
    for pid in $jupyter_pids; do
        echo "Killing JupyterLab process with PID: $pid"
        kill "$pid"
        # Optionally, wait for the process to be killed
        while kill -0 "$pid" 2> /dev/null; do
            echo "Waiting for JupyterLab process PID $pid to terminate..."
            sleep 1
        done
    done
else
    echo "No JupyterLab process found."
fi

# Set Jupyter configuration directory to a custom path within the project
jupyter_config_dir="${dir}/notebook-venv/.jupyter"
mkdir -p "${jupyter_config_dir}"

# Check and update Jupyter configuration
jupyter_config_file="${jupyter_config_dir}/jupyter_lab_config.py"
if [ ! -f "${jupyter_config_file}" ]; then
    echo "Creating Jupyter configuration file and setting base_url and environment variable..."
    cat << EOF > "${jupyter_config_file}"
c.ServerApp.base_url = '/lab'
import os
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'
EOF
else
    if ! grep -q "c.ServerApp.base_url" "${jupyter_config_file}"; then
        echo "Adding base_url setting to existing Jupyter configuration file..."
        echo "c.ServerApp.base_url = '/lab'" >> "${jupyter_config_file}"
    fi
    if ! grep -q "PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION" "${jupyter_config_file}"; then
        echo "Adding environment variable setting to existing Jupyter configuration file..."
        echo "import os" >> "${jupyter_config_file}"
        echo "os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'" >> "${jupyter_config_file}"
    fi
fi

# Verify the configuration
echo "Jupyter configuration file content:"
cat "${jupyter_config_file}"

# Start JupyterLab with the custom configuration directory
echo "Starting JupyterLab..."
source ../notebook-venv/bin/activate

# Ensure we have the jupyter lab packages themselves installed
pip install --upgrade jupyterlab notebook ipykernel ipywidgets

export JUPYTER_CONFIG_DIR="${jupyter_config_dir}"
nohup jupyter lab --ip=0.0.0.0 --no-browser > jupyter_lab.log 2>&1 &
sleep 4 # Give it a moment to start and write to the log
grep -E "http://.*token=|https://.*token=" jupyter_lab.log