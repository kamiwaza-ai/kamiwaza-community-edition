#!/bin/bash
set -x

# Split EXCLUDE_CONTAINERS into an array if it is comma separated
EXCLUDE_CONTAINERS=${KAMIWAZA_EXCLUDE_CONTAINERS:-qdrant,nonexistant}
excluded_containers=(${EXCLUDE_CONTAINERS//,/ })

# Test for KAMIWAZA_ROOT in the environment and set/export it if not set
if [ -z "${KAMIWAZA_ROOT}" ]; then
    script_dir=$(dirname "$0")
    # Yes, these paths both lead to the same result; however, highlighting
    # that launch.py can be in ROOT or ROOT/kamiwaza, depending on the
    # install methods/env, but either way we want the upper folder
    if [ -f "$script_dir/launch.py" ]; then
        export KAMIWAZA_ROOT=$(cd "$script_dir" && pwd)
    elif [ -f "$script_dir/kamiwaza/launch.py" ]; then
        export KAMIWAZA_ROOT=$(cd "$script_dir" && pwd)
    fi
fi

# Determine platform
if [[ "$(uname)" == "Darwin" ]]; then
    platform='osx'
else
    platform='linux'
fi

# Determine architecture
arch_raw=$(uname -m)
case "$arch_raw" in
    "x86_64")
        arch='amd64'
        ;;
    "aarch64"|"arm64")
        arch='arm64'
        ;;
    *)
        echo "Unsupported architecture: $arch_raw"
        exit 1
        ;;
esac

# Determine CPU or GPU
if command -v nvidia-smi &> /dev/null && nvidia-smi > /dev/null 2>&1; then
    cpugpu='gpu'
else
    cpugpu='cpu'
fi

# Check for KAMIWAZA_ENV, set to "default" if not set
KAMIWAZA_ENV=${KAMIWAZA_ENV:-default}

# Get the component argument if provided
component_arg=$1

# Main loop to process components
for component_path in $(find kamiwaza/deployment -mindepth 1 -maxdepth 1 -type d | grep -v '/envs$'); do
    component=$(basename $component_path)
    
    # If a component argument is provided, skip components that don't match
    if [[ -n "$component_arg" && "$component" != *"$component_arg"* ]]; then
        continue
    fi

    # Check if the component is excluded
    exclude=false
    for excluded in "${excluded_containers[@]}"; do
        if [[ "$component" == *"$excluded"* ]]; then
            exclude=true
            break
        fi
    done
    if [[ "$exclude" == true ]]; then
        echo "Skipping $component because it is excluded"
        continue
    fi

    # Determine the appropriate architecture suffixes to create directories for
    arch_suffixes=() # Initialize an empty array to hold potential architecture suffixes
    if [[ -d "kamiwaza/deployment/${component}/${arch}" ]]; then
        arch_suffixes+=("${arch}")
    fi
    if [[ -d "kamiwaza/deployment/${component}/${arch}-cpu" ]]; then
        arch_suffixes+=("${arch}-cpu")
    fi
    if [[ -d "kamiwaza/deployment/${component}/${arch}-gpu" ]]; then
        arch_suffixes+=("${arch}-gpu")
    fi

    # Create environment specific directories based on the architecture suffixes found
    for suffix in "${arch_suffixes[@]}"; do
        mkdir -p "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}"
    done

    # Copy files from both architecture and architecture with CPU/GPU suffix if they exist
    for suffix in "${arch_suffixes[@]}"; do
        for file in docker-compose.yml prelaunch.sh postlaunch.sh; do
            if [[ -f "kamiwaza/deployment/${component}/${suffix}/${file}" ]]; then
                cp "kamiwaza/deployment/${component}/${suffix}/${file}" "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}/"
            fi
        done
        # Copy any other *.yml files in the source to the target
        for yml_file in kamiwaza/deployment/${component}/${suffix}/*.yml; do
            if [[ -f "$yml_file" ]]; then
                cp "$yml_file" "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}/"
            fi
        done
        # Copy any *.py files in the source to the target
        for py_file in kamiwaza/deployment/${component}/${suffix}/*.py; do
            if [[ -f "$py_file" ]]; then
                cp "$py_file" "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}/"
            fi
        done
    done

    # Determine the appropriate architecture folder considering CPU/GPU suffix for further operations
    if [[ "$cpugpu" == "gpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-gpu" ]]; then
        arch_folder="${arch}-gpu"
    elif [[ -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}" ]]; then
        arch_folder="${arch}"
    elif [[ "$cpugpu" == "cpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-cpu" ]]; then
        arch_folder="${arch}-cpu"
    else
        echo "No suitable architecture folder found for component: ${component}"
        continue
    fi

    # Navigate to the component directory
    cd "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch_folder}"

    # Execute lifecycle scripts if they exist
    [[ -f "prelaunch.sh" ]] && bash "prelaunch.sh" > prelaunch.log 2>&1
    docker compose -f "docker-compose.yml" -p "${KAMIWAZA_ENV}-${component}" up -d
    [[ -f "launch.sh" ]] && sleep 5 && bash "launch.sh" > launch.log 2>&1
    [[ -f "postlaunch.sh" ]] && sleep 5 && bash "postlaunch.sh" > postlaunch.log 2>&1

    # Return to the original directory
    cd - > /dev/null
done
exit 0