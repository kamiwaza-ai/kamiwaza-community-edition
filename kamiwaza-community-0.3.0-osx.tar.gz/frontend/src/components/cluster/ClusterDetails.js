import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';


const ClusterDetails = () => {
    const [cluster, setCluster] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    let { cluster_id } = useParams();

    useEffect(() => {
        const fetchClusterDetails = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/cluster/${cluster_id}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setCluster(response.data);
                } else {
                    throw new Error(`Failed to fetch cluster details from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchClusterDetails();
    }, [cluster_id]);

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Clusters Home
            </StyledButton>
            <StyledHeader>Cluster Details</StyledHeader>
            {loading && <StyledParagraph>Loading...</StyledParagraph>}
            {error && <StyledParagraph>Error: {error.message}</StyledParagraph>}
            <div className="cluster-list">
                {cluster && (
                    <div key={cluster.id} className="cluster-card">
                        <StyledHeader>{cluster.name}</StyledHeader>
                        <StyledParagraph><strong>Location ID:</strong> {cluster.location_id}</StyledParagraph>
                        <StyledParagraph><strong>ID:</strong> {cluster.id}</StyledParagraph>
                        <StyledParagraph><strong>Created At:</strong> {cluster.created_at}</StyledParagraph>
                    </div>
                )}
            </div>
        </StyledMainContent>
    );
};

export default ClusterDetails;