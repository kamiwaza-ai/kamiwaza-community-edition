import React from 'react';
import Spinner from '../common/Spinner';
import VectorDBList from './VectorDBList';
import AddVectorDBModal from './AddVectorDBForm';
import VectorDBDetails from './VectorDBDetails';
import ErrorComponent from '../common/ErrorComponent';
import { StyledMainContent, StyledHeader } from '../../StyledComponents';

const VectorDBHome = () => {
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);

    // Only set loading to false when all components have mounted
    // and started their own data fetching
    React.useEffect(() => {
        setLoading(false);
    }, []);

    return (
        <StyledMainContent className="crudcontainer">
            <StyledHeader>VectorDB Home</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            <VectorDBList />
            <AddVectorDBModal />
        </StyledMainContent>
    );
};

export default VectorDBHome;
