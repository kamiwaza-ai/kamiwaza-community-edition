import React from 'react';
import { NavLink } from 'react-router-dom';
import { useTheme } from '@mui/material/styles';
import { BASE_URL, LAB_URL } from '../../const';

function Navbar() {
  const theme = useTheme();
  return (
    <nav style={{ backgroundColor: theme.palette.primary.main, padding: theme.spacing(1) }} className="navbar navbar-expand-lg">
      <div className="container-fluid">
        <NavLink style={{ color: theme.palette.primary.contrastText }} className="navbar-brand" to="/">Kamiwaza Dashboard</NavLink>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item"><NavLink style={{ color: theme.palette.primary.contrastText }} className="nav-link" to="/" end>Home</NavLink></li>
            <li className="nav-item"><a style={{ color: theme.palette.primary.contrastText }} className="nav-link" href={`${LAB_URL}/lab`} target="_blank" rel="noopener noreferrer">Notebooks</a></li>
            <li className="nav-item"><NavLink style={{ color: theme.palette.primary.contrastText }} className="nav-link" to="/models">Models</NavLink></li>
            <li className="nav-item"><NavLink style={{ color: theme.palette.primary.contrastText }} className="nav-link" to="/catalog">Catalog</NavLink></li>
            <li className="nav-item"><NavLink style={{ color: theme.palette.primary.contrastText }} className="nav-link" to="/activity">Activity</NavLink></li>
            <li className="nav-item"><NavLink style={{ color: theme.palette.primary.contrastText }} className="nav-link" to="/cluster/home">Clusters</NavLink></li>
            <li className="nav-item"><NavLink style={{ color: theme.palette.primary.contrastText }} className="nav-link" to="/vectordbs">VectorDBs</NavLink></li>
            <li className="nav-item"><a style={{ color: theme.palette.primary.contrastText }} className="nav-link" href={`${BASE_URL}/docs`} target="_blank" rel="noopener noreferrer">API Docs</a></li>
            {/* Add other nav items here */}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;