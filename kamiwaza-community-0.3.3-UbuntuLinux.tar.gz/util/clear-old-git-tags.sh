#!/bin/bash
set -e  # Exit on error
set -o pipefail  # Catch errors in pipelines

# Parse arguments
DRY_RUN=false
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--dry-run]"
            exit 1
            ;;
    esac
done

# Function to determine if a version is a release version (no -rc, -pl, etc.)
is_release_version() {
    local version=$1
    if [[ $version =~ ^v[0-9]+\.[0-9]+\.[0-9]+(\.[0-9]+)?$ ]]; then
        return 0  # true
    else
        return 1  # false
    fi
}

# Function to extract version numbers for comparison
version_to_compare() {
    # Remove leading 'v' and any suffixes after first non-version char
    echo "$1" | sed 's/^v//' | sed 's/[^0-9\.].*$//'
}

# Function to compare version strings, handling quad-dot versions
version_gt() {
    IFS='.' read -ra VER1 <<< "$1"
    IFS='.' read -ra VER2 <<< "$2"
    local length=$(( ${#VER1[@]} > ${#VER2[@]} ? ${#VER1[@]} : ${#VER2[@]} ))
    
    for ((i=0; i<length; i++)); do
        local v1=${VER1[i]:-0}  # Use 0 if index doesn't exist
        local v2=${VER2[i]:-0}
        if ((10#$v1 > 10#$v2)); then
            return 0  # true
        elif ((10#$v1 < 10#$v2)); then
            return 1  # false
        fi
    done
    return 1  # false if equal
}

# Get all tags starting with v
all_tags=$(git tag | grep "^v" | sort -V)

# Get the latest release version
latest_release=$(echo "$all_tags" | grep -E "^v[0-9]+\.[0-9]+\.[0-9]+(\.[0-9]+)?$" | sort -V | tail -n 1)
latest_version=$(version_to_compare "$latest_release")

if $DRY_RUN; then
    echo "DRY RUN - no changes will be made"
    echo "Latest release version: $latest_release"
    echo "These tags would be removed:"
fi

# Process each tag
for tag in $all_tags; do
    base_version=$(version_to_compare "$tag")
    
    # Skip processing if:
    # 1. It's a clean release version (v1.2.3 or v1.2.3.4)
    # 2. It's a higher version than our latest release (unreleased versions)
    if is_release_version "$tag"; then
        if ! $DRY_RUN; then
            echo "Keeping release tag: $tag"
        fi
        continue
    fi
    
    if version_gt "$base_version" "$latest_version"; then
        if ! $DRY_RUN; then
            echo "Keeping unreleased version tag: $tag"
        fi
        continue
    fi
    
    if $DRY_RUN; then
        echo "$tag"
    else
        echo "Removing old RC/pre-release tag: $tag"
        git tag -d "$tag"
        git push origin ":refs/tags/$tag"
    fi
done

if $DRY_RUN; then
    echo "DRY RUN complete - no changes were made"
else
    echo "Tag cleanup complete!"
fi