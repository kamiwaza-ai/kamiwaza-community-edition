#!/bin/bash

# Read commit from file or env var
LLAMA_COMMIT="${KAMIWAZA_LLAMA_COMMIT:-$(cat llamacpp.commit)}"

# Check if commit is empty
if [[ -z "${LLAMA_COMMIT}" ]]; then
    echo "Error: No commit specified in llamacpp.commit or KAMIWAZA_LLAMA_COMMIT"
    exit 1
fi

set -ex

mkdir -p llamacpp
cd llamacpp

# Function to build llama.cpp
build_llama() {
    local build_dir=$1
    cd "$build_dir"
    git fetch origin
    git checkout $LLAMA_COMMIT
    git branch -D kamiwaza || true
    git checkout -b kamiwaza
    cmake -B build && cmake --build build --config Release
    cd ..
}

# Check if we need to rebuild
if [ -d "llama.cpp" ]; then
    echo "Existing llama.cpp found. Rebuilding..."
    
    # Remove old build directory if it exists
    if [ -d "llama.cpp_new" ]; then
        rm -rf llama.cpp_new
    fi
    
    # Clone a new copy
    git clone https://github.com/ggerganov/llama.cpp.git llama.cpp_new
    
    # Set up and activate venv
    if [ ! -d "venv" ]; then
        python -m venv venv
    fi
    source venv/bin/activate
    
    # Build the new copy
    build_llama "llama.cpp_new"
    
    # Check if build was successful
    if [ -f "llama.cpp_new/llama-server" -o -f "llama.cpp_new/build/bin/llama-server" ]; then
        echo "Build successful. Replacing old version..."
        mv llama.cpp llama.cpp_old
        mv llama.cpp_new llama.cpp
        rm -rf llama.cpp_old
    else
        echo "Build failed. Keeping old version."
        rm -rf llama.cpp_new
    fi
else
    echo "No existing llama.cpp found. Performing fresh install..."
    git clone https://github.com/ggerganov/llama.cpp.git
    python -m venv venv
    source venv/bin/activate
    build_llama "llama.cpp"
fi

deactivate || true