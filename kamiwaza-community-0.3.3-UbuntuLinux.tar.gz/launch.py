import os
from kamiwaza.lib.util import get_kamiwaza_root

# TODO: investigate a better way to deal with python etcd3 lib being dated.
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'

import subprocess
import logging
import sys
from kamiwaza.util.config import RuntimeConfig
from kamiwaza.util.config import RuntimeClusterManager

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

KAMIWAZA_ROOT = get_kamiwaza_root()
os.environ["KAMIWAZA_ROOT"] = KAMIWAZA_ROOT
os.environ["KAMIWAZA_LAUNCH_HOST"] = "true"

# Check if PYTHONPATH contains a path element with 'kamiwaza' that does not match the current working directory
pythonpath = os.environ.get('PYTHONPATH', '')
cwd = os.getcwd()
parent_cwd = os.path.dirname(cwd) if cwd.endswith('kamiwaza') else None
allow_extra_kamiwaza_path = '--allow-extra-kamiwaza-path' in sys.argv

for path in pythonpath.split(os.pathsep):
    if 'kamiwaza' in path and not (path.startswith(cwd) or (parent_cwd and path.startswith(parent_cwd))):
        message = f"PYTHONPATH contains a path element with 'kamiwaza' that does not match the current working directory: {path}"
        if allow_extra_kamiwaza_path:
            print(f"Warning: {message}")
            logger.warning(f"Warning: {message}")
        else:
            print(f"Fatal error: {message}")
            logger.error(f"Fatal error: {message}")
            sys.exit(1)

if os.environ.get("KAMIWAZA_DEBUG_MODE", "False") == "True":
    logging.getLogger().setLevel(logging.DEBUG)

rc = RuntimeConfig()
rc.set_config('initialized', True)

# If we have updated the db config we will need that, otherwise,
# flush the cache. Should really only matter in development or
# upgrades
rcm = RuntimeClusterManager()
rcm.invalidate_config_cache(excluded_config_keys=['cluster'])

# Path to main.py
main_py_path = None
if os.path.exists(os.path.join(KAMIWAZA_ROOT, 'main.py')):
    main_py_path = os.path.join(KAMIWAZA_ROOT, 'main.py')
elif os.path.exists(os.path.join(KAMIWAZA_ROOT, 'kamiwaza', 'main.py')):
    main_py_path = os.path.join(KAMIWAZA_ROOT, 'kamiwaza', 'main.py')
else:
    logger.error("main.py not found in KAMIWAZA_ROOT or KAMIWAZA_ROOT/kamiwaza")
    raise FileNotFoundError("main.py not found in KAMIWAZA_ROOT or KAMIWAZA_ROOT/kamiwaza")

# Function to display help message
def show_help():
    print("Usage: launch.py [options]")
    print("")
    print("Options:")
    print("  -h, --help            Show this help message and exit")
    print("  --standalone          Run in standalone mode without clustering")
    print("  --ray-host=HOST       Specify the Ray head node host")
    print("  --ray-port=PORT       Specify the Ray head node port")
    print("     Note: if neither --standalone or -ray-host is passed, Kamiwaza starts ray with this node as the head node")
    print("  --allow-extra-kamiwaza-path")
    print("                        Developer only: Allow extra 'kamiwaza' path in PYTHONPATH")

# Check for the help flag
if '-h' in sys.argv or '--help' in sys.argv:
    show_help()
    sys.exit(0)

#  Develope the --standalone flag and other arguments in the command line
standalone_flag = '--standalone' if '--standalone' in sys.argv else ''
ray_host = next((arg for arg in sys.argv if arg.startswith('--ray-host=')), '')
ray_port = next((arg for arg in sys.argv if arg.startswith('--ray-port=')), '')

if os.path.exists(os.path.join(KAMIWAZA_ROOT, 'ray-is-worker')):
    if not ray_host:
        logger.critical("This node is not the Kamiwaza head node, but ray_host is not set; set KAMIWAZA_RAY_HOST (and if needed KAMIWAZA_RAY_PORT) in start! Exiting.")
        sys.exit(1)

# Call main.py using subprocess with the standalone flag and other arguments if present
env = os.environ.copy()
subprocess_args = ['python', main_py_path]
if standalone_flag:
    subprocess_args.append(standalone_flag)
if ray_host:
    subprocess_args.append(ray_host)
if ray_port:
    subprocess_args.append(ray_port)
try:
    subprocess.run(subprocess_args, check=True, env=env)
except subprocess.CalledProcessError as e:
    logger.error(f"Error occurred while running main.py: {str(e)}")
    raise
