import { createTheme } from '@mui/material/styles';

const baseSpacing = 8;

const theme = createTheme({
  palette: {
    primary: {
      main: '#4caf50',
      light: '#80e27e',
      dark: '#087f23',
      contrastText: '#fff',
    },
    secondary: {
      main: '#ff4081',
      light: '#ff79b0',
      dark: '#c60055',
      contrastText: '#000',
    },
    background: {
      default: '#f4f5f7',
      paper: '#fff',
    },
    text: {
      primary: '#333',
      secondary: '#555',
    },
    accent: {
      main: '#4caf50',
      light: '#80e27e',
      dark: '#087f23',
    },
    error: {
      main: '#f44336',
      light: '#e57373',
      dark: '#b71c1c', // Adjusted for better contrast and visibility, especially on hover states in UI components
      contrastText: '#fff',
    },
    warning: {
      main: '#ff9800',
      light: '#ffb74d',
      dark: '#f57c00',
      contrastText: '#fff',
    },
    info: {
      main: '#2196f3',
      light: '#64b5f6',
      dark: '#1976d2',
      contrastText: '#fff',
    },
    success: {
      main: '#4caf50',
      light: '#81c784',
      dark: '#388e3c',
      contrastText: '#fff',
    },
    divider: '#e0e0e0',
  },
  typography: {
    fontFamily: [
      '"Roboto"',
      '"Helvetica Neue"',
      '"Arial"',
      'sans-serif'
    ].join(','),
    h1: {
      fontSize: '3rem',
      fontWeight: 700,
      lineHeight: 1.2,
      marginTop: `${baseSpacing * 2}px ${baseSpacing * 2}px`,
      marginBottom: `${baseSpacing * 2}px ${baseSpacing * 2}px`,
      '@media (max-width:600px)': {
        fontSize: '2.2rem',
      },
    },
    h2: {
      fontSize: '2.5rem',
      fontWeight: 600,
      lineHeight: 1.3,
      marginTop: `${baseSpacing * 2}px ${baseSpacing * 2}px`,
      marginBottom: `${baseSpacing * 2}px ${baseSpacing * 2}px`,
      '@media (max-width:600px)': {
        fontSize: '2rem',
      },
    },
    h3: {
      fontSize: '2rem',
      fontWeight: 500,
      lineHeight: 1.4,
      marginTop: `${baseSpacing * 2}px ${baseSpacing * 2}px`,
      marginBottom: `${baseSpacing * 2}px ${baseSpacing * 2}px`,
      '@media (max-width:600px)': {
        fontSize: '1.75rem',
      },
    },
    body1: {
      fontSize: '1rem',
      fontWeight: 400,
      color: '#333',
      lineHeight: 1.4,
    },
    body2: {
      fontSize: '0.875rem',
      fontWeight: 400,
      color: '#555',
    },
    button: {
      textTransform: 'none',
      fontWeight: 500,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          padding: `${baseSpacing * 1.5}px ${baseSpacing * 2}px`,
          boxShadow: '0px 2px 4px -1px rgba(0,0,0,0.2)',
          marginLeft: `${baseSpacing * 1.5}px`,
          marginRight: `${baseSpacing * 1.5}px`,
          '&:hover': {
            boxShadow: '0px 4px 5px -2px rgba(0,0,0,0.4)',
          },
        },
      },
    },
    MuiTextField: {
        styleOverrides: {
            root: {
                margin: '8px' //equivalent to theme.spacing(1)
            }
        }
    },
    MuiCheckbox: {
      styleOverrides: {
        root: {
          color: '#4caf50',
          '&.Mui-checked': {
            color: '#4caf50',
          },
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          padding: '10px',
          '&:hover': {
            backgroundColor: 'rgba(0, 0, 0, 0.04)',
          },
        },
      },
    },
    MuiModal: {
      styleOverrides: {
        paper: {
          backgroundColor: '#fff',
          boxShadow: '0px 6px 10px -4px rgba(0,0,0,0.3)',
        },
      },
    },
    MuiCircularProgress: {
      styleOverrides: {
        root: {
          color: '#4caf50',
        },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: {
          backgroundColor: '#e8eaf6',
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: {
          '&:nth-of-type(odd)': {
            backgroundColor: '#f5f5f5',
          },
          '&:hover': {
            backgroundColor: '#e0e0e0',
          },
        },
      },
    },
    MuiTableBody: {
      styleOverrides: {
        root: {
          '& .MuiTableCell-body': {
            color: '#555',
          },
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        head: {
          fontWeight: 700,
        },
        body: {
          fontWeight: 400,
        },
        root: {
            padding: `${baseSpacing * 1.5}px ${baseSpacing * 2}px`, // For instance, theme.spacing(1.5, 2)
        },
      },
    },
    // Additional components can be styled here
  },
  spacing: baseSpacing,
});

export default theme;

