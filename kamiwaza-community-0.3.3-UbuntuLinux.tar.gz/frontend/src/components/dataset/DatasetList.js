import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { BASE_URL } from '../../const';
import DatasetDetails from './DatasetDetails';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import {
    StyledMainContent,
    StyledHeader,
    StyledTable,
    StyledTableHead,
    StyledTableCell,
    StyledTableRow,
    StyledTableBody
} from '../../StyledComponents';

const DatasetList = () => {
    const [datasets, setDatasets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchDatasets = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/catalog/dataset`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setDatasets(response.data);
                } else {
                    throw new Error(`Failed to fetch datasets from ${uri}`);
                }
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchDatasets();
    }, []);

    return (
        <StyledMainContent>
            <StyledHeader>Dataset List</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {datasets.length === 0 && !loading ? (
                <p>No datasets available.</p>
            ) : (
                <StyledTable>
                    <StyledTableHead>
                        <StyledTableRow>
                            <StyledTableCell>Platform</StyledTableCell>
                            <StyledTableCell>ID</StyledTableCell>
                            <StyledTableCell>Environment</StyledTableCell>
                        </StyledTableRow>
                    </StyledTableHead>
                    <StyledTableBody>
                        {datasets.map(dataset => (
                            <StyledTableRow key={dataset.id}>
                                <StyledTableCell>[{dataset.platform}]</StyledTableCell>
                                <StyledTableCell>
                                    <Link to={`/catalog/dataset/${dataset.urn}`}>{dataset.id}</Link>
                                </StyledTableCell>
                                <StyledTableCell>{dataset.environment}</StyledTableCell>
                            </StyledTableRow>
                        ))}
                    </StyledTableBody>
                </StyledTable>
            )}
        </StyledMainContent>
    );
};

export default DatasetList;
