import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { 
  StyledMainContent, 
  StyledHeader, 
  StyledParagraph, 
  StyledTable, 
  StyledTableHead, 
  StyledTableCell 
} from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';

function ActivityFeed() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    axios.get(`${BASE_URL}/activity/activities/`)
      .then(response => {
        setActivities(response.data);
        setLoading(false);
      })
      .catch(error => {
        setError(error.message);
        setLoading(false);
      });
  }, []);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    if (date.toDateString() === today.toDateString()) {
      return `Today ${date.toLocaleTimeString()}`;
    } else {
      return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
    }
  };

  return (
    <StyledMainContent className="crudcontainer">
      <StyledHeader>Recent Activities</StyledHeader>
      {loading && <Spinner />}
      {error && <ErrorComponent message={error} />}
      <StyledTable>
        <StyledTableHead>
          <tr>
            <StyledTableCell>Activity</StyledTableCell>
          </tr>
        </StyledTableHead>
        <tbody>
          {activities.map(activity => (
            <tr key={activity.id}>
              <StyledTableCell>
                <StyledParagraph>
                  {formatDate(activity.created_at)} <b>{activity.user_id}</b> {activity.action || `${activity.module} ${activity.apicall}`}
                </StyledParagraph>
              </StyledTableCell>
            </tr>
          ))}
        </tbody>
      </StyledTable>
    </StyledMainContent>
  );
}

export default ActivityFeed;
