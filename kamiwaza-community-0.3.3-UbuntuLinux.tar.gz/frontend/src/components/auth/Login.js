import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { StyledTextField, StyledButton, StyledMainContent } from '../../StyledComponents';
import { useTheme } from '@mui/material/styles';

const Login = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const { login, user } = useContext(AuthContext);
  const [error, setError] = useState(null);
  const theme = useTheme();
  const navigate = useNavigate();

  useEffect(() => {
    // If user is already logged in, redirect to home page
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const formData = new URLSearchParams();
      formData.append('username', credentials.username);
      formData.append('password', credentials.password);
      await login(formData);
      navigate('/');
    } catch (err) {
      if (err.message === 'Network Error') {
        setError('Service Unavailable. Please try again later.');
      } else if (err.response && err.response.status === 401) {
        setError('Invalid username or password');
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
    }
  };

  // If user is already logged in, don't render the form
  if (user) {
    return null;
  }

  return (
    <StyledMainContent style={{ padding: theme.spacing(3) }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <StyledTextField
          label="Username"
          name="username"
          value={credentials.username}
          onChange={handleChange}
          fullWidth
          margin="normal"
        />
        <StyledTextField
          label="Password"
          name="password"
          type="password"
          value={credentials.password}
          onChange={handleChange}
          fullWidth
          margin="normal"
        />
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <StyledButton type="submit" variant="contained" color="primary">
          Login
        </StyledButton>
      </form>
    </StyledMainContent>
  );
};

export default Login;
