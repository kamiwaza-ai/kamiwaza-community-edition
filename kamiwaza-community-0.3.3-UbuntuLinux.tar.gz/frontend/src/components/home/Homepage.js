import React, { useEffect, useState } from 'react';
import { useTheme } from '@mui/material/styles';
import DOMPurify from 'dompurify'; // You'll need to npm install dompurify
import api from '../../utils/api';

const Homepage = () => {
  const theme = useTheme();
  const [newsContent, setNewsContent] = useState(null);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await api.get('/api/news/latest', {
          headers: {
            'Accept': 'application/json'
          }
        });
        
        // Validate we have JSON data with a content field
        if (response?.data?.content) {
          // Sanitize the HTML content
          const clean = DOMPurify.sanitize(response.data.content, {
            FORBID_TAGS: ['script', 'iframe'],
            FORBID_ATTR: ['onerror', 'onload', 'onclick']
          });
          
          // Only set if we got clean content
          if (clean) {
            setNewsContent(clean);
          }
        }
      } catch (error) {
        // Silently handle any errors - content will remain as default
        console.debug('News content not available:', error);
      }
    };

    fetchNews();
  }, []); // Empty dependency array means this runs once on mount

  return (
    <div className="main-content" style={{
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.background.default,
      display: 'flex', // Use flexbox to create columns
      flexDirection: 'row', // Align children in a row
      justifyContent: 'space-between' // Space between the columns
    }}>
      <div style={{ flex: 1, marginRight: '1rem' }}> {/* Column 1 */}
        <h1 style={{ color: theme.palette.primary.main }}>Updates</h1>
        <h2>Latest Release</h2>
        <ul style={{ color: theme.palette.text.secondary }}>
          <li>vLLM 0.7.2 supporting DeepSeek v3/R1 improved performance, Qwen-2.5-VL models and much more</li>
          <li>Improvements to network handfor various systems</li>
        </ul>
      </div>
      <div style={{ flex: 1 }}> {/* Column 2 */}
        <h1 style={{ color: theme.palette.primary.main }}>Latest News</h1>
        <div style={{ color: theme.palette.text.secondary }}>
          {newsContent ? (
            <div dangerouslySetInnerHTML={{ __html: newsContent }} />
          ) : (
            <>
              <div>&nbsp;</div>
              <div>Join our Discord: <a href="https://discord.gg/cVGBS5rD2U">https://discord.gg/cVGBS5rD2U</a></div>
              <div>&nbsp;</div>
              <div>Check out our <b>new improved</b> website: <a href="https://www.kamiwaza.ai/community">https://www.kamiwaza.ai/community</a></div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Homepage;