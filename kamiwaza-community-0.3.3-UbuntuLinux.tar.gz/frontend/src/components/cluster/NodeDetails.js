import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton, StyledSubSection, StyledList, StyledListItem } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const NodeDetails = () => {
    const [nodeDetails, setNodeDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const { node_id } = useParams();

    useEffect(() => {
        const fetchNodeDetails = async () => {
            try {
                const uri = `${BASE_URL}/cluster/node/${node_id}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setNodeDetails(response.data);
                } else {
                    throw new Error(`Failed to fetch node details from ${uri}`);
                }
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchNodeDetails();
    }, [node_id]);

    if (loading) return <StyledParagraph>Loading...</StyledParagraph>;
    if (error) return <StyledParagraph>Error: {error.message}</StyledParagraph>;

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Clusters Home
            </StyledButton>
            <StyledHeader>Node Details</StyledHeader>
            {nodeDetails ? (
                <div className="node-details">
                    <h2 className="node-name">{nodeDetails.node.last_config?.name || 'N/A'}</h2>
                    <StyledSubSection>
                        <div className="subsection-title">General Information</div>
                        <StyledList>
                            <StyledListItem><strong>ID: </strong> {nodeDetails.node.id}</StyledListItem>
                            <StyledListItem><strong>State: </strong> {nodeDetails.node.active ? 'Active' : 'Inactive'}</StyledListItem>
                            <StyledListItem><strong>Last Seen: </strong> {nodeDetails.node.last_seen || 'N/A'}</StyledListItem>
                            <StyledListItem>
                                <strong>Location: </strong> 
                                {nodeDetails.location ? (
                                    <Link to={`/cluster/locations/${nodeDetails.location.id}`}>
                                        {nodeDetails.location.name}
                                    </Link>
                                ) : 'N/A'}
                            </StyledListItem>
                            <StyledListItem><strong>Ray ID: </strong> {nodeDetails.node.ray_id || 'N/A'}</StyledListItem>
                        </StyledList>
                    </StyledSubSection>
                    <StyledSubSection>
                        <div className="subsection-title">Location Details</div>
                        {nodeDetails.location ? (
                            <StyledList>
                                <StyledListItem><strong>Name: </strong> {nodeDetails.location.name}</StyledListItem>
                                <StyledListItem><strong>Datacenter: </strong> {nodeDetails.location.datacenter || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Region: </strong> {nodeDetails.location.region || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Zone: </strong> {nodeDetails.location.zone || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Building: </strong> {nodeDetails.location.building || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Address: </strong> {nodeDetails.location.address || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Contact Phone: </strong> {nodeDetails.location.contact_phone || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Contact Name: </strong> {nodeDetails.location.contact_name || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Contact Email: </strong> {nodeDetails.location.contact_email || 'N/A'}</StyledListItem>
                            </StyledList>
                        ) : (
                            <StyledParagraph>No location details available.</StyledParagraph>
                        )}
                    </StyledSubSection>
                    <StyledSubSection>
                        <div className="subsection-title">Hardware Details</div>
                        {nodeDetails.hardware ? (
                            <StyledList>
                                <StyledListItem><strong>Name: </strong> {nodeDetails.hardware.name}</StyledListItem>
                                <StyledListItem><strong>GPUs: </strong> {nodeDetails.hardware.gpus.join(', ') || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Cluster IP: </strong> {nodeDetails.hardware.cluster_ip}</StyledListItem>
                                <StyledListItem><strong>Processors: </strong> {nodeDetails.hardware.processors.join(', ') || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>OS: </strong> {nodeDetails.hardware.os}</StyledListItem>
                                <StyledListItem><strong>Platform: </strong> {nodeDetails.hardware.platform}</StyledListItem>
                                <StyledListItem><strong>Local Node ID: </strong> {nodeDetails.hardware.local_node_id}</StyledListItem>
                                <StyledListItem><strong>Configuration: </strong> {nodeDetails.hardware.configuration || 'N/A'}</StyledListItem>
                            </StyledList>
                        ) : (
                            <StyledParagraph>No hardware details available.</StyledParagraph>
                        )}
                    </StyledSubSection>
                    <StyledSubSection>
                        <div className="subsection-title">Last Configuration</div>
                        {nodeDetails.node.last_config ? (
                            <StyledList>
                                <StyledListItem><strong>Cluster IP: </strong> {nodeDetails.node.last_config.cluster_ip}</StyledListItem>
                                <StyledListItem><strong>Configuration: </strong> {nodeDetails.node.last_config.configuration || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>GPUs: </strong> {nodeDetails.node.last_config.gpus.join(', ') || 'N/A'}</StyledListItem>
                                <StyledListItem><strong>Local Node ID: </strong> {nodeDetails.node.last_config.local_node_id}</StyledListItem>
                                <StyledListItem><strong>OS: </strong> {nodeDetails.node.last_config.os}</StyledListItem>
                                <StyledListItem><strong>Platform: </strong> {nodeDetails.node.last_config.platform}</StyledListItem>
                                <StyledListItem><strong>Processors: </strong> {nodeDetails.node.last_config.processors.join(', ') || 'N/A'}</StyledListItem>
                            </StyledList>
                        ) : (
                            <StyledParagraph>No configuration details available.</StyledParagraph>
                        )}
                    </StyledSubSection>
                </div>
            ) : (
                <StyledParagraph>No node details available.</StyledParagraph>
            )}
        </StyledMainContent>
    );
};

export default NodeDetails;
