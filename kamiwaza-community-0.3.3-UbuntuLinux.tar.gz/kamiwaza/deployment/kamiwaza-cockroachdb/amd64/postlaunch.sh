#!/bin/bash

# Define your variables
DIRECTORY_TARGET="."                # By default we assume this will run in the deployment directory and certs will be there
CERTS_DIR="certs"                   # Directory containing your certs
HOST="localhost"                    # Host where CockroachDB is running
NEW_ROOT_PASSWORD="kamiwazaGetY0urCape"    # New password for the root user
POSTGRES_PASSWORD="kamiwazaGetY0urCape"    # Password for the postgres user

# Change to the CockroachDB directory
cd "$COCKROACH_DIR"

# Change root password
echo "ALTER USER root WITH PASSWORD '${NEW_ROOT_PASSWORD}';" | \
cockroach sql --certs-dir="$CERTS_DIR" --host="$HOST"

# Add postgres user and change password
echo "CREATE USER IF NOT EXISTS postgres; ALTER USER postgres WITH PASSWORD '${POSTGRES_PASSWORD}';" | \
cockroach sql --certs-dir="$CERTS_DIR" --host="$HOST"

# Grant permissions to postgres user
echo "GRANT ALL ON DATABASE postgres TO postgres; GRANT ALL ON ALL TABLES IN SCHEMA public TO postgres; ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO postgres;" | \
cockroach sql --certs-dir="$CERTS_DIR" --host="$HOST"

echo "Script execution completed."
