import os
from kamiwaza.services.lab.spawner import KamiwazaLabSpawner
from kamiwaza.services.lab.config import settings
from kamiwaza.lib.util import get_kamiwaza_root
from jupyterhub.app import get_config

# Get the config object
c = get_config()

# JupyterHub configuration
c.JupyterHub.hub_ip = '0.0.0.0'
c.JupyterHub.hub_port = 8000

# Use KamiwazaLabSpawner
c.JupyterHub.spawner_class = KamiwazaLabSpawner

# Configure KamiwazaLabSpawner
c.KamiwazaLabSpawner.persistent_storage_root = '/data/user-notebooks'
c.KamiwazaLabSpawner.use_kamiwaza_lab = True

# Set resource limits (adjust as needed)
c.KamiwazaLabSpawner.mem_limit = '2G'
c.KamiwazaLabSpawner.cpu_limit = 1.0

# No authentication for now (as per your requirement)
c.JupyterHub.authenticator_class = 'nullauthenticator.NullAuthenticator'

# Traefik configuration (assuming Traefik is handling SSL termination)
c.JupyterHub.ssl_cert = None
c.JupyterHub.ssl_key = None
c.JupyterHub.port = 8000
c.JupyterHub.bind_url = 'http://:8000'

# Use the database URL from settings
c.JupyterHub.db_url = settings.database_url