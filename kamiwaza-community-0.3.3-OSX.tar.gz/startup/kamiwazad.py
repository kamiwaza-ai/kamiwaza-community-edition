#!/usr/bin/env python3

"""
Improved Master Service Script (kamiwazad)

This script acts as the master service for controlling other services.
It is designed to be installed and managed via systemd/systemctl.

Features:
- Start, monitor, and restart services
- Kill orphan processes
- Log all activities
- Send alerts when critical issues occur
- Provide status updates for the services
- Track PIDs of subprocesses for reliable monitoring
- Graceful shutdown and restart mechanisms
- Monitor Docker containers and Ray service

Requirements:
- The script should start the necessary services in the correct order.
- It should monitor the services and restart them if they fail.
- It should check for and kill orphan processes.
- It should log all activities to a log file.
- It should send alerts when critical failures occur3V49F7.
- It should provide status updates for the services.
"""

import subprocess
import logging
import time
import os
import platform
import select
import signal
import sys
import json
import traceback
import venv 
import threading
from typing import Dict, List, Optional, Union, Tuple
import yaml
from dotenv import load_dotenv
import psutil
import argparse
from dataclasses import dataclass
from typing import Optional, Iterator, IO, Dict, Any
from enum import Enum
import subprocess
import select
import fcntl
import os
import errno
import time
import logging
from contextlib import contextmanager


# Load environment variables
print("loading env", file=sys.stderr)

load_dotenv()

# Get KAMIWAZA_ROOT from environment variable
print("set root", file=sys.stderr)
KAMIWAZA_ROOT = os.getenv('KAMIWAZA_ROOT')
os.chdir(KAMIWAZA_ROOT)
if not KAMIWAZA_ROOT:
    raise EnvironmentError("KAMIWAZA_ROOT environment variable is not set")

service_states = {} 

def is_worker_node() -> bool:
    """Determine if we are a worker node or not"""
    worker_status = os.getenv('KAMIWAZAD_IS_WORKER', '0')
    return worker_status != '0'

def get_pids_by_name(process_identifier: Union[str, List[str]], full_cmdline: bool = False) -> List[int]:
    """
    Get PIDs of processes matching the given identifier(s).
    
    Args:
        process_identifier: String or list of strings to match against process names/cmdlines
        full_cmdline: If True, match against full command line instead of just executable name
        
    Returns:
        List of matching PIDs
    """
    if isinstance(process_identifier, str):
        process_identifiers = [process_identifier]
    else:
        process_identifiers = process_identifier
        
    matching_pids = []
    
    # Get our own process hierarchy to avoid killing parents/ourselves
    current_pid = os.getpid()
    parent_pids = []
    try:
        # Build list of our parent process chain
        current = current_pid
        while current > 1:  # Avoid including init
            try:
                parent = psutil.Process(current).ppid()
                parent_pids.append(parent)
                current = parent
            except psutil.NoSuchProcess:
                break
    except Exception:
        logger.warning("Could not determine parent PIDs - proceeding with caution")
    
    safe_pids = set([current_pid] + parent_pids)
    
    try:
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                # Skip our process and all parent processes
                if proc.pid in safe_pids:
                    continue
                    
                # Get full command line if requested
                if full_cmdline:
                    try:
                        cmdline = ' '.join(proc.cmdline())
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                    proc_name = cmdline
                else:
                    proc_name = proc.name()
                
                # Check if process matches any of the identifiers
                for identifier in process_identifiers:
                    if identifier in proc_name:
                        matching_pids.append(proc.pid)
                        break
                        
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
                
        return matching_pids
        
    except Exception as e:
        logger.error(f"Error getting PIDs: {e}")
        return []

def expand_env_vars(value):
    """Expand environment variables in a string or dictionary."""
    if isinstance(value, str):
        # Handle shell-style variable expansion
        if value.startswith("${") and ":" in value and "}" in value:
            var_name = value[2:value.index(":")]
            modifier = value[value.index(":"):value.index("}")]
            default_value = value[value.index(":")+2:value.index("}")]
            
            env_value = os.getenv(var_name)
            if modifier == ":-":
                # Use default if var is unset or empty
                return default_value if not env_value else env_value
            elif modifier == ":+":
                # Use alternate value only if var is set and not empty
                return default_value if env_value else ""
        return os.path.expandvars(value)
    elif isinstance(value, dict):
        return {k: expand_env_vars(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [expand_env_vars(item) for item in value]
    return value

def setup_logging(log_directories: List[str], log_filename: str) -> str:
    """
    Set up logging by creating the log directory if it doesn't exist
    and return the path to the log file.
    """
    for log_dir in log_directories:
        try:
            if not os.path.exists(log_dir):
                os.makedirs(log_dir, exist_ok=True)
            
            log_file = os.path.join(log_dir, log_filename)
            
            # Test if the directory is writable
            with open(log_file, 'a') as f:
                f.write('')
            
            return log_file
        except (PermissionError, OSError):
            continue
    
    raise RuntimeError(f"Unable to create or write to any of the specified log directories for {log_filename}.")

# Load configuration
with open('startup/kamiwaza.yml', 'r', encoding='utf-8') as f:
    config = yaml.safe_load(f)

# Expand environment variables in the config
config = expand_env_vars(config)

# Set up logging
log_file = setup_logging(config['logging']['directories'], 'kamiwazad.log')

# Configure logging
logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,  # Changed from INFO to DEBUG
    format='%(asctime)s %(levelname)s %(message)s',
)
logger = logging.getLogger(__name__)

# Configuration parameters
KAMIWAZA_ENV = os.getenv('KAMIWAZA_ENV', 'default')
MONITOR_INTERVAL = 60  # in seconds
RESTART_DELAY = 5  # in seconds

def setup_process_logging(service_name: str) -> str:
    """Set up logging for a specific process."""
    log_filename = f'kamiwazad-{service_name}.log'
    return setup_logging(config['logging']['directories'], log_filename)

class CommandState(Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class RunningCommand:
    """
    Unified interface for both blocking and non-blocking command execution.
    Provides iterators for stdout/stderr regardless of execution mode.
    """
    pid: Optional[int]
    state: CommandState
    return_code: Optional[int] = None
    _process: Optional[subprocess.Popen] = None
    _stdout_iter: Optional[Iterator[str]] = None
    _stderr_iter: Optional[Iterator[str]] = None
    _stdin: Optional[IO] = None

    @property
    def stdout(self) -> Iterator[str]:
        """Returns an iterator over stdout lines."""
        if self._stdout_iter is None:
            return iter(())
        return self._stdout_iter

    @property
    def stderr(self) -> Iterator[str]:
        """Returns an iterator over stderr lines."""
        if self._stderr_iter is None:
            return iter(())
        return self._stderr_iter

def create_nonblocking_pipe_reader(pipe: IO, process: subprocess.Popen) -> Iterator[str]:
    """
    Creates a non-blocking pipe reader that yields lines as they become available.
    Handles both immediate and future data without blocking indefinitely.
    """
    if pipe is None:
        return
        
    # Set pipe to non-blocking mode
    flags = fcntl.fcntl(pipe, fcntl.F_GETFL)
    fcntl.fcntl(pipe, fcntl.F_SETFL, flags | os.O_NONBLOCK)
    
    buffer = ""
    
    while True:
        # Check if process has ended and pipe is empty
        if process.poll() is not None:
            if not select.select([pipe], [], [], 0)[0]:
                if buffer:
                    yield buffer
                break
                
        try:
            # Check for immediately available data
            ready, _, _ = select.select([pipe], [], [], 0)
            if ready:
                chunk = os.read(pipe.fileno(), 4096)
                if not chunk:  # EOF
                    if buffer:
                        yield buffer
                    break
                    
                buffer += chunk.decode('utf-8')
                while '\n' in buffer:
                    line, buffer = buffer.split('\n', 1)
                    yield line
        except (IOError, OSError) as e:
            if e.errno != errno.EAGAIN:
                logger.error(f"Pipe read error: {e}")
                raise
            time.sleep(0.01)  # Prevent tight loop when no data

def create_blocking_pipe_reader(output: str) -> Iterator[str]:
    """Creates an iterator over lines from a completed command's output."""
    yield from output.splitlines()

def run_command(
    command: Union[str, Dict[str, str]],
    cwd: Optional[str] = None,
    input: Optional[str] = None,
    log_file: Optional[str] = None,
    active_venv: Optional[str] = None,
    blocking: bool = True,
    env: Optional[Dict[str, str]] = None
) -> RunningCommand:
    """
    Unified command runner that handles both blocking and non-blocking cases.
    
    Args:
        command: The command to run
        cwd: Working directory for the command
        input: Optional input to pass to the command
        log_file: Optional file to redirect stdout to
        active_venv: Optional path to virtual environment activate script
        blocking: Whether to run in blocking mode
        env: Optional environment variables
        
    Returns:
        RunningCommand object with access to process state and output
    """
    # Handle dict command by checking environment
    if isinstance(command, dict):
        # Check if we're in development by looking for kamiwaza-shibboleth file
        is_dev = os.path.exists('kamiwaza-shibboleth')
        env_type = 'development' if is_dev else 'production'
        command = command[env_type]

    logger.debug(f"Running command: {command} (blocking={blocking})")

    if active_venv:
        command = f"source {active_venv} && {command}"
    
    try:
        if blocking:
            # For blocking commands, use subprocess.run
            result = subprocess.run(
                command,
                shell=True,
                executable='/bin/bash',
                cwd=cwd,
                input=input,
                capture_output=True,
                text=True,
                env=env
            )
            
            # If a log file is specified, write the output
            if log_file:
                with open(log_file, 'a', encoding='utf-8') as f:
                    if result.stdout:
                        f.write(result.stdout)
                    if result.stderr:
                        f.write(result.stderr)
            
            return RunningCommand(
                pid=None,  # Process already completed
                state=CommandState.COMPLETED if result.returncode == 0 else CommandState.FAILED,
                return_code=result.returncode,
                _stdout_iter=create_blocking_pipe_reader(result.stdout),
                _stderr_iter=create_blocking_pipe_reader(result.stderr)
            )
        else:
            # Modified non-blocking setup
            process = subprocess.Popen(
                command,
                shell=True,
                executable='/bin/bash',
                cwd=cwd,
                stdin=subprocess.PIPE if input else None,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=False,  # Changed to False for unbuffered output
                bufsize=0,   # Disable buffering
                env=env
            )
            
            if input and process.stdin:
                process.stdin.write(input.encode('utf-8'))
                process.stdin.flush()
            
            # Modified tee_output function
            if log_file:
                def tee_output():
                    with open(log_file, 'ab') as f:  # Open in binary mode
                        while process.poll() is None:  # Check if process is still running
                            # Read from stdout
                            if process.stdout:
                                ready, _, _ = select.select([process.stdout], [], [], 0.1)
                                if ready:
                                    data = os.read(process.stdout.fileno(), 4096)
                                    if data:
                                        f.write(data)
                                        f.flush()
                            
                            # Read from stderr
                            if process.stderr:
                                ready, _, _ = select.select([process.stderr], [], [], 0.1)
                                if ready:
                                    data = os.read(process.stderr.fileno(), 4096)
                                    if data:
                                        f.write(data)
                                        f.flush()
                        
                        # Drain any remaining output after process ends
                        for pipe in [process.stdout, process.stderr]:
                            if pipe:
                                data = pipe.read()
                                if data:
                                    f.write(data)
                                    f.flush()
                
                threading.Thread(target=tee_output, daemon=True).start()
            
            return RunningCommand(
                pid=process.pid,
                state=CommandState.RUNNING,
                _process=process,
                _stdout_iter=create_nonblocking_pipe_reader(process.stdout, process),
                _stderr_iter=create_nonblocking_pipe_reader(process.stderr, process),
                _stdin=process.stdin
            )
            
    except Exception as e:
        logger.error(f"Command execution failed: {str(e)}")
        return RunningCommand(
            pid=None,
            state=CommandState.FAILED,
            return_code=-1,
            _stdout_iter=create_blocking_pipe_reader(""),
            _stderr_iter=create_blocking_pipe_reader(str(e))
        )


def check_docker_status() -> str:
    """Check the status of Docker containers."""
    try:
        # Match shell-style variable expansion
        head_ip = os.getenv('KAMIWAZA_HEAD_IP')
        is_worker = is_worker_node()
        
        # Select the appropriate config based on node type
        if is_worker:
            docker_config = config['services']['containers-worker']
            logger.debug("Using containers-worker configuration")
        else:
            docker_config = config['services']['containers']
            logger.debug("Using containers configuration")
            
        working_dir = docker_config['working_directory']
        
        logger.info("Checking Docker container status...")
        logger.debug(f"Running command: {docker_config['startup_check']['command']}")
        result = run_command(docker_config['startup_check']['command'], cwd=working_dir, env=os.environ.copy())
        
        # Add detailed debug output for the command result
        logger.debug("Docker command output:")
        logger.debug(f"  stdout: {result.stdout}")
        logger.debug(f"  stderr: {result.stderr}")
        logger.debug(f"  return_code: {result.return_code}")
        
        if result.state == CommandState.FAILED:
            logger.error(f"Docker compose command failed with code {result.return_code}")
            return 'error'

        # Collect all stdout lines into a single string
        stdout = '\n'.join(result.stdout)
        if not stdout:
            logger.error("No output from docker compose ls command")
            return 'error'

        try:
            containers = json.loads(stdout)
            logger.debug(f"Parsed container status: {json.dumps(containers, indent=2)}")
        except json.JSONDecodeError:
            logger.error("Failed to parse container status JSON")
            return 'error'

        logger.info("Running container validation...")
        logger.debug(f"Running validation command: {docker_config['startup_check']['validation']}")
        validation_result = run_command(
            docker_config['startup_check']['validation'], 
            cwd=working_dir,
            input=stdout,
            env=os.environ.copy()
        )
        
        # Add detailed debug output for validation
        logger.debug("Validation command output:")
        logger.debug(f"  stdout: {list(validation_result.stdout)}")  # Convert generator to list
        logger.debug(f"  stderr: {list(validation_result.stderr)}")  # Convert generator to list
        logger.debug(f"  return_code: {validation_result.return_code}")
        
        if validation_result.state == CommandState.COMPLETED:
            logger.info("All containers are in expected state")
            return 'running'
        else:
            logger.warning("Containers not in expected state")
            stderr_output = '\n'.join(list(validation_result.stderr))  # Convert generator to list
            if stderr_output:
                logger.warning(f"Validation error: {stderr_output}")
            return 'error'

    except Exception as e:
        logger.error(f"Error checking docker status: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        return 'error'

def is_service_enabled(service_config: dict) -> bool:
    """
    Evaluate if a service is enabled. Handles:
    - boolean values (True/False)
    - string values ("true"/"false")
    - shell commands that return 0/1
    - environment variable references
    """
    enabled = service_config.get('enabled', True)
    
    # Handle boolean values
    if isinstance(enabled, bool):
        return enabled
        
    # Handle string values
    if isinstance(enabled, str):
        # Check for literal true/false
        if enabled.lower() == 'true':
            return True
        if enabled.lower() == 'false':
            return False
            
        # If it starts with $, treat as environment variable
        if enabled.startswith('$'):
            var_name = enabled.lstrip('${}')
            return os.environ.get(var_name, '').lower() == 'true'
            
        # Otherwise treat as command to evaluate
        try:
            result = run_command(enabled, blocking=True, env=os.environ.copy())
            return result.return_code == 0
        except Exception as e:
            logger.error(f"Error evaluating enabled command: {e}")
            return False
            
    return bool(enabled)

def check_service_startup(service_name: str, service_config: Dict) -> bool:
    """Check if a service has started correctly using its startup check."""
    if 'startup_check' not in service_config:
        logger.debug(f"No startup check defined for {service_name}")
        return True

    try:
        check_cmd = service_config['startup_check']['command']
        logger.debug(f"Running startup check command for {service_name}: {check_cmd}")
        
        check_result = run_command(
            check_cmd,
            cwd=service_config.get('working_directory'),
            active_venv=service_config.get('venv'),
            blocking=True
        )

        # Collect all output first
        output_lines = list(check_result.stdout)
        raw_output = '\n'.join(output_lines)

        # Debug logging
        if service_config.get('debug', False):
            logger.debug(f"{service_name} check command output:")
            for line in output_lines:
                logger.debug(f"  stdout: {line.rstrip()}")
            for line in check_result.stderr:
                logger.debug(f"  stderr: {line.rstrip()}")

        if check_result.state != CommandState.COMPLETED:
            logger.error(f"Startup check command failed for {service_name}")
            return False

        if 'validation' in service_config['startup_check']:
            validation_script = service_config['startup_check']['validation']
            logger.debug(f"Running validation script for {service_name}")
            
            validation_result = run_command(
                validation_script,
                input=raw_output,
                cwd=service_config.get('working_directory'),
                active_venv=service_config.get('venv'),
                blocking=True,
                env=os.environ.copy()
            )

            if validation_result.return_code == 0:
                logger.info(f"Service {service_name} startup verified successfully")
                return True
            elif any(msg in line.lower() for line in validation_result.stderr for msg in ["not-applicable", "disabled"]):
                return True                                                                   # Add this line
            else:
                logger.error(f"{service_name} startup verification failed")
                return False

        return True

    except Exception as e:
        logger.error(f"Error checking {service_name} startup: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        return False



def is_service_ready(service_name: str) -> bool:
    """Check if a service is ready using its process check command."""
    service_config = config['services'][service_name]
    
    # Check if service is enabled
    if not is_service_enabled(service_config):
        logger.debug(f"Service {service_name} is disabled, skipping readiness check")
        return True
    
    # For containers, use the startup check directly
    if service_name == 'containers':
        return check_service_startup(service_name, service_config)
    
    # For other services...
    if 'process_check' not in service_config:
        return True

    try:
        check_cmd = service_config['process_check']
        result = run_command(
            check_cmd,
            cwd=service_config.get('working_directory'),
            active_venv=service_config.get('venv'),
            blocking=True,
            env=os.environ.copy()
        )
        return result.return_code == 0
    except Exception as e:
        logger.error(f"Error checking {service_name} readiness: {e}")
        return False




def start_services() -> None:
    """Start the required services in the defined order."""
    logger.info("Starting services...")
    try:
        for service_name in config['startup_order']:
            logger.info(f"Processing service {service_name} based on startup order")
            service_config = config['services'][service_name]
            
            # Use is_service_enabled consistently
            if not is_service_enabled(service_config):
                logger.info(f"Skipping disabled service: {service_name}")
                continue
            
            # Check dependencies using service_states
            if 'dependencies' in service_config:
                for dep in service_config['dependencies']:
                    while not is_service_ready(dep):
                        logger.info(f"Waiting for dependency {dep} to be ready before starting {service_name}")
                        time.sleep(5)

            # Check if service is already running if check_first is enabled
            if service_config.get('check_first', False):
                logger.info(f"Checking if {service_name} is already running")
                if check_service_startup(service_name, service_config):
                    status = check_service_status(service_name, service_config)
                    if status == 'running':
                        logger.info(f"{service_name} is already running, skipping start")
                        service_states[service_name] = 'running'
                        continue
                    logger.info(f"{service_name} check failed ({status}), will attempt to start")

            # Proceed with normal service start
            max_attempts = service_config.get('max_startup_attempts', 1)
            for attempt in range(max_attempts):
                logger.info(f"Starting {service_name} (attempt {attempt + 1}/{max_attempts})")
                
                if start_service(service_config, service_name):
                    logger.info(f"{service_name} started successfully")
                    service_states[service_name] = 'running'
                    break
                
                if attempt < max_attempts - 1:
                    logger.warning(f"{service_name} startup attempt {attempt + 1} failed, retrying...")
                    time.sleep(service_config.get('startup_check_interval', 5))
            else:
                service_states[service_name] = 'stopped'
                raise RuntimeError(f"Failed to start {service_name} after {max_attempts} attempts")

    except Exception as e:
        logger.error(f"Failed to start services: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        send_alert(f"Failed to start services: {str(e)}")
        sys.exit(1)

def stop_service(service_name: str, is_shutdown: bool = False) -> bool:
    """
    Stop a service based on its configuration.
    Returns True if service was successfully stopped or wasn't running,
    False if there was an error stopping a running service.
    """
    if service_name not in config['services']:
        logger.warning(f"Unknown service: {service_name}")
        return True
    
    service_config = config['services'][service_name]
    success = True
    debug = service_config.get('debug', False)
    
    try:
        if debug:
            logger.debug(f"Stopping {service_name}")
            
        # If we have a stop_command, use that
        if 'stop_command' in service_config:
            cmd = service_config['stop_command']
            if debug:
                logger.debug(f"Running stop command: {cmd}")
                
            result = run_command(
                cmd,
                cwd=service_config.get('working_directory'),
                active_venv=service_config.get('venv'),
                blocking=True,
                env=os.environ.copy()
            )
            
            if result.state != CommandState.COMPLETED:
                logger.error(f"Stop command for {service_name} failed")
                success = False
                
        # Handle stop_process entries (legacy support)
        elif 'stop_process' in service_config:
            logger.warning(f"Service {service_name} using deprecated stop_process configuration")
            process_identifiers = service_config['stop_process']
            if isinstance(process_identifiers, str):
                process_identifiers = [process_identifiers]
                
            if debug:
                logger.debug(f"Stopping processes matching: {process_identifiers}")
                
            # First try exact matches
            pids = get_pids_by_name(process_identifiers)
            
            # If no matches found, try matching against full command lines
            if not pids:
                pids = get_pids_by_name(process_identifiers, full_cmdline=True)
                
            if pids:
                for pid in pids:
                    if debug:
                        logger.debug(f"Killing PID {pid}")
                    if not kill_process(pid, service_name):
                        success = False
            elif debug:
                logger.debug(f"No matching processes found")
                
    except Exception as e:
        logger.error(f"Error stopping {service_name}: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        success = False
        
    finally:
        if is_shutdown:
            service_states[service_name] = 'stopped'
            
    return success

def stop_all_services(is_shutdown: bool = False) -> bool:
    """
    Stop all services in reverse startup order.
    Returns True if all stop attempts completed without errors.
    """
    all_success = True
    results = []
    
    for service_name in reversed(config['startup_order']):
        if service_name in config['services'] and config['services'][service_name]['enabled']:
            logger.info(f"Processing stop for {service_name}")
            
            # Get current status for logging but don't use it to skip stops
            status = check_service_status(service_name, config['services'][service_name])
            logger.info(f"Current status of {service_name}: {status}")
            
            # Always attempt to stop, even if status check says not running
            if service_name == 'containers':
                # Special handling for containers - always run stop command
                success = stop_service(service_name, is_shutdown)
                results.append(f"{service_name}: {'stopped' if success else 'failed to stop'}")
            else:
                # For other services, still try to stop but report status appropriately
                if status != 'running':
                    results.append(f"{service_name}: not running")
                    continue
                    
                if not stop_service(service_name, is_shutdown):
                    all_success = False
                    results.append(f"{service_name}: failed to stop")
                else:
                    results.append(f"{service_name}: stopped")
    
    print()  # Add blank line for readability
    for result in results:
        print(result)
    print()
    
    return all_success

def check_service_status(service_name: str, service_config: Dict) -> str:
    """Check the status of a service."""
    try:
        debug = service_config.get('debug', False)
        logger.info(f"Debug mode for {service_name}: {debug}")
        
        # Special handling for container services
        if service_name in ['containers', 'containers-worker']:
            # Determine if we're on a worker node
            is_worker = is_worker_node()
            
            # Skip if this is the wrong service type for this node
            if (service_name == 'containers' and is_worker) or \
               (service_name == 'containers-worker' and not is_worker):
                return 'not-applicable'
                
            return check_docker_status()
        
        # For other services, use the process_check command if available
        if 'process_check' in service_config:
            try:
                if debug:
                    logger.info(f"Running process check command: {service_config['process_check']}")
                active_venv = service_config.get('venv')
                result = run_command(
                    service_config['process_check'], 
                    active_venv=active_venv,
                    env=os.environ.copy()
                )
                
                if debug:
                    logger.info("=== Process Check Output ===")
                    logger.info(f"Return code: {result.return_code}")
                    logger.info("STDOUT:")
                    stdout_lines = list(result.stdout)
                    for line in stdout_lines:
                        logger.info(f"  {line.rstrip()}")
                    logger.info("STDERR:")
                    stderr_lines = list(result.stderr)
                    for line in stderr_lines:
                        logger.info(f"  {line.rstrip()}")
                    logger.info("=== End Process Check Output ===")
                
                if result.state == CommandState.COMPLETED:
                    if debug:
                        logger.info(f"Process check for {service_name} succeeded")
                    return 'running'
                else:
                    if debug:
                        logger.info(f"Process check for {service_name} failed with code {result.return_code}")
                    return 'stopped'
                
            except Exception as e:
                logger.error(f"Error running process check for {service_name}: {e}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                return 'error'
        
        logger.debug(f"No process check found for service {service_name}")
        return 'not-applicable'
        
    except Exception as e:
        logger.error(f"Error checking status for {service_name}: {e}")
        return 'error'

        
        

def start_service(service_config: Dict, service_name: str) -> bool:
    """Start a service and return whether it started successfully."""
    try:
        script = service_config['script']
        target_os = service_config.get('platform', 'none').lower()
        os_type = platform.system().lower()
        if target_os != os_type and target_os != 'none':
            logger.info(f"Skipping {service_name} on {os_type} as it's configured for {target_os}")
            return True
        should_block = service_config.get('process_block', True)
        
        # Get and verify working directory
        if 'working_directory' not in service_config:
            raise ValueError(f"Working directory not specified for service {service_name}")
        
        cwd = os.path.expandvars(service_config['working_directory'])
        if not os.path.isabs(cwd):
            cwd = os.path.join(config['base_directory'], cwd)
        
        if not os.path.isdir(cwd):
            raise FileNotFoundError(f"Working directory for {service_name} does not exist: {cwd}")

        # Get the script command
        if isinstance(script, dict):
            is_dev = os.path.exists('kamiwaza-shibboleth')
            env_type = 'development' if is_dev else 'production'
            if env_type not in script:
                raise ValueError(f"No script specified for environment type '{env_type}' in service {service_name}")
            script = script[env_type]

        # Handle any arguments specified in config
        # Store original script before appending args
        original_script = script

        if 'args' in service_config:
            args = service_config['args']
            if isinstance(args, list):
                script = f"{script} {' '.join(args)}"
            else:
                script = f"{script} {args}"

        # Handle active_venv for Python commands
        if script.startswith('python'):
            venv_path = os.path.join(KAMIWAZA_ROOT, 'venv')
            venv_python = get_venv_python(venv_path)
            script = script.replace('python', venv_python, 1)
        elif original_script.endswith('.sh') and not original_script.startswith('bash'):
            script = f"bash {original_script}"
            if 'args' in service_config:
                args = service_config['args']
                if isinstance(args, list):
                    script = f"{script} {' '.join(args)}"
                else:
                    script = f"{script} {args}"

        # Run any pre-start commands if configured
        if 'pre_start' in service_config:
            logger.info(f"Running pre-start commands for {service_name}")
            for pre_command in service_config['pre_start']:
                pre_result = run_command(pre_command, cwd=cwd)
                if pre_result.state != CommandState.COMPLETED:
                    raise RuntimeError(f"Pre-start command failed: {pre_command}")
        
        # Start the main service
        logger.info(f"Starting {service_name} with command: {script} in {cwd}")
        log_file = setup_process_logging(service_name)
        
        result = run_command(script, cwd=cwd, log_file=log_file, blocking=should_block, env=os.environ.copy())
        
        # For non-continuous services, wait for completion
        if should_block:
            if result.state != CommandState.COMPLETED:
                logger.error(f"{service_name} failed to complete successfully")
                return False
            
            # Give a moment for things to settle
            logger.info(f"Service {service_name} completed, waiting 5s before status check")
            time.sleep(5)
            
            # Verify the service started correctly
            if is_service_ready(service_name):
                logger.info(f"Service {service_name} startup verified successfully")
                return True
            else:
                logger.error(f"{service_name} startup verification failed")
                return False

        return True  # For continuous services, just return True if we got here

    except Exception as e:
        logger.error(f"Error starting {service_name}: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        return False

# Function to send alerts
def send_alert(message: str) -> None:
    """
    Send alerts.

    Parameters:
    - message (str): The alert message to send.

    This function should be implemented to send alerts
    via email, SMS, or other methods as needed.
    """
    # TODO: Implement the alert sending mechanism
    logger.info(f"Alert: {message}")
    # For example, send an email or push notification
    pass

def get_venv_python(venv_path: str) -> str:
    """Get the Python executable path from the virtual environment."""
    env_builder = venv.EnvBuilder(with_pip=True)
    env_context = env_builder.ensure_directories(venv_path)
    return env_context.env_exe

def is_process_running(pid: int) -> bool:
    """
    Check if a process with the given PID is running.

    Parameters:
    - pid (int): The PID to check.

    Returns:
    - bool: True if the process is running, False otherwise.
    """
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    else:
        return True

def monitor_service(service_name: str, service_config: Dict) -> None:
    """Monitor a single service and restart it if necessary."""
    return
    if 'process_check' in service_config:
        try:
            # Process checks should always be blocking
            result = run_command(service_config['process_check'])
            if result.state == CommandState.COMPLETED:
                logger.debug(f"{service_name} is running correctly")
            else:
                logger.warning(f"{service_name} process check failed. Restarting...")
                stop_service(service_name)
                start_service(service_config, service_name)
        except Exception as e:
            logger.error(f"Error checking {service_name}: {e}")
            stop_service(service_name)
            start_service(service_config, service_name)
    else:
        logger.warning(f"{service_name} is not running. Restarting...")
        start_service(service_config, service_name)

def monitor_docker_containers() -> None:
    """Monitor Docker containers based on YAML configuration."""
    logger.info("Checking Docker containers...")
    try:
        docker_config = config['services']['containers']
        result = run_command(docker_config['startup_check']['command'])
        
        if result.state == CommandState.FAILED:
            logger.warning("Docker container check failed")
            stderr_output = '\n'.join(result.stderr)
            if stderr_output:
                logger.warning(f"Docker check error: {stderr_output}")
            return
            
        stdout = '\n'.join(result.stdout)
        if not stdout:
            logger.warning("No output from docker container check")
            return
            
        validation_result = run_command(
            docker_config['startup_check']['validation'],
            input=stdout
        )
        
        if validation_result.state != CommandState.COMPLETED:
            logger.warning("Docker containers are not in the expected state. Restarting...")
            restart_result = run_command(docker_config['script'])
            if restart_result.state != CommandState.COMPLETED:
                logger.error("Failed to restart Docker containers")
                stderr_output = '\n'.join(restart_result.stderr)
                if stderr_output:
                    logger.error(f"Restart error: {stderr_output}")
            else:
                logger.info("Docker containers restarted successfully")
        else:
            logger.debug("Docker containers are in the expected state")
            
    except Exception as e:
        logger.error(f"Error while monitoring Docker containers: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        send_alert(f"Error while monitoring Docker containers: {e}")

def kill_process(pid: int, process_name: str, timeout: int = 10) -> bool:
    """
    Kill a process with escalating force.
    
    Args:
        pid: Process ID to kill
        process_name: Name for logging
        timeout: How long to wait for SIGTERM before using SIGKILL
        
    Returns:
        bool: True if process was killed, False if it couldn't be killed
    """
    try:
        # First try SIGTERM
        logger.info(f"Sending SIGTERM to {process_name} (PID: {pid})")
        os.kill(pid, signal.SIGTERM)
        
        # Wait for the process to terminate
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                # Check if process is still running
                os.kill(pid, 0)
                time.sleep(1.5)
            except ProcessLookupError:
                logger.info(f"{process_name} (PID: {pid}) terminated gracefully")
                return True
                
        # Process didn't terminate, use SIGKILL
        logger.warning(f"{process_name} (PID: {pid}) didn't respond to SIGTERM after {timeout}s, using SIGKILL")
        os.kill(pid, signal.SIGKILL)
        
        # Verify process is gone
        time.sleep(1.5)
        try:
            os.kill(pid, 0)
            logger.error(f"Failed to kill {process_name} (PID: {pid}) even with SIGKILL")
            return False
        except ProcessLookupError:
            logger.info(f"{process_name} (PID: {pid}) terminated with SIGKILL")
            return True
            
    except ProcessLookupError:
        logger.debug(f"{process_name} (PID: {pid}) was already terminated")
        return True
    except Exception as e:
        logger.error(f"Error killing {process_name} (PID: {pid}): {e}")
        return False

def kill_orphans() -> None:
    """Kill orphan processes based on YAML configuration."""
    logger.info("Checking for orphan processes...")
    try:
        for process_config in config['orphan_processes']['processes']:
            process_identifiers = process_config['name']
            if isinstance(process_identifiers, str):
                process_identifiers = [process_identifiers]
                
            for identifier in process_identifiers:
                # Try exact match first
                pids = get_pids_by_name(identifier)
                
                # If no matches, try full command line
                if not pids:
                    pids = get_pids_by_name(identifier, full_cmdline=True)
                
                killed_count = 0
                failed_count = 0
                
                if not pids:
                    logger.debug(f"No orphan processes found for {identifier}")
                    continue
                    
                logger.info(f"Found {len(pids)} orphan process(es) for {identifier}")
                
                for pid in pids:
                    if kill_process(pid, f"{identifier} orphan"):
                        killed_count += 1
                    else:
                        failed_count += 1
                
                if killed_count:
                    logger.info(f"Successfully killed {killed_count} orphan {identifier} process(es)")
                if failed_count:
                    logger.error(f"Failed to kill {failed_count} orphan {identifier} process(es)")
                    send_alert(f"Failed to kill {failed_count} orphan {identifier} process(es)")
                    
    except Exception as e:
        logger.error(f"Error while killing orphans: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        send_alert(f"Error while killing orphans: {e}")

def monitor_services():
    while True:
        for service_name, service_config in config['services'].items():
            if service_config['enabled']:
                monitor_service(service_name, service_config)
        
        #no
        #monitor_docker_containers()
        #no
        #kill_orphans()
        
        time.sleep(config['monitoring']['interval'])

def get_service_status() -> Dict[str, str]:
    """Get the status of all services."""
    logger.info("Getting service status...")
    services_status: Dict[str, str] = {}
    try:
        # Check actual container status first
        docker_status = check_docker_status()

        # Determine if we're on a head or worker node
        is_worker = is_worker_node()
        
        # Then process all services
        for service_name, service_config in config['services'].items():
            # Skip the container service that doesn't apply to this node type
            if service_name == 'containers' and is_worker:
                services_status[service_name] = 'not-applicable'
                continue
            if service_name == 'containers-worker' and not is_worker:
                services_status[service_name] = 'not-applicable'
                continue

            if not service_config['enabled']:
                services_status[service_name] = 'disabled'
                continue

            # Handle the appropriate container service
            if service_name in ['containers', 'containers-worker']:
                services_status[service_name] = docker_status
                continue

            status = check_service_status(service_name, service_config)
            services_status[service_name] = status

    except Exception as e:
        logger.error(f"Error getting service status: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        send_alert(f"Error getting service status: {e}")

    return services_status

def print_kamiwazad_status():
    """Print the status of kamiwazad and all managed services."""
    services_status = get_service_status()
    print("Service statuses:")
    for service, status in services_status.items():
        print(f"  {service}: {status}")

def handle_sigterm(signum, frame):
    """
    Handle SIGTERM signal for graceful shutdown.
    """
    logger.info("Received SIGTERM signal. Shutting down services...")
    stop_all_services(is_shutdown=True)
    sys.exit(0)

def handle_sighup(signum, frame):
    """
    Handle SIGHUP signal for configuration reload.
    """
    logger.info("Received SIGHUP signal. Reloading configuration...")
    try:
        # Reload the configuration
        global config
        with open('startup/kamiwaza.yml', 'r', encoding='utf-8') as f:
            new_config = yaml.safe_load(f)
            
        # Expand environment variables in the new config
        new_config = expand_env_vars(new_config)
        
        # Update the global config
        config = new_config
        
        logger.info("Configuration reloaded successfully")
        
        # Optionally restart services that have configuration changes
        # This could be implemented later if needed
        
    except Exception as e:
        logger.error(f"Error reloading configuration: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        send_alert(f"Error reloading configuration: {e}")

def start_kamiwazad():
    """Start the kamiwazad service."""
    logger.info("Starting kamiwazad...")
    
    # Change to the base directory
    os.chdir(config['base_directory'])
    
    # Handle SIGTERM for graceful shutdown
    signal.signal(signal.SIGTERM, handle_sigterm)

    # Start the services
    start_services()

    # Run the orphan killer once at startup
    kill_orphans()

    # Start the monitoring in a separate thread
    monitor_thread = threading.Thread(target=monitor_services, daemon=True)
    monitor_thread.start()

    # Keep the main thread alive
    while True:
        time.sleep(1)

def stop_kamiwazad():
    """Stop the kamiwazad service and all managed services."""
    logger.info("Stopping kamiwazad and all managed services...")
    print("Attempting to stop services...")
    try:
        with open('startup/kamiwaza.yml', 'r', encoding='utf-8') as f:
            current_config = yaml.safe_load(f)
            current_config = expand_env_vars(current_config)
            
        global config
        config = current_config
        
        success = stop_all_services(is_shutdown=True)
        if not success:
            print("\nWarning: Some services may not have stopped cleanly")
        else:
            print("\nAll services stopped successfully")
                
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        print(f"Error during shutdown: {e}")
    finally:
        logger.info("Stop operation completed")
        print("Stop operation completed")

def start_missing_services() -> None:
    """Start only services that are currently not running."""
    logger.info("Checking for missing services...")
    try:
        current_status = get_service_status()
        
        for service_name in config['startup_order']:
            service_config = config['services'][service_name]
            
            # Skip if service is disabled or not applicable
            if not is_service_enabled(service_config):
                continue
                
            status = current_status.get(service_name)
            if status in ['stopped', 'error']:
                logger.info(f"Attempting to start {service_name} (current status: {status})")
                
                # Check dependencies first
                if 'dependencies' in service_config:
                    for dep in service_config['dependencies']:
                        dep_status = current_status.get(dep)
                        if dep_status in ['stopped', 'error']:
                            logger.info(f"Starting dependency {dep} first")
                            if not start_service(config['services'][dep], dep):
                                logger.error(f"Failed to start dependency {dep}, skipping {service_name}")
                                continue
                
                if start_service(service_config, service_name):
                    logger.info(f"Successfully started {service_name}")
                else:
                    logger.error(f"Failed to start {service_name}")
            else:
                logger.debug(f"Skipping {service_name} (status: {status})")
                
    except Exception as e:
        logger.error(f"Error starting missing services: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")

def main():
    parser = argparse.ArgumentParser(description="Kamiwazad service manager")
    parser.add_argument('command', choices=['start', 'stop', 'status'], help="Command to execute")
    parser.add_argument('-a', '--all', action='store_true', help="Check all service statuses even if daemon is down")
    parser.add_argument('--missing', action='store_true', help="Start only missing/stopped services")
    args = parser.parse_args()

    print(f"mode: {args.command}", file=sys.stderr)

    # Set up main logging
    main_log_file = setup_logging(config['logging']['directories'], 'kamiwazad.log')
    print(f"logging to {main_log_file}")

    logging.basicConfig(
        filename=main_log_file,
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s',
    )
    global logger
    logger = logging.getLogger(__name__)

    logger.debug(f"kzd startup, Environment: {os.environ}")

    if args.command == 'start':
        logger.info("Starting kamiwazad daemon...")
        try:
            if args.missing:
                # Only start missing services
                start_missing_services()
            else:
                # Start all enabled services
                start_services()
            
            # Start monitoring thread
            monitor_thread = threading.Thread(target=monitor_services, daemon=True)
            monitor_thread.start()

            # Set up signal handlers
            signal.signal(signal.SIGTERM, handle_sigterm)
            signal.signal(signal.SIGHUP, handle_sighup)  # For config reload

            # Keep the daemon running
            while True:
                time.sleep(1)
                
        except KeyboardInterrupt:
            logger.info("Received interrupt signal")
            stop_kamiwazad()
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
            stop_kamiwazad()

    elif args.command == 'stop':
        logger.info("Stopping all managed services...")
        stop_kamiwazad()
        
    elif args.command == 'status':
        if args.all:
            # Always show service status regardless of daemon state
            print_kamiwazad_status()
        else:
            # Only show service status if daemon is running (existing behavior)
            pid_file = "/tmp/kamiwazad.pid"
            if os.path.exists(pid_file):
                with open(pid_file, 'r') as f:
                    pid = int(f.read().strip())
                if is_process_running(pid):
                    print_kamiwazad_status()
                else:
                    print("kamiwazad is not running")
            else:
                print("kamiwazad is not running")

if __name__ == '__main__':
    main()

