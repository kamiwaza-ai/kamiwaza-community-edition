#!/bin/bash
set -ex

# Set up directories for certificates and keys
mkdir -p certs
mkdir -p secrets
mkdir -p volumes

# Set restrictive permissions on cert directories
chmod 700 certs secrets

# Create the Certificate Authority (CA) if it doesn't exist
if [[ ! -f "certs/ca.crt" ]]; then
    cockroach cert create-ca \
    --certs-dir=certs \
    --ca-key=secrets/ca.key
fi

# Set proper permissions on CA files
chmod 700 secrets/ca.key
chmod 700 certs/ca.crt

# Retrieve the default hostname and ensure it's not empty
HOSTNAMES=$(hostname)
if [[ -z "$HOSTNAMES" ]]; then echo "Hostname retrieval failed"; exit 1; fi

# Check the operating system and adjust IP address retrieval and hostname accordingly
if [[ "$(uname -s)" == "Darwin" ]]; then
    # Retrieve IP addresses using ifconfig on macOS
    IP_ADDRESSES=$(ifconfig | grep inet | grep -v inet6 | awk '{print $2}' | tr '\n' ' ')
    if [[ -z "$IP_ADDRESSES" ]]; then echo "IP address retrieval failed"; exit 1; fi
    # Include short hostname on macOS
    HOSTNAMES="$HOSTNAMES $(hostname -s)"
else
    # Retrieve IP addresses using hostname -I on Linux
    IP_ADDRESSES=$(hostname -I | tr ' ' '\n' | grep -v '^$')
    if [[ -z "$IP_ADDRESSES" ]]; then echo "IP address retrieval failed"; exit 1; fi
fi

# Combine all hostnames and IPs into one string
ALL_NAMES="$HOSTNAMES $IP_ADDRESSES cockroachdb"

# Include localhost and the fully-qualified domain name as common DNS names
COMMON_NAMES="localhost $(hostname -f)"

# Combine and deduplicate all possible names for certificate inclusion
ALL_CERT_NAMES=$(echo "$ALL_NAMES $COMMON_NAMES" | tr ' ' '\n' | sort -u | tr '\n' ' ')

# Create node certificate with all detected names if it doesn't exist
if [[ ! -f "certs/node.crt" ]]; then
    cockroach cert create-node \
    $ALL_CERT_NAMES \
    --certs-dir=certs \
    --ca-key=secrets/ca.key
fi

# Set proper permissions on node cert files
chmod 700 certs/node.crt
chmod 700 certs/node.key

# Create a client certificate for the root user if it doesn't exist
if [[ ! -f "certs/client.root.crt" ]]; then
    cockroach cert create-client \
    root \
    --certs-dir=certs \
    --ca-key=secrets/ca.key
fi

# Set proper permissions on client cert files
chmod 740 certs/client.root.*

# Handle Docker certificate path prefix on macOS
export CERT_PATH_PREFIX=$(uname -s | grep -q 'Darwin' && echo '/host_mnt/' || echo '')
