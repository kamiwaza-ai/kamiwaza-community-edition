#!/bin/bash
# set-node-version.sh - Ensure correct Node version for frontend

source "$(dirname "${BASH_SOURCE[0]}")/../set-kamiwaza-root.sh"
source "$(dirname "${BASH_SOURCE[0]}")/../common.sh"

# Determine env file location
if [[ -f "${KAMIWAZA_ROOT}/env.sh" ]]; then
    ENV_FILE="${KAMIWAZA_ROOT}/env.sh"
elif [[ -f "/etc/kamiwaza/env.sh" ]]; then
    ENV_FILE="/etc/kamiwaza/env.sh"
else
    echo "No env.sh file found in ${KAMIWAZA_ROOT} or /etc/kamiwaza"
    exit 1
fi

source "$ENV_FILE"

if ! command -v nvm &> /dev/null; then
    if [[ "${KAMIWAZA_COMMUNITY:-}" != "true" ]]; then
        # Enterprise edition: Set up NVM in /opt/kamiwaza/nvm
        NVM_INSTALL_DIR="/opt/kamiwaza/nvm"
    else
        # Community edition: Use standard home directory installation
        NVM_INSTALL_DIR="$HOME/.nvm"
    fi
    NVM_ENV_FILE="$ENV_FILE" bash ${NVM_INSTALL_DIR}/install.sh --no-use
fi

if ! command -v nvm &> /dev/null; then
    source ${NVM_INSTALL_DIR}/nvm.sh
    source ${NVM_INSTALL_DIR}/bash_completion
fi

promote_nvm_node  # Called after nvm use to ensure proper PATH ordering
nvm use 22

# Verify we actually got Node 22
if ! verify_node_version; then
    echo "Failed to set Node 22 as active version" >&2
    exit 1
fi