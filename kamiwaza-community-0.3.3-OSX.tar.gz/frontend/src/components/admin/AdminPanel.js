import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../utils/api';
import { 
  StyledButton, 
  StyledTextField, 
  StyledTable, 
  StyledTableCell, 
  StyledTableRow, 
  StyledTableHead, 
  StyledTableBody,
  StyledMainContent,
  StyledBox
} from '../../StyledComponents';

const AdminPanel = () => {
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({ username: '', email: '', password: '' });
  const [selectedUser, setSelectedUser] = useState(null);
  const [formKey, setFormKey] = useState(0);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await api.get('/auth/users/');
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const handleNewUserChange = (e) => {
    setNewUser({ ...newUser, [e.target.id]: e.target.value });
  };

  const handleSelectedUserChange = (e) => {
    setSelectedUser({ ...selectedUser, [e.target.name]: e.target.value });
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    try {
      await api.post('/auth/users/local', newUser);
      setNewUser({ username: '', email: '', password: '' });
      fetchUsers();  // Refresh the user list after adding a new user
    } catch (error) {
      console.error('Error adding user:', error);
    }
  };

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    if (!selectedUser) return;
    try {
      await api.put(`/auth/users/${selectedUser.id}`, selectedUser);
      setSelectedUser(null);
      fetchUsers();
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const handleDeleteUser = async (userId) => {
    try {
      await api.delete(`/auth/users/${userId}`);
      fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  return (
    <StyledMainContent>
      <h2>Admin Panel</h2>
      
      <h3>Add New User</h3>
      <form onSubmit={handleAddUser} key={formKey} autoComplete="off">
        {/* Hidden field to trick browsers */}
        <input type="text" style={{display: 'none'}} />
        <StyledTextField
          id="username"
          name={`username_${Math.random()}`}
          label="Username"
          value={newUser.username}
          onChange={handleNewUserChange}
          autoComplete="off"
          fullWidth
          margin="normal"
          inputProps={{
            autoComplete: 'new-username',
            form: {
              autoComplete: 'off',
            },
          }}
        />
        <StyledTextField
          id="email"
          name={`email_${Math.random()}`}
          label="Email"
          value={newUser.email}
          onChange={handleNewUserChange}
          autoComplete="off"
          fullWidth
          margin="normal"
          inputProps={{
            autoComplete: 'new-email',
            form: {
              autoComplete: 'off',
            },
          }}
        />
        <StyledTextField
          id="password"
          name={`password_${Math.random()}`}
          label="Password"
          type="password"
          value={newUser.password}
          onChange={handleNewUserChange}
          autoComplete="new-password"
          fullWidth
          margin="normal"
          inputProps={{
            autoComplete: 'new-password',
            form: {
              autoComplete: 'off',
            },
          }}
        />
        <StyledButton type="submit" variant="contained" color="primary">
          Add User
        </StyledButton>
      </form>

      <StyledBox mt={4}>
        <h3>User List</h3>
        <StyledTable>
          <StyledTableHead>
            <StyledTableRow>
              <StyledTableCell>Username</StyledTableCell>
              <StyledTableCell>Email</StyledTableCell>
              <StyledTableCell>Actions</StyledTableCell>
            </StyledTableRow>
          </StyledTableHead>
          <StyledTableBody>
            {users.map((user) => (
              <StyledTableRow key={user.id}>
                <StyledTableCell>
                  <Link to={`/user/${user.id}`}>{user.username}</Link>
                </StyledTableCell>
                <StyledTableCell>{user.email}</StyledTableCell>
                <StyledTableCell>
                  <StyledButton onClick={() => setSelectedUser(user)} variant="outlined" color="primary">
                    Edit
                  </StyledButton>
                  <StyledButton onClick={() => handleDeleteUser(user.id)} variant="outlined" color="secondary">
                    Delete
                  </StyledButton>
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </StyledTableBody>
        </StyledTable>
      </StyledBox>

      {selectedUser && (
        <div>
          <h3>Edit User</h3>
          <form onSubmit={handleUpdateUser}>
            <StyledTextField
              name="username"
              label="Username"
              value={selectedUser.username}
              onChange={handleSelectedUserChange}
              fullWidth
              margin="normal"
            />
            <StyledTextField
              name="email"
              label="Email"
              value={selectedUser.email}
              onChange={handleSelectedUserChange}
              fullWidth
              margin="normal"
            />
            <StyledButton type="submit" variant="contained" color="primary">
              Update User
            </StyledButton>
          </form>
        </div>
      )}
    </StyledMainContent>
  );
};

export default AdminPanel;