#!/bin/bash

set -e # Exit on error
set -o pipefail # Catch errors in pipelines

# Change to parent directory of script location
cd "$(dirname "${BASH_SOURCE[0]}")/.."

# Load environment variables
load_env_vars() {
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    if [ -f "$script_dir/../deployment/build.env" ]; then
        source "$script_dir/../deployment/build.env"
    else
        echo "Error: Missing build.env file" >&2
        exit 1
    fi
}

# Function to tag and push for a given repository
tag_and_push() {
    local repo_dir="$1"
    local script_parent_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    cd "$repo_dir" || exit 1
    local branch=$(git symbolic-ref --short HEAD)
    if [ "$branch" != "main" ] && [ "$branch" != "master" ]; then
        echo "Error: Not on main or master branch." >&2
        cd "$script_parent_dir" || exit 1
        exit 1
    fi

    git pull --ff-only || { 
        echo "Error: Failed to pull latest changes from remote." >&2
        cd "$script_parent_dir" || exit 1
        exit 1
    }
    local kamiwaza_version="v${KAMIWAZA_VERSION_MAJOR}.${KAMIWAZA_VERSION_MINOR}.${KAMIWAZA_VERSION_PATCH}"
    git tag -a "$kamiwaza_version" -m "Release $kamiwaza_version"
    git push origin "$kamiwaza_version" || {
        echo "Error: Failed to push tag to remote." >&2
        cd "$script_parent_dir" || exit 1
        exit 1
    }
    cd "$script_parent_dir" || exit 1
}

load_env_vars

# Tag current repo (.)
tag_and_push "."

# Tag subdirectory repos (./kamiwaza and ./kamiwaza-sdk)
tag_and_push "./kamiwaza"
tag_and_push "./kamiwaza-sdk"
