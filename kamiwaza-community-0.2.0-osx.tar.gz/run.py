import asyncio
import os
import signal
from datetime import datetime
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from kamiwaza.scheduler.config import settings  # Adjust import path as needed
from kamiwaza.services.models.services import ModelService
from kamiwaza.serving.services import ServingService
from kamiwaza.cluster.models.cluster import DBMeta  # Adjust import path as needed
import logging

logger = logging.getLogger(__name__)

# Define a global event for signal handling
sleep_interrupt_event = asyncio.Event()

async def signal_handler(signum):
    sleep_interrupt_event.set()

async def store_periodic_pid():
    """Store the current process ID (PID) in the DBMeta table with the key 'periodic_pid'."""
    engine = create_engine(settings.database_url)
    Session = sessionmaker(bind=engine)
    session = Session()
    pid = os.getpid()
    try:
        periodic_pid_meta = session.query(DBMeta).filter(DBMeta.key == 'periodic_pid').first()
        if periodic_pid_meta:
            periodic_pid_meta.value = str(pid)
        else:
            new_meta = DBMeta(key='periodic_pid', value=str(pid))
            session.add(new_meta)
        session.commit()
    except Exception as e:
        logger.error(f"Failed to store periodic PID in the database: {e}")
    finally:
        session.close()

async def periodic_tasks():
    logger.debug("### Kamiwaza: periodic_tasks() startup")
    
    # Store the PID of the current process for later use with signal handling
    await store_periodic_pid()
    
    last_run_time = 0  # Initialize the last run time to 0
    
    while True:
        current_time = datetime.now().timestamp()  # Get the current time in seconds since the epoch
        
        if current_time - last_run_time >= 1:
            logger.debug("### Kamiwaza: periodic_tasks() run begins")
            
            # Schedule your tasks
            model_service = ModelService()
            await model_service.process_downloads()  # This needs to be an async function
            
            serving_service = ServingService()
            await serving_service.health_check()
            
            last_run_time = datetime.now().timestamp()  # Update the last run time to the current time
        
        # Calculate the sleep time dynamically based on the time taken by the tasks
        elapsed_time = datetime.now().timestamp() - current_time
        sleep_time = max(settings.cycle_time - elapsed_time, 0)
        
        logger.debug(f"### Kamiwaza: Sleeping for {sleep_time} seconds before next cycle")
        
        # Wait for either the sleep time to elapse or the event to be set
        try:
            await asyncio.wait([asyncio.sleep(sleep_time), sleep_interrupt_event.wait()], return_when=asyncio.FIRST_COMPLETED)
        finally:
            sleep_interrupt_event.clear()  # Reset the event for the next cycle

async def main():
    # Get the current event loop
    loop = asyncio.get_running_loop()
    
    # Register the signal handler within the event loop
    loop.add_signal_handler(signal.SIGUSR1, lambda: asyncio.create_task(signal_handler(signal.SIGUSR1)))
    
    # Run the periodic tasks
    await periodic_tasks()

if __name__ == "__main__":
    asyncio.run(main())