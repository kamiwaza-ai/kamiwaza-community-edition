#!/bin/bash

# Function to print messages in colors
print_in_color() {
    case $1 in
        green)
            echo -e "\033[92m$2\033[0m"
            ;;
        red)
            echo -e "\033[91m$2\033[0m"
            ;;
        yellow)
            echo -e "\033[93m$2\033[0m"
            ;;
        blue)
            echo -e "\033[94m$2\033[0m"
            ;;
        *)
            echo "$2"
            ;;
    esac
}

print_in_color none "Checking for virtual environment..."
if [[ "$VIRTUAL_ENV" == "" ]]; then
    print_in_color yellow "No virtual environment detected. Creating and activating one..."
    python3.10 -m venv venv
    source venv/bin/activate
    if [[ -z "$VIRTUAL_ENV" ]]; then
        print_in_color red "Failed to create or activate virtual environment."
        exit 1
    fi
fi
print_in_color green "Running 2nd phase installer in venv..."
export KAMIWAZA_RUN_FROM_INSTALL='yes'
source setup.sh
unset KAMIWAZA_RUN_FROM_INSTALL