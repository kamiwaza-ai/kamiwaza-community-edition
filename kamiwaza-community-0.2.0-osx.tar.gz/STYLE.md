# Style Considerations

## Preamble
I wanted to document certain choices and the 'why' of those choices. Without further ado:


## Interface/Implementation vs Plugin vs ??

In the early stages, I don't feel like I have a perfect handle on instances where we might opt for

* An interface/implementation pattern where we (Kamiwaza) provide some implementation(s) but leave the door open for others
* An plugin architecture (where we explicitly load a class but said class probably has the interface/implementation pattern)
* An adapter pattern where we have a single class and load adapters

And in the early days we've implemented all of them for different reasons, eg

* We use an interface/implementation pattern for vector databases
* We use a plugin+adapter pattern for hubs, where we provide callable functions via the plugin (HubsHf) but an adapter to massage hub data to our pydantic schema (ModelMapper/ModelFileMapper)
* We use the plugin architecture for the catalog (with the DataPlugin class being universal in theory but our version being the datahub to start)

These things have to be subject to change, but we do know we want to avoid interface/implementation patterns that lock us into a single implementation when we may interact with several - obviously, we'd very much expect in big varied enterprise environments to see multiple catalogs (Hive+starburst+alation+datahub maybe even, hah!)

So we will see

## Subclassing considerations

### Prototypes in unmodified child classes

Four ways I considered handling this:

1. Declare the method in the subclass and call super().__def__(**kwargs) - I don't mind this much, it's very readable, pylint does not like it and arguably it's repetitious and therefore against the spirit if not the letter of certain PEPs
2. Declare non-overridden methods in the child class docstring
3. Do the first choice (declare in the subclass and call a pointless super() -- except comment it out; this silences the pylint whining, and makes it a true no-op executably
4. Just don't do any of those. That is, "get over it" and if the subclass doesn't override, ignore it and assume the IDE will figure it otu

In the end I'm doing the commented declaration as of now (although this may not be consistent in early code), but so be it.
