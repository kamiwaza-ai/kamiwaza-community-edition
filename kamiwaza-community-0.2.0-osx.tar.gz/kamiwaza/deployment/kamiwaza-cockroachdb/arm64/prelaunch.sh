#!/bin/bash

mkdir -p certs
mkdir -p secrets
mkdir -p volumes

cockroach cert create-ca \
--certs-dir=certs \
--ca-key=secrets/ca.key

cockroach cert create-node \
localhost \
$(hostname) \
--certs-dir=certs \
--ca-key=secrets/ca.key

cockroach cert create-client \
root \
--certs-dir=certs \
--ca-key=secrets/ca.key

# this is meant to ensure the way the cockroach compose certs path is done will work properly with osx docker
# This is Docker desktop; YMMV if you are using a different docker on osx
export CERT_PATH_PREFIX=$(uname -s | grep -q 'Darwin' && echo '/host_mnt/' || echo '')
