import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/custom.scss';
import React from 'react';
import { createRoot } from 'react-dom/client'; // Updated import for React 18
import './index.css'; // If you have global styles
import App from './App'; // Ensure this points to your App component

// Updated render method for React 18
const container = document.getElementById('root');
const root = createRoot(container);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
