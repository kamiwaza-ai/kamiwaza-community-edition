import React from 'react';
import { useTheme } from '@mui/material/styles';

const Homepage = () => {
  const theme = useTheme();
  return (
    <div className="main-content" style={{
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.background.default,
      display: 'flex', // Use flexbox to create columns
      flexDirection: 'row', // Align children in a row
      justifyContent: 'space-between' // Space between the columns
    }}>
      <div style={{ flex: 1, marginRight: '1rem' }}> {/* Column 1 */}
        <h1 style={{ color: theme.palette.primary.main }}>Updates</h1>
        <p style={{ color: theme.palette.text.secondary }}>
          <h2>Latest Release</h2>
          <ul>
            <li>Improvements in model downloads: Batched downloading, download queue, downloads restart on failure</li>
            <li>Model Engines now have health checks; dedicated view for model deployments as a list separate from model details; automatic health checks</li>
          </ul>
        </p>
      </div>
      <div style={{ flex: 1 }}> {/* Column 2 */}
        <h1 style={{ color: theme.palette.primary.main }}>Latest News</h1>
        <p style={{ color: theme.palette.text.secondary }}>
          <div>&nbsp;</div>
          <div>Register for SW2con (replacing GlueCon) with code <b>20speaker</b>, get 20% off, and see Kamiwaza.AI CTO Matt Wallace presenting on the challenges of the Enterprise AI Journey</div>
          <div>&nbsp;</div>
          <div><img src='/sw2con.png' width='400' /></div>
        </p>
      </div>
    </div>
  );
};

export default Homepage;
