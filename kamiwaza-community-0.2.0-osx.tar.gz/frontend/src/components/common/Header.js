import React from 'react';

function Header() {
  return (
    <header className="bg-light py-3">
      <div className="container d-flex align-items-center">
        <img src="/logo.png" alt="Kamiwaza" width='30' />
        <h1 className="h2 mb-0 ms-2">Kamiwaza Dashboard</h1>
      </div>
    </header>
  );
}

export default Header;
