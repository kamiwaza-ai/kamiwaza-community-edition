import React from 'react';
import { StyledCircularProgress } from '../../StyledComponents';

const Spinner = () => (
    <div className="d-flex justify-content-center py-5">
        <StyledCircularProgress />
    </div>
);

export default Spinner;
