import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledTable, StyledTableCell, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { BASE_URL } from '../../const';

const ModelConfigDetail = () => {
    const [modelConfig, setModelConfig] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { model_config_id } = useParams();

    useEffect(() => {
        const fetchModelConfigDetail = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`${BASE_URL}/model_configs/${model_config_id}`);
                setModelConfig(response.data);
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchModelConfigDetail();
    }, [model_config_id]);

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    return (
        <StyledMainContent>
            <StyledButton component={Link} to={`/models/${modelConfig?.model_id}`} variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Back to Config List
            </StyledButton>
            {modelConfig ? (
                <StyledTable>
                    <tbody>
                        <tr><StyledTableCell>Name</StyledTableCell><StyledTableCell>{modelConfig.name}</StyledTableCell></tr>
                        <tr><StyledTableCell>Description</StyledTableCell><StyledTableCell>{modelConfig.description}</StyledTableCell></tr>
                        <tr><StyledTableCell>Data Type</StyledTableCell><StyledTableCell>{modelConfig.dtype}</StyledTableCell></tr>
                        <tr><StyledTableCell>Served Model Name</StyledTableCell><StyledTableCell>{modelConfig.served_model_name}</StyledTableCell></tr>
                        <tr><StyledTableCell>Host</StyledTableCell><StyledTableCell>{modelConfig.host}</StyledTableCell></tr>
                        <tr><StyledTableCell>Port</StyledTableCell><StyledTableCell>{modelConfig.port}</StyledTableCell></tr>
                        <tr><StyledTableCell>Max Model Length</StyledTableCell><StyledTableCell>{modelConfig.max_model_len}</StyledTableCell></tr>
                        <tr><StyledTableCell>Max Number of Sequences</StyledTableCell><StyledTableCell>{modelConfig.max_num_seqs}</StyledTableCell></tr>
                        <tr><StyledTableCell>Tensor Parallel Size</StyledTableCell><StyledTableCell>{modelConfig.tensor_parallel_size}</StyledTableCell></tr>
                        <tr><StyledTableCell>Swap Space</StyledTableCell><StyledTableCell>{modelConfig.swap_space}</StyledTableCell></tr>
                        <tr><StyledTableCell>GPU Memory Utilization</StyledTableCell><StyledTableCell>{modelConfig.gpu_memory_utilization}</StyledTableCell></tr>
                        <tr><StyledTableCell>Enforce Eager Execution</StyledTableCell><StyledTableCell>{modelConfig.enforce_eager ? 'Yes' : 'No'}</StyledTableCell></tr>
                        <tr><StyledTableCell>Disable Log Requests</StyledTableCell><StyledTableCell>{modelConfig.disable_log_requests ? 'Yes' : 'No'}</StyledTableCell></tr>
                    </tbody>
                </StyledTable>
            ) : (
                <StyledParagraph>Model Config not found</StyledParagraph>
            )}
        </StyledMainContent>
    );
};

export default ModelConfigDetail;
