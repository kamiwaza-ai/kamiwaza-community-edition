import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { StyledMainContent, StyledSubHeader, StyledTable, StyledTableCell, StyledTableHead, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import { BASE_URL } from '../../const';
import ModelDeploymentDetailModal from './ModelDeploymentDetail'; // Import the modal component

/**
 * Component to list model deployments with options to view details and open API documentation.
 * @param {Object} props - Component props.
 * @param {string} [props.model_id] - Optional model ID to filter deployments.
 * @param {boolean} props.refreshDeployments - Trigger to refresh deployments list.
 */
const ModelDeploymentList = ({ model_id, refreshDeployments }) => {
    const [modelDeployments, setModelDeployments] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [selectedDeploymentId, setSelectedDeploymentId] = useState(null); // State to track selected deployment for details

    // Define fetchModelDeployments as a useCallback hook to avoid re-creation on every render
    const fetchModelDeployments = useCallback(async () => {
        setLoading(true);
        try {
            let url = `${BASE_URL}/serving/deployments`;
            if (model_id) {
                url += `?model_id=${model_id}`;
            }
            const response = await axios.get(url);
            setModelDeployments(response.data);
            setLoading(false);
        } catch (err) {
            setError(err);
            setLoading(false);
        }
    }, [model_id]); // Dependency array to re-create the function when model_id changes

    useEffect(() => {
        fetchModelDeployments();
    }, [fetchModelDeployments, refreshDeployments]); // Also re-run effect when refreshDeployments changes

    const handleOpenDetails = (deploymentId) => {
        setSelectedDeploymentId(deploymentId); // Set the selected deployment ID to open the modal
    };

    // Function to handle refreshing the list of deployments
    const handleRefreshDeployments = () => {
        fetchModelDeployments();
    };

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    return (
        <StyledMainContent>
            <StyledSubHeader>Model Deployments</StyledSubHeader>
            {modelDeployments.length > 0 ? (
                <StyledTable>
                    <StyledTableHead>
                        <tr>
                            <StyledTableCell>Model Name</StyledTableCell>
                            <StyledTableCell>Host</StyledTableCell>
                            <StyledTableCell>Port</StyledTableCell>
                            <StyledTableCell>Open API</StyledTableCell>
                            <StyledTableCell>Details</StyledTableCell>
                        </tr>
                    </StyledTableHead>
                    <tbody>
                        {modelDeployments.map((deployment) => (
                            <tr key={deployment.id}>
                                <StyledTableCell>{deployment.model_name}</StyledTableCell>
                                <StyledTableCell>{deployment.host_name}</StyledTableCell>
                                <StyledTableCell>{deployment.listen_port}</StyledTableCell>
                                <StyledTableCell>
                                    {deployment.engine_name === 'vllm' ? (
                                        <StyledButton as="a" href={`http://${deployment.host_name}:${deployment.listen_port}/docs`} target="_blank">Open API</StyledButton>
                                    ) : deployment.engine_name === 'llamacpp' ? (
                                        <StyledButton as="a" href={`http://${deployment.host_name}:${deployment.listen_port}`} target="_blank">Open Llamacpp Chat</StyledButton>
                                    ) : (
                                        <span>&nbsp;</span>
                                    )}
                                </StyledTableCell>
                                <StyledTableCell>
                                    <StyledButton onClick={() => handleOpenDetails(deployment.id)}>Details</StyledButton>
                                </StyledTableCell>
                            </tr>
                        ))}
                    </tbody>
                </StyledTable>
            ) : (
                <p>No model deployments found.</p>
            )}
            {/* Conditionally render the modal if a deployment ID is selected */}
            {selectedDeploymentId && (
                <ModelDeploymentDetailModal
                    deploymentId={selectedDeploymentId}
                    isOpen={!!selectedDeploymentId}
                    onClose={() => setSelectedDeploymentId(null)} // Reset selected deployment ID to close the modal
                    onDeploymentStopped={handleRefreshDeployments} // Prop to trigger refresh of the deployment list
                />
            )}
        </StyledMainContent>
    );
};

export default ModelDeploymentList;
