import React, { useState, useContext } from 'react';
import axios from 'axios';
import { StyledMainContent, StyledButton, StyledTextField, StyledCheckbox, StyledFormControlLabel, StyledSubHeader } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ModelList from './ModelList'; // Assuming you have a component to list models
import ModelFilesContext from './ModelFilesContext';
import { BASE_URL } from '../../const';

const ModelHubSearch = () => {
    const { setModelFiles } = useContext(ModelFilesContext);
    const [query, setQuery] = useState('');
    const [isExact, setIsExact] = useState(false);
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const clearResults = () => setResults([]);

    const handleSearch = async (event) => {
        event.preventDefault();
        setLoading(true);
    
        if (query.trim() !== '') {
            try {
                const response = await axios.post(`${BASE_URL}/models/search/`, {
                    query,
                    exact: isExact,
                    hubs_to_search: ["*"]
                });
                // Assuming the API returns an object with a 'results' array
                setResults(response.data.results.map(item => item.model)); // Update this line
                setLoading(false);
            } catch (err) {
                console.error('Search error:', err);
                setError(err);
                setLoading(false);
            }
        } else {
            setLoading(false); // Ensure loading is set to false if query is empty
        }
    };

    return (
        <StyledMainContent>
            <StyledSubHeader>Model Hub Search</StyledSubHeader>
            <form onSubmit={handleSearch}>
                <StyledTextField
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search for models..."
                />
                <StyledFormControlLabel
                    control={
                        <StyledCheckbox
                            type="checkbox"
                            checked={isExact}
                            onChange={(e) => setIsExact(e.target.checked)}
                        />
                    }
                    label="Exact match"
                />
                <StyledButton type="submit">Search</StyledButton>
            </form>

            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {results.length > 0 && !loading && <ModelList models={results} search={true} setModelFiles={setModelFiles} clearSearchResults={clearResults} />}
        </StyledMainContent>
    );
};

export default ModelHubSearch;
