import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { Link, useLocation } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const UserList = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const fetchUsers = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/users`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setUsers(response.data);
                } else {
                    throw new Error(`Failed to fetch users from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchUsers();
    }, []);

    return (
        <StyledMainContent className="crudlist">
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <StyledHeader>User List</StyledHeader>
            {loading && <StyledParagraph>Loading...</StyledParagraph>}
            {error && <StyledParagraph>Error: {error.message}</StyledParagraph>}
            {users.length === 0 && !loading ? (
                <StyledParagraph>No users available.</StyledParagraph>
            ) : (
                <ul>
                    {users.map(user => (
                        <li key={user.id}>
                            <b>Name: </b> {user.name} <br/>
                            <b>Email: </b> {user.email}
                        </li>
                    ))}
                </ul>
            )}
        </StyledMainContent>
    );
};

export default UserList;
