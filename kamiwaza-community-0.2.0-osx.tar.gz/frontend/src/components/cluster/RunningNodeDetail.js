import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import { BASE_URL } from '../../const';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const RunningNodeDetail = () => {
    const [node, setNode] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { node_id } = useParams();

    useEffect(() => {
        const fetchRunningNodeDetail = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`${BASE_URL}/cluster/get_running_nodes`);
                const nodeDetail = response.data.find(node => node.node_id === node_id);
                setNode(nodeDetail);
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchRunningNodeDetail();
    }, [node_id]);

    if (loading) return <StyledMainContent />;
    if (error) return <StyledParagraph message={error.message} />;

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Back to Cluster Home
            </StyledButton>
            <StyledButton component={Link} to="/clusters/runningnodes" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Back to Running Node List
            </StyledButton>
            {node ? (
                <div>
                    <StyledHeader>{node.node_id}</StyledHeader>
                    <StyledParagraph><strong>Alive:</strong> {node.alive.toString()}</StyledParagraph>
                    <StyledParagraph><strong>Node Manager Address:</strong> {node.node_manager_address}</StyledParagraph>
                    <StyledParagraph><strong>Node Manager Hostname:</strong> {node.node_manager_hostname}</StyledParagraph>
                    <StyledParagraph><strong>Node Manager Port:</strong> {node.node_manager_port}</StyledParagraph>
                    <StyledParagraph><strong>Object Manager Port:</strong> {node.object_manager_port}</StyledParagraph>
                    <StyledParagraph><strong>Object Store Socket Name:</strong> {node.object_store_socket_name}</StyledParagraph>
                    <StyledParagraph><strong>Raylet Socket Name:</strong> {node.raylet_socket_name}</StyledParagraph>
                    <StyledParagraph><strong>Metrics Export Port:</strong> {node.metrics_export_port}</StyledParagraph>
                </div>
            ) : (
                <StyledParagraph>Node not found</StyledParagraph>
            )}
        </StyledMainContent>
    );
};

export default RunningNodeDetail;