import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link, useLocation } from 'react-router-dom';

const NodeList = ({ nodes: propNodes }) => {
    const [nodes, setNodes] = useState(propNodes || []);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const location = useLocation();

    useEffect(() => {
        if (!propNodes) {
            const fetchNodes = async () => {
                setLoading(true);
                try {
                    const uri = `${BASE_URL}/cluster/nodes`;
                    const response = await axios.get(uri);
                    if (response.status === 200) {
                        setNodes(response.data);
                    } else {
                        throw new Error(`Failed to fetch nodes from ${uri}`);
                    }
                    setLoading(false);
                } catch (err) {
                    setError(err);
                    setLoading(false);
                }
            };

            fetchNodes();
        }
    }, [propNodes]);

    return (
        <StyledMainContent className="crudlist">
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <StyledHeader>Node List</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {nodes.length === 0 && !loading ? (
                <StyledParagraph>No nodes available.</StyledParagraph>
            ) : (
                <ul>
                    {nodes.map(node => (
                        <li key={node.id}>
                            Node ID: {node.id} - Node Name: {node.name}
                        </li>
                    ))}
                </ul>
            )}
        </StyledMainContent>
    );
};

export default NodeList;
