import React from 'react';
import Spinner from '../common/Spinner';
import ClusterList from './ClusterList';
import LocationList from './LocationList';
import NodeList from './NodeList';
import HardwareList from './HardwareList';
import ErrorComponent from '../common/ErrorComponent';
import RunningNodeList from './RunningNodeList';
import { StyledMainContent, StyledHeader } from '../../StyledComponents';

const ClusterHome = () => {
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);

    // Only set loading to false when all components have mounted
    // and started their own data fetching
    React.useEffect(() => {
        setLoading(false);
    }, []);

    return (
        <StyledMainContent className="crudcontainer">
            <StyledHeader>Cluster Home</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            <ClusterList />
            <LocationList />
            <NodeList />
            <RunningNodeList />
            <HardwareList />
        </StyledMainContent>
    );
};

export default ClusterHome;
