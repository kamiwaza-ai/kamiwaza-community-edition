import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useLocation } from 'react-router-dom';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const RunningNodeList = () => {
    const [nodes, setNodes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const fetchNodes = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/get_running_nodes`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setNodes(response.data);
                } else {
                    throw new Error(`Failed to fetch nodes from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err.response && err.response.data && err.response.data.detail ? err.response.data.detail : err);
                setLoading(false);
            }
        };

        fetchNodes();
    }, []);

    return (
        <StyledMainContent>
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <StyledHeader>Running Nodes</StyledHeader>
            {loading && <StyledParagraph>Loading...</StyledParagraph>}
            {error && <StyledParagraph>Error: {typeof error === 'string' ? error : error.message}</StyledParagraph>}
            {nodes.length === 0 && !loading ? (
                <StyledParagraph>No running nodes available.</StyledParagraph>
            ) : (
                <ul>
                    {nodes.map(node => (
                        <li key={node.node_id}>
                            Node ID: <Link to={`/cluster/runningnodes/${node.node_id}`}>{node.node_id.length > 33 ? `${node.node_id.slice(0, 15)}...${node.node_id.slice(-15)}` : node.node_id}</Link>, Node Manager Address: {node.node_manager_address}
                        </li>
                    ))}
                </ul>
            )}
        </StyledMainContent>
    );
};

export default RunningNodeList;
