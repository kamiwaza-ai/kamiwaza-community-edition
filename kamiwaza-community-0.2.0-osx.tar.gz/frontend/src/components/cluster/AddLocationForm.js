import React, { useState } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledModal, StyledButton, StyledTable, StyledTableCell, StyledTextField, StyledCircularProgress, StyledModalContent, StyledSubHeader } from '../../StyledComponents';

const AddLocationModal = ({ closeModal, showModal, addLocation }) => {
    const [locationData, setLocationData] = useState({
        name: '',
        datacenter: '',
        region: '',
        zone: '',
        building: '',
        address: '',
        contact_phone: '',
        contact_name: '',
        contact_email: ''
    });

    const handleAddLocation = async () => {
        try {
            const response = await axios.post(`${BASE_URL}/cluster/location`, locationData);
            if (response.status === 200) {
                addLocation(response.data); // Call addLocation with the new location
                closeModal();
            } else {
                // Handle non-successful response
            }
        } catch (err) {
            console.error('Add location error:', err);
            // Handle add location error
        }
    };

    const handleInputChange = (event) => {
        setLocationData({
            ...locationData,
            [event.target.name]: event.target.value
        });
    };

    return (
        <StyledModal open={showModal} onClose={closeModal}>
            <StyledModalContent>
                <StyledTable>
                    <thead>
                        <tr>
                            <StyledTableCell>
                                <StyledSubHeader>Add New Location</StyledSubHeader>
                            </StyledTableCell>
                        </tr>
                    </thead>
                    <tbody>
                        {Object.keys(locationData).map((key) => (
                            <tr key={key}>
                                <StyledTableCell>{key.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</StyledTableCell>
                                <StyledTableCell>
                                    <StyledTextField
                                        name={key}
                                        value={locationData[key]}
                                        onChange={handleInputChange}
                                    />
                                </StyledTableCell>
                            </tr>
                        ))}
                    </tbody>
                </StyledTable>
                <StyledButton variant="secondary" onClick={closeModal}>
                    Close
                </StyledButton>
                <StyledButton variant="primary" onClick={handleAddLocation}>
                    Add Location
                    </StyledButton>
            </StyledModalContent>
        </StyledModal>
    );
};

export default AddLocationModal;

