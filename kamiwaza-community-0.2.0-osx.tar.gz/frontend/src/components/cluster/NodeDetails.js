import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const NodeDetails = () => {
    const [node, setNode] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    let { '*': id } = useParams();

    useEffect(() => {
        const fetchNodeDetails = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/node/${id}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setNode(response.data);
                } else {
                    throw new Error(`Failed to fetch node details from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchNodeDetails();
    }, [id]);

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Clusters Home
            </StyledButton>
            <StyledHeader>Node Details</StyledHeader>
            {loading && <StyledParagraph>Loading...</StyledParagraph>}
            {error && <StyledParagraph>Error: {error.message}</StyledParagraph>}
            <div className="node-list">
                {node && (
                    <div key={node.id} className="node-card">
                        <h2 className="node-name">{node.name}</h2>
                        <p className="node-info"><strong>ID:</strong> {node.id}</p>
                        <p className="node-info"><strong>State:</strong> {node.state}</p>
                        <p className="node-info"><strong>Resources:</strong> {JSON.stringify(node.resources)}</p>
                    </div>
                )}
            </div>
        </StyledMainContent>
    );
};

export default NodeDetails;
