#!/bin/bash

set -ex

# Get the directory of the BASH_SOURCE
dir=$(dirname "${BASH_SOURCE[0]}")
dir=$(realpath "${dir}")
# Change to the notebooks directory
cd "${dir}/notebooks"

# Get PIDs of JupyterLab processes
jupyter_pids=$(ps auxwww | grep '[p]ython' | grep jupyter-lab | awk '{print $2}')

# If PIDs were found, kill the processes
if [ ! -z "$jupyter_pids" ]; then
    for pid in $jupyter_pids; do
        echo "Killing JupyterLab process with PID: $pid"
        kill "$pid"
        # Optionally, wait for the process to be killed
        while kill -0 "$pid" 2> /dev/null; do
            echo "Waiting for JupyterLab process PID $pid to terminate..."
            sleep 1
        done
    done
else
    echo "No JupyterLab process found."
fi

# Start JupyterLab
echo "Starting JupyterLab..."
source ../notebook-venv/bin/activate
export PYTHONPATH="${PYTHONPATH}:${dir}"

nohup jupyter lab --ip=0.0.0.0 --no-browser > jupyter_lab.log 2>&1 &
sleep 4 # Give it a moment to start and write to the log
grep -E "http://.*token=|https://.*token=" jupyter_lab.log
# Wait a bit for JupyterLab to start

