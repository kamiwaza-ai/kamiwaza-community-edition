#!/bin/bash
set -x

# Add preserve-etcd flag check
PRESERVE_ETCD=0
for arg in "$@"; do
    if [[ "$arg" == "--preserve-etcd" ]]; then
        PRESERVE_ETCD=1
        # Remove this arg from $@ so it doesn't interfere with component_arg
        shift
    fi
done

# Split EXCLUDE_CONTAINERS into an array if it is comma separated
EXCLUDE_CONTAINERS=${KAMIWAZA_EXCLUDE_CONTAINERS:-qdrant,jupyterhub,nonexistant}
excluded_containers=(${EXCLUDE_CONTAINERS//,/ })

# Check for KAMIWAZA_ENV, set to "default" if not set
KAMIWAZA_ENV=${KAMIWAZA_ENV:-default}

# Get the component argument if provided
component_arg=$1

# Platform detection
if [[ "$(uname)" == "Darwin" ]]; then
    platform='osx'
else
    platform='linux'
fi

# Architecture detection
arch_raw=$(uname -m)
case "$arch_raw" in
    "x86_64")
        arch='amd64'
        ;;
    "aarch64"|"arm64")
        arch='arm64'
        ;;
    *)
        echo "Unsupported architecture: $arch_raw"
        exit 1
        ;;
esac

# GPU detection
if command -v nvidia-smi &> /dev/null && nvidia-smi > /dev/null 2>&1; then
    cpugpu='gpu'
else
    cpugpu='cpu'
fi

# Main loop to process components
for component_path in $(find kamiwaza/deployment -mindepth 1 -maxdepth 1 -type d | grep -v '/envs$'); do
    component=$(basename $component_path)
    
    # Component arg filtering
    if [[ -n "$component_arg" && "$component" != *"$component_arg"* ]]; then
        continue
    fi

    # Exclusion check
    exclude=false
    for excluded in "${excluded_containers[@]}"; do
        if [[ "$component" == *"$excluded"* ]]; then
            exclude=true
            break
        fi
    done
    if [[ "$exclude" == true ]]; then
        echo "Skipping $component because it is excluded"
        continue
    fi

    # Architecture folder determination
    if [[ "$cpugpu" == "gpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-gpu" ]]; then
        arch_folder="${arch}-gpu"
    elif [[ -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}" ]]; then
        arch_folder="${arch}"
    elif [[ "$cpugpu" == "cpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-cpu" ]]; then
        arch_folder="${arch}-cpu"
    else
        echo "No suitable architecture folder found for component: ${component}"
        continue
    fi

    # Navigate to component directory
    cd "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch_folder}"

    # Special handling for etcd
    if [[ "$component" == *"etcd"* && "$PRESERVE_ETCD" -eq 0 ]]; then
        echo "Stopping etcd with volume removal"
        docker compose -f "docker-compose.yml" -p "${KAMIWAZA_ENV}-${component}" down --rmi none
        # Actually remove the data directory
        rm -rf "${DOCKER_VOLUME_DIRECTORY:-.}/volumes/etcd"/*.etcd
    else
        echo "Stopping ${component}"
        docker compose -f "docker-compose.yml" -p "${KAMIWAZA_ENV}-${component}" stop
    fi

    # Return to original directory
    cd - > /dev/null
done

echo "All containers have been stopped."
exit 0