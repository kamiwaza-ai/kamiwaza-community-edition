import asyncio
import os
import ray
import signal
from datetime import datetime, timezone
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from kamiwaza.scheduler.config import settings  # Adjust import path as needed
from kamiwaza.services.models.services import ModelService
from kamiwaza.serving.services import ServingService
from kamiwaza.cluster.services import ClusterService
from kamiwaza.cluster.models.cluster import DBMeta  # Adjust import path as needed
from kamiwaza.util.netutil import node_hostip
import logging
from logging.handlers import RotatingFileHandler

# Create logs directory if it doesn't exist
os.makedirs("/tmp/kamiwaza", exist_ok=True)

# Configure root logger
logging.basicConfig(level=logging.DEBUG)  # Keep console logging if desired

# Create a rotating file handler
file_handler = RotatingFileHandler(
    filename="/tmp/kamiwaza/serving.log",
    maxBytes=10*1024*1024,  # 10MB per file
    backupCount=5,  # Keep 5 backup files
    encoding='utf-8'
)

# Set formatter
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
file_handler.setFormatter(formatter)

# Get the logger and add the handler
logger = logging.getLogger(__name__)
logger.addHandler(file_handler)

# Prevent duplicate logging
logger.propagate = False

# Define a global event for signal handling
sleep_interrupt_event = asyncio.Event()

async def signal_handler(signum):
    """
    Asynchronous signal handler that sets the sleep interrupt event.

    Args:
        signum (int): The signal number received.
    """
    sleep_interrupt_event.set()

async def store_periodic_pid():
    """
    Store the current process ID (PID) and host information in the DBMeta table.

    This function creates a database session, retrieves or creates DBMeta entries
    for the periodic PID and host information, and updates them with current values.
    Also checks if Ray is initialized to determine if running in a cluster context.

    The stored information includes:
    - periodic_pid: Current process ID
    - periodic_host: Host identifier from node_hostip()
    - periodic_ray: Whether process is running in Ray cluster
    - periodic_ray_node_id: Node ID if running in Ray cluster
    - periodic_ray_job_id: Job ID if running in Ray cluster
    """
    engine = create_engine(settings.database_url)
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        # Get process info
        pid = os.getpid()
        
        host = node_hostip()  # This returns the hostname we need
            
        # Get Ray-specific details if running in Ray
        ray_context = {}
        if ray.is_initialized():
            ray_context = ray.runtime_context.get_runtime_context()
        
        meta_keys = {
            'periodic_pid': str(pid),
            'periodic_host': host,
            'periodic_ray': 'true' if ray.is_initialized() else 'false',
            'periodic_ray_node_id': ray_context.get_node_id() if ray.is_initialized() else '',
            'periodic_ray_job_id': ray_context.get_job_id() if ray.is_initialized() else ''
        }
        
        for key, value in meta_keys.items():
            meta_entry = session.query(DBMeta).filter(DBMeta.key == key).first()
            if meta_entry:
                meta_entry.value = value
            else:
                new_meta = DBMeta(key=key, value=value)
                session.add(new_meta)
                
        session.commit()
        logger.info(f"Stored periodic process info: {meta_keys}")
        
    except Exception as e:
        logger.error(f"Failed to store periodic process info in database: {e}")
        raise
    finally:
        session.close()

async def periodic_tasks():
    """
    Execute periodic tasks at regular intervals.

    This function runs continuously, performing the following tasks:
    1. Stores the periodic PID
    2. Processes model downloads
    3. Performs health checks on serving services
    4. Updates cluster nodes

    The function sleeps for a configurable amount of time between cycles,
    and can be interrupted by a signal.
    """
    await store_periodic_pid()
    
    last_run_time = 0
    # Track child processes that need cleanup
    child_processes = set()
    
    while True:
        current_time = datetime.now(timezone.utc).timestamp()
        
        if current_time - last_run_time >= 1:
            # Clean up any finished child processes
            finished_processes = set()
            for process in child_processes:
                if not process.is_alive():
                    process.join(timeout=3)  # Give each process 3 seconds to clean up
                    finished_processes.add(process)
            child_processes -= finished_processes
            
            logger.debug("Starting model downloads processing cycle")
            model_service = ModelService()
            try:
                await model_service.process_downloads()
                logger.debug("Successfully completed model downloads processing")
            except Exception as e:
                logger.error(f"Error processing model downloads: {e}", exc_info=True)
            
            logger.debug("Starting serving health check")
            serving_service = ServingService()
            try:
                await serving_service.health_check()
                logger.debug("Successfully completed serving health check")
            except Exception as e:
                logger.error(f"Error in serving health check: {e}", exc_info=True)

            logger.debug("Starting cluster node update")
            cluster_service = ClusterService()
            try:
                await cluster_service.periodic_node_update()
                logger.debug("Successfully completed cluster node update")
            except Exception as e:
                logger.error(f"Error in cluster node update: {e}", exc_info=True)
            
            last_run_time = datetime.now(timezone.utc).timestamp()
        
        elapsed_time = datetime.now(timezone.utc).timestamp() - current_time
        sleep_time = max(settings.cycle_time - elapsed_time, 0)
        
        sleep_task = asyncio.create_task(asyncio.sleep(sleep_time))
        interrupt_task = asyncio.create_task(sleep_interrupt_event.wait())
        
        try:
            await asyncio.wait([sleep_task, interrupt_task], return_when=asyncio.FIRST_COMPLETED)
        finally:
            sleep_interrupt_event.clear()  # Reset the event for the next cycle

def handle_child_process(signum, frame):
    """Handle terminated child processes to prevent zombies."""
    try:
        while True:
            # WNOHANG specified to make this non-blocking
            pid, status = os.waitpid(-1, os.WNOHANG)
            if pid == 0:
                break
    except ChildProcessError:
        pass

async def main():
    """
    Main asynchronous function to set up and run the periodic tasks.

    This function:
    1. Gets the current event loop
    2. Registers the signal handler for SIGUSR1
    3. Runs the periodic tasks
    """
    # Get the current event loop
    loop = asyncio.get_running_loop()
    
    # In both Ray and local mode, we want to handle SIGUSR1 the same way
    # The difference is how the signal gets to us - through Ray or directly
    loop.add_signal_handler(signal.SIGUSR1, lambda: asyncio.create_task(signal_handler(signal.SIGUSR1)))
    
    # Handle child processes cleanup in both modes
    signal.signal(signal.SIGCHLD, handle_child_process)
    
    # Run the periodic tasks
    await periodic_tasks()

if __name__ == "__main__":
    # Get environment variables
    kamiwaza_root = os.getenv("KAMIWAZA_ROOT")
    kamiwaza_lib_root = os.getenv("KAMIWAZA_LIB_ROOT")
    ray_init_address = os.getenv("KAMIWAZA_RAY_INIT_ADDRESS")

    # Prepare runtime environment
    runtime_env = {
        "env_vars": {
            "KAMIWAZA_ENV_INIT": "yes"
        }
    }

    if kamiwaza_root:
        runtime_env["env_vars"]["KAMIWAZA_ROOT"] = kamiwaza_root
        
    if kamiwaza_lib_root:
        runtime_env["env_vars"]["KAMIWAZA_LIB_ROOT"] = kamiwaza_lib_root
        
    if "PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION" not in os.environ:
        runtime_env["env_vars"]["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"

    # Add PYTHONPATH if it exists in the environment
    if 'PYTHONPATH' in os.environ:
        runtime_env['env_vars']['PYTHONPATH'] = os.environ['PYTHONPATH']

    # Initialize Ray
    ray_params = {
        "runtime_env": runtime_env,
        "address": ray_init_address if ray_init_address else "auto"
    }
    ray.init(**ray_params)

    # Run the main async function
    asyncio.run(main())