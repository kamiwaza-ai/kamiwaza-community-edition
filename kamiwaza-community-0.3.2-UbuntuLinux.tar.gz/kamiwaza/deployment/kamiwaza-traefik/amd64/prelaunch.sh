#!/bin/bash

# Define variables
CERT_DIR="./certs"
DOMAIN="*.default.deployment.kamiwaza.ai"
CERT_FILE="$CERT_DIR/domain.crt"
KEY_FILE="$CERT_DIR/domain.key"
DAYS_VALID=3650
RSA_LENGTH=4096

# Check if the certs directory and the necessary files exist
if [ ! -d "$CERT_DIR" ] || [ ! -f "$CERT_FILE" ] || [ ! -f "$KEY_FILE" ]; then
    echo "Certificates not found for Traefik, generating new self-signed certificate..."

    # Create certs directory if it doesn't exist
    mkdir -p "$CERT_DIR"

    if [[ "$OSTYPE" == "darwin"* ]]; then
        chown ${USER}:staff "$CERT_DIR"
    else
        sudo chown ${USER}:${USER} "$CERT_DIR"
    fi
    
    # Generate the private key and self-signed certificate
    openssl req -newkey rsa:$RSA_LENGTH -nodes -keyout "$KEY_FILE" -x509 -sha256 -days $DAYS_VALID \
    -subj "/C=US/ST=State/L=City/O=Organization/OU=Unit/CN=$DOMAIN" \
    -addext "subjectAltName=DNS:$DOMAIN" \
    -out "$CERT_FILE"
    
    echo "Certificate and key have been generated and stored in $CERT_DIR."
else
    echo "Certificates already exist in $CERT_DIR."
fi