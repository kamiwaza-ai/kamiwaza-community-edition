#!/bin/bash

line='    image: minio/minio:RELEASE.2023-03-20T20-16-18Z'

if [[ $line == image:* ]] ; then
  echo match on original
else
  echo no match on original
fi

line="${line#"${line%%[![:space:]]*}"}"

if [[ $line == image:* ]] ; then
  echo match on trimmed
else
  echo no match on trimmed
fi
