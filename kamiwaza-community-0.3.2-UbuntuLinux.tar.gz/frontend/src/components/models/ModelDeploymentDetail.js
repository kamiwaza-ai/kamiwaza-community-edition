import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledTable, StyledTableCell, 
  StyledButton, StyledConfirmModal, StyledModalContent, StyledIconButton, StyledCloseButton, StyledNegativeButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import { BASE_URL } from '../../const';
import { format, differenceInMinutes, differenceInHours, differenceInDays, differenceInWeeks } from 'date-fns';

/**
 * Modal component to display the details of a model deployment.
 * @param {Object} props - Component props.
 * @param {string} props.deploymentId - The ID of the deployment to display details for.
 * @param {boolean} props.isOpen - Controls the visibility of the modal.
 * @param {Function} props.onClose - Callback function to close the modal.
 * @param {Function} props.onDeploymentStopped - Callback function to trigger refresh of the deployment list.
 */
const ModelDeploymentDetailModal = ({ deploymentId, isOpen, onClose, onDeploymentStopped }) => {
    const [deploymentDetail, setDeploymentDetail] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [confirmStop, setConfirmStop] = useState(false);
    const [confirmForceRemove, setConfirmForceRemove] = useState(false);
    const [showScaling, setShowScaling] = useState(false);
    const [stopError, setStopError] = useState(null);

    useEffect(() => {
        const fetchDeploymentDetail = async () => {
            if (!deploymentId) return;
            setLoading(true);
            try {
                const response = await axios.get(`${BASE_URL}/serving/deployment/${deploymentId}`);
                setDeploymentDetail(response.data);
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchDeploymentDetail();
    }, [deploymentId]);

    const handleStopDeployment = async (force = false) => {
        try {
            await axios.delete(`${BASE_URL}/serving/deployment/${deploymentId}`, { params: { force } });
            onClose(); // Close the modal after stopping the deployment
            onDeploymentStopped(); // Trigger refresh of the deployment list
        } catch (err) {
            if (err.response && err.response.status === 404) {
                setStopError("Deployment not found. You may need to force remove it.");
                // Update the deployment status to trigger the "Force Remove" button
                setDeploymentDetail(prevState => ({
                    ...prevState,
                    status: 'STOP_REQUESTED'
                }));
                // Close the confirmation modal
                setConfirmStop(false);
            } else {
                setError(err);
            }
        }
    };

    const formatDuration = (minutes) => {
        if (minutes < 60) return `${minutes} minutes`;
        const hours = differenceInHours(new Date(), new Date().setMinutes(new Date().getMinutes() - minutes));
        if (hours < 24) return `${hours} hours`;
        const days = differenceInDays(new Date(), new Date().setMinutes(new Date().getMinutes() - minutes));
        if (days < 7) return `${days} days`;
        const weeks = differenceInWeeks(new Date(), new Date().setMinutes(new Date().getMinutes() - minutes));
        return `${weeks} weeks`;
    };

    if (!isOpen) return null; // Do not render the modal if it is not open

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    // Check if deploymentDetail and its properties exist before rendering
    const renderDeploymentDetails = () => {
        if (!deploymentDetail) return <StyledParagraph>Deployment detail not found.</StyledParagraph>;

        const firstInstance = deploymentDetail.instances && deploymentDetail.instances.length > 0 ? deploymentDetail.instances[0] : null;

        return (
            <>
                <StyledHeader>Deployment Detail</StyledHeader>
                <StyledTable>
                    <tbody>
                        <tr><StyledTableCell>Model Name</StyledTableCell><StyledTableCell>{deploymentDetail.m_name}</StyledTableCell></tr>
                        {firstInstance && (
                            <>
                                <tr><StyledTableCell>API URL</StyledTableCell><StyledTableCell>{`http(s)://${firstInstance.host_name}:${deploymentDetail.lb_port}`}</StyledTableCell></tr>
                                <tr><StyledTableCell></StyledTableCell><StyledTableCell><small>e.g. {`http(s)://${firstInstance.host_name}:${deploymentDetail.lb_port}/v1/models`}</small></StyledTableCell></tr>
                            </>
                        )}
                        <tr><StyledTableCell>Running for</StyledTableCell><StyledTableCell>{formatDuration(deploymentDetail.duration)}</StyledTableCell></tr>
                        <tr><StyledTableCell>Engine</StyledTableCell><StyledTableCell>{deploymentDetail.engine_name}</StyledTableCell></tr>
                        <tr><StyledTableCell>Status</StyledTableCell><StyledTableCell>{deploymentDetail.status}</StyledTableCell></tr>
                        <tr>
                            <StyledTableCell>Scaling</StyledTableCell>
                            <StyledTableCell>
                                <StyledButton onClick={() => setShowScaling(!showScaling)}>
                                    {showScaling ? 'Hide' : 'Show'}
                                </StyledButton>
                            </StyledTableCell>
                        </tr>
                        {showScaling && (
                            <>
                                <tr><StyledTableCell>Autoscaling</StyledTableCell><StyledTableCell>{deploymentDetail.autoscaling ? 'Enabled' : 'Disabled'}</StyledTableCell></tr>
                                <tr><StyledTableCell>Min Copies</StyledTableCell><StyledTableCell>{deploymentDetail.min_copies}</StyledTableCell></tr>
                                <tr><StyledTableCell>Starting Copies</StyledTableCell><StyledTableCell>{deploymentDetail.starting_copies}</StyledTableCell></tr>
                                <tr><StyledTableCell>Max Copies</StyledTableCell><StyledTableCell>{deploymentDetail.max_copies || 'Unlimited'}</StyledTableCell></tr>
                                {deploymentDetail.gpu_allocation && (
                                    <tr>
                                        <StyledTableCell>GPU Allocation</StyledTableCell>
                                        <StyledTableCell>{(deploymentDetail.vram_allocation / (1000 * 1000 * 1000)).toFixed(2)} GB</StyledTableCell>
                                    </tr>
                                )}
                            </>
                        )}
                    </tbody>
                </StyledTable>
                <StyledHeader>Instances</StyledHeader>
                <StyledTable>
                    <thead>
                        <tr>
                            <StyledTableCell>Host</StyledTableCell>
                            <StyledTableCell>Port</StyledTableCell>
                            <StyledTableCell>{deploymentDetail.engine_name === 'llamacpp' ? 'Process ID' : 'Container ID'}</StyledTableCell>
                            <StyledTableCell>Deployed At</StyledTableCell>
                        </tr>
                    </thead>
                    <tbody>
                        {deploymentDetail.instances && deploymentDetail.instances.map(instance => (
                            <tr key={instance.id}>
                                <StyledTableCell>{instance.host_name}</StyledTableCell>
                                <StyledTableCell>{instance.listen_port}</StyledTableCell>
                                <StyledTableCell>{instance.container_id}</StyledTableCell>
                                <StyledTableCell>{format(new Date(instance.deployed_at), 'MM/dd/yyyy HH:mm')}</StyledTableCell>
                            </tr>
                        ))}
                    </tbody>
                </StyledTable>
                {stopError && <StyledParagraph style={{ color: 'red' }}>{stopError}</StyledParagraph>}
                <StyledNegativeButton onClick={() => setConfirmStop(true)}>Stop Deployment</StyledNegativeButton>
                {(deploymentDetail.status === 'STOP_REQUESTED' || stopError) && (
                    <StyledNegativeButton onClick={() => setConfirmForceRemove(true)}>Force Remove</StyledNegativeButton>
                )}
            </>
        );
    };

    return (
        <StyledConfirmModal open={isOpen} onClose={onClose}>
            <StyledModalContent>
                <StyledIconButton onClick={onClose} aria-label="close" style={{ alignSelf: 'flex-end' }}>
                    <StyledCloseButton />
                </StyledIconButton>
                {renderDeploymentDetails()}
                <StyledConfirmModal open={confirmStop} onClose={() => setConfirmStop(false)}>
                    <StyledModalContent>
                        <p>This will stop this model deployment. It will immediately become unavailable. Are you sure?</p>
                        <StyledButton onClick={() => handleStopDeployment(false)}>Yes, Stop</StyledButton>
                        <StyledButton onClick={() => setConfirmStop(false)}>No, Cancel</StyledButton>
                    </StyledModalContent>
                </StyledConfirmModal>
                <StyledConfirmModal open={confirmForceRemove} onClose={() => setConfirmForceRemove(false)}>
                    <StyledModalContent>
                        <p>This will forcibly remove this model deployment from the list. If it's still running, it will be stopped. Are you sure?</p>
                        <StyledButton onClick={() => handleStopDeployment(true)}>Yes, Force Remove</StyledButton>
                        <StyledButton onClick={() => setConfirmForceRemove(false)}>No, Cancel</StyledButton>
                    </StyledModalContent>
                </StyledConfirmModal>
            </StyledModalContent>
        </StyledConfirmModal>
    );
};

export default ModelDeploymentDetailModal;