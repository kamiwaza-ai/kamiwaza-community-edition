import React, { useContext } from 'react';
import { AppBar, Toolbar, Box } from '@mui/material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { 
  StyledHeader, 
  StyledSubHeader, 
  StyledButton,
  StyledLink,
  StyledHeaderToolbar,
  StyledLogoBox
} from '../../StyledComponents';

const Header = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: 'white', boxShadow: 2 }}>
      <StyledHeaderToolbar>
        <StyledLogoBox>
          <img src="/logo_65_65.png" alt="Kamiwaza Logo" style={{ height: '50px', marginRight: '15px' }} />
          <StyledHeader component="div">
            Kamiwaza
          </StyledHeader>
        </StyledLogoBox>
        {user ? (
          <>
            <StyledSubHeader sx={{ 
              marginRight: 2, 
              fontSize: '1.1rem', 
              color: 'primary.main'
            }}>
              Welcome, {user.username}
            </StyledSubHeader>
            <StyledButton onClick={handleLogout}>
              Logout
            </StyledButton>
          </>
        ) : (
          <StyledLink to="/login" component={RouterLink}>
            <StyledButton>
              Login
            </StyledButton>
          </StyledLink>
        )}
      </StyledHeaderToolbar>
    </AppBar>
  );
};

export default Header;