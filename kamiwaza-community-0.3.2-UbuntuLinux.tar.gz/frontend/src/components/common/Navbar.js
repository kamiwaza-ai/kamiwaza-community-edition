import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import { StyledButton, StyledHeader } from '../../StyledComponents';
import { BASE_URL, LAB_URL } from '../../const';

const Navbar = () => {
  const { user } = useContext(AuthContext);
  const theme = useTheme();

  const navButtonStyle = {
    color: theme.palette.primary.contrastText,
    backgroundColor: 'transparent',
    margin: '0 8px',
    fontFamily: "'Montserrat', 'Roboto', sans-serif",
    fontWeight: 600,
    textTransform: 'none',
    fontSize: '0.9rem',
    padding: '6px 12px',
    transition: 'all 0.2s ease',
    '&:hover': {
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
    },
    '&:focus': {
      backgroundColor: 'rgba(255, 255, 255, 0.2)',
    },
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" sx={{ backgroundColor: theme.palette.primary.main, boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
        <Toolbar sx={{ display: 'flex', justifyContent: 'space-between', py: 0.5 }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <StyledButton component={Link} to="/" sx={navButtonStyle}>Home</StyledButton>
            <StyledButton component="a" href={`${LAB_URL}/lab`} target="_blank" rel="noopener noreferrer" sx={navButtonStyle}>Notebooks</StyledButton>
            <StyledButton component={Link} to="/models" sx={navButtonStyle}>Models</StyledButton>
            <StyledButton component={Link} to="/catalog" sx={navButtonStyle}>Catalog</StyledButton>
            <StyledButton component={Link} to="/activity" sx={navButtonStyle}>Activity</StyledButton>
            <StyledButton component={Link} to="/cluster/home" sx={navButtonStyle}>Cluster</StyledButton>
            <StyledButton component={Link} to="/vectordbs/home" sx={navButtonStyle}>VectorDBs</StyledButton>
            <StyledButton component="a" href={`${BASE_URL}/docs`} target="_blank" rel="noopener noreferrer" sx={navButtonStyle}>API Docs</StyledButton>
          </Box>
          {user && user.is_superuser && (
            <StyledButton component={Link} to="/admin" sx={{...navButtonStyle, marginLeft: 'auto'}}>Admin</StyledButton>
          )}
        </Toolbar>
      </AppBar>
    </Box>
  );
};

export default Navbar;