// frontend/src/context/AuthContext.js
import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../const';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await axios.get(`${BASE_URL}/auth/verify-token`, {
          withCredentials: true
        });
        if (response.data) {
          setUser(response.data);
        }
      } catch (error) {
        console.error('Auth check failed', error);
        setUser(null);
      }
      setLoading(false);
    };
  
    checkAuth();
  }, []);

  const verifyToken = async (token) => {
    try {
      const response = await fetch(`${BASE_URL}/auth/verify-token`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const userData = await response.json();
        return userData;
      } else {
        throw new Error('Token verification failed');
      }
    } catch (error) {
      console.error('Error verifying token:', error);
      return null;
    }
  };

  const login = async (credentials) => {
    try {
      const response = await axios.post(`${BASE_URL}/auth/token`, credentials, {
        withCredentials: true,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });
      const userResponse = await axios.get(`${BASE_URL}/auth/users/me`, {
        withCredentials: true
      });
      setUser(userResponse.data);
      return userResponse.data;
    } catch (error) {
      console.error('Login failed', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await axios.post(`${BASE_URL}/auth/logout`, {}, { withCredentials: true });
      setUser(null);
    } catch (error) {
      console.error('Logout failed', error);
    }
  };

  const createUser = async (userData) => {
    if (!user || !user.is_superuser) {
      throw new Error('Unauthorized: Only admins can create users');
    }
    try {
      const response = await axios.post(`${BASE_URL}/auth/users/`, userData, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      return response.data;
    } catch (error) {
      console.error('User creation failed', error);
      throw error;
    }
  };

  const getWelcomeMessage = () => {
    return user ? `Welcome, ${user.username}` : '';
  };

  const fetchUserData = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/auth/users/me`, {
        withCredentials: true
      });
      setUser(response.data);
    } catch (error) {
      console.error('Failed to fetch user data', error);
      setUser(null);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      login, 
      logout, 
      createUser, 
      getWelcomeMessage, 
      fetchUserData,
      verifyToken
    }}>
      {children}
    </AuthContext.Provider>
  );
};
