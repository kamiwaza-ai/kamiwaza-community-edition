#!/bin/bash

# Function to check if an image is in use
is_image_in_use() {
    local image_id=$1
    if docker ps -a --filter ancestor=$image_id --format '{{.ID}}' | grep -q .; then
        return 0  # Image is in use
    else
        return 1  # Image is not in use
    fi
}

# Get the list of images and their tags, without using uniq
image_tags=$(docker images --format "{{.ID}}:{{.Repository}}:{{.Tag}}" | sort)

# Loop through images and their tags
echo "Checking for duplicate image tags..."
prev_image_id=""
while IFS=: read -r image_id repo tag; do
    # If this image ID is the same as the previous one, it's a duplicate tag
    if [ "$image_id" == "$prev_image_id" ] && [ "$tag" != "latest" ]; then
        # Check if image is in use
        if is_image_in_use $image_id; then
            echo "Skipping $repo:$tag (image in use)"
        else
            # Attempt to remove the redundant tag
            echo "Removing redundant tag $repo:$tag"
            if docker rmi "$repo:$tag" >/dev/null 2>&1; then
                echo "Removed: $repo:$tag"
            else
                echo "Error: Could not remove $repo:$tag. Might be referenced in multiple repositories."
            fi
        fi
    fi

    # Store the current image ID for the next iteration
    prev_image_id="$image_id"
done <<< "$image_tags"

echo "Cleanup complete."
