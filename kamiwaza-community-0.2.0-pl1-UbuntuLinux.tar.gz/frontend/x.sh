#!/bin/bash

# Define the output file
output_file="/tmp/jscode.txt"

# Clear the output file
> "$output_file"

# Find all .js files and concatenate them
find src -name "*.js" -print0 | while IFS= read -r -d '' file; do
    # Add filename as a header
    echo "=== $file ===" >> "$output_file"

    # Append the file's contents to the output file
    cat "$file" >> "$output_file"

    # Optionally add a newline or separator after each file's contents
    echo -e "\n" >> "$output_file"
done

echo "Concatenation complete. All JS files are merged into $output_file."

