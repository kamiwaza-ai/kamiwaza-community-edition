// ClusterList.js
import React, { useState, useEffect, useContext } from 'react';
import { Link, useLocation } from 'react-router-dom';
import axios from 'axios';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const ClusterList = () => {
    const [clusters, setClusters] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const fetchClusters = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/clusters`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setClusters(response.data);
                } else {
                    throw new Error(`Failed to fetch clusters from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchClusters();
    }, []);

    return (
        <StyledMainContent className="crudlist">
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <StyledHeader>Cluster List</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {clusters.length === 0 && !loading ? (
                <StyledParagraph>No clusters available.</StyledParagraph>
            ) : (
                <ul>
                    {clusters.map(cluster => (
                        <li key={cluster.id}>
                            <Link to={`/cluster/${cluster.id}`}>{cluster.name}</Link>
                        </li>
                    ))}
                </ul>
            )}
        </StyledMainContent>
    );
};

export default ClusterList;
