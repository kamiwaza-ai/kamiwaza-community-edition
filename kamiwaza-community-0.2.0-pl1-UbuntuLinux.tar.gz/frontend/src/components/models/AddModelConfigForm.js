// addModelConfigForm.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledModal, StyledButton, StyledTable, StyledTableCell, StyledTextField, StyledModalContent, StyledSubHeader, StyledTooltipText } from '../../StyledComponents';

const AddModelConfigForm = ({ closeModal, showModal, model_id, setParentModelConfigs }) => {
    const [modelConfigData, setModelConfigData] = useState({});
    const [showAllConfigFields, setShowAllConfigFields] = useState(false);

    useEffect(() => {
        const fetchDefaultModelConfig = async () => {
            try {
                const response = await axios.get(`${BASE_URL}/models/${model_id}/configs?default=True`);
                if (response.status === 200 && response.data.length < 1) {
                    alert("WARNING: No default model configuration found. You can try to re-download a .json config file if it is a hub model to regenerate a config. This should never happen.")
                }
                if (response.status === 200 && response.data.length > 0) {
                    const defaultConfigData = response.data[0]; // Since default=True, expect 0 or 1 configs

                    // Predefined keys that should always be visible, excluding 'model_id' and 'default' as they cannot be changed by the user
                    const alwaysVisibleKeys = [
                        'name', 'description', 'max_model_len', 'tensor_parallel_size',
                        'gpu_memory_utilization', 'temperature', 'max_num_sequences'
                    ];

                    // Refactor to separate config data into always visible and additional configs, excluding dropKeys
                    const dropKeys = ["id", "created_at", "modified_at", "model_id", "default"];
                    const { alwaysVisibleConfig, additionalConfig } = Object.keys(defaultConfigData).reduce((acc, key) => {
                        if (!dropKeys.includes(key)) {
                            if (alwaysVisibleKeys.includes(key)) {
                                acc.alwaysVisibleConfig[key] = ''; // Set default values to empty to allow user input
                            } else {
                                acc.additionalConfig[key] = defaultConfigData[key];
                            }
                        }
                        return acc;
                    }, { alwaysVisibleConfig: {}, additionalConfig: {} });

                    // Define tooltips for explaining each configuration option
                    const tooltips = {
                        name: 'The unique name for this model configuration.',
                        description: 'A brief description of what this model configuration is for.',
                        max_model_len: 'Maximum number of tokens of context length (input+output)',
                        max_num_sequences: 'The maximum number of sequences in a batch; 16-256+ depending on hardware and model size',
                        tensor_parallel_size: 'Number of GPUs to deploy onto; these must be on the same host',
                        gpu_memory_utilization: 'GPU memory utilization percentage; must be at least enough for model, input context, and kv/cache; Kamiwaza default gives substantially more to provide larger kv cache for performance',
                        temperature: 'Amount of chaos/randomness/creativity applied to the generation; higher is more creative; generally 0.01 to ~1.2 depending on model',
                        top_p: 'Nucleus sampling: selects the smallest set of tokens whose cumulative probability exceeds the threshold p.',
                        // Additional tooltips will be defined later
                    };

                    // Populate defaultModelConfigData with structured configs and tooltips
                    const defaultConfig = {
                        alwaysVisibleConfig,
                        additionalConfig,
                        tooltips,
                    };

                    setModelConfigData(defaultConfig);
                } else {
                    console.error('Failed to fetch default model config');
                }
            } catch (err) {
                console.error('Error fetching default model config:', err);
            }
        };

        if (showModal) {
            fetchDefaultModelConfig();
        }
    }, [showModal, model_id]);

    const handleAddModelConfig = async () => {
        // Required fields based on CreateModelConfig schema from model.py
        const requiredFields = ['name', 'dtype'];
        const submittedData = { ...modelConfigData['alwaysVisibleConfig'], ...modelConfigData['additionalConfig'] };
        // Check if all required fields are present
        const missingFields = requiredFields.filter(field => !submittedData[field]);
        if (missingFields.length > 0) {
            // Alert the user about missing required fields and abort the operation
            alert(`Error: Missing required fields: ${missingFields.join(', ')}`);
            for (const field of missingFields) {
                console.log(`${field}: ${submittedData[field]}`);
            }
            return;
        }

        // Construct the payload with only the fields that have been set by the user
        const modelConfigPayload = {
            model_id: model_id, // Assuming model_id is available in the scope
            default: false,
            name: submittedData.name,
            served_model_name: submittedData.served_model_name || 'model',
            ...(submittedData.dtype ? { dtype: submittedData.dtype } : {}),
            ...(submittedData.description ? { description: submittedData.description } : {}),
            ...(submittedData.max_length !== undefined && { max_length: submittedData.max_length }),
            ...(submittedData.max_num_seqs !== undefined && { max_num_seqs: submittedData.max_num_seqs }),
            ...(submittedData.swap_space !== undefined && { swap_space: submittedData.swap_space }),
            ...(submittedData.gpu_memory_req !== undefined && { gpu_memory_req: submittedData.gpu_memory_req }),
            ...(submittedData.enforce_eager !== undefined && { enforce_eager: submittedData.enforce_eager }),
            ...(submittedData.disable_log_requests !== undefined && { disable_log_requests: submittedData.disable_log_requests }),
            ...(submittedData.trust_remote_code !== undefined && { trust_remote_code: submittedData.trust_remote_code }),
            ...(submittedData.architectures && { architectures: submittedData.architectures }),
            ...(submittedData.rope_theta !== undefined && { rope_theta: submittedData.rope_theta }),
            ...(submittedData.rope_scaling !== undefined && { rope_scaling: submittedData.rope_scaling }),
        };

        try {
            const response = await axios.post(`${BASE_URL}/model_configs/`, modelConfigPayload);
            if (response.status === 200) {
                setParentModelConfigs((prevConfigs) => [...prevConfigs, response.data]);
                closeModal();
            } else {
                console.error('Failed to add model config');
            }
        } catch (err) {
            console.error('Add model config error:', err);
        }
    };

    const handleInputChange = (event) => {
        const { name, value, type, checked } = event.target;
        // Determine if the field is part of alwaysVisibleConfig or additionalConfig
        const isAlwaysVisibleConfig = name in modelConfigData.alwaysVisibleConfig;

        setModelConfigData(prevState => {
            // Update the correct part of the state based on the input name
            if (isAlwaysVisibleConfig) {
                return {
                    ...prevState,
                    alwaysVisibleConfig: {
                        ...prevState.alwaysVisibleConfig,
                        [name]: type === 'checkbox' ? checked : value,
                    },
                };
            } else {
                return {
                    ...prevState,
                    additionalConfig: {
                        ...prevState.additionalConfig,
                        [name]: type === 'checkbox' ? checked : value,
                    },
                };
            }
        });
    };

    const handleInputFocus = (event) => {
        const { name } = event.target;
        // Ensure the input remains controlled by not setting its value to undefined
        if (modelConfigData.alwaysVisibleConfig[name] === '') {
            setModelConfigData(prevState => ({
                ...prevState,
                alwaysVisibleConfig: {
                    ...prevState.alwaysVisibleConfig,
                    [name]: '' // Keep as empty string instead of setting to undefined
                }
            }));
        }
    };

    const renderConfigFields = (config, tooltips) => {
        // Check if config is not null or undefined before proceeding
        if (!config) return null; // Return null or an appropriate fallback

        return Object.keys(config).map((key) => (
            <React.Fragment key={key}>
                <tr>
                    <StyledTableCell>{key.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</StyledTableCell>
                    <StyledTableCell>
                        {key === 'enforce_eager' || key === 'disable_log_requests' ? (
                            <input
                                type="checkbox"
                                name={key}
                                checked={config[key]}
                                onChange={handleInputChange}
                            />
                        ) : (
                            <StyledTextField
                                name={key}
                                value={config[key]}
                                onChange={handleInputChange}
                                onFocus={handleInputFocus}
                                placeholder={key in modelConfigData.alwaysVisibleConfig ? 'Enter value or leave blank for default' : ''}
                            />
                        )}
                    </StyledTableCell>
                </tr>
                {tooltips[key] && (
                    <tr>
                        <StyledTableCell colSpan="2">
                            <StyledTooltipText>{tooltips[key]}</StyledTooltipText>
                        </StyledTableCell>
                    </tr>
                )}
            </React.Fragment>
        ));
    };

    return (
        <StyledModal open={showModal} onClose={closeModal}>
            <StyledModalContent>
                <StyledTable>
                    <thead>
                        <tr>
                            <StyledTableCell>
                                <StyledSubHeader>Add New Model Configuration</StyledSubHeader>
                            </StyledTableCell>
                        </tr>
                    </thead>
                    <tbody>
                        {renderConfigFields(modelConfigData.alwaysVisibleConfig, modelConfigData.tooltips)}
                        {showAllConfigFields && renderConfigFields(modelConfigData.additionalConfig, modelConfigData.tooltips)}
                    </tbody>
                </StyledTable>
                {!showAllConfigFields && (
                    <StyledButton variant="secondary" onClick={() => setShowAllConfigFields(true)}>
                        Show ALL Config Fields
                    </StyledButton>
                )}
                <StyledButton variant="secondary" onClick={closeModal}>
                    Close
                </StyledButton>
                <StyledButton variant="primary" onClick={handleAddModelConfig}>
                    Add Model Config
                </StyledButton>
            </StyledModalContent>
        </StyledModal>
    );
};

export default AddModelConfigForm;

