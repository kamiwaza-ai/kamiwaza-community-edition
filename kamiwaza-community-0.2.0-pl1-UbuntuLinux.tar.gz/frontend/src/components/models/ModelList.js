// ModelList.js
import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import DownloadModal from './DownloadModal';
import ModelFilesContext from './ModelFilesContext';
import { BASE_URL } from '../../const';
import {
  StyledMainContent, StyledSubHeader, StyledButton, StyledTable, StyledTableHead,
  StyledTableCell, FixedStyledTable, FixedStyledTableCell, DescStyledDiv,
  StyledNegativeTableCell, StyledIconButton, StyledCloseButton, StyledNegativeButton
} from '../../StyledComponents';
import ReactMarkdown from 'react-markdown';
import Modal from 'react-modal';
import ConfirmModal from '../common/ConfirmModal'; // Import ConfirmModal component

Modal.setAppElement('#root'); // Set the app element for the modal

const ModelList = ({ models: propModels, search = false, clearSearchResults }) => {
    const [models, setModels] = useState(propModels || []);
    const [searchEnabled, setSearchEnabled] = useState(search);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [selectedModel, setSelectedModel] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [markdownModal, setMarkdownModal] = useState(false);
    const [markdownContent, setMarkdownContent] = useState('');
    const [confirmDelete, setConfirmDelete] = useState(false); // State for confirm delete modal
    const { setModelFiles } = useContext(ModelFilesContext);
    const { refreshModelList, setRefreshModelList } = useContext(ModelFilesContext);

    useEffect(() => {
        const fetchModels = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/models/`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setModels(response.data);
                } else {
                    throw new Error(`Failed to fetch models from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        if (!propModels) {
            fetchModels();
        }
    }, [propModels, refreshModelList]);

    const handleDownloadClick = async (model) => {
        setLoading(true);
        try {
            const response = await axios.post(`${BASE_URL}/model_files/search/`, {
                hub: model.hub,
                model: model.repo_modelId,
                version: model.version || ''
            });
            setSelectedModel({ ...model, files: response.data });
            setShowModal(true);
        } catch (err) {
            console.error('Error fetching files:', err);
            setError(err);
        } finally {
            setLoading(false);
        }
    };

    const handleDeleteClick = (model) => {
        setSelectedModel(model);
        setConfirmDelete(true);
    };

    const handleConfirmDelete = async () => {
        setLoading(true);
        try {
            const response = await axios.delete(`${BASE_URL}/models/${selectedModel.id}`);
            if (response.status === 200) {
                setModels(models.filter(model => model.id !== selectedModel.id));
                setConfirmDelete(false);
            } else {
                throw new Error(`Failed to delete model with id ${selectedModel.id}`);
            }
        } catch (err) {
            console.error('Error deleting model:', err);
            setError(err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <StyledMainContent>
            <StyledSubHeader>
                {!search ? "Your Models" : (
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    Model Search Results
                    {models.length > 0 && (
                        <StyledIconButton onClick={clearSearchResults} aria-label="close">
                            <StyledCloseButton />
                        </StyledIconButton>
                    )}
                  </div>
                )}
            </StyledSubHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {models.length === 0 && !loading ? (
                <p>No models available.</p>
            ) : (
                <FixedStyledTable>
                    <StyledTableHead>
                        <tr>
                            <StyledTableCell>Model Name</StyledTableCell>
                            <StyledTableCell>Download</StyledTableCell>
                            <StyledTableCell>Source</StyledTableCell>
                            {!search && <StyledNegativeTableCell>Delete</StyledNegativeTableCell>}
                        </tr>
                    </StyledTableHead>
                    <tbody>
                        {models.map(model => (
                            <tr key={model.id || model.repo_modelId}>
                                <StyledTableCell>
                                    {model.id ? (
                                        <a href={`/models/${model.id}`} title={model.name}>
                                            {model.name.substring(0, 100)}
                                        </a>
                                    ) : (
                                        <span title={model.repo_modelId}>
                                            {model.repo_modelId.substring(0, 100)}
                                        </span>
                                    )}
                                </StyledTableCell>
                                <StyledTableCell>
                                    <StyledButton onClick={() => handleDownloadClick(model)}>Download</StyledButton>
                                </StyledTableCell>
                                <StyledTableCell>
                                    <span onClick={() => window.open(model.source_repository, '_blank', 'noopener,noreferrer')} title="Open in New Window">
                                        {model.source_repository}<sup>↗️</sup>
                                    </span>
                                </StyledTableCell>
                                {!search && (
                                    <StyledTableCell>
                                        <StyledNegativeButton onClick={() => handleDeleteClick(model)}>Delete</StyledNegativeButton>
                                    </StyledTableCell>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </FixedStyledTable>
            )}
            {showModal && selectedModel && (
                <DownloadModal
                    model={selectedModel}
                    closeModal={() => setShowModal(false)}
                    showModal={showModal}
                    setModelFiles={setModelFiles} // Pass setModelFiles as a prop
                />
            )}
            {confirmDelete && selectedModel && (
                <ConfirmModal
                    title="Confirm Delete"
                    message="DELETING THIS MODEL WILL REMOVE ALL IT'S FILES. Do you want to delete it and all it's files?"
                    showModal={confirmDelete}
                    onConfirm={handleConfirmDelete}
                    onCancel={() => setConfirmDelete(false)}
                />
            )}
        </StyledMainContent>
    );
};

export default ModelList;
