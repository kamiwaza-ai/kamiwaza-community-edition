

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { Link } from 'react-router-dom';
import DatasetDetails from './DatasetDetails';

const DatasetList = () => {
    const [datasets, setDatasets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchDatasets = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/catalog/catalog/dataset`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setDatasets(response.data);
                } else {
                    throw new Error(`Failed to fetch datasets from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchDatasets();
    }, []);

    return (
        <div className="main-content">
            <h1>Dataset List</h1>
            {loading && <p>Loading...</p>}
            {error && <p>Error: {error.message}</p>}
            {datasets.length === 0 && !loading ? (
                <p>No datasets available.</p>
            ) : (
                <ul>
                    {datasets.map(dataset => (
                        <li key={dataset.id}>
                            <b>[{dataset.platform}]: </b> <Link to={`/catalog/dataset/${dataset.urn}`}>{dataset.id}</Link> {dataset.environment}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default DatasetList;
