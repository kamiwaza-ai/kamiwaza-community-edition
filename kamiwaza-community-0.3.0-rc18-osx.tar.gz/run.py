import asyncio
import os
import ray
import signal
from datetime import datetime, timezone
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from kamiwaza.scheduler.config import settings  # Adjust import path as needed
from kamiwaza.services.models.services import ModelService
from kamiwaza.serving.services import ServingService
from kamiwaza.cluster.services import ClusterService
from kamiwaza.cluster.models.cluster import DBMeta  # Adjust import path as needed
import logging

logger = logging.getLogger(__name__)

# Define a global event for signal handling
sleep_interrupt_event = asyncio.Event()

async def signal_handler(signum):
    sleep_interrupt_event.set()

async def store_periodic_pid():
    """Store the current process ID (PID) in the DBMeta table with the key 'periodic_pid'."""
    engine = create_engine(settings.database_url)
    Session = sessionmaker(bind=engine)
    session = Session()
    pid = os.getpid()
    try:
        periodic_pid_meta = session.query(DBMeta).filter(DBMeta.key == 'periodic_pid').first()
        if periodic_pid_meta:
            periodic_pid_meta.value = str(pid)
        else:
            new_meta = DBMeta(key='periodic_pid', value=str(pid))
            session.add(new_meta)
        session.commit()
    except Exception as e:
        logger.error(f"Failed to store periodic PID in the database: {e}")
    finally:
        session.close()

async def periodic_tasks():
    await store_periodic_pid()
    
    last_run_time = 0  # Initialize the last run time to 0
    
    while True:
        current_time = datetime.now(timezone.utc).timestamp()
        
        if current_time - last_run_time >= 1:
            model_service = ModelService()
            await model_service.process_downloads()
            
            serving_service = ServingService()
            await serving_service.health_check()

            cluster_service = ClusterService()
            await cluster_service.periodic_node_update()
            
            last_run_time = datetime.now(timezone.utc).timestamp()
        
        elapsed_time = datetime.now(timezone.utc).timestamp() - current_time
        sleep_time = max(settings.cycle_time - elapsed_time, 0)
        
        sleep_task = asyncio.create_task(asyncio.sleep(sleep_time))
        interrupt_task = asyncio.create_task(sleep_interrupt_event.wait())
        
        try:
            await asyncio.wait([sleep_task, interrupt_task], return_when=asyncio.FIRST_COMPLETED)
        finally:
            sleep_interrupt_event.clear()  # Reset the event for the next cycle


async def main():
    # Get the current event loop
    loop = asyncio.get_running_loop()
    
    # Register the signal handler within the event loop
    loop.add_signal_handler(signal.SIGUSR1, lambda: asyncio.create_task(signal_handler(signal.SIGUSR1)))
    
    # Run the periodic tasks
    await periodic_tasks()

if __name__ == "__main__":
    # Get environment variables
    kamiwaza_root = os.getenv("KAMIWAZA_ROOT")
    kamiwaza_lib_root = os.getenv("KAMIWAZA_LIB_ROOT")
    ray_init_address = os.getenv("KAMIWAZA_RAY_INIT_ADDRESS")

    # Prepare runtime environment
    runtime_env = {
        "env_vars": {
            "KAMIWAZA_ROOT": kamiwaza_root,
            "KAMIWAZA_LIB_ROOT": kamiwaza_lib_root,
            "PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION": "python"
        }
    }

    # Add PYTHONPATH if it exists in the environment
    if 'PYTHONPATH' in os.environ:
        runtime_env['env_vars']['PYTHONPATH'] = os.environ['PYTHONPATH']

    # Initialize Ray
    ray_params = {
        "runtime_env": runtime_env,
        "address": ray_init_address if ray_init_address else "auto"
    }
    ray.init(**ray_params)

    # Run the main async function
    asyncio.run(main())