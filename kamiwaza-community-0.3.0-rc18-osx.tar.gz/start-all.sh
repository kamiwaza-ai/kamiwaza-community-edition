#!/bin/bash

# start-all.sh should be in path with the venv; this should have the installer,
# etc. It may/may not have launch.py (dependant on environmentals)

START_DIR=$(dirname "${BASH_SOURCE[0]}")
START_DIR=$(realpath "${START_DIR}")
cd "${START_DIR}"

# Function to print messages in colors
print_in_color() {
    case $1 in
        green)
            echo -e "\033[92m$2\033[0m"
            ;;
        red)
            echo -e "\033[91m$2\033[0m"
            ;;
        yellow)
            echo -e "\033[93m$2\033[0m"
            ;;
        blue)
            echo -e "\033[94m$2\033[0m"
            ;;
        *)
            echo "$2"
            ;;
    esac
}

# Check for ~/.kamiwaza-installed
if [ -f ~/.kamiwaza-installed ]; then
    print_in_color green "Kamiwaza installation detected."
else
    if [ -f ./image-install.sh ]; then
        print_in_color yellow "Running image-install.sh..."
        source ./image-install.sh
        if [ $? -ne 0 ]; then
            print_in_color red "image-install.sh failed. Please check the errors and try again."
            exit 1
        fi
        newgrp docker
    else
        print_in_color red "~/.kamiwaza-installed not found and image-install.sh is missing. Please run the installer first."
        exit 1
    fi
fi

# Check if user is in docker group
if ! groups $USER | grep &>/dev/null '\bdocker\b'; then
    print_in_color red "User $USER is not in the docker group. Please add the user to the docker group and try again."
    exit 1
fi

# Check if user has access to Docker daemon
if ! docker info &> /dev/null; then
    print_in_color red "You do not have access to the Docker daemon. Please ensure your user is added to the 'docker' group, log out and log back in, and try again."
    exit 1
else
    print_in_color green "You have access to the Docker daemon."
fi

if [ ! -f containers-up.sh ] ; then
    print_in_color red "containers-up.sh not found, this is in the wrong directory or your install may have issues; support@kamiwaza.ai or discord"
    exit 1
fi

if [ ! -f restart-or-start-lab.sh ] ; then
    print_in_color red "restart-or-start-lab.sh not found, this is in the wrong directory or your install may have issues; support@kamiwaza.ai or discord"
    exit 1
fi

if [ ! -f start-ray.sh ] ; then
    print_in_color red "start-ray.sh not found, this is in the wrong directory or your install may have issues; support@kamiwaza.ai or discord"
    exit 1
fi

if [ ! -f venv/bin/activate ] ; then
    print_in_color red "venv/bin/activate not found, you are running from the wrong directory or have not run install.sh"
    exit 1
fi

# Attempt to fetch metadata from Azure's instance metadata service - if we are we will
# attempt to mount an ephemeral disk or, if present, an unmounted managed disk of
# appropriate (250G+) size
echo "Checking for Azure VM..."
metadata=$(timeout 2s curl -H "Metadata: true" -s -f "http://169.254.169.254/metadata/instance?api-version=2021-02-01")

# Check if the curl command was successful and the response contains "AzurePublicCloud"
if [[ $? -eq 0 && $metadata == *"AzurePublicCloud"* ]]; then
    # Metadata was successfully fetched and contains "AzurePublicCloud"
    AZUREVM=1
    print_in_color green "Azure VM detected."
else
    # The request failed or did not contain "AzurePublicCloud"
    AZUREVM=0
    echo "Not running on Azure VM."
fi

# If in Azure, proceed with disk mount script
if [[ $AZUREVM -eq 1 ]] ; then
    print_in_color blue "Attempting to mount disk..."
    if [ -f ../mountlocal.sh ] ; then
        cd ..
        bash ./mountlocal.sh
        cd -
    elif [ -f ./mountlocal.sh ] ; then
        bash ./mountlocal.sh
    fi
fi

cd "${START_DIR}"
print_in_color blue "Starting containers..."
bash containers-up.sh && sleep 5 && bash containers-up.sh > container_start.log 2>&1
print_in_color green "Done; container startup in container_start.log (both output and errors)"

cd "$START_DIR"
# Running the restart-or-start-lab.sh script and capturing its output
print_in_color blue "Starting Jupyter lab..."
bash restart-or-start-lab.sh > lab_startall_start.log 2>&1

sleep 1

# Grep for the JupyterLab URL token from the lab_start.log in either cwd or ./notebooks and print it
print_in_color yellow "JupyterLab URL(s):"
if [ -f jupyter_lab.log ]; then
    grep -E "http://.*token=|https://.*token=" jupyter_lab.log
elif [ -f ./notebooks/jupyter_lab.log ]; then
    grep -E "http://.*token=|https://.*token=" ./notebooks/jupyter_lab.log
else
    print_in_color red "lab_start.log not found in either cwd (`pwd`) or ./notebooks"
fi

deactivate || true

cd "$START_DIR"

# we basically want ray to have this but it does do it on its own (start-ray.sh) :shrug:
print_in_color blue "Activating virtual environment..."
source venv/bin/activate

# Call the start-ray.sh script to start Ray
print_in_color blue "Starting Ray..."
bash start-ray.sh

print_in_color blue "Setting up frontend..."
cd frontend
npm install
npm install -g webpack webpack-cli webpack-dev-server
nohup npm start > npm.log 2>&1 &
cd -

cd "$START_DIR"
deactivate || true
print_in_color blue "Reactivating virtual environment..."
source venv/bin/activate

# dev env things; not present in community/enterprise
if [ -f "dev-env.sh" ]; then
    print_in_color blue "Sourcing dev-env.sh..."
    source dev-env.sh
fi

print_in_color blue "Launching Kamiwaza..."
if [ -f "launch.py" ]; then
    python launch.py
elif [ -f "kamiwaza/launch.py" ]; then
    python kamiwaza/launch.py
else
    print_in_color red "launch.py not found in the current directory or in kamiwaza/"
    exit 1
fi