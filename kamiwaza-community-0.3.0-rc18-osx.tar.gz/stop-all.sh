#!/bin/bash

force_stop=false


# Set KAMIWAZA_ENV to 'default' if not set
if [ -z "$KAMIWAZA_ENV" ]; then
  KAMIWAZA_ENV="default"
fi

# Check for running Docker Compose projects with '*-kamiwaza-*' in their name
running_projects=$(docker compose ls | grep "\-kamiwaza\-" | awk '{print $1}')

# Extract the environment names from the running projects
mismatched_projects=()
for project in $running_projects; do
  env_name=$(echo "$project" | cut -d'-' -f1)
  if [ "$env_name" != "$KAMIWAZA_ENV" ]; then
    mismatched_projects+=("$project")
  fi
done

# If there are mismatched environments and force_stop is not true, exit with a message
if [ ${#mismatched_projects[@]} -gt 0 ] && [ "$force_stop" = false ]; then

  echo '!!!!WARNING'
  echo "The following kamiwaza containers are running that do not match the current KAMIWAZA_ENV ($KAMIWAZA_ENV):"
  for project in "${mismatched_projects[@]}"; do
    echo "$project"
  done
  echo ''
  echo 'The {name of script} script is not safe across multiple environments, so it is recommended to stop the running env first.'
  echo "(Note: stop-env.sh <env-name> can be used to turn down just containers but not other kamiwaza services)"
  echo ''
  echo "Use '-y' flag to ignore this warning and force stop all services (including containers but only for ${KAMIWAZA_ENV})."
  exit 1
fi

# Parse arguments
for arg in "$@"; do
  if [ "$arg" = "-y" ]; then
    force_stop=true
  fi
done

# Function to stop JupyterLab
stop_jupyter_lab() {
    echo "Stopping JupyterLab..."
    bash stop-lab.sh
}

# Function to terminate the kamiwaza process
terminate_kamiwaza_process() {
    echo "Terminating kamiwaza process..."
    kamiwaza_pids=$(ps auxwww | grep '[p]ython' | grep 'kamiwaza' | grep -v 'ms-python' | awk '{print $2}')
    if [ ! -z "$kamiwaza_pids" ]; then
        for pid in $kamiwaza_pids; do
            echo "Killing kamiwaza process with PID: $pid"
            kill "$pid"
            timeout=0
            while kill "$pid" 2> /dev/null; do
                if [ $timeout -ge 20 ]; then
                    echo "Force killing kamiwaza process with PID: $pid"
                    kill -9 "$pid"
                    break
                fi
                echo "Waiting for kamiwaza process PID $pid to terminate..."
                sleep 1
                timeout=$((timeout + 1))
            done
        done
    else
        echo "No kamiwaza process found."
    fi
}

# Function to terminate the frontend process
terminate_frontend_process() {
    echo "Terminating frontend process..."

    # Terminate npm start process
    npm_start_pids=$(ps auxwww | grep '[n]pm start' | awk '{print $2}')
    if [ ! -z "$npm_start_pids" ]; then
        for pid in $npm_start_pids; do
            echo "Killing npm start process with PID: $pid"
            kill "$pid"
            timeout=0
            while kill "$pid" 2> /dev/null; do
                if [ $timeout -ge 20 ]; then
                    echo "Force killing npm start process with PID: $pid"
                    kill -9 "$pid"
                    break
                fi
                echo "Waiting for npm start process PID $pid to terminate..."
                sleep 1
                timeout=$((timeout + 1))
            done
        done
    else
        echo "No npm start process found."
    fi

    # Terminate webpack process
    webpack_pids=$(ps auxwww | grep '[w]ebpack' | awk '{print $2}')
    if [ ! -z "$webpack_pids" ]; then
        for pid in $webpack_pids; do
            echo "Killing webpack process with PID: $pid"
            kill "$pid"
            timeout=0
            while kill "$pid" 2> /dev/null; do
                if [ $timeout -ge 20 ]; then
                    echo "Force killing webpack process with PID: $pid"
                    kill -9 "$pid"
                    break
                fi
                echo "Waiting for webpack process PID $pid to terminate..."
                sleep 1
                timeout=$((timeout + 1))
            done
        done
    else
        echo "No webpack process found."
    fi
}
# Function to stop Ray
stop_ray() {
    echo "Stopping Ray..."

    if [ ! -f venv/bin/activate ] ; then
        echo "venv/bin/activate not found, you are running from the wrong directory or have not run install.sh"
        if ! command -v ray &> /dev/null; then
            echo "Ray is not installed or not in PATH"
            return 1
        else
            echo "Running Ray stop without virtual environment"
            ray stop
            return 0
        fi
    fi

    source venv/bin/activate

    ray stop

    deactivate || true
}

# Function to stop Docker containers
stop_docker_containers() {
    echo "Stopping Docker containers..."
    bash stop-env.sh ${KAMIWAZA_ENV:-default}
}

# Confirm with the user if force_stop is not set
if [ "$force_stop" = false ]; then
    echo "Are you SURE you want to do this? This will stop JupyterLab, terminate kamiwaza and frontend processes, stop Ray, and stop Docker containers."
    read -p "Type 'yes' to continue: " confirmation
    if [ "$confirmation" != "yes" ]; then
        echo "Operation cancelled."
        exit 1
    fi
fi

# Execute the functions
stop_jupyter_lab
terminate_frontend_process
stop_ray
terminate_kamiwaza_process
stop_docker_containers

echo "All processes and containers have been stopped."

