#!/usr/bin/env python3

import os
import re
from typing import List

def get_environment_variable(variable_name: str, error_message: str) -> str:
    """
    Retrieves an environment variable value. Exits the script with an error message if the variable is not set.

    :param variable_name: Name of the environment variable to retrieve.
    :param error_message: Error message to display if the variable is not set.
    :return: Value of the environment variable.
    """
    value = os.environ.get(variable_name)
    if not value:
        print(error_message)
        exit(1)
    return value

def file_exists(file_path: str) -> None:
    """
    Checks if a file exists. Exits the script with an error message if the file does not exist.

    :param file_path: Path to the file to check.
    """
    if not os.path.isfile(file_path):
        print(f"Input file {file_path} not found")
        exit(1)

def process_file(input_file: str, output_file: str, datahub_version: str, actions_version: str) -> None:
    """
    Processes the input file, performing replacements based on environment variables, and writes the output to a new file.

    :param input_file: Path to the input file.
    :param output_file: Path to the output file.
    :param datahub_version: Value of the DATAHUB_VERSION environment variable.
    :param actions_version: Value of the ACTIONS_VERSION environment variable.
    """
    in_network_section = False  # Flag to track if we are within a network section
    with open(input_file, "r") as infile, open(output_file, "w") as outfile:
        for line in infile:
            line = re.sub(r'\$\{DATAHUB_VERSION:-head\}', datahub_version, line)
            line = re.sub(r'\$\{ACTIONS_VERSION:-head\}', actions_version, line)

            # Replace image variables with their default values
            if 'image:' in line and '${' in line:
                matches = re.findall(r'\$\{([^:]+):-([^\}]+)\}', line)
                for match in matches:
                    image_var, image_default_value = match
                    image_var_value = os.environ.get(image_var, image_default_value)
                    line = line.replace(f'${{{image_var}:-{image_default_value}}}', f'{image_var_value}')

            # Adjust paths as per instructions
            line = line.replace('../mysql', '${PWD}/volumes/mysql')
            line = line.replace('${HOME}', '${PWD}')

            # Check if we are entering or leaving a network section
            if 'networks:' in line:
                in_network_section = True
            elif in_network_section and re.match(r'^\s+name:', line):
                line = re.sub(r'name: (.+)', r'name: ${KAMIWAZA_ENV:-default}_\1', line)
            elif in_network_section and not line.startswith(' '):
                # If we are in a network section and encounter a line that starts at the beginning, we've left the section
                in_network_section = False

            outfile.write(line)

def main() -> None:
    """
    Main function to set up environment variables and process the vend-docker-compose.yml file.
    """
    datahub_version = get_environment_variable("DATAHUB_VERSION", "DATAHUB_VERSION is not set. Please set it before running this script.")
    actions_version = get_environment_variable("ACTIONS_VERSION", "ACTIONS_VERSION is not set. Please set it before running this script.")
    input_file = "vend-docker-compose.yml"
    output_file = "remapped-docker-compose.yml"
    file_exists(input_file)
    process_file(input_file, output_file, datahub_version, actions_version)
    print("Processing complete. Output saved in", output_file)

if __name__ == "__main__":
    main()

