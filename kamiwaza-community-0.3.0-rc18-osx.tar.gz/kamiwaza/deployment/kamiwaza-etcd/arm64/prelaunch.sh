#!/bin/bash
set -x

# Create necessary directories for certificates, secrets, and etcd volumes
mkdir -p ./certs
mkdir -p ./config
mkdir -p ./secrets
mkdir -p ./volumes/etcd

# Set the default node name environment variable
export KAMIWAZA_ETCD_NODE_NAME=${KAMIWAZA_ETCD_NODE_NAME:-kamiwaza0}

# Default values for CA configuration
: ${KAMIWAZA_CA_COMMON_NAME:="KAMIWAZA CA"}
: ${KAMIWAZA_CA_ORGANIZATION:="KAMIWAZA Inc."}
: ${KAMIWAZA_CA_ORGANIZATIONAL_UNIT:="Certificate Authority"}
: ${KAMIWAZA_CA_LOCALITY:="Internet"}
: ${KAMIWAZA_CA_STATE:="Digital"}
: ${KAMIWAZA_CA_COUNTRY:="US"}

# Check for existing certificates
CERT_FILES=("certs/ca.pem" "certs/ca-key.pem" "certs/ca.csr" "certs/kamiwaza0-key.pem" "certs/kamiwaza0.csr" "certs/kamiwaza0.pem" "certs/peer-kamiwaza0-key.pem" "certs/peer-kamiwaza0.csr" "certs/peer-kamiwaza0.pem")
EXISTING_CERTS=()
for FILE in "${CERT_FILES[@]}"; do
  if [[ -f "$FILE" ]]; then
    EXISTING_CERTS+=("$FILE")
  fi
done

# Get the absolute path of the current script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"


# Find the KAMIWAZA_ROOT folder by navigating up the directory tree
KAMIWAZA_ROOT="$SCRIPT_DIR"
while [[ "$KAMIWAZA_ROOT" != "/" && ! -f "$KAMIWAZA_ROOT/launch.py" ]]; do
    KAMIWAZA_ROOT="$(dirname "$KAMIWAZA_ROOT")"
done

# Check if KAMIWAZA_ROOT was found
if [[ ! -f "$KAMIWAZA_ROOT/launch.py" && ! -f "$KAMIWAZA_ROOT/install.py" ]]; then
    echo "Error: KAMIWAZA_ROOT not found. Please ensure launch.py or install.py exists in the expected directory structure."
    exit 1
fi

# Check for the 'deployment' directory in KAMIWAZA_ROOT
# installable kamiwaza will have launch.py or install.py in the KAMIWAZA_ROOT, but 
# other deployments will still have launch.py or install.py one folder down
if [[ -d "$KAMIWAZA_ROOT/deployment" ]]; then
    KAMIWAZA_ROOT="$(dirname "$KAMIWAZA_ROOT")"
fi

# Create the KAMIWAZA_ROOT/runtime folder if it doesn't exist
mkdir -p "${KAMIWAZA_ROOT}/runtime/etcd/certs"


if [[ ${#EXISTING_CERTS[@]} -eq ${#CERT_FILES[@]} ]]; then
  echo "All certificate files already exist."
  # Check if certificates exist in the runtime folder
  CERTS_IN_RUNTIME=()
  for FILE in "${CERT_FILES[@]}"; do
    if [[ -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/$FILE" ]]; then
      CERTS_IN_RUNTIME+=("$FILE")
    fi
  done
  if [[ ${#CERTS_IN_RUNTIME[@]} -eq ${#CERT_FILES[@]} ]]; then
    echo "All certificate files already exist in the runtime folder. Exiting."
    exit 0
  else
    echo "Certificates exist, but not in the runtime folder. Copying..."
    for FILE in "${CERT_FILES[@]}"; do
      if [[ ! -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/$FILE" ]]; then
        echo "Copying $FILE to runtime folder..."
        cp -r "${SCRIPT_DIR}/$FILE" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
      fi
    done
    exit 0
  fi
else
  echo "Some or all certificate files are missing. Generating all certificates and configuration files."
fi

cat <<EOF > config/ca-config.json
{
  "signing": {
    "default": {
      "expiry": "8760h"
    },
    "profiles": {
      "client": {
        "usages": ["signing", "key encipherment", "client auth"],
        "expiry": "8760h"
      },
      "peer": {
        "usages": ["signing", "key encipherment", "server auth", "client auth"],
        "expiry": "8760h"
      }
    }
  }
}
EOF

# Write the ca-csr.json file dynamically
if [[ ! -f "./config/ca-csr.json" ]]; then
  cat <<EOF >./config/ca-csr.json
{
  "CN": "$KAMIWAZA_CA_COMMON_NAME",
  "key": {
    "algo": "ecdsa",
    "size": 384
  },
  "names": [
    {
      "C": "$KAMIWAZA_CA_COUNTRY",
      "ST": "$KAMIWAZA_CA_STATE",
      "L": "$KAMIWAZA_CA_LOCALITY",
      "O": "$KAMIWAZA_CA_ORGANIZATION",
      "OU": "$KAMIWAZA_CA_ORGANIZATIONAL_UNIT"
    }
  ]
}
EOF
fi
## end: ca-csr.json write

# Function to retrieve system IP addresses
get_system_ips() {
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux system IP extraction
    ip -4 addr | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v "127.0.0.1"
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    # MacOS system IP extraction
    ifconfig | grep inet | grep -v inet6 | grep -v "127.0.0.1" | awk '{print $2}'
  else
    echo "Unsupported OS type for IP extraction"
    return 1
  fi
}

# Create the req-csr.json file
create_req_csr_json() {
  local ips=($(get_system_ips))
  ips+=("127.0.0.1")  # Add localhost to the list of IPs
  ips+=("localhost")  # Add 'localhost' hostname
  ips+=("etcd")  # Add 'etcd' hostname for connections from docker containers (traefik)

  # Start the JSON file
  echo "{" > config/req-csr.json
  echo "  \"CN\": \"etcd\"," >> config/req-csr.json
  echo "  \"hosts\": [" >> config/req-csr.json

  # Add each IP to the JSON array
  local first=true
  for ip in "${ips[@]}"; do
    if [ "$first" = true ]; then
      first=false
    else
      echo "," >> config/req-csr.json
    fi
    echo "    \"$ip\"" >> config/req-csr.json
  done

  # Finish the JSON file
  echo "  ]," >> config/req-csr.json
  echo "  \"key\": {" >> config/req-csr.json
  echo "    \"algo\": \"ecdsa\"," >> config/req-csr.json
  echo "    \"size\": 384" >> config/req-csr.json
  echo "  }," >> config/req-csr.json
  echo "  \"names\": [" >> config/req-csr.json
  echo "    {" >> config/req-csr.json
  echo "      \"O\": \"autogenerated\"," >> config/req-csr.json
  echo "      \"OU\": \"etcd cluster\"," >> config/req-csr.json
  echo "      \"L\": \"the internet\"" >> config/req-csr.json
  echo "    }" >> config/req-csr.json
  echo "  ]" >> config/req-csr.json
  echo "}" >> config/req-csr.json
}

# Call the function to create req-csr.json
create_req_csr_json

# Check if a list of nodes is provided via environment variable
if [[ -n "$KAMIWAZA_ETCD_NODE_LIST" ]]; then
  # Split the comma-separated list into an array
  IFS=',' read -r -a NODE_LIST <<< "$KAMIWAZA_ETCD_NODE_LIST"
  INFRAS=()
  # Validate each node name against a hostname regular expression
  for NODE in "${NODE_LIST[@]}"; do
    # Regex to match valid hostnames (allows TLD/FQDN)
    if [[ "$NODE" =~ ^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$ ]]; then
      INFRAS+=("$NODE")
    else
      echo "Invalid hostname: $NODE"
    fi
  done
  # Default to single node if no valid hostnames are provided
  if [ ${#INFRAS[@]} -eq 0 ]; then
    echo "No valid hostnames provided. Defaulting to single node kamiwaza0."
    INFRAS=(kamiwaza0)
  fi
else
  # Default to single node if no node list is provided
  INFRAS=(kamiwaza0)
fi



# Generate CA certificate and key
cfssl gencert -initca config/ca-csr.json | cfssljson -bare certs/ca

# Generate client and peer certificates for each node
for NODE in "${INFRAS[@]}"; do
  # Client certificates
  cfssl gencert \
    -ca=certs/ca.pem \
    -ca-key=certs/ca-key.pem \
    -config=config/ca-config.json \
    -profile=client \
    config/req-csr.json | cfssljson -bare certs/${NODE}

  # Peer certificates
  cfssl gencert \
    -ca=certs/ca.pem \
    -ca-key=certs/ca-key.pem \
    -config=config/ca-config.json \
    -profile=peer \
    config/req-csr.json | cfssljson -bare certs/peer-${NODE}
done

# Copy certificates to the runtime folder
for FILE in "${CERT_FILES[@]}"; do
  if [[ ! -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/$FILE" ]]; then
    echo "Copying $FILE to runtime folder..."
    cp -r "${SCRIPT_DIR}/$FILE" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
  fi
done

for NODE in "${INFRAS[@]}"; do
  # Client certificates
  if [[ ! -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/${NODE}.pem" ]]; then
    echo "Copying client certificate for $NODE to runtime folder..."
    cp -r "${SCRIPT_DIR}/certs/${NODE}.pem" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
  fi

  # Peer certificates
  if [[ ! -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/peer-${NODE}.pem" ]]; then
    echo "Copying peer certificate for $NODE to runtime folder..."
    cp -r "${SCRIPT_DIR}/certs/peer-${NODE}.pem" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
  fi

  # Peer key
  if [[ ! -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/peer-${NODE}-key.pem" ]]; then
    echo "Copying peer key for $NODE to runtime folder..."
    cp -r "${SCRIPT_DIR}/certs/peer-${NODE}-key.pem" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
  fi

  # CA certificate
  if [[ ! -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/ca.pem" ]]; then
    echo "Copying CA certificate to runtime folder..."
    cp -r "${SCRIPT_DIR}/certs/ca.pem" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
  fi
done

echo "Certificate creation and copying complete. Configuration files have been set up."
