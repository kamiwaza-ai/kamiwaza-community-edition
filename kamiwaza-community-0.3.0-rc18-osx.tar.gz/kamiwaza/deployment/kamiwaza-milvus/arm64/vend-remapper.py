#!/usr/bin/env python3

import os
import re
from typing import Optional

def get_environment_variable(variable_name: str, error_message: str) -> str:
    """
    Retrieves an environment variable value. Exits the script with an error message if the variable is not set.

    :param variable_name: Name of the environment variable to retrieve.
    :param error_message: Error message to display if the variable is not set.
    :return: Value of the environment variable.
    """
    value = os.environ.get(variable_name)
    if not value:
        print(error_message)
        exit(1)
    return value

def file_exists(file_path: str) -> None:
    """
    Checks if a file exists. Exits the script with an error message if the file does not exist.

    :param file_path: Path to the file to check.
    """
    if not os.path.isfile(file_path):
        print(f"Input file {file_path} not found")
        exit(1)

def process_file(input_file: str, output_file: str) -> None:
    """
    Processes the input file, specifically looking for network section replacements, and writes the output to a new file.
    Strips out any line containing 'container_name:'.

    :param input_file: Path to the input file.
    :param output_file: Path to the output file.
    """
    in_network_section = False  # Flag to track if we are within a network section
    with open(input_file, "r", encoding="utf-8") as infile, open(output_file, "w", encoding="utf-8") as outfile:
        for line in infile:
            # Skip lines containing 'container_name:'
            if 'container_name:' in line:
                continue

            # Check if we are entering or leaving a network section
            if 'networks:' in line:
                in_network_section = True
            elif in_network_section and re.match(r'^\s+name:', line):
                line = re.sub(r'name: (.+)', r'name: ${KAMIWAZA_ENV:-default}_\1', line)
            elif in_network_section and not line.startswith(' '):
                # If we are in a network section and encounter a line that starts at the beginning, we've left the section
                in_network_section = False

            outfile.write(line)

def main() -> None:
    """
    Main function to process the vend-docker-compose.yml file.
    """
    input_file = "vend-docker-compose.yml"
    output_file = "remapped-docker-compose.yml"
    file_exists(input_file)
    process_file(input_file, output_file)
    print("Processing complete. Output saved in", output_file)

if __name__ == "__main__":
    main()

