import React, { useContext } from 'react';
import { StyledFloatingWindow, StyledDownloadStatusModalContent, StyledButton, StyledDownloadProgressBar, StyledDownloadStatusText, StyledDownloadStatusItem } from '../../StyledComponents';
import ModelFilesContext from './ModelFilesContext'; // Import ModelFilesContext

const DownloadStatusModal = ({ closeModal }) => {
    const { statusModelFiles, clearCompletedDownloads } = useContext(ModelFilesContext); // Use clearCompletedDownloads from context

    // Override the onClose method to prevent closing on escape
    const handleOnClose = (event, reason) => {
        if (reason !== 'backdropClick' && reason !== 'escapeKeyDown') {
            closeModal();
        }
    };

    return (
        statusModelFiles.length > 0 ? // Render the component if statusModelFiles has items
        <StyledFloatingWindow>
            <StyledDownloadStatusModalContent>
                {statusModelFiles.map((status, index) => (
                    <StyledDownloadStatusItem key={index}>
                        <StyledDownloadStatusText variant="body1">{status.name}</StyledDownloadStatusText>
                        <StyledDownloadProgressBar variant="determinate" value={status.download_percentage || 0} />
                        {status.storage_location && !status.dl_requested_at ? (
                            <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold', color: 'green' }}>
                                Complete{status.download_elapsed ? ` (${status.download_elapsed})` : ''}
                            </StyledDownloadStatusText>
                        ) : status.dl_requested_at && !status.is_downloading ? (
                            <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold' }}>Queued</StyledDownloadStatusText>
                        ) : (
                            <>
                                <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold' }}>
                                    {status.download_elapsed} / {status.download_remaining}
                                </StyledDownloadStatusText>
                                <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold' }}>{status.download_throughput}</StyledDownloadStatusText>
                            </>
                        )}
                    </StyledDownloadStatusItem>
                ))}
                <StyledButton onClick={clearCompletedDownloads}>Clear Completed</StyledButton> {/* Use clearCompletedDownloads from context */}
            </StyledDownloadStatusModalContent>
        </StyledFloatingWindow>
        : null
    );
};

export default DownloadStatusModal;
