// addModelConfigForm.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledModal, WrappedTextDescStyledDiv, StyledButton, StyledTable, StyledTableCell, StyledTextField, StyledModalContent, StyledSubHeader, StyledTooltipText, StyledCollapseButton } from '../../StyledComponents';

const AddModelConfigForm = ({ closeModal, showModal, m_id, setParentModelConfigs }) => {
    const [modelConfigData, setModelConfigData] = useState({
        general: {
            name: '',
            description: '',
        },
        vLLM: {
            max_model_len: '',
            worker_use_ray: null,
            pipeline_parallel_size: '',
            tensor_parallel_size: '',
            max_parallel_loading_workers: '',
            block_size: '',
            seed: '',
            swap_space: '',
            gpu_memory_utilization: '',
            max_num_batched_tokens: '',
            max_num_seqs: '',
            max_paddings: '',
            quantization: '',
            enforce_eager: null,
            max_context_len_to_capture: '',
            disable_custom_all_reduce: null,
            enable_lora: null,
            max_loras: '',
            max_lora_rank: '',
            lora_extra_vocab_size: '',
            lora_dtype: '',
            max_cpu_loras: '',
        },
        llamaCPP: {
            ctx_size: '',
            threads: '',
            threads_batch: '',
            rope_scaling: '',
            rope_freq_base: '',
            rope_freq_scale: '',
            yarn_ext_factor: '',
            yarn_attn_factor: '',
            yarn_beta_slow: '',
            yarn_beta_fast: '',
            batch_size: '',
            memory_f32: null,
            mlock: null,
            n_gpu_layers: '',
            lora: '',
            lora_base: '',
            timeout: '',
            embedding: null,
            parallel: '',
            cont_batching: null,
            log_disable: null,
            slots_endpoint_disable: null,
            n_predict: '',
            override_kv: '',
            grp_attn_n: '',
            grp_attn_w: '',
            chat_template: '',
        },
        tooltips: {
            ctx_size: 'Size of the prompt context',
            threads: 'Number of threads to use during computation',
            threads_batch: 'Number of threads to use during batch and prompt processing',
            rope_scaling: 'RoPE frequency scaling method, defaults to linear unless specified by the model',
            rope_freq_base: 'RoPE base frequency (default: loaded from model)',
            rope_freq_scale: 'RoPE frequency scaling factor, expands context by a factor of 1/N',
            yarn_ext_factor: 'YaRN: extrapolation mix factor',
            yarn_attn_factor: 'YaRN: scale sqrt(t) or attention magnitude',
            yarn_beta_slow: 'YaRN: high correction dim or alpha',
            yarn_beta_fast: 'YaRN: low correction dim or beta',
            batch_size: 'Batch size for prompt processing',
            memory_f32: 'Use f32 instead of f16 for memory key+value (not recommended)',
            mlock: 'Force system to keep model in RAM rather than swapping or compressing',
            n_gpu_layers: 'Number of layers to store in VRAM',
            lora: 'Apply LoRA adapter (implies --no-mmap)',
            lora_base: 'Optional model to use as a base for the layers modified by the LoRA adapter',
            timeout: 'Server read/write timeout in seconds',
            embedding: 'Enable embedding vector output',
            parallel: 'Number of slots for process requests',
            cont_batching: 'Enable continuous batching (a.k.a dynamic batching)',
            log_disable: 'Disables logging to a file',
            slots_endpoint_disable: 'Disables slots monitoring endpoint',
            n_predict: 'Maximum tokens to predict',
            override_kv: 'Advanced option to override model metadata by key',
            grp_attn_n: 'Set the group attention factor to extend context size through self-extend',
            grp_attn_w: 'Set the group attention width to extend context size through self-extend',
            chat_template: 'Set custom jinja chat template',
            max_model_len: 'Model context length. If unspecified, will be automatically derived from the model.',
            worker_use_ray: 'Use Ray for distributed serving, will be automatically set when using more than 1 GPU',
            pipeline_parallel_size: 'Number of pipeline stages',
            tensor_parallel_size: 'Number of tensor parallel replicas',
            max_parallel_loading_workers: 'Load model sequentially in multiple batches, to avoid RAM OOM when using tensor parallel and large models',
            block_size: 'Token block size',
            seed: 'Random seed',
            swap_space: 'CPU swap space size (GiB) per GPU',
            gpu_memory_utilization: 'The fraction of GPU memory to be used for the model executor, which can range from 0 to 1. If unspecified, will use the default value of 0.9.',
            max_num_batched_tokens: 'Maximum number of batched tokens per iteration',
            max_num_seqs: 'Maximum number of sequences per iteration',
            max_paddings: 'Maximum number of paddings in a batch',
            quantization: 'Method used to quantize the weights. If None, we first check the `quantization_config` attribute in the model config file. If that is None, we assume the model weights are not quantized and use `dtype` to determine the data type of the weights.',
            enforce_eager: 'Always use eager-mode PyTorch. If False, will use eager mode and CUDA graph in hybrid for maximal performance and flexibility.',
            max_context_len_to_capture: 'Maximum context length covered by CUDA graphs. When a sequence has context length larger than this, we fall back to eager mode.',
            disable_custom_all_reduce: 'See ParallelConfig',
            enable_lora: 'If True, enable handling of LoRA adapters.',
            max_loras: 'Max number of LoRAs in a single batch.',
            max_lora_rank: 'Max LoRA rank.',
            lora_extra_vocab_size: 'Maximum size of extra vocabulary that can be present in a LoRA adapter (added to the base model vocabulary).',
            lora_dtype: 'Data type for LoRA. If auto, will default to base model dtype.',
            max_cpu_loras: 'Maximum number of LoRAs to store in CPU memory. Must be >= than max_num_seqs. Defaults to max_num_seqs.',
        },
    });
    const [showAllConfigFields, setShowAllConfigFields] = useState(false);
    const [showVLLMFields, setShowVLLMFields] = useState(false);
    const [showLlamaCPPFields, setShowLlamaCPPFields] = useState(false);

    useEffect(() => {
        const fetchDefaultModelConfig = async () => {
            try {
                const response = await axios.get(`${BASE_URL}/models/${m_id}/configs?default=true`);
                if (response.status === 200) {
                    if (response.data.length > 0) {
                        const defaultConfigData = response.data[0]; // Since default=True, expect 0 or 1 configs
    
                        // Check if the config object is empty
                        if (Object.keys(defaultConfigData.config).length === 0) {
                            console.log("Default config data found but the config object is empty.");
                            // Optionally, handle the empty config case differently here
                        } else {
                            // Process the config data
                            const { general, vLLM, llamaCPP } = Object.entries(defaultConfigData.config).reduce((acc, [key, value]) => {
                                if (key.startsWith('vllm_')) {
                                    acc.vLLM[key.substring(5)] = value; // Remove prefix
                                } else if (key.startsWith('llama_cpp_')) {
                                    acc.llamaCPP[key.substring(10)] = value; // Remove prefix
                                } else {
                                    acc.general[key] = value;
                                }
                                return acc;
                            }, { general: {}, vLLM: {}, llamaCPP: {} });
    
                            console.log("Processed general config:", general);
                            console.log("Processed vLLM config:", vLLM);
                            console.log("Processed llamaCPP config:", llamaCPP);
    
                            setModelConfigData(prevState => ({
                                ...prevState,
                                general: { ...prevState.general, ...general },
                                vLLM: { ...prevState.vLLM, ...vLLM },
                                llamaCPP: { ...prevState.llamaCPP, ...llamaCPP },
                            })); // Update state
                        }
                    } else {
                        alert("WARNING: No default model configuration found. You can try to re-download a .json config file if it is a hub model to regenerate a config. This should never happen.");
                    }
                } else {
                    console.error('Failed to fetch default model config');
                }
            } catch (err) {
                console.error('Error fetching default model config:', err);
            }
        };
    
        if (showModal) {
            fetchDefaultModelConfig();
        }
    }, [showModal, m_id]);
    
    const handleAddModelConfig = async () => {
        const submittedData = {
            ...modelConfigData.general,
            ...modelConfigData.vLLM,
            ...modelConfigData.llamaCPP,
        };

        console.log("Submitted Data:", submittedData);

        // Construct the payload with only the fields that have been set by the user and are not null
        const modelConfigPayload = {
            m_id: m_id,
            default: false,
            name: submittedData.name,
            description: submittedData.description,
            config: Object.entries(submittedData).reduce((acc, [key, value]) => {
                if (key !== 'name' && key !== 'description' && value !== '' && value !== null) {
                    acc[key] = value;
                }
                return acc;
            }, {}),
        };

        console.log("Payload being sent:", modelConfigPayload);

        try {
            const response = await axios.post(`${BASE_URL}/model_configs/`, modelConfigPayload);
            if (response.status === 200) {
                setParentModelConfigs((prevConfigs) => [...prevConfigs, response.data]);
                closeModal();
            } else {
                console.error('Failed to add model config');
            }
        } catch (err) {
            console.error('Add model config error:', err);
        }
    };

    const handleInputChange = (event, section) => {
        const { name, value, type, checked } = event.target;
        setModelConfigData(prevState => ({
            ...prevState,
            [section]: {
                ...prevState[section],
                [name]: type === 'checkbox' ? checked : value,
            },
        }));
    };

    const renderConfigFields = (config, tooltips, section) => {
        console.log(`Rendering fields for section: ${section}`, config); // Debugging output

        return Object.entries(config).map(([key, value]) => {
            // Explicitly always render 'name' and 'description' fields in the 'general' section
            if (section === 'general' || key === 'name' || key === 'description' || (value !== '' && value !== null)) {
                return (
                    <React.Fragment key={key}>
                        <tr>
                            <StyledTableCell>{key}</StyledTableCell>
                            <StyledTableCell>
                                {typeof value === 'boolean' || value === null ? (
                                    <select
                                        name={key}
                                        value={value === null ? '' : value.toString()}
                                        onChange={(event) => handleInputChange(event, section)}
                                    >
                                        <option value="" disabled selected>Select...</option>
                                        <option value="true">Yes</option>
                                        <option value="false">No</option>
                                    </select>
                                ) : (
                                    <StyledTextField
                                        name={key}
                                        value={value}
                                        onChange={(event) => handleInputChange(event, section)}
                                        placeholder={section === 'general' ? 'Enter value or leave blank for default' : ''}
                                    />
                                )}
                            </StyledTableCell>
                        </tr>
                        {tooltips[key] && (
                            <tr>
                                <StyledTableCell colSpan="2">
                                    <StyledTooltipText>{tooltips[key]}</StyledTooltipText>
                                </StyledTableCell>
                            </tr>
                        )}
                    </React.Fragment>
                );
            }
            return null;
        });
    };

    return (
        <StyledModal open={showModal} onClose={closeModal}>
            <StyledModalContent>
                <StyledTable>
                    <thead>
                        <tr>
                            <StyledTableCell>
                                <StyledSubHeader>Add New Model Configuration</StyledSubHeader>
                                <WrappedTextDescStyledDiv style={{ width: '600px' }}>You must supply Name and Description for this config. The other fields are optional, and we will use defaults for values you do not provide.
                                    Note: some config values overlap! Something like n_ctx that is used in both engines cannot be set twice even if set it in both sections.</WrappedTextDescStyledDiv>
                            </StyledTableCell>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <StyledTableCell colSpan="2">
                                <StyledSubHeader>General</StyledSubHeader>
                            </StyledTableCell>
                        </tr>
                        {renderConfigFields(modelConfigData.general, modelConfigData.tooltips, 'general')}
                        {showAllConfigFields && (
                            <>
                                <tr>
                                    <StyledTableCell colSpan="2">
                                        <StyledSubHeader>
                                            vLLM
                                            <StyledCollapseButton onClick={() => setShowVLLMFields(!showVLLMFields)}>
                                                {showVLLMFields ? '▼' : '▶'}
                                            </StyledCollapseButton>
                                        </StyledSubHeader>
                                    </StyledTableCell>
                                </tr>
                                {showVLLMFields && renderConfigFields(modelConfigData.vLLM, modelConfigData.tooltips, 'vLLM')}
                                <tr>
                                    <StyledTableCell colSpan="2">
                                        <StyledSubHeader>
                                            Llama.cpp
                                            <StyledCollapseButton onClick={() => setShowLlamaCPPFields(!showLlamaCPPFields)}>
                                                {showLlamaCPPFields ? '▼' : '▶'}
                                            </StyledCollapseButton>
                                        </StyledSubHeader>
                                    </StyledTableCell>
                                </tr>
                                {showLlamaCPPFields && renderConfigFields(modelConfigData.llamaCPP, modelConfigData.tooltips, 'llamaCPP')}
                            </>
                        )}
                    </tbody>
                </StyledTable>
                {!showAllConfigFields && (
                    <StyledButton variant="secondary" onClick={() => setShowAllConfigFields(true)}>
                        Show ALL Config Fields
                    </StyledButton>
                )}
                <StyledButton variant="secondary" onClick={closeModal}>
                    Close
                </StyledButton>
                <StyledButton variant="primary" onClick={handleAddModelConfig}>
                    Add Model Config
                </StyledButton>
            </StyledModalContent>
        </StyledModal>
    );
};

export default AddModelConfigForm;
