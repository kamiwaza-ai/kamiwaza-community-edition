import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const UserDetails = () => {
    const [user, setUser] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    let { '*': id } = useParams();

    useEffect(() => {
        const fetchUserDetails = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/user/${id}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setUser(response.data);
                } else {
                    throw new Error(`Failed to fetch user details from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchUserDetails();
    }, [id]);

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Clusters Home
            </StyledButton>
            <StyledButton component={Link} to="/cluster" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                {"<< Back to User List"}
            </StyledButton>
            <StyledHeader>User Details</StyledHeader>
            {loading && <StyledParagraph>Loading...</StyledParagraph>}
            {error && <StyledParagraph>Error: {error.message}</StyledParagraph>}
            <div className="user-list">
                {user && (
                    <div key={user.id} className="user-card">
                        <h2 className="user-name">{user.name}</h2>
                        <p className="user-info"><strong>ID:</strong> {user.id}</p>
                        <p className="user-info"><strong>Version:</strong> {user.version}</p>
                        <p className="user-info"><strong>Created At:</strong> {user.created_at}</p>
                    </div>
                )}
            </div>
        </StyledMainContent>
    );
};

export default UserDetails;
