import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledButton, StyledModalContent, StyledCircularProgress } from '../../StyledComponents';
import ErrorComponent from '../common/ErrorComponent';
import AddLocationModal from './AddLocationForm';
import { Link, useLocation } from 'react-router-dom';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const LocationList = () => {
    const [locations, setLocations] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const location = useLocation();

    useEffect(() => {
        setLoading(true);
        const fetchLocations = async () => {
            try {
                const response = await axios.get(`${BASE_URL}/cluster/locations`);
                if (response.status === 200) {
                    setLocations(response.data);
                } else {
                    throw new Error('Failed to fetch locations');
                }
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchLocations();
    }, []);

    const handleAddLocation = () => {
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
    };

    const addLocation = location => {
        setLocations(currentLocations => [...currentLocations, location]);
    };

    return (
        <StyledMainContent className="crudlist">
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <div className="header-with-button">
                <StyledHeader>Location List</StyledHeader>
                <StyledButton className="addButton" onClick={handleAddLocation} aria-label="Add new location"></StyledButton>
            </div>
            {loading && <StyledCircularProgress />}
            {error && <ErrorComponent message={error.message} />}
            {locations.length === 0 && !loading ? (
                <p>No locations available.</p>
            ) : (
                <ul>
                    {locations.map(location => (
                        <li key={location.id}>
                            <Link to={`/cluster/locations/${location.id}`}>{location.name}</Link>
                        </li>
                    ))}
                </ul>
            )}
            <AddLocationModal showModal={showModal} closeModal={closeModal} addLocation={addLocation} />
        </StyledMainContent>
    );
};

export default LocationList;
