import React, { useState, useEffect } from 'react';
import { styled } from '@mui/material/styles';
import { Typography, Box, Container, Button, Alert, CircularProgress } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import AppTemplateList from './AppTemplateList';
import AppDeploymentList from './AppDeploymentList';
import api from '../../utils/api';
import { BASE_URL } from '../../const';
import { useTour } from '../../contexts/TourContext';
import { useNavigate } from 'react-router-dom';

// Styled components
const PageContainer = styled(Container)(({ theme }) => ({
  paddingTop: theme.spacing(2),
  paddingBottom: theme.spacing(4),
  maxWidth: '1400px',
}));

const PageTitle = styled(Typography)(({ theme }) => ({
  color: theme.palette.primary.main,
  fontSize: '2.5rem',
  fontWeight: 700,
  marginBottom: theme.spacing(1),
  background: 'linear-gradient(90deg, #00c07f, #00c0a0)',
  backgroundClip: 'text',
  textFillColor: 'transparent',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
}));

const PageSubtitle = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.secondary,
  fontSize: '1.1rem',
  marginBottom: theme.spacing(4),
}));

const ImportButton = styled(Button)(({ theme }) => ({
  marginBottom: theme.spacing(3),
  background: 'linear-gradient(90deg, #00c07f, #00c0a0)',
  color: 'white',
  fontWeight: 600,
  padding: theme.spacing(1.5, 3),
  borderRadius: 8,
  '&:hover': {
    background: 'linear-gradient(90deg, #00a66b, #00a089)',
  },
  '&:disabled': {
    background: theme.palette.grey[300],
    color: theme.palette.grey[500],
  },
}));

const AppGarden = () => {
  const { startTour } = useTour();
  const navigate = useNavigate();
  const [refreshDeployments, setRefreshDeployments] = useState(false);
  const [refreshTemplates, setRefreshTemplates] = useState({ trigger: false });
  const [gardenStatus, setGardenStatus] = useState(null);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [hasDeployedModels, setHasDeployedModels] = useState(null);

  useEffect(() => {
    checkGardenStatus();
    syncRemoteApps(); // Add remote sync on page load, like news
    checkModelDeployments();
    
    // Start app garden tour after a delay
    const timer = setTimeout(() => {
      startTour('appGarden');
    }, 1500);

    return () => clearTimeout(timer);
  }, [startTour]);

  const checkGardenStatus = async () => {
    try {
      const response = await api.get('/apps/garden/status');
      setGardenStatus(response.data);
    } catch (error) {
      console.error('Error checking garden status:', error);
    }
  };

  const syncRemoteApps = async () => {
    try {
      // Call remote sync endpoint (has built-in 4-hour cache like news)
      const response = await api.post('/apps/remote/sync');
      
      if (response.data.success && response.data.imported_count > 0) {
        console.log(`Auto-synced ${response.data.imported_count} remote apps`);
        
        // Refresh garden status and templates after successful sync
        await checkGardenStatus();
        setRefreshTemplates({ trigger: !refreshTemplates.trigger });
        handleDeploymentChange();
      }
    } catch (error) {
      // Silently fail like news - don't show user errors for background sync
      console.warn('Background remote app sync failed:', error);
    }
  };

  const handleImportGardenApps = async () => {
    setImporting(true);
    setImportResult(null);

    try {
      const response = await api.post('/apps/garden/import');
      setImportResult(response.data);

      if (response.data.success) {
        // Refresh garden status after successful import
        await checkGardenStatus();
        
        // If we have imported templates, pass them to avoid extra API call
        if (response.data.imported_templates && response.data.imported_templates.length > 0) {
          setRefreshTemplates({ trigger: !refreshTemplates.trigger, newTemplates: response.data.imported_templates });
        } else {
          // Fallback to trigger refresh if no templates returned
          setRefreshTemplates({ trigger: !refreshTemplates.trigger });
        }
        
        handleDeploymentChange();
      }
    } catch (error) {
      console.error('Error importing garden apps:', error);
      setImportResult({
        success: false,
        errors: [error.response?.data?.detail || 'Failed to import garden apps'],
      });
    } finally {
      setImporting(false);
    }
  };

  const handleDeploymentChange = () => {
    // Toggle to trigger refresh in AppDeploymentList
    setRefreshDeployments(!refreshDeployments);
  };

  const checkModelDeployments = async () => {
    try {
      const response = await api.get('/serving/deployments');
      const deployments = Array.isArray(response.data) ? response.data : [];

      // Consider a model deployed if deployment is DEPLOYED, has non-zero lb_port,
      // and at least one instance is DEPLOYED (matches server-side selection logic)
      const anyDeployed = deployments.some(dep => {
        const hasPort = dep.lb_port && dep.lb_port !== 0;
        const isDeployed = dep.status === 'DEPLOYED';
        const hasDeployedInstance = Array.isArray(dep.instances) && dep.instances.some(inst => inst.status === 'DEPLOYED');
        return isDeployed && hasPort && hasDeployedInstance;
      });

      setHasDeployedModels(anyDeployed);
    } catch (error) {
      console.warn('Error checking model deployments for App Garden banner:', error);
      // On error, do not show the banner (avoid false warning)
      setHasDeployedModels(null);
    }
  };

  const shouldShowImportButton =
    gardenStatus?.garden_apps_available && gardenStatus?.missing_count > 0;

  return (
    <PageContainer>
      <Box sx={{ mb: 4 }}>
        <PageTitle variant="h1" data-tour="app-garden-title">
          App Garden
        </PageTitle>
        <PageSubtitle variant="body1">Deploy AI-Powered Applications with Ease</PageSubtitle>
      </Box>

      {/* Garden Import Section */}
      {hasDeployedModels === false && (
        <Box sx={{ mb: 3 }}>
          <Alert severity="warning" sx={{ display: 'flex', alignItems: 'center' }}>
            No models are currently deployed. Most apps require a deployed model to function.
            <Button
              color="warning"
              size="small"
              sx={{ ml: 2 }}
              onClick={() => navigate('/models')}
            >
              Go to Models
            </Button>
          </Alert>
        </Box>
      )}
      {shouldShowImportButton && (
        <Box sx={{ mb: 3 }}>
          <ImportButton
            startIcon={
              importing ? <CircularProgress size={20} color="inherit" /> : <DownloadIcon />
            }
            onClick={handleImportGardenApps}
            disabled={importing}
            data-tour="pull-images-button"
          >
            {importing
              ? 'Importing...'
              : `Import ${gardenStatus.missing_count} ${gardenStatus.missing_count === 1 ? 'App' : 'Apps'}`}
          </ImportButton>

          {gardenStatus.missing_apps?.length > 0 && (
            <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary', mt: 1 }}>
              Available apps: {gardenStatus.missing_apps.join(', ')}
            </Typography>
          )}
        </Box>
      )}

      {/* Import Results */}
      {importResult && (
        <Box sx={{ mb: 3 }}>
          <Alert
            severity={importResult.success ? 'success' : 'error'}
            onClose={() => setImportResult(null)}
            sx={{ mb: 2 }}
          >
            {importResult.success
              ? `Successfully imported ${importResult.imported_count} app${importResult.imported_count !== 1 ? 's' : ''}!`
              : 'Import failed'}
            {importResult.errors?.length > 0 && (
              <Box sx={{ mt: 1 }}>
                {importResult.errors.map((error, index) => (
                  <Typography key={index} variant="caption" sx={{ display: 'block' }}>
                    • {error}
                  </Typography>
                ))}
              </Box>
            )}
          </Alert>
        </Box>
      )}

      {/* Available App Templates */}
      <AppTemplateList
        onDeploymentChange={handleDeploymentChange}
        refreshTemplates={refreshTemplates}
      />

      {/* Deployed Applications */}
      <AppDeploymentList refreshDeployments={refreshDeployments} />
    </PageContainer>
  );
};

export default AppGarden;
