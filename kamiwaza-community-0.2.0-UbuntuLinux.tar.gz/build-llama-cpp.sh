#!/bin/bash

LLAMA_COMMIT=`cat llamacpp.commit`
# TODO validate commit format

mkdir -p llamacpp
cd llamacpp
if [ -d "llama.cpp" -a -d "llama.cpp/venv" ]; then
	deactivate
  	source venv/bin/activate
else
	mkdir -p llama.cpp
	deactivate
	python -m venv venv
	source venv/bin/activate
	git clone https://github.com/ggerganov/llama.cpp.git
fi

cd llama.cpp
# now build it 
git checkout -b kamiwaza $LLAMA_COMMIT
make clean
make
deactivate
