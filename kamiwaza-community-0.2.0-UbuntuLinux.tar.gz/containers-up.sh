#!/bin/bash
set -x

if [[ "$(uname)" == "Darwin" ]]; then
    platform='osx'
else
    platform='linux'
fi

arch_raw=$(uname -m)
if [[ "$arch_raw" == "x86_64" ]]; then
    arch='amd64'
elif [[ "$arch_raw" == "aarch64" || "$arch_raw" == "arm64" ]]; then
    arch='arm64'
else
    echo "Unsupported architecture: $arch_raw"
    exit 1
fi

if command -v nvidia-smi &> /dev/null && nvidia-smi > /dev/null 2>&1; then
    cpugpu='gpu'
else
    cpugpu='cpu'
fi

for component in $(find kamiwaza/deployment -mindepth 1 -maxdepth 1 -type d); do
    component=$(basename $component)
    if [[ "$cpugpu" == "gpu" ]]; then
        if [[ -d "kamiwaza/deployment/${component}/${arch}-gpu" ]]; then
            arch_folder="${arch}-gpu"
        elif [[ -d "kamiwaza/deployment/${component}/${arch}" ]]; then
            arch_folder="${arch}"
        elif [[ -d "kamiwaza/deployment/${component}/${arch}-cpu" ]]; then
            arch_folder="${arch}-cpu"
        else
            echo "No suitable architecture folder found for component: ${component}"
            continue
        fi
    else
        if [[ -d "kamiwaza/deployment/${component}/${arch}-cpu" ]]; then
            arch_folder="${arch}-cpu"
        elif [[ -d "kamiwaza/deployment/${component}/${arch}" ]]; then
            arch_folder="${arch}"
        elif [[ -d "kamiwaza/deployment/${component}/${arch}-gpu" ]]; then
            echo "################"
            echo "## WARNING: system appears to lack a gpu, but only gpu image available in ${component}"
            echo "################"
            continue
        else
            echo "No suitable architecture folder found for component: ${component}"
            continue
        fi
    fi
    cd "kamiwaza/deployment/${component}/${arch_folder}"
    if [[ -f "prelaunch.sh" ]]; then
        bash "prelaunch.sh"
    fi
    docker-compose -f "docker-compose.yml" -p ${component} up -d
    if [[ -f "launch.sh" ]]; then
        sleep 5
        bash "launch.sh"
    fi
    if [[ -f "postlaunch.sh" ]]; then
        sleep 5
        bash "postlaunch.sh"
    fi
    cd ../../../..

done
exit 0

