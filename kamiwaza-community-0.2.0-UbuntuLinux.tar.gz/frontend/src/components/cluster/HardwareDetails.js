import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const HardwareDetails = () => {
    const [hardware, setHardware] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    let { '*': id } = useParams();

    useEffect(() => {
        const fetchHardwareDetails = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/hardware/${id}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setHardware(response.data);
                } else {
                    throw new Error(`Failed to fetch hardware details from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchHardwareDetails();
    }, [id]);

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Hardware Home
            </StyledButton>
            <StyledHeader>Hardware Details</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            <div className="hardware-list">
                {hardware && hardware.map(hardware => (
                    <div key={hardware.id} className="hardware-card">
                        <StyledHeader>{hardware.name}</StyledHeader>
                        <StyledParagraph><strong>ID:</strong> {hardware.id}</StyledParagraph>
                        <StyledParagraph><strong>Node ID:</strong> {hardware.node_id}</StyledParagraph>
                        <StyledParagraph><strong>Location ID:</strong> {hardware.location_id}</StyledParagraph>
                    </div>
                ))}
            </div>
        </StyledMainContent>
    );
};

export default HardwareDetails;