// HardwareList.js
import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import { Link, useLocation } from 'react-router-dom';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const HardwareList = () => {
    const [hardware, setHardware] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const fetchHardware = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/hardware`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setHardware(response.data);
                } else {
                    throw new Error(`Failed to fetch hardware from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchHardware();
    }, []);

    return (
        <StyledMainContent className="crudlist">
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <StyledHeader>Hardware List</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {hardware.length === 0 && !loading ? (
                <StyledParagraph>No hardware available.</StyledParagraph>
            ) : (
                <ul>
                    {hardware.map(hw => (
                        <li key={hw.id}>
                            {hw.name} - {hw.description}
                        </li>
                    ))}
                </ul>
            )}
        </StyledMainContent>
    );
};

export default HardwareList;

