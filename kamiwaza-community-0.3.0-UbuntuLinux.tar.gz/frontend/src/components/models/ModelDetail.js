//ModelDetail.js

import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledTable, StyledTableCell, StyledTableHead, StyledButton, StyledModalContent } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ModelConfigList from './ModelConfigList'; // Import ModelConfigList component
import ModelDeploymentList from './ModelDeploymentList';
import AddModelConfigForm from './AddModelConfigForm'; // Assume similar to AddLocationForm
import { BASE_URL } from '../../const';

const ModelDetail = () => {
    const [model, setModel] = useState(null);
    const [modelConfigs, setModelConfigs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [showModal, setShowModal] = useState(false); // For AddModelConfigForm modal
    const [refreshDeployments, setRefreshDeployments] = useState(false); // State to trigger refresh of deployments
    const { model_id } = useParams();

    useEffect(() => {
        const fetchModelDetail = async () => {
            setLoading(true);
            try {
                console.log('fetching MODEL ' + model_id)
                const response = await axios.get(`${BASE_URL}/models/${model_id}`);
                setModel(response.data);
                setLoading(false);
            } catch (err) {
                if (err.response && err.response.status === 404) {
                    setError(new Error('Model not found'));
                } else {
                    setError(err);
                }
                setLoading(false);
            }
        };

        const fetchModelConfigs = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`${BASE_URL}/models/${model_id}/configs`);
                setModelConfigs(response.data);
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchModelDetail();
        fetchModelConfigs();
    }, [model_id]);

    const handleAddConfig = () => {
        setShowModal(true);
    };

    const addModelConfig = (newConfig) => {
        setModelConfigs([...modelConfigs, newConfig]);
    };

    const closeModal = () => {
        setShowModal(false);
    };

    // Callback to trigger refresh from child components
    const triggerRefreshDeployments = useCallback(() => {
        setRefreshDeployments(prevState => !prevState);
    }, []);

    if (loading) return <Spinner />;

    return (
        <StyledMainContent style={{ display: 'flex', flexDirection: 'row' }}>
            <div style={{ flex: 1 }}>
                <StyledButton component={Link} to="/models" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Back to Model List
                </StyledButton>
                {error ? (
                    <ErrorComponent message={error.message} />
                ) : model ? (
                    <StyledTable>
                        <tbody>
                            <tr><StyledTableCell>Name</StyledTableCell><StyledTableCell>{model.name}</StyledTableCell></tr>
                            {model.family && <tr><StyledTableCell>Family</StyledTableCell><StyledTableCell>{model.family}</StyledTableCell></tr>}
                            {model.purpose && <tr><StyledTableCell>Purpose</StyledTableCell><StyledTableCell>{model.purpose}</StyledTableCell></tr>}
                            {model.version && <tr><StyledTableCell>Version</StyledTableCell><StyledTableCell>{model.version}</StyledTableCell></tr>}
                            {model.author && <tr><StyledTableCell>Author</StyledTableCell><StyledTableCell>{model.author}</StyledTableCell></tr>}
                            {model.source_repository && <tr><StyledTableCell>Source Repository</StyledTableCell><StyledTableCell>{model.source_repository}</StyledTableCell></tr>}
                            {model.description && <tr><StyledTableCell>Description</StyledTableCell><StyledTableCell>{model.description}</StyledTableCell></tr>}
                            {model.sha_repository && <tr><StyledTableCell>SHA Repository</StyledTableCell><StyledTableCell>{model.sha_repository}</StyledTableCell></tr>}
                            {model.hub && <tr><StyledTableCell>Hub</StyledTableCell><StyledTableCell>{model.hub}</StyledTableCell></tr>}
                            {model.private !== null && <tr><StyledTableCell>Private</StyledTableCell><StyledTableCell>{model.private ? 'Yes' : 'No'}</StyledTableCell></tr>}
                            {model.m_files && model.m_files.length > 0 && <tr><StyledTableCell>Model Files</StyledTableCell><StyledTableCell>
                                <StyledTable style={{tableLayout: 'fixed', width: '100%'}}>
                                    <tbody>
                                        {model.m_files.map(file => {
                                            let fileSize = file.size;
                                            let unit = 'B';
                                            if (fileSize >= 1024) {
                                                fileSize /= 1024;
                                                unit = 'K';
                                            }
                                            if (fileSize >= 1024) {
                                                fileSize /= 1024;
                                                unit = 'M';
                                            }
                                            if (fileSize >= 1024) {
                                                fileSize /= 1024;
                                                unit = 'G';
                                            }
                                            // Determine the download status of the file
                                            let downloadStatus = '';
                                            if (file.is_downloading) {
                                                downloadStatus = ' (downloading)';
                                            } else if (file.download && file.storage_location !== null) {
                                                downloadStatus = ' (downloaded)';
                                            } else if (file.dl_requested_at !== null && !file.is_downloading) {
                                                downloadStatus = ' (queued)';
                                            }
                                            return (
                                                <tr key={file.id}>
                                                    <StyledTableCell style={{width: '45%', overflow: 'hidden', textOverflow: 'ellipsis'}}>{file.name}</StyledTableCell>
                                                    <StyledTableCell style={{width: '25%', overflow: 'hidden', textOverflow: 'ellipsis'}}>{fileSize.toFixed(1)}{unit}</StyledTableCell>
                                                    <StyledTableCell style={{width: '30%', overflow: 'hidden', textOverflow: 'ellipsis'}}>{downloadStatus}</StyledTableCell>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </StyledTable>
                            </StyledTableCell></tr>}
                        </tbody>
                    </StyledTable>
                ) : (
                    <StyledParagraph>Model not found</StyledParagraph>
                )}
            </div>
            {!error && model && (
                <div style={{ flex: 1, marginLeft: '20px' }}>
                    <ModelConfigList model_id={model_id} handleAddConfig={handleAddConfig} triggerRefreshDeployments={triggerRefreshDeployments} setParentModelConfigs={setModelConfigs} modelConfigs={modelConfigs} />
                    <AddModelConfigForm showModal={showModal} closeModal={closeModal} m_id={model_id} setParentModelConfigs={setModelConfigs} />
                    <div style={{ marginTop: '20px' }}>
                        <ModelDeploymentList model_id={model_id} refreshDeployments={refreshDeployments} />
                    </div>
                </div>
            )}
        </StyledMainContent>
    );
};

export default ModelDetail;
