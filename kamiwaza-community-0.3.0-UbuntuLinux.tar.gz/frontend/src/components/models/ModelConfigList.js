// ModelConfigList.js

import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledTable, StyledTableCell, StyledTableHead, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import { BASE_URL } from '../../const';

const ModelConfigList = ({ handleAddConfig, triggerRefreshDeployments, setParentModelConfigs, modelConfigs }) => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { model_id } = useParams();
    const navigate = useNavigate();

    const deployConfig = useCallback(async (configId) => {
        try {
            const configDetailResponse = await axios.get(`${BASE_URL}/model_configs/${configId}`);
            const configDetail = configDetailResponse.data;
            await axios.post(`${BASE_URL}/serving/deploy_model`, {
                m_id: model_id,
                m_config_id: configId
            });
            triggerRefreshDeployments(); // Refresh the deployment list after successful deployment
        } catch (err) {
            console.error("Failed to deploy model config:", err);
            // Handle error (e.g., show error notification)
        }
    }, [model_id, triggerRefreshDeployments]);

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    return (
        <StyledMainContent>
            <StyledHeader>Model Configurations</StyledHeader>
            {modelConfigs.length > 0 ? (
                <StyledTable>
                    <StyledTableHead>
                        <tr>
                            <StyledTableCell>Name</StyledTableCell>
                            <StyledTableCell>Description</StyledTableCell>
                            <StyledTableCell>Actions</StyledTableCell>
                        </tr>
                    </StyledTableHead>
                    <tbody>
                        {modelConfigs.map((config) => (
                            <tr key={config.id}>
                                <StyledTableCell>{config.name}</StyledTableCell>
                                <StyledTableCell>{config.description || 'No description available'}</StyledTableCell>
                                <StyledTableCell>
                                    <Link to={`/model_configs/${config.id}`}>View Config</Link>
                                    <StyledButton onClick={() => deployConfig(config.id)} variant="outlined">
                                        Deploy
                                    </StyledButton>
                                </StyledTableCell>
                            </tr>
                        ))}
                    </tbody>
                </StyledTable>
            ) : (
                <p>No model configurations found for this model.</p>
            )}
            <StyledButton onClick={handleAddConfig} variant="outlined">
                + New Config for Model
            </StyledButton>
        </StyledMainContent>
    );
};

export default ModelConfigList;
