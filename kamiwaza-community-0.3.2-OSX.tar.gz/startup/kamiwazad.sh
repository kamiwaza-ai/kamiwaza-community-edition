#!/bin/bash

set -e

# Ensure the script can be run from any directory
cd "$(dirname "${BASH_SOURCE[0]}")"
source ../set-kamiwaza-root.sh

if [ -f ${KAMIWAZA_ROOT:-..}/.kamiwaza_install_community ]; then
    export KAMIWAZA_COMMUNITY=true
fi

if [ ! -f ${KAMIWAZA_ROOT:-.}/env.sh ]; then
    bash ${KAMIWAZA_ROOT:-..}/first-boot.sh --community
fi

# Source configurations
if [ -f /etc/kamiwaza/env.sh ]; then
    source /etc/kamiwaza/env.sh
elif [ -f ../env.sh ]; then
    source ../env.sh
elif [ ! -f ../.kamiwaza_install_community ]; then
    echo " ###### WARNING ######: /etc/kamiwaza/env.sh does not exist. Contact support@kamiwaza.ai"
fi

# Locations
LOG_DIRS=("/opt/kamiwaza/logs" "/var/log" "/tmp")
LOGROTATE_CONF="/etc/logrotate.d/kamiwaza"

# Test each log directory for writeability
for dir in "${LOG_DIRS[@]}"; do
    if [ -d "$dir" ] && [ -w "$dir" ]; then
        LOG_DIR="$dir"
        break
    fi
done

if [ -z "${LOG_DIR:-}" ]; then
    echo "No writable log directory found in: ${LOG_DIRS[*]}"
    exit 1
fi

# Immediately rotate logs for a clean start
rotate_logs() {
    # Rotate logs in each configured directory
    for log_dir in "/opt/kamiwaza/logs" "/var/log" "/tmp"; do
        # Skip if directory doesn't exist
        [ ! -d "$log_dir" ] && continue
        
        # Rotate each log file up to 3 times before startup
        for logfile in kamiwazad-azure_disk_mount.log kamiwazad-containers.log kamiwazad-core.log kamiwazad-frontend.log kamiwazad-jupyter.log kamiwazad-ray.log kamiwazad.log; do
            if [ -f "${log_dir}/${logfile}" ]; then
                for i in $(seq 3 -1 1); do
                    if [ -f "${log_dir}/${logfile}.${i}" ]; then
                        mv "${log_dir}/${logfile}.${i}" "${log_dir}/${logfile}.$((i+1))"
                    fi
                done
                mv "${log_dir}/${logfile}" "${log_dir}/${logfile}.1"
            fi
        done
    done
}

# Worker detection logic
if [ -f "/etc/kamiwaza/config/is_worker" ]; then
    export KAMIWAZAD_IS_WORKER=1
elif [ -n "${KAMIWAZA_HEAD_IP:-}" ]; then
    ifconfig | grep inet | awk '{print $2}' | grep -q "^${KAMIWAZA_HEAD_IP}$" > /dev/null 2>&1
    export KAMIWAZAD_IS_WORKER=$?
else
    export KAMIWAZAD_IS_WORKER=0
fi

# Activate virtual environment and install dependencies
source "${KAMIWAZA_ROOT:-}/venv/bin/activate"
pip3 install -q python-dotenv psutil pyyaml || exit 1

# Define paths
PYTHON_INTERPRETER="${KAMIWAZA_ROOT:-}/venv/bin/python"
KAMIWAZA_SCRIPT="${KAMIWAZA_ROOT:-}/startup/kamiwazad.py"
PID_FILE="/tmp/kamiwazad.pid"
LOG_FILE="$LOG_DIR/kamiwazad.log"

if [ -z "${KAMIWAZA_ROOT:-}" ]; then
    echo "KAMIWAZA_ROOT is not set. Repair your install or contact support@kamiwaza.ai"
    exit 1
fi

cd "${KAMIWAZA_ROOT}"

setup_logging() {
    # Create log directory if it doesn't exist
    if [ ! -d "$LOG_DIR" ]; then
        mkdir -p "$LOG_DIR" 2>/dev/null || \
        sudo -n mkdir -p "$LOG_DIR" 2>/dev/null || \
        LOG_DIR="/tmp"

        # If sudo mkdir worked, set permissions
        if [ -d "$LOG_DIR" ] && [ "$LOG_DIR" != "/tmp" ]; then
            sudo -n chown "$USER:$(id -g)" "$LOG_DIR"
            sudo -n chmod 755 "$LOG_DIR"
        fi
    fi

    # Touch log file and set permissions if it doesn't exist
    if [ ! -f "$LOG_FILE" ]; then
        touch "$LOG_FILE" 2>/dev/null || sudo -n touch "$LOG_FILE"
        if [ -f "$LOG_FILE" ]; then
            sudo -n chown "$USER:$(id -g)" "$LOG_FILE"
            sudo -n chmod 644 "$LOG_FILE"
        fi
    fi
}

start() {
    local missing_only=false
    if [ "${1:-}" = "--missing" ]; then
        missing_only=true
    fi
    
    if [ -f $PID_FILE ]; then
        PID=$(cat $PID_FILE)
        if kill -0 $PID 2>/dev/null; then
            if [ "$missing_only" = true ]; then
                echo "Checking for missing services..."
                "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" start --missing
                return
            else
                echo "kamiwazad is already running (PID: $PID)"
                return
            fi
        else
            echo "Stale PID file found. Removing and starting kamiwazad..."
            rm $PID_FILE
        fi
    fi

    # Setup logging infrastructure
    setup_logging
    
    # Rotate logs before starting
    rotate_logs

    # Process cloud-init files if present
    if [ -f "/tmp/kamiwaza_public_key" ] && [ -f "/tmp/kamiwaza_known_host" ]; then
        echo "Ingesting Kamiwaza keys..."
        
        if ! grep -qf "/tmp/kamiwaza_known_host" "${CUSTOMER_KNOWN_HOSTS:-}"; then
            cat "/tmp/kamiwaza_known_host" >> "${CUSTOMER_KNOWN_HOSTS:-}"
            echo "Added known hosts entry from cloud-init"
        fi

        if [ ! -f "${CUSTOMER_PRIVATE_KEY:-}" ]; then
            cp "/tmp/kamiwaza_public_key" "${CUSTOMER_PRIVATE_KEY:-}"
            chmod 600 "${CUSTOMER_PRIVATE_KEY:-}"
            echo "Installed customer private key from cloud-init"
        fi

        rm -f "/tmp/kamiwaza_public_key" "/tmp/kamiwaza_known_host"
        echo "Removed temporary cloud-init files"
    fi
    
    echo "Starting kamiwazad..."
    nohup "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" start ${1:-} 1>"$LOG_FILE" 2>&1 & 
    PID=$!
    echo $PID > $PID_FILE
    
    # Wait briefly to check if process is still running
    sleep 1
    if kill -0 $PID 2>/dev/null; then
        echo "kamiwazad started with PID: $PID"
        echo "Logs available at: $LOG_FILE"
        echo "Log rotation configured in: $LOGROTATE_CONF"
    else
        echo "Failed to start kamiwazad. Check logs at: $LOG_FILE"
        rm -f $PID_FILE
        exit 1
    fi
}

stop() {
    local force_stop=false
    if [ -f $PID_FILE ]; then
        PID=$(cat $PID_FILE)
        if kill -0 $PID 2>/dev/null; then
            echo "kamiwazad is running (PID: $PID)"
            echo "Stopping kamiwazad daemon first..."
            "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" stop
            kill $PID
            rm $PID_FILE
            echo "kamiwazad daemon stopped"
        else
            echo "kamiwazad daemon not running (stale PID file found)"
            rm $PID_FILE
            force_stop=true
        fi
    else
        echo "kamiwazad daemon not running"
        force_stop=true
    fi

    # Even if kamiwazad isn't running, try to stop services
    if [ "$force_stop" = true ]; then
        echo "No running daemon found - attempting direct service shutdown..."
        echo "This may take a moment as we check each service..."
        "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" stop
    fi
}

status() {
    local check_all=false
    if [ "${1:-}" = "-a" ]; then
        check_all=true
    fi

    if [ -f $PID_FILE ]; then
        PID=$(cat $PID_FILE)
        if ps -p $PID > /dev/null; then
            echo "kamiwazad is running (PID: $PID)"
            "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" status
        else
            echo "kamiwazad is not running (stale PID file found)"
            rm $PID_FILE
            if [ "$check_all" = true ]; then
                echo "Checking service statuses directly..."
                "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" status -a
            fi
        fi
    else
        echo "kamiwazad is not running"
        if [ "$check_all" = true ]; then
            echo "Checking service statuses directly..."
            "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" status -a
        fi
    fi
}

case "${1:-}" in
    start)
        start "${2:-}"  # Pass second argument to start
        ;;
    stop)
        stop
        ;;
    restart)
        stop
        start
        ;;
    status)
        status "${2:-}"  # Pass the second argument to status
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status [-a]}"
        exit 1
        ;;
esac

exit 0