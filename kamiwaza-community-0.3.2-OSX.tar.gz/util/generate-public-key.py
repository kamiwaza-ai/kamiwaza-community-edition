import os
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend

def prompt_user_overwrite(file_path: str) -> bool:
    """Prompt the user for overwriting an existing file."""
    while True:
        response = input(f"{file_path} already exists. Do you want to overwrite it? (yes/no): ").strip().lower()
        if response in ['yes', 'no']:
            return response == 'yes'
        print("Please respond with 'yes' or 'no'.")

def generate_jwt_keypair(runtime_dir: str) -> None:
    """Generate JWT keypair and save to the specified runtime directory."""
    private_key_path = os.path.join(runtime_dir, 'jwt_private_key.pem')
    public_key_path = os.path.join(runtime_dir, 'jwt_public_key.pem')

    # Check if keys already exist
    if os.path.exists(private_key_path) or os.path.exists(public_key_path):
        if not prompt_user_overwrite(private_key_path) or not prompt_user_overwrite(public_key_path):
            print("Key generation aborted by user.")
            return

    # Generate a private key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )

    # Get the public key
    public_key = private_key.public_key()

    # Serialize the private key
    pem_private = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )

    # Serialize the public key
    pem_public = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    # Write the keys to files
    with open(private_key_path, 'wb') as f:
        f.write(pem_private)

    with open(public_key_path, 'wb') as f:
        f.write(pem_public)

    print(f"JWT keypair generated and saved in {runtime_dir}")

if __name__ == "__main__":
    runtime_dir = os.path.join(os.path.dirname(__file__), '..', 'runtime')
    os.makedirs(runtime_dir, exist_ok=True)
    generate_jwt_keypair(runtime_dir)
