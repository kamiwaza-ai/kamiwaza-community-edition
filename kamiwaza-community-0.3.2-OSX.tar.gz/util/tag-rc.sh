#!/bin/bash

set -e # Exit on error
set -o pipefail # Catch errors in pipelines

# Change to parent directory of script location
cd "$(dirname "${BASH_SOURCE[0]}")/.."

# Load environment variables
load_env_vars() {
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    if [ -f "$script_dir/deployment/build.env" ]; then
        source "$script_dir/deployment/build.env"
    else
        echo "Error: Missing build.env file" >&2
        exit 1
    fi
}

# Function to determine the next RC version number
get_next_rc_number() {
    local repo_dir="$1"
    local version_prefix="v${KAMIWAZA_VERSION_MAJOR}.${KAMIWAZA_VERSION_MINOR}.${KAMIWAZA_VERSION_PATCH}-rc"
    # Fetch tags and get the highest RC version number
    git fetch --tags
    local rc_version=$(git tag -l "${version_prefix}*" | sort -V | tail -n 1 | awk -F'rc' '{print $2}')
    if [ -z "$rc_version" ]; then
        echo 1 # If no previous RC, start with rc1
    else
        echo $((rc_version + 1)) # Increment existing RC version
    fi
}

# Function to tag and push for a given repository
tag_and_push() {
    local repo_dir="$1"
    cd "$repo_dir" || exit 1
    local branch=$(git symbolic-ref --short HEAD)
    if [ "$branch" != "main" ] && [ "$branch" != "master" ]; then
        echo "Error: Not on main or master branch." >&2
        exit 1
    fi

    git pull --ff-only || { echo "Error: Failed to pull latest changes from remote." >&2; exit 1; }
    local rc_number=$(get_next_rc_number "$repo_dir")
    local kamiwaza_version="v${KAMIWAZA_VERSION_MAJOR}.${KAMIWAZA_VERSION_MINOR}.${KAMIWAZA_VERSION_PATCH}-rc${rc_number}"
    git tag -a "$kamiwaza_version" -m "Release candidate $kamiwaza_version"
    git push origin "$kamiwaza_version" || { echo "Error: Failed to push tag to remote." >&2; exit 1; }
}

load_env_vars

# Tag current repo (.)
tag_and_push "."

# Tag subdirectory repos (./kamiwaza and ./kamiwaza-sdk)
tag_and_push "./kamiwaza"
tag_and_push "./kamiwaza-sdk"
