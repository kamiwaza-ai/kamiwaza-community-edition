import os
os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"

from kamiwaza.services.prompts.setup import setup as psetup
from kamiwaza.services.models.setup import setup as msetup
from kamiwaza.cluster.setup import setup as csetup
from kamiwaza.services.activity.setup import setup as asetup
from kamiwaza.serving.setup import setup as ssetup
from kamiwaza.services.auth.setup import setup as authsetup

def reset_all_databases(reset_db: bool = True, skip_confirmation: bool = False) -> None:
    """
    Reset all Kamiwaza databases to initial state.
    This is a destructive operation that will delete all data if reset_db is True.
    
    Args:
        reset_db: Whether to reset the databases. Defaults to True.
        skip_confirmation: Whether to skip the confirmation prompt. Defaults to False.
    """
    print("*** Resetting all databases...")
    
    psetup(reset_db=reset_db)
    msetup(reset_db=reset_db)
    csetup(reset_db=reset_db)
    asetup(reset_db=reset_db)
    ssetup(reset_db=reset_db)
    authsetup(reset_db=reset_db)
    
    print("*** Database reset complete")

if __name__ == "__main__":
    import sys
    skip_confirmation = "--force" in sys.argv
    
    if not skip_confirmation:
        # Confirm with user before proceeding
        response = input("This will delete ALL data from ALL databases. Are you sure? [y/N] ")
        if response.lower() != 'y':
            print("Database reset cancelled")
            sys.exit(0)
    
    reset_all_databases(reset_db=True, skip_confirmation=skip_confirmation)