#!/bin/bash
set -e

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --head)
            export KAMIWAZA_SWARM_HEAD=true
            shift
            ;;
        --worker)
            shift
            ;;
        --head-ip=*)
            export KAMIWAZA_HEAD_IP="${1#*=}"
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage:"
            echo "  For head node: $0 --head"
            echo "  For worker node: $0 --worker --head-ip=<head_ip>"
            exit 1
            ;;
    esac
done

# Check for required parameters
if [[ "${KAMIWAZA_SWARM_HEAD:-}" != "true" && -z "${KAMIWAZA_HEAD_IP:-}" ]]; then
    echo "Error: Must specify either --head or --worker with --head-ip"
    echo "Usage:"
    echo "  For head node: $0 --head"
    echo "  For worker node: $0 --worker --head-ip=<head_ip>"
    exit 1
fi

# Set up KAMIWAZA_ROOT from script directory
SCRIPT_DIR=$(dirname "${BASH_SOURCE[0]}")
source "${SCRIPT_DIR}/set-kamiwaza-root.sh"

cd "${SCRIPT_DIR}" || { echo "Failed to change to script directory"; exit 1; }

# Check if already set up
if [ -f ~/.kamiwaza-installed ]; then
    echo "Kamiwaza is already installed and configured."
    exit 0
fi

# Run disk setup
bash /opt/kamiwaza/kamiwaza/mountlocal.sh

# Ensure Docker group membership (this is critical)
if ! groups | grep -q '\bdocker\b'; then
    sudo usermod -aG docker $USER
    echo "Added to docker group - you must log out and back in"
    exit 1
fi

# Then ensure the environment file exists and has proper permissions
if [[ "${KAMIWAZA_COMMUNITY:-}" != "true" ]]; then
    # Enterprise edition: env.sh goes in /etc/kamiwaza
    sudo mkdir -p /etc/kamiwaza
    sudo touch /etc/kamiwaza/env.sh
    sudo chown ${USER}:${USER} /etc/kamiwaza/env.sh
    sudo chmod 640 /etc/kamiwaza/env.sh
else
    # Community edition: env.sh stays in KAMIWAZA_ROOT
    touch "${KAMIWAZA_ROOT}/env.sh"
    chmod 640 "${KAMIWAZA_ROOT}/env.sh"
fi

# Add near the start of first-boot.sh, after Docker group check
source common.sh
setup_environment

if [ -f /etc/kamiwaza/env.sh ]; then
    source /etc/kamiwaza/env.sh
else
    echo "No env.sh file found in /etc/kamiwaza - contact support@kamiwaza.ai - you should not use first-boot.sh without it."
    exit 1
fi

if [ ! -f "${KAMIWAZA_ROOT}/venv/bin/python3" ]; then
    echo "No venv/bin/python3 file found - contact support@kamiwaza.ai - you should not use first-boot.sh without it."
    exit 1
fi

# After the venv/python check but before NVM setup
if [[ "${KAMIWAZA_SWARM_HEAD:-}" != "true" ]]; then
    echo "Getting JWT public key from head node..."
    sudo mkdir -p /opt/kamiwaza/kamiwaza/runtime
    ssh -i /etc/kamiwaza/ssl/cluster.key -o StrictHostKeyChecking=no ${KAMIWAZA_HEAD_IP} \
        "sudo cat /opt/kamiwaza/kamiwaza/runtime/jwt_public_key.pem" | \
        sudo tee /opt/kamiwaza/kamiwaza/runtime/jwt_public_key.pem > /dev/null
else
    "${KAMIWAZA_ROOT}/venv/bin/python3" util/generate_jwt_keys.py
fi

# Set up NVM in /opt/kamiwaza/nvm
echo "Setting up NVM environment..."
if [ ! -d "/opt/kamiwaza/nvm" ]; then
    sudo mkdir -p /opt/kamiwaza/nvm
    sudo chown -R ${USER}:${USER} /opt/kamiwaza/nvm
fi

# Set up system-wide NVM config
if [ ! -f "/etc/profile.d/kamiwaza-nvm.sh" ]; then
    sudo tee /etc/profile.d/kamiwaza-nvm.sh << 'EOF'
export NVM_DIR="/opt/kamiwaza/nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
EOF
    sudo chmod 644 /etc/profile.d/kamiwaza-nvm.sh
fi

# Source NVM settings
export NVM_DIR="/opt/kamiwaza/nvm"

# Source NVM
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"

if ! command -v nvm &> /dev/null; then
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | NVM_DIR="/opt/kamiwaza/nvm" bash
    if ! command -v nvm &> /dev/null; then  
        echo "NVM was not available and failed to install. Contact support@kamiwaza.ai"
        exit 1
    fi
fi

# Handle Node installation and version checking
if ! command -v node &> /dev/null; then
    echo "Node not found. Installing Node 22..."
    nvm install 22
    nvm alias default 22
    nvm use 22
else
    node_version=$(node --version || echo "")
    if [[ ! "$node_version" =~ ^v22 ]]; then
        echo "Node version $node_version detected. Switching to Node 22..."
        nvm install 22
        nvm alias default 22
        nvm use 22
        
        # Check if version switched successfully
        node_version=$(node --version || echo "")
        if [[ ! "$node_version" =~ ^v22 ]]; then
            echo "ERROR: Unable to set Node version to 22"
            echo "This might be caused by:"
            echo "1. A system-wide Node installation"
            echo "2. PATH conflicts in your shell configuration"
            exit 1
        else
            echo "Successfully switched to Node 22"
        fi
    else
        echo "Node version $node_version detected."
    fi
fi


# Get primary group of current user
PRIMARY_GROUP=$(id -gn)

# Install and start kamiwazad service
sudo tee /etc/systemd/system/kamiwazad.service << EOF
[Unit]
Description=Kamiwaza Service Manager
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
ExecStart=/opt/kamiwaza/kamiwaza/startup/kamiwazad.sh start
ExecStop=/opt/kamiwaza/kamiwaza/startup/kamiwazad.sh stop
Restart=on-failure
User=${USER}
Group=${PRIMARY_GROUP}
WorkingDirectory=/opt/kamiwaza/kamiwaza
Environment=KAMIWAZA_ROOT=/opt/kamiwaza/kamiwaza
Environment=NVM_DIR=/opt/kamiwaza/nvm
StandardOutput=append:/opt/kamiwaza/logs/kamiwazad.log
StandardError=append:/opt/kamiwaza/logs/kamiwazad.log

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable kamiwazad
sudo systemctl start kamiwazad

# Mark as configured
touch ~/.kamiwaza-installed