#!/bin/bash
set -e

# use naive mode so etcd reads from file
export KAMIWAZA_INSTALL=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --community)
            export KAMIWAZA_COMMUNITY=true
            export KAMIWAZA_SWARM_HEAD=true
            shift
            ;;
        --head)
            export KAMIWAZA_SWARM_HEAD=true
            shift
            ;;
        --worker)
            shift
            ;;
        --head-ip=*)
            export KAMIWAZA_HEAD_IP="${1#*=}"
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage:"
            echo "  For community edition: $0 --community"
            echo "  For head node: $0 --head"
            echo "  For worker node: $0 --worker --head-ip=<head_ip>"
            exit 1
            ;;
    esac
done

# Check for required parameters
if [[ "${KAMIWAZA_COMMUNITY:-}" != "true" && "${KAMIWAZA_SWARM_HEAD:-}" != "true" && -z "${KAMIWAZA_HEAD_IP:-}" ]]; then
    echo "Error: Must specify either --community, --head or --worker with --head-ip"
    echo "Usage:"
    echo "  For community edition: $0 --community"
    echo "  For head node: $0 --head"
    echo "  For worker node: $0 --worker --head-ip=<head_ip>"
    exit 1
fi

# Set up KAMIWAZA_ROOT from script directory
SCRIPT_DIR=$(dirname "${BASH_SOURCE[0]}")
source "${SCRIPT_DIR}/set-kamiwaza-root.sh"

cd "${SCRIPT_DIR}" || { echo "Failed to change to script directory"; exit 1; }

# Check if already set up
if [ -f ~/.kamiwaza-installed ]; then
    echo "Kamiwaza is already installed and configured."
    exit 0
fi

# Ensure Docker group membership (this is critical)
if ! groups | grep -q '\bdocker\b'; then
    sudo usermod -aG docker $USER
    echo "Added to docker group - you must log out and back in"
    exit 1
fi

# Then ensure the environment file exists and has proper permissions
if [[ "${KAMIWAZA_COMMUNITY:-}" != "true" ]]; then
    # Enterprise edition: env.sh goes in /etc/kamiwaza
    sudo mkdir -p /etc/kamiwaza
    sudo mkdir -p /opt/kamiwaza/logs
    sudo touch /etc/kamiwaza/env.sh
    sudo chown ${USER}:${USER} /etc/kamiwaza/env.sh /opt/kamiwaza/logs
    sudo chmod 640 /etc/kamiwaza/env.sh
else
    # Community edition: env.sh stays in KAMIWAZA_ROOT
    touch "${KAMIWAZA_ROOT}/env.sh"
    chmod 640 "${KAMIWAZA_ROOT}/env.sh"
fi

# Add near the start of first-boot.sh, after Docker group check
source common.sh
setup_environment

if [[ "${KAMIWAZA_COMMUNITY:-}" != "true" ]]; then
    if [ -f /etc/kamiwaza/env.sh ]; then
        source /etc/kamiwaza/env.sh
    else
        echo "No env.sh file found in /etc/kamiwaza - contact support@kamiwaza.ai - you should not use first-boot.sh without it."
        exit 1
    fi
else
    if [ -f "${KAMIWAZA_ROOT}/env.sh" ]; then
        source "${KAMIWAZA_ROOT}/env.sh"
    fi
fi

if [ ! -f "${KAMIWAZA_ROOT}/venv/bin/python3" ]; then
    echo "No venv/bin/python3 file found - contact support@kamiwaza.ai - you should not use first-boot.sh without it."
    exit 1
fi

# After the venv/python check but before NVM setup
if [[ "${KAMIWAZA_SWARM_HEAD:-}" != "true" && "${KAMIWAZA_COMMUNITY:-}" != "true" ]]; then
    echo "Getting JWT public key from head node..."
    sudo mkdir -p ${KAMIWAZA_ROOT}/runtime
    ssh -i /etc/kamiwaza/ssl/cluster.key -o StrictHostKeyChecking=no ${KAMIWAZA_HEAD_IP} \
        "sudo cat ${KAMIWAZA_ROOT}/runtime/jwt_public_key.pem" | \
        sudo tee ${KAMIWAZA_ROOT}/runtime/jwt_public_key.pem > /dev/null
else
    "${KAMIWAZA_ROOT}/venv/bin/python3" util/generate_jwt_keys.py
fi

# flag that we should run a non-disruptive db upgrade
touch ${KAMIWAZA_ROOT}/.kamiwaza-db-reset
echo "Set flag for db upgrade"

# Only set up NVM for enterprise edition
if [[ "${KAMIWAZA_COMMUNITY:-}" != "true" ]]; then
    echo "Setting up NVM environment..."
    NVM_BASE="/opt/kamiwaza/nvm"
    sudo mkdir -p "${NVM_BASE}"
    sudo chown -R ${USER}:${USER} "${NVM_BASE}"

    # Set up NVM config
    if [ ! -f "/etc/profile.d/kamiwaza-nvm.sh" ]; then
        sudo tee /etc/profile.d/kamiwaza-nvm.sh << EOF
export NVM_DIR="${NVM_BASE}"
[ -s "\$NVM_DIR/nvm.sh" ] && \. "\$NVM_DIR/nvm.sh"
[ -s "\$NVM_DIR/bash_completion" ] && \. "\$NVM_DIR/bash_completion"
EOF
        sudo chmod 644 /etc/profile.d/kamiwaza-nvm.sh
    fi

    # Source NVM settings
    export NVM_DIR="${NVM_BASE}"

    # Source NVM
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"

    if ! command -v nvm &> /dev/null; then
        curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | NVM_DIR="${NVM_BASE}" bash
        if ! command -v nvm &> /dev/null; then  
            echo "NVM was not available and failed to install. Contact support@kamiwaza.ai"
            exit 1
        fi
    fi

    # Handle Node installation and version checking
    if ! command -v node &> /dev/null; then
        echo "Node not found. Installing Node 22..."
        nvm install 22
        nvm alias default 22
        nvm use 22
    else
        node_version=$(node --version || echo "")
        if [[ ! "$node_version" =~ ^v22 ]]; then
            echo "Node version $node_version detected. Switching to Node 22..."
            nvm install 22
            nvm alias default 22
            nvm use 22
            
            # Check if version switched successfully
            node_version=$(node --version || echo "")
            if [[ ! "$node_version" =~ ^v22 ]]; then
                echo "ERROR: Unable to set Node version to 22"
                echo "This might be caused by:"
                echo "1. A system-wide Node installation"
                echo "2. PATH conflicts in your shell configuration"
                exit 1
            else
                echo "Successfully switched to Node 22"
            fi
        else
            echo "Node version $node_version detected."
        fi
    fi
fi

# Get primary group of current user
PRIMARY_GROUP=$(id -gn)

# For community edition, logs go in KAMIWAZA_ROOT/logs
if [[ "${KAMIWAZA_COMMUNITY:-}" == "true" ]]; then
    LOG_DIR="/tmp"
else
    LOG_DIR="/opt/kamiwaza/logs"
fi

# Only set up kamiwazad service for enterprise edition
if [[ "${KAMIWAZA_COMMUNITY:-}" != "true" ]]; then
    # Install and start kamiwazad service
    sudo tee /etc/systemd/system/kamiwazad.service << EOF
[Unit]
Description=Kamiwaza Service Manager
After=network.target docker.service
Requires=docker.service

[Service]
Type=forking
PIDFile=/tmp/kamiwazad.pid
ExecStart=${KAMIWAZA_ROOT}/startup/kamiwazad.sh start
ExecStop=${KAMIWAZA_ROOT}/startup/kamiwazad.sh stop
Restart=always
RestartSec=30
StartLimitInterval=300
StartLimitBurst=5
User=${USER}
Group=${PRIMARY_GROUP}
WorkingDirectory=${KAMIWAZA_ROOT}
Environment=KAMIWAZA_ROOT=${KAMIWAZA_ROOT}
Environment=NVM_DIR=${NVM_BASE}
Environment=KAMIWAZA_COMMUNITY=${KAMIWAZA_COMMUNITY:-}
StandardOutput=append:${LOG_DIR}/kamiwazad.log
StandardError=append:${LOG_DIR}/kamiwazad.log

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable kamiwazad
    sudo systemctl start kamiwazad

    chmod a+x ${KAMIWAZA_ROOT}/startup/kamiwazad.sh || true
fi

unset KAMIWAZA_INSTALL

# Create logs directory if it doesn't exist
if [[ ! -d "${LOG_DIR}" ]]; then
    # Try to create with sudo first in case we don't have permissions
    if ! sudo mkdir -p "${LOG_DIR}" 2>/dev/null; then
        # Fall back to regular mkdir if sudo fails
        mkdir -p "${LOG_DIR}" || {
            echo "ERROR: Failed to create logs directory at ${LOG_DIR}" 
            exit 1
        }
    fi
    
    # Set permissions to allow writing logs
    sudo chown -R "${USER}:${PRIMARY_GROUP}" "${LOG_DIR}" || {
        echo "WARNING: Failed to set permissions on ${LOG_DIR}"
        # Don't exit since the directory exists and may still be writable
    }
fi

# Mark as configured
touch ~/.kamiwaza-installed