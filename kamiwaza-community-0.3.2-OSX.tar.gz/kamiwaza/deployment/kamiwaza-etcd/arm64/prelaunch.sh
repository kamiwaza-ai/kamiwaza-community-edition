#!/bin/bash
set -euo pipefail

# Create necessary directories for certificates, secrets, and etcd volumes
mkdir -p ./certs
mkdir -p ./config
mkdir -p ./secrets
mkdir -p ./volumes/etcd

# Set the default node name environment variable using hostname
export KAMIWAZA_ETCD_NODE_NAME=${KAMIWAZA_ETCD_NODE_NAME:-$(hostname)}
echo "Setting KAMIWAZA_ETCD_NODE_NAME to ${KAMIWAZA_ETCD_NODE_NAME}"

# Default values for CA configuration
: ${KAMIWAZA_CA_COMMON_NAME:="KAMIWAZA CA"}
: ${KAMIWAZA_CA_ORGANIZATION:="KAMIWAZA Inc."}
: ${KAMIWAZA_CA_ORGANIZATIONAL_UNIT:="Certificate Authority"}
: ${KAMIWAZA_CA_LOCALITY:="Internet"}
: ${KAMIWAZA_CA_STATE:="Digital"}
: ${KAMIWAZA_CA_COUNTRY:="US"}

# Check for existing certificates (updated to use hostname)
CERT_FILES=(
 "certs/ca.pem" 
 "certs/ca-key.pem" 
 "certs/ca.csr" 
 "certs/$(hostname)-key.pem" 
 "certs/$(hostname).csr" 
 "certs/$(hostname).pem" 
 "certs/peer-$(hostname)-key.pem" 
 "certs/peer-$(hostname).csr" 
 "certs/peer-$(hostname).pem"
)
EXISTING_CERTS=()
for FILE in "${CERT_FILES[@]}"; do
 if [[ -f "$FILE" ]]; then
   EXISTING_CERTS+=("$FILE")
 fi
done

# Get the absolute path of the current script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"

# Find the KAMIWAZA_ROOT folder by navigating up the directory tree
KAMIWAZA_ROOT="$SCRIPT_DIR"
while [[ "$KAMIWAZA_ROOT" != "/" && ! -f "$KAMIWAZA_ROOT/launch.py" && ! -f "$KAMIWAZA_ROOT/install.py" ]]; do
   KAMIWAZA_ROOT="$(dirname "$KAMIWAZA_ROOT")"
done

# dev layout
if [ -f "${KAMIWAZA_ROOT}/../compile.sh" ]; then
 KAMIWAZA_ROOT="$(dirname "$KAMIWAZA_ROOT")"
fi

# Check if KAMIWAZA_ROOT was found
if [[ ! -f "$KAMIWAZA_ROOT/launch.py" && ! -f "$KAMIWAZA_ROOT/install.py" ]]; then
   echo "Error: KAMIWAZA_ROOT not found. Please ensure launch.py or install.py exists in the expected directory structure."
   exit 1
fi

# Create the KAMIWAZA_ROOT/runtime folder if it doesn't exist
mkdir -p "${KAMIWAZA_ROOT}/runtime/etcd/certs"

# Determine if we are in community/single-node mode
if [[ -f "${KAMIWAZA_ROOT}/.kamiwaza_install_community" ]]; then
    is_community=true
else
    is_community=false
fi

if [[ "${KAMIWAZA_COMMUNITY:-}" == "true" ]]; then
    is_community=true
    echo "Operating in community/single-node mode..."
fi

# Function to generate ETCD certificates
generate_etcd_certs() {
   echo "Generating ETCD certificates..."
   cat <<EOF > config/ca-config.json
{
   "signing": {
       "default": {
           "expiry": "8760h"
       },
       "profiles": {
           "client": {
               "usages": ["signing", "key encipherment", "client auth"],
               "expiry": "8760h"
           },
           "peer": {
               "usages": ["signing", "key encipherment", "server auth", "client auth"],
               "expiry": "8760h"
           }
       }
   }
}
EOF

   # Write the ca-csr.json file dynamically
   if [[ ! -f "./config/ca-csr.json" ]]; then
       cat <<EOF >./config/ca-csr.json
{
   "CN": "$KAMIWAZA_CA_COMMON_NAME",
   "key": {
       "algo": "ecdsa",
       "size": 384
   },
   "names": [
       {
           "C": "$KAMIWAZA_CA_COUNTRY",
           "ST": "$KAMIWAZA_CA_STATE",
           "L": "$KAMIWAZA_CA_LOCALITY",
           "O": "$KAMIWAZA_CA_ORGANIZATION",
           "OU": "$KAMIWAZA_CA_ORGANIZATIONAL_UNIT"
       }
   ]
}
EOF
   fi

   # Function to retrieve system IP addresses
   get_system_ips() {
     if [[ "$OSTYPE" == "linux-gnu"* ]]; then
       # Linux system IP extraction
       ip -4 addr | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v "127.0.0.1"
     elif [[ "$OSTYPE" == "darwin"* ]]; then
       # MacOS system IP extraction
       ifconfig | grep inet | grep -v inet6 | grep -v "127.0.0.1" | awk '{print $2}'
     else
       echo "Unsupported OS type for IP extraction"
       return 1
     fi
   }

  # Create the req-csr.json file
  create_req_csr_json() {
      local node_name="${KAMIWAZA_ENV:-default}_kamiwaza-etcd-${KAMIWAZA_ETCD_NODE_NAME}"
      local ips=()
      
      # In community mode, only use localhost and container name
      if [[ "$is_community" == "true" ]]; then
          ips+=("127.0.0.1")
          ips+=("localhost")
          ips+=("${node_name}")
          ips+=("etcd")
      else
          # Original IP detection for non-community mode
          ips=($(ip -4 addr | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v "127.0.0.1"))
          ips+=("127.0.0.1")
          ips+=("localhost")
          ips+=("${node_name}")
          ips+=("etcd")
      fi

      # Start the JSON file
      echo "{" > config/req-csr.json
      echo "  \"CN\": \"etcd\"," >> config/req-csr.json
      echo "  \"hosts\": [" >> config/req-csr.json

      # Add each IP and DNS entry as SANs
      local first=true
      for entry in "${ips[@]}"; do
          if [ "$first" = true ]; then
              first=false
          else
              echo "," >> config/req-csr.json
          fi
          echo "    \"$entry\"" >> config/req-csr.json
      done

      # Finish the JSON structure
      echo "  ]," >> config/req-csr.json
      echo "  \"key\": {" >> config/req-csr.json
      echo "    \"algo\": \"ecdsa\"," >> config/req-csr.json
      echo "    \"size\": 384" >> config/req-csr.json
      echo "  }," >> config/req-csr.json
      echo "  \"names\": [" >> config/req-csr.json
      echo "    {" >> config/req-csr.json
      echo "      \"O\": \"autogenerated\"," >> config/req-csr.json
      echo "      \"OU\": \"etcd cluster\"," >> config/req-csr.json
      echo "      \"L\": \"the internet\"" >> config/req-csr.json
      echo "    }" >> config/req-csr.json
      echo "  ]" >> config/req-csr.json
      echo "}" >> config/req-csr.json
  }


   # Call the function to create req-csr.json
   create_req_csr_json

   # Generate CA certificate and key if they don't exist
   if [[ ! -f "./certs/ca.pem" || ! -f "./certs/ca-key.pem" ]]; then
       cfssl gencert -initca config/ca-csr.json | cfssljson -bare certs/ca
   fi

   # Generate peer certificates for this node
   cfssl gencert \
       -ca=certs/ca.pem \
       -ca-key=certs/ca-key.pem \
       -config=config/ca-config.json \
       -profile=peer \
       config/req-csr.json | cfssljson -bare "certs/peer-${KAMIWAZA_ETCD_NODE_NAME}"
}

# Simplified logic for community/single-node mode
if [[ "$is_community" == "true" ]]; then
    echo "Setting up single-node etcd configuration..."
    # Always generate certs in community mode if they don't exist locally
    if ! find "${SCRIPT_DIR}/certs" -name "*.pem" | grep -q .; then
        generate_etcd_certs
    fi

    # Always overwrite runtime certs with local certs in community mode
    echo "Copying local certificates to runtime folder (overwriting)..."
    cp -vf "${SCRIPT_DIR}/certs/ca.pem" "${SCRIPT_DIR}/certs/ca-key.pem" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
    cp -vf "${SCRIPT_DIR}/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}.pem" "${SCRIPT_DIR}/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}-key.pem" \
        "${KAMIWAZA_ROOT}/runtime/etcd/certs/"

    # Set single-node cluster configuration
    export KAMIWAZA_ETCD_ADVERTISE_PEER_URLS="https://${KAMIWAZA_ENV:-default}_kamiwaza-etcd-${KAMIWAZA_ETCD_NODE_NAME}:2380"
    export KAMIWAZA_ETCD_ADVERTISE_CLIENT_URLS="https://${KAMIWAZA_ENV:-default}_kamiwaza-etcd-${KAMIWAZA_ETCD_NODE_NAME}:2379"
    export KAMIWAZA_ETCD_INITIAL_CLUSTER="${KAMIWAZA_ENV:-default}_kamiwaza-etcd-${KAMIWAZA_ETCD_NODE_NAME}=https://${KAMIWAZA_ENV:-default}_kamiwaza-etcd-${KAMIWAZA_ETCD_NODE_NAME}:2380"
    export KAMIWAZA_ETCD_CLUSTER_STATE="new"
else
    # Determine if we are the head node
    is_head=false
    if [[ -n "${KAMIWAZA_HEAD_IP:-}" ]]; then
        # First try a clean check
        if ! ifconfig_out=$(ifconfig 2>&1); then
            # Only retry on error up to 3 times
            for i in {1..3}; do
                if ifconfig_out=$(ifconfig 2>&1); then
                    break
                elif [[ $i -lt 3 ]]; then
                    echo "Network interface check failed (attempt $i/3), retrying in 1s..."
                    sleep 1
                fi
            done
        fi
        
        # If we have output, check for IP match
        if [[ -n "$ifconfig_out" ]]; then
            echo "$ifconfig_out" | grep inet | awk '{print $2}' | grep -q "^${KAMIWAZA_HEAD_IP}$" && is_head=true
        fi
    else
        is_head=true  # No head IP means we're standalone/head
    fi

    if [[ "$is_head" == "true" ]]; then
        echo "Operating as head node..."
        
        # Check if certs exist in runtime but not locally
        if ! find "${SCRIPT_DIR}/certs" -name "*.pem" | grep -q . && \
           find "${KAMIWAZA_ROOT}/runtime/etcd/certs" -name "*.pem" | grep -q .; then
            echo "Found certificates in runtime, copying to local..."
            cp -v "${KAMIWAZA_ROOT}/runtime/etcd/certs/ca.pem" "${KAMIWAZA_ROOT}/runtime/etcd/certs/ca-key.pem" "${SCRIPT_DIR}/certs/"
            cp -v "${KAMIWAZA_ROOT}/runtime/etcd/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}.pem" \
                "${KAMIWAZA_ROOT}/runtime/etcd/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}-key.pem" "${SCRIPT_DIR}/certs/"
        fi

        # Generate certs if they still don't exist locally
        if ! find "${SCRIPT_DIR}/certs" -name "*.pem" | grep -q .; then
            generate_etcd_certs
        fi

        # Copy local certs to runtime
        cp -v "${SCRIPT_DIR}/certs/ca.pem" "${SCRIPT_DIR}/certs/ca-key.pem" "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
        cp -v "${SCRIPT_DIR}/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}.pem" "${SCRIPT_DIR}/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}-key.pem" \
            "${KAMIWAZA_ROOT}/runtime/etcd/certs/"

    else
        echo "Operating as worker node..."
        # Ensure cluster key exists and has right permissions
        if [[ ! -f "/etc/kamiwaza/ssl/cluster.key" ]]; then
            echo "Error: cluster.key not found"
            exit 1
        fi
        chmod 600 /etc/kamiwaza/ssl/cluster.key

        # Function to check if head node's etcd is ready
        check_head_etcd_ready() {
            ssh -i /etc/kamiwaza/ssl/cluster.key \
                -o StrictHostKeyChecking=no \
                -o UserKnownHostsFile=/dev/null \
                "${USER}@${KAMIWAZA_HEAD_IP}" \
                "docker ps --filter name=kamiwaza-etcd --format '{{.Status}}' | grep -q 'Up'"
            return $?
        }

        # Wait for head node's etcd to be ready
        echo "Waiting for head node etcd to be ready..."
        max_head_attempts=60  # 30 minutes with 30-second sleep
        head_attempt=1
        while [[ $head_attempt -le $max_head_attempts ]]; do
            if check_head_etcd_ready; then
                echo "Head node etcd is ready"
                break
            fi
            echo "Head node etcd not ready yet (attempt $head_attempt/$max_head_attempts)..."
            sleep 30
            ((head_attempt++))
        done

        if [[ $head_attempt -gt $max_head_attempts ]]; then
            echo "Error: Head node etcd failed to become ready after $(( max_head_attempts * 30 )) seconds"
            exit 1
        fi

        # Get CA certificates from head node with improved retry logic
        echo "Fetching CA certificates from head node..."
        max_attempts=10
        attempt=1
        while [[ $attempt -le $max_attempts ]]; do
            if scp -i /etc/kamiwaza/ssl/cluster.key \
                -o StrictHostKeyChecking=no \
                -o UserKnownHostsFile=/dev/null \
                -o ConnectTimeout=10 \
                "${USER}@${KAMIWAZA_HEAD_IP}:${SCRIPT_DIR}/certs/ca.pem" \
                "${USER}@${KAMIWAZA_HEAD_IP}:${SCRIPT_DIR}/certs/ca-key.pem" \
                "${SCRIPT_DIR}/certs/" 2>/dev/null; then
                
                echo "Successfully retrieved CA certificates from deployment path"
                
                # Copy CA certs to runtime
                cp -v "${SCRIPT_DIR}/certs/ca.pem" "${SCRIPT_DIR}/certs/ca-key.pem" \
                    "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
                
                break
            fi
            
            echo "Attempt $attempt failed. Waiting before retry..."
            sleep 15
            ((attempt++))
        done
        
        if [[ $attempt -gt $max_attempts ]]; then
            echo "Failed to retrieve CA certificates after $max_attempts attempts"
            exit 1
        fi

        # Generate our peer certificates in ./certs using the CA
        echo "Generating peer certificates..."
        generate_etcd_certs

        # Always overwrite runtime peer certs with our local ones
        echo "Copying local peer certificates to runtime (overwriting)..."
        cp -vf "${SCRIPT_DIR}/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}.pem" \
            "${SCRIPT_DIR}/certs/peer-${KAMIWAZA_ETCD_NODE_NAME}-key.pem" \
            "${KAMIWAZA_ROOT}/runtime/etcd/certs/"
    fi
fi

# Verify required certificates exist in both locations
required_certs=(
   "ca.pem"
   "peer-${KAMIWAZA_ETCD_NODE_NAME}.pem"
   "peer-${KAMIWAZA_ETCD_NODE_NAME}-key.pem"
)

for cert in "${required_certs[@]}"; do
   if [[ ! -f "${SCRIPT_DIR}/certs/$cert" ]]; then
       echo "Error: Required certificate $cert not found in local certs"
       exit 1
   fi
   if [[ ! -f "${KAMIWAZA_ROOT}/runtime/etcd/certs/$cert" ]]; then
       echo "Error: Required certificate $cert not found in runtime certs"
       echo "KAMIWAZA_ROOT: ${KAMIWAZA_ROOT}"
       exit 1
   fi
done

echo "ETCD certificates validated successfully"

# Configure etcd cluster membership
if [[ "$is_community" != "true" ]]; then
    source "${KAMIWAZA_ROOT}/etcd_cluster_manager.sh"
    build_cluster_config
fi

echo "Prelaunch check for etcd with the following configuration:"
echo "  Node Name: ${KAMIWAZA_ETCD_NODE_NAME:-Not Set}"
echo "  Advertise Peer URLs: ${KAMIWAZA_ETCD_ADVERTISE_PEER_URLS:-Not Set}"
echo "  Advertise Client URLs: ${KAMIWAZA_ETCD_ADVERTISE_CLIENT_URLS:-Not Set}" 
echo "  Initial Cluster: ${KAMIWAZA_ETCD_INITIAL_CLUSTER:-Not Set}"
echo "  Cluster State: ${KAMIWAZA_ETCD_CLUSTER_STATE:-Not Set}"
echo "  Mode: $(if [[ "$is_community" == "true" ]]; then echo "Community/Single-node"; else echo "Enterprise/Cluster"; fi)"