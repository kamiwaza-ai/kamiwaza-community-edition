import os
import sys
from kamiwaza.services.lab.spawner import KamiwazaLabSpawner
from kamiwaza.services.lab.config import settings
from kamiwaza.lib.util import get_kamiwaza_root

# Get the config object
c = get_config() # noqa

# JupyterHub configuration
c.JupyterHub.hub_ip = '0.0.0.0'
c.JupyterHub.hub_port = 8000

# Use KamiwazaLabSpawner
c.JupyterHub.spawner_class = KamiwazaLabSpawner

# Configure KamiwazaLabSpawner
c.KamiwazaLabSpawner.persistent_storage_root = '/data/user-notebooks'
c.KamiwazaLabSpawner.use_kamiwaza_lab = True

# Set default resource limits (these can be overridden per user if needed)
c.KamiwazaLabSpawner.mem_limit = '2G'
c.KamiwazaLabSpawner.cpu_limit = 1.0

# Use NullAuthenticator as authentication is handled by Traefik
c.JupyterHub.authenticator_class = 'nullauthenticator.NullAuthenticator'

# Disable SSL on JupyterHub as Traefik handles SSL termination
c.JupyterHub.ssl_cert = None
c.JupyterHub.ssl_key = None

# Configure JupyterHub to listen on all interfaces
c.JupyterHub.bind_url = 'http://:8000'

# Use the database URL from settings
c.JupyterHub.db_url = settings.database_url

# Allow spawning of multiple servers per user
c.JupyterHub.allow_named_servers = True

# Increase spawn timeout if needed
c.Spawner.start_timeout = 120

# Configure the KamiwazaLabSpawner to use Docker
c.KamiwazaLabSpawner.network_name = os.environ.get('DOCKER_NETWORK_NAME', 'jupyterhub-network')
c.KamiwazaLabSpawner.extra_host_config = {'network_mode': c.KamiwazaLabSpawner.network_name}

# Mount Kamiwaza root directory
kamiwaza_root = get_kamiwaza_root()
c.KamiwazaLabSpawner.volumes = {kamiwaza_root: {'bind': '/srv/kamiwaza', 'mode': 'ro'}}

# Use the specified Docker image for user containers
c.KamiwazaLabSpawner.image = os.environ.get('DOCKER_NOTEBOOK_IMAGE', 'jupyter/base-notebook:latest')

# Spawn command to start the single-user server
c.KamiwazaLabSpawner.cmd = os.environ.get('DOCKER_SPAWN_CMD', 'start-singleuser.sh')

# Shutdown any idle kernels after 1 hour
c.JupyterHub.services = [
    {
        'name': 'idle-culler',
        'command': [sys.executable, '-m', 'jupyterhub_idle_culler', '--timeout=3600'],
    }
]

# Debug logging
c.JupyterHub.log_level = 'DEBUG'
c.Spawner.debug = True

# Allow the proxy to be run as root (needed for port 8000)
c.ConfigurableHTTPProxy.should_start = False
c.ConfigurableHTTPProxy.auth_token = os.environ.get('CONFIGPROXY_AUTH_TOKEN', '')