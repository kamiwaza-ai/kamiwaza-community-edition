#!/bin/bash

# TODO - harden things like etcd version check
#set -euo pipefail

source ~/.profile
source ~/.bashrc

# unset KAMIWAZA_ROOT in case of weird reinstall cases
unset KAMIWAZA_ROOT

source set-kamiwaza-root.sh

# Function to print messages in colors
print_in_color() {
    case $1 in
        green)
            echo -e "\033[92m$2\033[0m"
            ;;
        red)
            echo -e "\033[91m$2\033[0m"
            ;;
        yellow)
            echo -e "\033[93m$2\033[0m"
            ;;
        blue)
            echo -e "\033[94m$2\033[0m"
            ;;
        *)
            echo "$2"
            ;;
    esac
}

# don't permit unless flag passed
unset USER_ACCEPTED_KAMIWAZA_LICENSE

# Check for community install file
if [[ -f ".kamiwaza_install_community" ]]; then
    export KAMIWAZA_COMMUNITY=true
    export KAMIWAZA_SWARM_HEAD=true
fi

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --community)
            # Community edition uses local env.sh and acts as head node
            export KAMIWAZA_COMMUNITY=true
            export KAMIWAZA_SWARM_HEAD=true
            shift
            ;;
        --head)
            export KAMIWAZA_SWARM_HEAD=true
            shift
            ;;
        --worker)
            if [[ -z "${KAMIWAZA_HEAD_IP:-}" ]]; then
                print_in_color red "KAMIWAZA_HEAD_IP must be set for worker nodes"
                exit 1
            fi
            shift
            ;;
        --i-accept-the-kamiwaza-license)
            export USER_ACCEPTED_KAMIWAZA_LICENSE='yes'
            shift
            ;;
        *)
            print_in_color red "Unknown option: $1"
            echo "Usage: $0 (--head | --worker | --community) [--i-accept-the-kamiwaza-license]"
            exit 1
            ;;
    esac
done

if [[ "${KAMIWAZA_SWARM_HEAD:-}" != "true" && -z "${KAMIWAZA_HEAD_IP:-}" ]]; then
    print_in_color red "Must specify either --community, --head or --worker with KAMIWAZA_HEAD_IP set"
    exit 1
fi

if [[ -n "${KAMIWAZA_HEAD_IP:-}" ]]; then
    export KAMIWAZA_HEAD_IP  # Export it so child processes get it
fi

source common.sh
setup_environment

# Verify initialization worked - updated to check correct location based on installation type
if [[ "$(uname)" == "Darwin" ]] || [[ "${KAMIWAZA_COMMUNITY:-}" == "true" ]]; then
    if [[ ! -f "${KAMIWAZA_ROOT:-}/env.sh" ]]; then
        print_in_color red "Community/OSX cluster initialization failed"
        exit 1
    fi
else
    if [[ ! -f /etc/kamiwaza/env.sh && ! -f "${KAMIWAZA_ROOT:-}/env.sh" ]]; then
        print_in_color red "Enterprise cluster initialization failed"
        exit 1
    fi
fi

# Source the appropriate env file
if [[ "$(uname)" == "Darwin" ]] || [[ "${KAMIWAZA_COMMUNITY:-}" == "true" ]]; then
    source "${KAMIWAZA_ROOT:-}/env.sh"
else
    if [[ -f /etc/kamiwaza/env.sh ]]; then
        source /etc/kamiwaza/env.sh
    elif [[ -f "${KAMIWAZA_ROOT:-}/env.sh" ]]; then
        source "${KAMIWAZA_ROOT:-}/env.sh"
    fi
fi

# Rest of venv setup and installation...
print_in_color none "Checking for virtual environment..."
if [[ -z "${VIRTUAL_ENV:-}" ]]; then
    print_in_color yellow "No virtual environment is active; creating if needed, and activating..."
    python3.10 -m venv venv
    source venv/bin/activate
    if [[ -z "${VIRTUAL_ENV:-}" ]]; then
        print_in_color red "Failed to create or activate virtual environment."
        exit 1
    fi
fi

print_in_color green "Running 2nd phase installer in venv..."
export KAMIWAZA_RUN_FROM_INSTALL='yes'
source setup.sh
unset KAMIWAZA_RUN_FROM_INSTALL
unset USER_ACCEPTED_KAMIWAZA_LICENSE