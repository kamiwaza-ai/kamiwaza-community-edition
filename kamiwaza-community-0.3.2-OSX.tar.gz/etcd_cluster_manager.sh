
#!/bin/bash
# etcd_cluster_manager.sh - Place in KAMIWAZA_ROOT
set -euo pipefail

build_cluster_config() {
    # Set node name
    export KAMIWAZA_ETCD_NODE_NAME=${KAMIWAZA_ETCD_NODE_NAME:-$(hostname)}
    local node_name="${KAMIWAZA_ENV:-default}_kamiwaza-etcd-${KAMIWAZA_ETCD_NODE_NAME}"

    if [ -n "${KAMIWAZA_HEAD_IP:-}" ] && ! ifconfig | grep inet | awk '{print $2}' | grep -q "^${KAMIWAZA_HEAD_IP}$"; then
        echo "Configuring worker node..."
        
        # Get head node hostname
        HEAD_HOSTNAME=$(ssh -i /etc/kamiwaza/ssl/cluster.key -o StrictHostKeyChecking=no ${KAMIWAZA_HEAD_IP} hostname)
        if [ $? -ne 0 ] || [ -z "${HEAD_HOSTNAME}" ]; then
            echo "Error: Failed to resolve head node's hostname via SSH"
            exit 1
        fi

        # Try to register this node with the cluster via the head node
        echo "Registering node with cluster..."
        if ! ssh -i /etc/kamiwaza/ssl/cluster.key -o StrictHostKeyChecking=no ${KAMIWAZA_HEAD_IP} \
            "cd ${KAMIWAZA_ROOT} && bash add_node_to_etcd_cluster.sh ${node_name}"; then
            echo "Error: Failed to register node with cluster"
            exit 1
        fi

        export KAMIWAZA_ETCD_CLUSTER_STATE="existing"
        local head_node_name="${KAMIWAZA_ENV:-default}_kamiwaza-etcd-${HEAD_HOSTNAME}"
        export KAMIWAZA_ETCD_INITIAL_CLUSTER="${node_name}=https://${node_name}:2380,${head_node_name}=https://${head_node_name}:2380"
    else
        echo "Configuring head node..."
        export KAMIWAZA_ETCD_CLUSTER_STATE="new"
        export KAMIWAZA_ETCD_INITIAL_CLUSTER="${node_name}=https://${node_name}:2380"
    fi

    export KAMIWAZA_ETCD_ADVERTISE_PEER_URLS="https://${node_name}:2380"
    export KAMIWAZA_ETCD_ADVERTISE_CLIENT_URLS="https://${node_name}:2379"

    echo "Etcd configuration generated:"
    echo "Node Name: ${KAMIWAZA_ETCD_NODE_NAME}"
    echo "Initial Cluster: ${KAMIWAZA_ETCD_INITIAL_CLUSTER}"
    echo "Cluster State: ${KAMIWAZA_ETCD_CLUSTER_STATE}"
    echo "Advertise Peer URLs: ${KAMIWAZA_ETCD_ADVERTISE_PEER_URLS}"
    echo "Advertise Client URLs: ${KAMIWAZA_ETCD_ADVERTISE_CLIENT_URLS}"
}

# Execute if run directly, allow sourcing without execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    build_cluster_config
fi