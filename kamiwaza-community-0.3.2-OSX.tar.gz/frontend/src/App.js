import React, { useState, useEffect } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/common/Header';
import Navbar from './components/common/Navbar';
import ModelIndex from './components/models/ModelIndex';
import ModelDetail from './components/models/ModelDetail';
import ModelFilesContext from './components/models/ModelFilesContext';
import ModelHubSearch from './components/models/ModelHubSearch';
import CatalogList from './components/dataset/DatasetList';
import ActivityFeed from './components/activity/ActivityFeed';
import DatasetDetails from './components/dataset/DatasetDetails';
import ClusterList from './components/cluster/ClusterList';
import ClusterHome from './components/cluster/ClusterHome';
import ClusterDetails from './components/cluster/ClusterDetails';
import LocationDetails from './components/cluster/LocationDetails';
import NodeDetails from './components/cluster/NodeDetails';
import HardwareDetails from './components/cluster/HardwareDetails';
import UserDetails from './components/cluster/UserDetails';
import UserList from './components/cluster/UserList';
import LocationList from './components/cluster/LocationList';
import NodeList from './components/cluster/NodeList';
import HardwareList from './components/cluster/HardwareList';
import RunningNodeDetail from './components/cluster/RunningNodeDetail';
import RunningNodeList from './components/cluster/RunningNodeList';
import Homepage from './components/home/Homepage';
import VectorDBHome from './components/vectordbs/VectorDbHome';
import VectorDBList from './components/vectordbs/VectorDBList';
import VectorDBDetails from './components/vectordbs/VectorDBDetails';
import AdminPanel from './components/admin/AdminPanel';
import theme from './Theme';
import ModelConfigDetail from './components/models/ModelConfigDetail';
import Cookies from 'js-cookie';
import { BASE_URL } from './const';
import { AuthProvider } from './context/AuthContext'; // Import AuthProvider
import Login from './components/auth/Login'; // Import Login component
import ProtectedRoute from './components/auth/ProtectedRoute'; // Import ProtectedRoute component

function App() {
  const [modelFiles, setModelFiles] = useState([]);
  const [hostResolvable, setHostResolvable] = useState(false);

  useEffect(() => {
    const testHostResolvable = async () => {
      try {
        const hostnameResponse = await fetch(`${BASE_URL}/cluster/get_hostname`);
        const { hostname } = await hostnameResponse.json();

        const img = new Image();
        img.src = `http://${hostname}/favicon.ico`;

        img.onload = () => {
          setHostResolvable(true);
          Cookies.set('hostnamesResolve', 'true', { expires: 1 });
        };

        img.onerror = () => {
          setHostResolvable(false);
          Cookies.set('hostnamesResolve', 'false', { expires: 1 });
        };
      } catch (error) {
        setHostResolvable(false);
        Cookies.set('hostnamesResolve', 'false', { expires: 1 });
      }
    };

    testHostResolvable();
  }, []);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider> {/* Wrap the app with AuthProvider */}
        <ModelFilesContext.Provider value={{ modelFiles, setModelFiles }}>
          <Router>
            <Header />
            <Navbar />
            <div className="app-content" style={{ padding: theme.spacing(3) }}>
              <Routes>
                {/* Protect routes that require authentication */}
                <Route path="/" element={<ProtectedRoute><Homepage /></ProtectedRoute>} />
                <Route path="/login" element={<Login />} />
                <Route path="/admin" element={<ProtectedRoute><AdminPanel /></ProtectedRoute>} />
                <Route path="/models" element={<ProtectedRoute><ModelIndex /></ProtectedRoute>} />
                <Route path="/models/:model_id" element={<ProtectedRoute><ModelDetail /></ProtectedRoute>} />
                <Route path="/models/search" element={<ProtectedRoute><ModelHubSearch /></ProtectedRoute>} />
                <Route path="/model_configs/:model_config_id" element={<ProtectedRoute><ModelConfigDetail /></ProtectedRoute>} />
                <Route path="/catalog" element={<ProtectedRoute><CatalogList /></ProtectedRoute>} />
                <Route path="/catalog/dataset/*" element={<ProtectedRoute><DatasetDetails /></ProtectedRoute>} />
                <Route path="/activity" element={<ProtectedRoute><ActivityFeed /></ProtectedRoute>} />
                <Route path="/cluster/locations/:location_id" element={<ProtectedRoute><LocationDetails /></ProtectedRoute>} />
                <Route path="/cluster/runningnodes/:node_id" element={<ProtectedRoute><RunningNodeDetail /></ProtectedRoute>} />
                <Route path="/cluster/runningnodes/" element={<ProtectedRoute><RunningNodeList /></ProtectedRoute>} />
                <Route path="/cluster/home" element={<ProtectedRoute><ClusterHome /></ProtectedRoute>} />
                <Route path="/cluster/:cluster_id" element={<ProtectedRoute><ClusterDetails /></ProtectedRoute>} />
                <Route path="/cluster/" element={<ProtectedRoute><ClusterList /></ProtectedRoute>} />
                <Route path="/cluster/node/:node_id" element={<ProtectedRoute><NodeDetails /></ProtectedRoute>} />
                <Route path="/cluster/hardware/:hardware_id" element={<ProtectedRoute><HardwareDetails /></ProtectedRoute>} />
                <Route path="/cluster/users/:user_id" element={<ProtectedRoute><UserDetails /></ProtectedRoute>} />
                <Route path="/cluster/users" element={<ProtectedRoute><UserList /></ProtectedRoute>} />
                <Route path="/cluster/locations" element={<ProtectedRoute><LocationList /></ProtectedRoute>} />
                <Route path="/cluster/nodes" element={<ProtectedRoute><NodeList /></ProtectedRoute>} />
                <Route path="/cluster/hardware" element={<ProtectedRoute><HardwareList /></ProtectedRoute>} />
                <Route path="/vectordbs/home" element={<ProtectedRoute><VectorDBHome /></ProtectedRoute>} />
                <Route path="/vectordbs" element={<ProtectedRoute><VectorDBList /></ProtectedRoute>} />
                <Route path="/vectordbs/:vectordb_id" element={<ProtectedRoute><VectorDBDetails /></ProtectedRoute>} />
                
              </Routes>
            </div>
          </Router>
        </ModelFilesContext.Provider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
