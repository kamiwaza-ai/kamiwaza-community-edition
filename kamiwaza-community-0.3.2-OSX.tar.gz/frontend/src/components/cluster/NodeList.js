import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton, StyledInactiveText } from '../../StyledComponents'; // Assuming StyledInactiveText is added for inactive nodes
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link, useLocation } from 'react-router-dom';

const NodeList = ({ nodes: propNodes }) => {
    const [nodes, setNodes] = useState(propNodes || []);
    const [showInactive, setShowInactive] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const location = useLocation();

    useEffect(() => {
        if (!propNodes) {
            const fetchNodes = async () => {
                setLoading(true);
                try {
                    const uri = `${BASE_URL}/cluster/nodes`;
                    const response = await axios.get(uri);
                    if (response.status === 200) {
                        setNodes(response.data);
                    } else {
                        throw new Error(`Failed to fetch nodes from ${uri}`);
                    }
                    setLoading(false);
                } catch (err) {
                    setError(err);
                    setLoading(false);
                }
            };

            fetchNodes();
        }
    }, [propNodes]);

    const getNodeIP = (node) => {
        // Prefer hardware IP if available, fallback to last_config, otherwise 'IP not available'
        return node.hardware?.cluster_ip || node.last_config?.cluster_ip || 'IP not available';
    };

    const activeNodes = nodes.filter(node => node.active);
    const inactiveNodes = nodes.filter(node => !node.active);

    return (
        <StyledMainContent className="crudlist">
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <StyledHeader>Node List</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {activeNodes.length === 0 && !loading ? (
                <StyledParagraph>No active nodes available.</StyledParagraph>
            ) : (
                <ul>
                    {activeNodes.map(node => (
                        <li key={node.id}>
                            {/* Link to NodeDetails with node ID */}
                            <Link to={`/cluster/node/${node.id}`}>
                                Node ID: {node.id.substring(0, 8)}...{node.id.substring(node.id.length - 8)} - Node IP: {getNodeIP(node)}
                            </Link>
                        </li>
                    ))}
                </ul>
            )}
            {inactiveNodes.length > 0 && (
                <StyledButton onClick={() => setShowInactive(!showInactive)}>
                    {showInactive ? 'Hide Inactive' : 'Show Inactive'}
                </StyledButton>
            )}
            {showInactive && (
                <ul>
                    {inactiveNodes.map(node => (
                        <li key={node.id} style={{ color: 'grey' }}> {/* Inline style used as a fallback. For a better approach, use StyledInactiveText if available */}
                            {/* If StyledInactiveText is not available, please add it to StyledComponents.js */}
                            {/* Link to NodeDetails with node ID for inactive nodes as well */}
                            <Link to={`/cluster/node/${node.id}`} style={{ color: 'grey' }}>
                                Node ID: {node.id.substring(0, 8)}...{node.id.substring(node.id.length - 8)} - Node IP: {getNodeIP(node)}
                            </Link>
                        </li>
                    ))}
                </ul>
            )}
        </StyledMainContent>
    );
};

export default NodeList;
