import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import AddLocationModal from './AddLocationForm';
import { BASE_URL } from '../../const';

const LocationDetails = () => {
    const [location, setLocation] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const { location_id } = useParams();

    const fetchLocationDetails = async () => {
        setLoading(true);
        try {
            const response = await axios.get(`${BASE_URL}/cluster/location/${location_id}`);
            setLocation(response.data);
            setLoading(false);
        } catch (err) {
            setError(err);
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchLocationDetails();
    }, [location_id]);

    const handleUpdateLocation = async (updatedLocation) => {
        try {
            await axios.put(`${BASE_URL}/cluster/location/${location_id}`, updatedLocation);
            fetchLocationDetails(); // Refresh the location details after update
        } catch (err) {
            console.error('Update location error:', err);
            setError(err);
        }
    };

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Cluster Home
            </StyledButton>
            <StyledButton component={Link} to="/cluster/locations" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Location List
            </StyledButton>

            {location ? (
                <div>
                    <StyledHeader>{location.name}</StyledHeader>
                    <StyledParagraph><strong>Datacenter:</strong> {location.datacenter}</StyledParagraph>
                    <StyledParagraph><strong>Region:</strong> {location.region}</StyledParagraph>
                    <StyledParagraph><strong>Zone:</strong> {location.zone}</StyledParagraph>
                    <StyledParagraph><strong>Building:</strong> {location.building}</StyledParagraph>
                    <StyledParagraph><strong>Address:</strong> {location.address}</StyledParagraph>
                    <StyledParagraph><strong>Contact Phone:</strong> {location.contact_phone}</StyledParagraph>
                    <StyledParagraph><strong>Contact Name:</strong> {location.contact_name}</StyledParagraph>
                    <StyledParagraph><strong>Contact Email:</strong> {location.contact_email}</StyledParagraph>
                    <StyledButton variant="outlined" onClick={() => setShowModal(true)}>
                        Update Location
                    </StyledButton>
                </div>
            ) : (
                <StyledParagraph>Location not found</StyledParagraph>
            )}

            {showModal && (
                <AddLocationModal
                    closeModal={() => setShowModal(false)}
                    showModal={showModal}
                    addLocation={handleUpdateLocation}
                    locationDetails={location}
                />
            )}
        </StyledMainContent>
    );
};

export default LocationDetails;
