import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton, StyledSubSection, StyledList, StyledListItem, StyledTable, StyledTableHead, StyledTableRow, StyledTableCell, StyledTableBody } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const HardwareDetails = () => {
    const [hardware, setHardware] = useState(null); // Initialize as null or an empty object
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    let { hardware_id } = useParams();

    useEffect(() => {
        const fetchHardwareDetails = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/hardware/${hardware_id}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setHardware(response.data); // Expecting a single object
                } else {
                    throw new Error(`Failed to fetch hardware details from ${uri}`);
                }
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchHardwareDetails();
    }, [hardware_id]);

    if (loading) return <StyledParagraph>Loading...</StyledParagraph>;
    if (error) return <StyledParagraph>Error: {error.message}</StyledParagraph>;

    const renderGPUs = (gpus) => {
        if (!gpus || gpus.length === 0) return <StyledParagraph>No GPUs available.</StyledParagraph>;

        const totalVRAM = gpus.reduce((sum, gpu) => sum + parseFloat(gpu.vram), 0);

        return (
            <div>
                {gpus.length > 1 && <StyledParagraph><strong>Total VRAM: </strong>{totalVRAM.toFixed(2)} GB</StyledParagraph>}
                <StyledTable>
                    <StyledTableHead>
                        <StyledTableRow>
                            <StyledTableCell>Full Name</StyledTableCell>
                            <StyledTableCell>Name</StyledTableCell>
                            <StyledTableCell>Type</StyledTableCell>
                            <StyledTableCell>VRAM</StyledTableCell>
                        </StyledTableRow>
                    </StyledTableHead>
                    <StyledTableBody>
                        {gpus.map((gpu, index) => (
                            <StyledTableRow key={index}>
                                <StyledTableCell>{gpu.fullname}</StyledTableCell>
                                <StyledTableCell>{gpu.name}</StyledTableCell>
                                <StyledTableCell>{gpu.type}</StyledTableCell>
                                <StyledTableCell>{gpu.vram}</StyledTableCell>
                            </StyledTableRow>
                        ))}
                    </StyledTableBody>
                </StyledTable>
            </div>
        );
    };

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Hardware Home
            </StyledButton>
            <StyledHeader>Hardware Details</StyledHeader>
            {hardware ? (
                <div className="hardware-details">
                    <StyledSubSection>
                        <div className="subsection-title">General Information</div>
                        <StyledList>
                            <StyledListItem><strong>Name: </strong> {hardware.name}</StyledListItem>
                            <StyledListItem><strong>ID: </strong> {hardware.id}</StyledListItem>
                            <StyledListItem><strong>Node ID: </strong> {hardware.node_id ? hardware.node_id : "No Node (Historical) - may be attached to new Node"}</StyledListItem>
                            <StyledListItem><strong>Local Node ID: </strong> {hardware.local_node_id}</StyledListItem>
                            <StyledListItem><strong>Cluster IP: </strong> {hardware.cluster_ip}</StyledListItem>
                            <StyledListItem><strong>Ray Node ID: </strong> {hardware.ray_node_id}</StyledListItem>
                            <StyledListItem><strong>Active: </strong> {hardware.active ? 'Yes' : 'No'}</StyledListItem>
                            <StyledListItem><strong>Created At: </strong> {new Date(hardware.created_at).toLocaleString()}</StyledListItem>
                        </StyledList>
                    </StyledSubSection>
                    <StyledSubSection>
                        <div className="subsection-title">Hardware Specifications</div>
                        <StyledList>
                            <StyledListItem><strong>GPUs: </strong> {renderGPUs(hardware.gpus)}</StyledListItem>
                            <StyledListItem><strong>Processors: </strong> {hardware.processors ? hardware.processors.join(', ') : 'N/A'}</StyledListItem>
                            <StyledListItem><strong>Processor Vendor: </strong> {hardware.processor_vendor}</StyledListItem>
                            <StyledListItem><strong>OS: </strong> {hardware.os}</StyledListItem>
                            <StyledListItem><strong>Platform: </strong> {hardware.platform}</StyledListItem>
                        </StyledList>
                    </StyledSubSection>
                    <StyledSubSection>
                        <div className="subsection-title">Configuration</div>
                        {hardware.configuration ? (
                            <StyledList>
                                {Object.entries(hardware.configuration).map(([key, value]) => (
                                    <StyledListItem key={key}>
                                        <strong>{key}: </strong> 
                                        {key === 'gpus' && Array.isArray(value) ? (
                                            renderGPUs(value)
                                        ) : (
                                            typeof value === 'object' ? JSON.stringify(value) : value
                                        )}
                                    </StyledListItem>
                                ))}
                            </StyledList>
                        ) : (
                            <StyledParagraph>No configuration details available.</StyledParagraph>
                        )}
                    </StyledSubSection>
                </div>
            ) : (
                <StyledParagraph>No hardware details available.</StyledParagraph>
            )}
        </StyledMainContent>
    );
};

export default HardwareDetails;