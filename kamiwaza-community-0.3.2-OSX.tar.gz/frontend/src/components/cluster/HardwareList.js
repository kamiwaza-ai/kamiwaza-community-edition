// HardwareList.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton, StyledInactiveText } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import { Link, useLocation } from 'react-router-dom';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const HardwareList = () => {
    const [hardware, setHardware] = useState([]);
    const [showInactive, setShowInactive] = useState(false);
    const [loading, setLoading] = useState(true); // Default to true for initial load
    const [error, setError] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const fetchHardware = async () => {
            try {
                const uri = `${BASE_URL}/cluster/hardware`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setHardware(response.data);
                } else {
                    throw new Error(`Failed to fetch hardware from ${uri}`);
                }
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchHardware();
    }, []);

    const activeHardware = hardware.filter(hw => hw.active !== false);
    const inactiveHardware = hardware.filter(hw => hw.active === false);

    return (
        <StyledMainContent className="crudlist">
            {location.pathname !== "/cluster/home" && (
                <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                    Clusters Home
                </StyledButton>
            )}
            <StyledHeader>Hardware List</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {!loading && activeHardware.length === 0 && inactiveHardware.length === 0 ? (
                <StyledParagraph>No hardware available.</StyledParagraph>
            ) : (
                <>
                    <ul>
                        {activeHardware.map(hw => (
                            <li key={hw.id}>
                                <Link to={`/cluster/hardware/${hw.id}`}>
                                    {hw.name} - Node ID: {hw.node_id ? `${hw.node_id.substring(0, 8)}...${hw.node_id.substring(hw.node_id.length - 8)}` : 'N/A'}
                                </Link>
                            </li>
                        ))}
                    </ul>
                    {inactiveHardware.length > 0 && (
                        <StyledButton onClick={() => setShowInactive(!showInactive)}>
                            {showInactive ? 'Hide Inactive' : 'Show Inactive'}
                        </StyledButton>
                    )}
                    {showInactive && (
                        <ul>
                            {inactiveHardware.map(hw => (
                                <li key={hw.id} style={{ color: 'grey' }}>
                                    <Link to={`/cluster/hardware/${hw.id}`} style={{ color: 'grey' }}>
                                        {hw.name} - Node ID: {hw.node_id ? `${hw.node_id.substring(0, 8)}...${hw.node_id.substring(hw.node_id.length - 8)}` : 'N/A'}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    )}
                </>
            )}
        </StyledMainContent>
    );
};

export default HardwareList;

