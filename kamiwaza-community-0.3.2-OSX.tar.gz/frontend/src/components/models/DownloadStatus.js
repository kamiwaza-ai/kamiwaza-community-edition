import React, { useContext, useState } from 'react';
import { StyledFloatingWindow, StyledDownloadStatusModalContent, StyledButton, StyledDownloadProgressBar, StyledDownloadStatusText, StyledDownloadStatusItem } from '../../StyledComponents';
import ModelFilesContext from './ModelFilesContext';
import { FaChevronUp, FaChevronDown } from 'react-icons/fa';

const DownloadStatusModal = ({ closeModal }) => {
    const { statusModelFiles, clearCompletedDownloads } = useContext(ModelFilesContext);
    const [isExpanded, setIsExpanded] = useState(true);

    const handleOnClose = (event, reason) => {
        if (reason !== 'backdropClick' && reason !== 'escapeKeyDown') {
            closeModal();
        }
    };

    const toggleExpand = () => {
        setIsExpanded(!isExpanded);
    };

    return (
        statusModelFiles.length > 0 ? 
        <StyledFloatingWindow>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                <h3>Download Status</h3>
                <div onClick={toggleExpand} style={{ cursor: 'pointer' }}>
                    {isExpanded ? <FaChevronUp /> : <FaChevronDown />}
                </div>
            </div>
            {isExpanded && (
                <StyledDownloadStatusModalContent>
                    {statusModelFiles.map((status, index) => (
                        <StyledDownloadStatusItem key={index}>
                            <StyledDownloadStatusText variant="body1">{status.name}</StyledDownloadStatusText>
                            <StyledDownloadProgressBar variant="determinate" value={status.download_percentage || 0} />
                            {status.storage_location && !status.dl_requested_at ? (
                                <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold', color: 'green' }}>
                                    Complete{status.download_elapsed ? ` (${status.download_elapsed})` : ''}
                                </StyledDownloadStatusText>
                            ) : status.dl_requested_at && !status.is_downloading ? (
                                <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold' }}>Queued</StyledDownloadStatusText>
                            ) : (
                                <>
                                    <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold' }}>
                                        {status.download_elapsed} / {status.download_remaining}
                                    </StyledDownloadStatusText>
                                    <StyledDownloadStatusText variant="body2" sx={{ fontWeight: 'bold' }}>{status.download_throughput}</StyledDownloadStatusText>
                                </>
                            )}
                        </StyledDownloadStatusItem>
                    ))}
                    <StyledButton onClick={clearCompletedDownloads}>Clear Completed</StyledButton>
                </StyledDownloadStatusModalContent>
            )}
        </StyledFloatingWindow>
        : null
    );
};

export default DownloadStatusModal;
