// ModelIndex.js
import React, { useState, useContext } from 'react';
import ModelHubSearch from './ModelHubSearch';
import ModelList from './ModelList';
import ModelFilesContext from './ModelFilesContext';
import { ModelFilesProvider } from './ModelFilesContext'; // Import ModelFilesProvider
import DownloadStatusModal from './DownloadStatus';
import { StyledMainContent, StyledHeader } from '../../StyledComponents';
import ModelDeploymentList from './ModelDeploymentList';
import axios from 'axios'; // Ensure axios is imported
import { BASE_URL } from '../../const';

const ModelIndex = () => {

  return (
    <ModelFilesProvider>
      <StyledMainContent>
        <StyledHeader>Models</StyledHeader>
        <ModelHubSearch />
        <br />
        <ModelDeploymentList />
        <ModelList />
        <DownloadStatusModal />
      </StyledMainContent>
    </ModelFilesProvider>
  );
};

export default ModelIndex;
