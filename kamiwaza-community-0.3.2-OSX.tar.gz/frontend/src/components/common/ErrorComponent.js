// ErrorComponent.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const ErrorComponent = ({ message }) => (
    <div className="alert alert-danger" role="alert">
        Error: {message}
    </div>
);

export default ErrorComponent;
