import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const DatasetDetails = () => {
    const [datasets, setDatasets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    let { '*': name } = useParams();

    useEffect(() => {
        const fetchDatasetDetails = async () => {
            // Do not retrieve if the name is none
            if (!name) {
                return;
            }
            try {
                const uri = `${BASE_URL}/catalog/dataset/${name}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setDatasets(response.data);
                } else {
                    throw new Error(`Failed to fetch dataset details from ${uri}`);
                }
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchDatasetDetails();
    }, [name]);

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/catalog" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Back to Dataset List
            </StyledButton>
            <StyledHeader>Dataset Details</StyledHeader>
            {loading && <StyledParagraph>Loading...</StyledParagraph>}
            {error && <StyledParagraph>Error: {error.message}</StyledParagraph>}
            <div className="dataset-list">
                {datasets && datasets.map(dataset => (
                    <div key={dataset.id} className="dataset-card">
                        <StyledHeader>{dataset.name}</StyledHeader>
                        <StyledParagraph><strong>Platform:</strong> {dataset.platform}</StyledParagraph>
                        <StyledParagraph><strong>Paths:</strong> {Array.isArray(dataset.paths) ? dataset.paths.join(', ') : 'N/A'}</StyledParagraph>
                        <StyledParagraph><strong>ID:</strong> {dataset.id}</StyledParagraph>
                        <StyledParagraph><strong>Actor:</strong> {dataset.actor}</StyledParagraph>
                        <StyledParagraph><strong>Removed:</strong> {dataset.removed ? 'Yes' : 'No'}</StyledParagraph>
                        <StyledParagraph><strong>Tags:</strong> {Array.isArray(dataset.tags) ? dataset.tags.join(', ') : 'N/A'}</StyledParagraph>
                    </div>
                ))}
            </div>
        </StyledMainContent>
    );
};

export default DatasetDetails;
