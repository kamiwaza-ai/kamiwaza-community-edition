import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledMainContent, StyledHeader, StyledButton, StyledModalContent, StyledCircularProgress } from '../../StyledComponents';
import ErrorComponent from '../common/ErrorComponent';
import { Link } from 'react-router-dom';

const VectorDBList = () => {
    const [vectorDBs, setVectorDBs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        setLoading(true);
        const fetchVectorDBs = async () => {
            try {
                const response = await axios.get(`${BASE_URL}/vectordb/vectordb/`);
                if (response.status === 200) {
                    setVectorDBs(response.data);
                } else {
                    throw new Error('Failed to fetch VectorDBs');
                }
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchVectorDBs();
    }, []);

    return (
        <StyledMainContent className="crudlist">
            <StyledHeader>VectorDB List</StyledHeader>
            {loading && <StyledCircularProgress />}
            {error && <ErrorComponent message={error.message} />}
            {vectorDBs.length === 0 && !loading ? (
                <p>No VectorDBs available.</p>
            ) : (
                <ul>
                    {vectorDBs.map(vectorDB => (
                        <li key={vectorDB.id}>
                            <Link to={`/vectordbs/${vectorDB.id}`}>{vectorDB.name}</Link>
                        </li>
                    ))}
                </ul>
            )}
        </StyledMainContent>
    );
};

export default VectorDBList;
