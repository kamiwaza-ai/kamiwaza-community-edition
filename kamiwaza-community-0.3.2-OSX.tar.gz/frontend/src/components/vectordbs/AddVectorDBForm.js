import React, { useState } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { StyledModal, StyledButton, StyledTable, StyledTableCell, StyledTextField, StyledCircularProgress, StyledModalContent, StyledSubHeader } from '../../StyledComponents';

const AddVectorDBModal = ({ closeModal, showModal, addVectorDB }) => {
    const [vectorDBData, setVectorDBData] = useState({
        name: '',
        // Add other fields as per the VectorDB schema
    });

    const handleAddVectorDB = async () => {
        try {
            const response = await axios.post(`${BASE_URL}/vectordb/vectordb/`, vectorDBData);
            if (response.status === 200) {
                addVectorDB(response.data); // Call addVectorDB with the new VectorDB
                closeModal();
            } else {
                // Handle non-successful response
            }
        } catch (err) {
            console.error('Add VectorDB error:', err);
            // Handle add VectorDB error
        }
    };

    const handleInputChange = (event) => {
        setVectorDBData({
            ...vectorDBData,
            [event.target.name]: event.target.value
        });
    };

    return (
        <StyledModal open={showModal} onClose={closeModal}>
            <StyledModalContent>
                <StyledTable>
                    <thead>
                        <tr>
                            <StyledTableCell>
                                <StyledSubHeader>Add New VectorDB</StyledSubHeader>
                            </StyledTableCell>
                        </tr>
                    </thead>
                    <tbody>
                        {Object.keys(vectorDBData).map((key) => (
                            <tr key={key}>
                                <StyledTableCell>{key.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</StyledTableCell>
                                <StyledTableCell>
                                    <StyledTextField
                                        name={key}
                                        value={vectorDBData[key]}
                                        onChange={handleInputChange}
                                    />
                                </StyledTableCell>
                            </tr>
                        ))}
                    </tbody>
                </StyledTable>
                <StyledButton variant="secondary" onClick={closeModal}>
                    Close
                </StyledButton>
                <StyledButton variant="primary" onClick={handleAddVectorDB}>
                    Add VectorDB
                </StyledButton>
            </StyledModalContent>
        </StyledModal>
    );
};

export default AddVectorDBModal;
