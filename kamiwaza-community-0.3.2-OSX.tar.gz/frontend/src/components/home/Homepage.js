import React from 'react';
import { useTheme } from '@mui/material/styles';

const Homepage = () => {
  const theme = useTheme();
  return (
    <div className="main-content" style={{
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.background.default,
      display: 'flex', // Use flexbox to create columns
      flexDirection: 'row', // Align children in a row
      justifyContent: 'space-between' // Space between the columns
    }}>
      <div style={{ flex: 1, marginRight: '1rem' }}> {/* Column 1 */}
        <h1 style={{ color: theme.palette.primary.main }}>Updates</h1>
        <h2>Latest Release</h2>
        <ul style={{ color: theme.palette.text.secondary }}>
          <li>Authentication merged into community and enabled in base EE; issues JWTs</li>
          <li>non-SSL endpoints have been removed; SSL everywhere! (even if self-signed certs are used)</li>
          <li>JupyterLab now requires Kamiwaza authentication instead of lab tokens</li>
          <li>Improvements in default SSL configuration, which includes fixing SSL rotation on model deletion in default configuration</li>
          <li>Introduction of <b>kamiwazad</b>, supporting one-command startups and systemd deployments</li>
          <li>Many package updates, including vLLM 0.6.3.post1 (and updated llama.cpp on OSX)</li>
          <li>Model configs more faithful in autodetecting configs during download</li>
          <li>Model configurations for vLLM now support declared parameters matching any known parameter</li>
          <li>Improved ray management</li>
          <li>Improved large-batch embeddings performance in pipelines</li>
          <li>Aligned recursive behavior between file and object ingestion in catalog service</li>
          <li><b>kamiwazad</b> now manages launching services - `bash startup/kamiwazad.sh start` is typical and `status` works</li>
          <li>Lightweight <b>client sdk</b> now available - https://github.com/kamiwaza-ai/kamiwaza-sdk</li>
          <li>Gorgeous new chatbot validated and integrated with 3.2 - https://github.com/m9e/chatbot - Many thanks to Vercel</li>
          <li>Many fixes and improvements!</li>
        </ul>
      </div>
      <div style={{ flex: 1 }}> {/* Column 2 */}
        <h1 style={{ color: theme.palette.primary.main }}>Latest News</h1>
        <div style={{ color: theme.palette.text.secondary }}>
          <div>&nbsp;</div>
          <div>Join our Discord: <a href="https://discord.gg/cVGBS5rD2U">https://discord.gg/cVGBS5rD2U</a></div>
          <div>&nbsp;</div>
          <div>Check out our <b>new improved</b> website: <a href="https://www.kamiwaza.ai/community">https://www.kamiwaza.ai/community</a></div>
        </div>
      </div>
    </div>
  );
};

export default Homepage;