#!/bin/bash
# set-node-version.sh - Ensure correct Node version for frontend

source ~/.bashrc
source ../common.sh

nvm use 22
promote_nvm_node  # Called after nvm use to ensure proper PATH ordering

# Verify we actually got Node 22
if ! verify_node_version; then
    echo "Failed to set Node 22 as active version" >&2
    exit 1
fi