# Get PIDs of kamiwaza Python processes, excluding ray/datahub/etc
# kamiwaza pids, with python
# - Exclude ray
# - Exclude datahub
# - Exclude ms-python (cursor)
# - Exclude grep (this script)
# - Only show processes owned by current user
# Note: Using $USER with egrep since we explicitly want to skip containerized 
# processes that may be running under the same UID but different usernames

pids=$(ps auxwww | egrep "^${USER}" | grep -i kamiwaza | grep '\.py' | grep python | grep -v ray | grep -v ms-python | grep -v grep | grep -v datahub | awk '{print $2}')

if [[ -z "${pids:-}" ]]; then
    echo "No kamiwaza processes found"
    exit 0
fi

echo "Found kamiwaza processes: $pids"

# Try graceful shutdown first
for attempt in {1..3}; do
    if [[ -z "${pids:-}" ]]; then
        echo "All processes stopped successfully"
        exit 0
    fi
    
    echo "Attempt $attempt: Sending SIGTERM to remaining processes..."
    for pid in $pids; do
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null || true
            echo "  Sent SIGTERM to $pid"
        fi
    done
    
    # Wait a bit between attempts
    sleep 2
    
    # Update list of remaining processes
    pids=$(ps auxwww | grep -i kamiwaza | grep '\.py' | grep python | grep -v ray | grep -v ms-python | grep -v grep | grep -v datahub | awk '{print $2}')
done

# Force kill any remaining processes
if [[ -n "${pids:-}" ]]; then
    echo "Some processes still running, sending SIGKILL..."
    for pid in $pids; do
        if kill -0 "$pid" 2>/dev/null; then
            kill -9 "$pid" 2>/dev/null || true
            echo "  Sent SIGKILL to $pid"
        fi
    done
fi
