#!/bin/bash

mkdir -p certs
mkdir -p secrets
mkdir -p volumes

cockroach cert create-ca \
--certs-dir=certs \
--ca-key=secrets/ca.key

cockroach cert create-node \
localhost \
$(hostname) \
--certs-dir=certs \
--ca-key=secrets/ca.key

cockroach cert create-client \
root \
--certs-dir=certs \
--ca-key=secrets/ca.key

