import React from 'react';
import { useTheme } from '@mui/material/styles';

const Homepage = () => {
  const theme = useTheme();
  return (
    <div className="main-content" style={{
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.background.default,
      display: 'flex', // Use flexbox to create columns
      flexDirection: 'row', // Align children in a row
      justifyContent: 'space-between' // Space between the columns
    }}>
      <div style={{ flex: 1, marginRight: '1rem' }}> {/* Column 1 */}
        <h1 style={{ color: theme.palette.primary.main }}>Updates</h1>
        <p style={{ color: theme.palette.text.secondary }}>
          <h2>Latest Release</h2>
          <ul>
            <li>Improvements in model config deployment and cluster mode, and cluster mode now usable in community edition (still single-node, but the behavior should match enterprise)</li>
            <li>Improved UI</li>
            <li>Improved cluster management and bootstrapping</li>
            <li>Cleanup and improvements in sentencetransformers middleware</li>
            <li>Added etcd for config management and traefik for endpoint loadbalancing</li>
            <li>Added 'KAMIWAZA_ENV' setting for startup for containers</li>
            <li>Many fixes</li>
          </ul>
        </p>
      </div>
      <div style={{ flex: 1 }}> {/* Column 2 */}
        <h1 style={{ color: theme.palette.primary.main }}>Latest News</h1>
        <p style={{ color: theme.palette.text.secondary }}>
          <div>&nbsp;</div>
          <div>Join our Discord: <a href="https://discord.gg/cVGBS5rD2U">https://discord.gg/cVGBS5rD2U</a></div>
          <div>&nbsp;</div>
          <div>Check out our website: <a href="https://www.kamiwaza.ai/community">https://www.kamiwaza.ai/community</a></div>
        </p>
      </div>
    </div>
  );
};

export default Homepage;
