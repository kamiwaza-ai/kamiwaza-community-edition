// Dynamically construct the API URL based on the current host
const API_PORT = '7777'; // API port
const LAB_PORT = '8888';

const isDefaultPort = (port) => port === '' || port === '80' || port === '443';

const currentPort = window.location.port;
const basePath = isDefaultPort(currentPort) ? '/api' : `:${API_PORT}`;
const labPath = isDefaultPort(currentPort) ? '/lab' : `:${LAB_PORT}`;

export const BASE_URL = `${window.location.protocol}//${window.location.hostname}${basePath}`;
export const LAB_URL = `${window.location.protocol}//${window.location.hostname}${labPath}`;