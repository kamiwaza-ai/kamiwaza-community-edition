**FurryFriends Pet Supplies: Live Animal Handling Guidelines**

---

At FurryFriends Pet Supplies, the well-being of our live animals and the safety of our employees are paramount. Whether dealing with fish, small rodents, reptiles, or other live animals, these guidelines ensure a humane, sanitary, and safe environment for both our pets and our team members.

---

### **1. Safety and Sanitation Practices**

#### **a. Personal Hygiene and Protective Gear**
- **Hand Washing:**
  - Employees must wash their hands thoroughly with soap and water before and after handling any live animals.
  - Use hand sanitizer when hand washing facilities are not immediately available.
- **Protective Equipment:**
  - Wear gloves when handling animals, especially those that may carry diseases or have sharp features (e.g., reptiles).
  - Use protective eyewear when necessary to prevent accidental splashes or bites.
  - Utilize aprons or protective clothing to maintain cleanliness and prevent cross-contamination between different animal species.

#### **b. Cleaning and Disinfection**
- **Enclosures and Equipment:**
  - Clean and disinfect all animal enclosures, cages, tanks, and equipment daily.
  - Use pet-safe cleaning agents to avoid harming the animals.
- **Sanitation Stations:**
  - Maintain designated sanitation stations equipped with cleaning supplies, gloves, and disinfectants.
  - Ensure sanitation stations are easily accessible to all employees.
- **Waste Disposal:**
  - Dispose of animal waste promptly and in accordance with local regulations.
  - Use sealed bags and designated waste containers to prevent contamination and odor.

#### **c. Store Environment Maintenance**
- **Temperature and Humidity Control:**
  - Monitor and maintain appropriate temperature and humidity levels for different animal species.
  - Ensure heating, cooling, and ventilation systems are functioning correctly.
- **Pest Control:**
  - Implement regular pest control measures to protect live animals from parasites and diseases.
  - Use pet-safe pest control products to avoid exposing animals to harmful chemicals.

---

### **2. Handling Procedures to Reduce Stress for the Animals**

#### **a. Gentle Handling Techniques**
- **Minimal Restraint:**
  - Handle animals gently and avoid excessive restraint to prevent injury and reduce stress.
  - Support the animal’s body adequately, especially when lifting or moving.
- **Slow Movements:**
  - Use slow, deliberate movements to avoid startling or frightening the animals.
  - Avoid sudden gestures or loud noises that may cause panic.

#### **b. Environment Familiarization**
- **Stable Environment:**
  - Keep animals in their enclosures unless necessary for cleaning or maintenance.
  - Minimize disruptions to their environment to maintain a sense of security.
- **Habituation:**
  - Allow animals to acclimate to their surroundings and handling routines gradually.
  - Provide hiding spots and enrichment activities to reduce anxiety.

#### **c. Species-Specific Care**
- **Understanding Needs:**
  - Educate employees on the specific behavioral and environmental needs of each animal species.
  - Tailor handling and care practices to accommodate the natural behaviors and preferences of different animals.
- **Enrichment Activities:**
  - Provide appropriate enrichment, such as toys, climbing structures, or foraging opportunities, to keep animals mentally and physically stimulated.
  - Rotate enrichment items regularly to maintain interest and prevent boredom.

---

### **3. Protocols for Ensuring the Well-Being of Both Animals and Employees**

#### **a. Health Monitoring and Veterinary Care**
- **Regular Health Checks:**
  - Conduct daily health inspections to identify signs of illness, injury, or distress in animals.
  - Record observations and report any concerns to management immediately.
- **Access to Veterinary Care:**
  - Establish a relationship with a qualified veterinarian for routine check-ups and emergency care.
  - Ensure prompt veterinary attention for any health issues or injuries.

#### **b. Training and Education**
- **Employee Training:**
  - Provide comprehensive training on animal handling, species-specific care, safety protocols, and emergency procedures.
  - Conduct regular refresher courses and update training materials as needed.
- **Knowledge Sharing:**
  - Encourage employees to share observations and insights about animal behavior and health.
  - Foster a collaborative environment where team members support each other in maintaining animal welfare.

#### **c. Emergency Preparedness**
- **Emergency Procedures:**
  - Develop and display clear emergency procedures for incidents such as animal escapes, injuries, or natural disasters.
  - Conduct regular drills to ensure employees are familiar with emergency protocols.
- **First Aid Kits:**
  - Maintain well-stocked first aid kits specifically designed for animals.
  - Train employees on how to use first aid supplies effectively in case of an emergency.

#### **d. Safe Interaction Practices**
- **Preventing Bites and Scratches:**
  - Handle animals with care, especially those prone to biting or scratching.
  - Use appropriate tools, such as leashes or carriers, to manage animals safely.
- **Avoiding Zoonotic Diseases:**
  - Implement measures to prevent the transmission of diseases between animals and humans.
  - Educate employees on recognizing signs of zoonotic diseases and the importance of hygiene practices.

#### **e. Employee Well-Being**
- **Stress Management:**
  - Provide support for employees who may experience stress from handling live animals.
  - Encourage breaks and promote a healthy work-life balance.
- **Ergonomic Practices:**
  - Use ergonomic tools and techniques to reduce the risk of injury when handling animals.
  - Ensure workstations are set up to minimize physical strain and promote safe handling.

---

### **4. Additional Best Practices**

#### **a. Record Keeping**
- **Documentation:**
  - Maintain accurate records of animal inventory, health status, handling incidents, and cleaning schedules.
  - Use digital systems or logs to track and manage information efficiently.
- **Compliance:**
  - Ensure all record-keeping practices comply with local regulations and industry standards.

#### **b. Customer Interaction**
- **Educating Customers:**
  - Provide customers with information on the proper care and handling of live animals.
  - Offer guidance on selecting suitable animals based on their lifestyle and experience.
- **Promoting Responsible Ownership:**
  - Encourage customers to adopt responsible pet ownership practices to ensure the well-being of their animals.

---

**FurryFriends Pet Supplies** is dedicated to fostering a safe, healthy, and stress-free environment for all live animals and our dedicated employees. By adhering to these guidelines, we ensure the highest standards of animal welfare and workplace safety, contributing to a positive experience for both our pets and our team.

---

*Thank you for your commitment to the care and well-being of our furry, scaly, and feathered friends! Together, we create a nurturing home for all pets.*