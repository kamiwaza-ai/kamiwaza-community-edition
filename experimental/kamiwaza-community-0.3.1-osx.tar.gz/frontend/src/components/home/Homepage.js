import React from 'react';
import { useTheme } from '@mui/material/styles';

const Homepage = () => {
  const theme = useTheme();
  return (
    <div className="main-content" style={{
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.background.default,
      display: 'flex', // Use flexbox to create columns
      flexDirection: 'row', // Align children in a row
      justifyContent: 'space-between' // Space between the columns
    }}>
      <div style={{ flex: 1, marginRight: '1rem' }}> {/* Column 1 */}
        <h1 style={{ color: theme.palette.primary.main }}>Updates</h1>
        <h2>Latest Release</h2>
        <ul style={{ color: theme.palette.text.secondary }}>
          <li>Improvements in model config deployment and cluster mode, and cluster mode now usable in community edition (still single-node, but the behavior should match enterprise)</li>
          <li>Improved UI</li>
          <li>Production mode React serving</li>
          <li>Improved cluster management and bootstrapping</li>
          <li>Significantly improved exception handling for model deployment/shutdown; including a force-stop function that will clear a model if the underlying engine is unavailable to respond to a graceful shutdown</li>
          <li>Cleanup and improvements in sentencetransformers middleware</li>
          <li>Added etcd for config management - visible under /cluster/runtime_config endpoint; we deploy on port 12379</li>
          <li>added Traefik as a load balancer; Kamiwaza now sports a unified endpoint for all services</li>
          <li>80/443 with / being the ui, /api/docs being the swagger docs, /lab/lab for Jupyter lab</li>
          <li>Deploys with self-signed certificates but you can now replace the certificate with your own (generally /deployment/envs/[env]/kamiwaza-traefik/[amd64|arm64]/certs</li>
          <li>Support for letsencrypt coming in the future</li>
          <li>All editions now standardize on traefik (all hosts) providing a port from 51100-51199 for model deployments, which map to ray.serve endpoints</li>
          <li>Added 'KAMIWAZA_ENV' setting for startup for containers - advanced use</li>
          <li>Updated over 50 packages and components, including vLLM (5.1), llamacpp (recent build), cockroachDB, etc.</li>
          <li>Improved model config management - more fields; fields are now generally all optional and graceful to not being set</li>
          <li>Many fixes</li>
          <li>and many more!</li>
        </ul>
      </div>
      <div style={{ flex: 1 }}> {/* Column 2 */}
        <h1 style={{ color: theme.palette.primary.main }}>Latest News</h1>
        <div style={{ color: theme.palette.text.secondary }}>
          <div>&nbsp;</div>
          <div>Join our Discord: <a href="https://discord.gg/cVGBS5rD2U">https://discord.gg/cVGBS5rD2U</a></div>
          <div>&nbsp;</div>
          <div>Check out our <b>new improved</b> website: <a href="https://www.kamiwaza.ai/community">https://www.kamiwaza.ai/community</a></div>
        </div>
      </div>
    </div>
  );
};

export default Homepage;