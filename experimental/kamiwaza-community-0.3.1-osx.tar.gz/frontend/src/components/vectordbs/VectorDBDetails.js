import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { BASE_URL } from '../../const';

const VectorDBDetails = () => {
    const [vectorDB, setVectorDB] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { vectordb_id } = useParams();

    useEffect(() => {
        const fetchVectorDBDetails = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`${BASE_URL}/vectordb/vectordb/${vectordb_id}`);
                setVectorDB(response.data);
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchVectorDBDetails();
    }, [vectordb_id]);

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/vectordbs/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                VectorDB Home
            </StyledButton>
            <StyledButton component={Link} to="/vectordbs" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                VectorDB List
            </StyledButton>

            {vectorDB ? (
                <div>
                    <StyledHeader>{vectorDB.name}</StyledHeader>
                    <StyledParagraph><strong>Instance Name:</strong> {vectorDB.name}</StyledParagraph>
                    <StyledParagraph><strong>Running On:</strong> {vectorDB.host}:{vectorDB.port}</StyledParagraph>
                    <StyledParagraph><strong>Description:</strong> {vectorDB.description}</StyledParagraph>
                    {vectorDB.created_at && <StyledParagraph><strong>Created At:</strong> {new Date(vectorDB.created_at).toLocaleString()}</StyledParagraph>}
                </div>
            ) : (
                <StyledParagraph>VectorDB not found</StyledParagraph>
            )}
        </StyledMainContent>
    );
};

export default VectorDBDetails;
