module.exports = {
    apps: [
      {
        name: 'react-app',
        script: 'npm',
        args: 'run serve',
        instances: 2,
        exec_mode: 'cluster',
        autorestart: true,
        watch: false,
        max_memory_restart: '1G',
        env: {
          NODE_ENV: 'production',
          PORT: 3000,
        },
        instance_var: 'INSTANCE_ID',
        exp_backoff_restart_delay: 100,
      },
    ],
  };