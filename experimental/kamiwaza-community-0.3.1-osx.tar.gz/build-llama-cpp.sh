#!/bin/bash

LLAMA_COMMIT=`cat llamacpp.commit`
# TODO validate commit format

set -ex

mkdir -p llamacpp
cd llamacpp
if [ -d "llama.cpp" -a -d "venv" ]; then
	deactivate || true
	source venv/bin/activate
	cd llama.cpp
else
	deactivate || true
	python -m venv venv
	source venv/bin/activate
	git clone https://github.com/ggerganov/llama.cpp.git
	cd llama.cpp
fi

# now build it 
git checkout -b kamiwaza $LLAMA_COMMIT
make clean
make
deactivate || true