#!/bin/bash

# Function to print messages in colors
print_in_color() {
    case $1 in
        green)
            echo -e "\033[92m$2\033[0m"
            ;;
        red)
            echo -e "\033[91m$2\033[0m"
            ;;
        yellow)
            echo -e "\033[93m$2\033[0m"
            ;;
        blue)
            echo -e "\033[94m$2\033[0m"
            ;;
        *)
            echo "$2"
            ;;
    esac
}

print_in_color none "Checking for venv..."
if [[ "$VIRTUAL_ENV" == "" ]]; then
    print_in_color red "Warning: Not running in a virtual environment; run install.sh instead"
    exit 1
fi

if [[ -z "$KAMIWAZA_RUN_FROM_INSTALL" ]]; then
    print_in_color red "Don't run directly; run install.sh instead"
    exit 1
fi

# ensure requirements installed/up to date
pip install --upgrade -r requirements.txt

tmp_dir=$(mktemp -d tmp_XXXXXX)
pushd "$tmp_dir" > /dev/null

echo "pwd: `pwd`"
if ! [ -f '../compile.sh' ] && ! python -c "import kamiwaza" &> /dev/null; then
    print_in_color yellow "The kamiwaza package is not installed - will install"
    popd > /dev/null
    rm -rf "$tmp_dir"
    kamiwaza_wheel=$(find . -name 'kamiwaza*.whl')
    if [[ -z "$kamiwaza_wheel" ]]; then
        print_in_color red "kamiwaza wheel file not found. Please ensure it's available and rerun this installer."
        exit 1
    else
        print_in_color blue "Installing kamiwaza package from wheel file: $kamiwaza_wheel"
        pip install "$kamiwaza_wheel"
        if [[ "$?" -ne 0 ]]; then
            print_in_color red "Failed to install kamiwaza package."
            exit 1
        else
            print_in_color green "Installed. Retesting."
        fi
        tmp_dir=$(mktemp -d tmp_XXXXXX)
        pushd "$tmp_dir" > /dev/null
        if ! python -c "import kamiwaza" &> /dev/null; then
            print_in_color red "Failed to verify the installation of kamiwaza package."
            popd > /dev/null
            rm -rf "$tmp_dir"
            exit 1
        else
            popd > /dev/null
            rm -rf "$tmp_dir"
            print_in_color green "kamiwaza package was successfully installed."
        fi
    fi
else
    popd > /dev/null
    rm -rf "$tmp_dir"
    print_in_color green "kamiwaza package is installed."
fi

print_in_color none "Checking for prerequisites..."
# Test if 'cockroach' command is available in PATH
if ! command -v cockroach &> /dev/null; then
    print_in_color red "CockroachDB command line tool 'cockroach' could not be found."
    if [[ "$(uname)" == "Darwin" ]]; then
        echo "If you are on OSX, you can install CockroachDB using Homebrew with the command: brew install cockroach"
    else
        echo "Please install CockroachDB from https://www.cockroachlabs.com/ and ensure 'cockroach' is in your PATH."
    fi
    exit 1
else
    print_in_color green "CockroachDB command line tool 'cockroach' is available."
fi

# Test if 'cfssl' command is available in PATH
if ! command -v cfssl &> /dev/null; then
    print_in_color red "CFSSL command line tool 'cfssl' could not be found."
    if [[ "$(uname)" == "Darwin" ]]; then
        echo "If you are on OSX, you can install CFSSL using Homebrew with the command: brew install cfssl"
    elif [[ "$(uname)" == "Linux" ]]; then
        echo "On Linux, the installer should have installed, but:"
        echo "sudo apt install -y python3.10 python3.10-dev libpython3.10-dev python3.10-venv golang-cfssl python-is-python3 etcd-client net-tools"
    else
        echo "Please install CFSSL from https://cfssl.org/ and ensure 'cfssl' is in your PATH."
    fi
    exit 1
else
    print_in_color green "CFSSL command line tool 'cfssl' is available."
fi

# Test if 'etcd-client' command is available in PATH
if ! command -v etcdctl &> /dev/null; then
    print_in_color red "etcd-client command line tool 'etcdctl' could not be found."
    if [[ "$(uname)" == "Darwin" ]]; then
        echo "If you are on OSX, you can install etcd-client using Homebrew with the command: brew install etcd"
    elif [[ "$(uname)" == "Linux" ]]; then
        echo "On Linux, the installer should have installed, but:"
        echo "sudo apt install -y etcd-client"
    else
        echo "Please install etcd-client from https://etcd.io/ and ensure 'etcdctl' is in your PATH."
    fi
    exit 1
else
    etcdctl_version=$(etcdctl version 2>/dev/null | awk '/etcdctl version:/ {print $3}')
    if [[ -z "$etcdctl_version" ]]; then
        print_in_color yellow "Unable to determine etcdctl version. Assuming it needs an update."
        etcdctl_version="0.0.0"  # Set to a version that will trigger the update
    fi
    
    if [[ "$etcdctl_version" < "3.5" ]]; then
        print_in_color yellow "etcd-client version is less than 3.5 or unknown. Attempting to update..."
        if [[ "$(uname)" == "Darwin" ]]; then
            print_in_color yellow 'Run `brew upgrade etcd` to update etcd on macOS.'
            exit 1
        else
            print_in_color yellow 'Running install-or-update-etcd.sh...'
            source install-or-update-etcd.sh
            # Re-test etcdctl version after update
            if ! command -v etcdctl &> /dev/null; then
                print_in_color red "Failed to install etcdctl. Please install manually."
                exit 1
            fi
            etcdctl_version=$(etcdctl version 2>/dev/null | awk '/etcdctl version:/ {print $3}')
            if [[ -z "$etcdctl_version" ]] || [[ "$etcdctl_version" < "3.5" ]]; then
                print_in_color red "Failed to update etcd-client to version 3.5 or higher, or unable to determine version. Please update manually."
                exit 1
            fi
        fi
    fi
    
    if [[ -z "$etcdctl_version" ]]; then
        print_in_color yellow "etcd-client command line tool 'etcdctl' is available, but unable to determine its version."
    else
        print_in_color green "etcd-client command line tool 'etcdctl' is available and version is $etcdctl_version."
    fi
fi

# Test if 'netstat' command is available in PATH
if ! command -v netstat &> /dev/null; then
    print_in_color red "netstat command line tool 'netstat' could not be found."
    if [[ "$(uname)" == "Darwin" ]]; then
        echo "If you are on OSX, you can install netstat using Homebrew with the command: brew install net-tools"
    elif [[ "$(uname)" == "Linux" ]]; then
        echo "On Linux, the installer should have installed, but:"
        echo "sudo apt install -y net-tools"
    else
        echo "Please install netstat from your package manager and ensure 'netstat' is in your PATH."
    fi
    echo "netstat is optional, so proceeding"
else
    print_in_color green "netstat command line tool 'netstat' is available."
fi

# Test if 'python3.10' command is available and its version
if ! python3.10 --version &> /dev/null; then
    print_in_color red "Python 3.10 could not be found."
    if [[ "$(uname)" == "Darwin" ]]; then
        echo "If you are on OSX, you can install Python 3.10 using Homebrew with the command: brew install python@3.10"
    elif [[ "$(uname)" == "Linux" ]]; then
        echo "On Linux, the installer should have installed, but:"
        echo "sudo apt install -y python3.10"
    else
        echo "Please install Python 3.10 from https://www.python.org/ and ensure 'python3.10' is in your PATH."
    fi
    exit 1
else
    python_version=$(python3.10 --version)
    if [[ "$python_version" == "Python 3.10."* ]]; then
        print_in_color green "Python 3.10 is available: $python_version"
    else
        print_in_color red "Python 3.10 is not the default version."
        exit 1
    fi
fi

# Test if 'python' command is available and its version
if ! python --version &> /dev/null; then
    print_in_color red "Python could not be found."
    exit 1
else
    python_version=$(python --version)
    if [[ "$python_version" == "Python 3.10."* ]]; then
        print_in_color green "Python is available: $python_version"
    else
        print_in_color red "Python is not the correct version (3.10)."
        exit 1
    fi
fi


print_in_color none "Checking for Docker installation and permissions..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    print_in_color red "Docker could not be found. Please install Docker and try again."
    exit 1
else
    print_in_color green "Docker is installed."
fi

# Check if 'docker compose' command is available
if ! docker compose version &> /dev/null; then
    print_in_color red "'docker compose' command is not available. Please ensure you have Docker Compose v2 and try again."
    exit 1
else
    print_in_color green "'docker compose' command is available."
fi

# Test if the user has access to the Docker daemon
if ! docker info &> /dev/null; then
    print_in_color red "You do not have access to the Docker daemon. Please ensure your user is added to the 'docker' group and try again."
    exit 1
else
    print_in_color green "You have access to the Docker daemon."
fi

print_in_color green "***********************************************************"
print_in_color green "==== Kamiwaza Installer ===="
print_in_color yellow "Your use of this software is subject to the license agreement. If you do not agree to the license terms, say no, exit this installer, and delete all copies of the software"

if [ ! -f LICENSE-kamiwaza ] ; then
    print_in_color red "License file not found. Contact support@kamiwaza.ai"
    exit 1
fi

if [[ "$USER_ACCEPTED_KAMIWAZA_LICENSE" == "yes" ]]; then
    print_in_color green "License agreement accepted via CLI flag. Continuing with installation..."
else
    more LICENSE-kamiwaza
    read -p "Do you agree to the license terms? (yes/no) " agreement
    if [[ "$agreement" != "yes" && "$agreement" != "y" ]]; then
        print_in_color red "You did not agree to the license terms. Exiting installer."
        exit 1
    else
        print_in_color green "You have agreed to the license terms. Continuing with installation..."
    fi
fi
# Check if 'notebook-venv' directory does not exist
if [ ! -d 'notebook-venv' ] ; then
    print_in_color none "Creating and activating the notebook virtual environment..."
    # Proceed with creating and activating the notebook virtual environment
    (
    python -m venv notebook-venv
    print_in_color none " ### Installing Notebook environment and packages... "
    source notebook-venv/bin/activate
    kamiwaza_wheel=$(find . -name 'kamiwaza*.whl')
    pip install "$kamiwaza_wheel"
    pip install -r requirements.txt
    )
else
    print_in_color red "Warning: 'notebook-venv' already exists. This may indicate that Kamiwaza is already installed."
    read -p "Do you want us to attempt to install the virtual environment and requirements anyway? (yes/no) " attempt_install
    if [[ "$attempt_install" != "yes" && "$attempt_install" != "y" ]]; then
        print_in_color yellow "Skipping virtual environment and requirements installation."
    else
        # Proceed with creating and activating the notebook virtual environment
        (
        python -m venv notebook-venv
        print_in_color green " ### Installing Notebook environment and packages... "
        source notebook-venv/bin/activate
        kamiwaza_wheel=$(find . -name 'kamiwaza*.whl')
        pip install "$kamiwaza_wheel"
        pip install -r requirements.txt
        pip install -r notebooks/extra-requirements.txt
        )
    fi
fi

# deactivate notebook venv if needed
deactivate || true

source venv/bin/activate

# Check for --install_llamacpp flag and set variable
install_llamacpp="no"
for arg in "$@"; do
    if [ "$arg" == "--install_llamacpp" ]; then
        install_llamacpp="yes"
        break
    fi
done

if [ -f llamacpp.commit ] ; then
    if [[ "$install_llamacpp" == "yes" || "$(uname)" == "Darwin" ]]; then
        print_in_color green "### Installing llamacpp..."
        bash build-llama-cpp.sh
    else
        print_in_color yellow "Skipping llamacpp installation."
    fi
fi

print_in_color none "### Running Kamiwaza install.py..."
python install.py
if [ $? -ne 0 ]; then
    print_in_color red "Kamiwaza install.py failed. Exiting."
    exit 1
else
    print_in_color green "Kamiwaza install.py completed successfully."
    touch ~/.kamiwaza-installed
fi

