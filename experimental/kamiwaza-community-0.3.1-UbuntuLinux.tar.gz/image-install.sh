#!/bin/bash

# Function to print messages in colors
print_in_color() {
    case $1 in
        green)
            echo -e "\033[92m$2\033[0m"
            ;;
        red)
            echo -e "\033[91m$2\033[0m"
            ;;
        yellow)
            echo -e "\033[93m$2\033[0m"
            ;;
        *)
            echo "$2"
            ;;
    esac
}

# Check if NVM is installed and if Node.js v21 is available
if command -v nvm > /dev/null 2>&1; then
    print_in_color green "NVM is already installed."
else
    print_in_color yellow "NVM is not installed. Installing NVM..."
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
    export NVM_DIR="$([ -z "${XDG_CONFIG_HOME-}" ] && printf %s "${HOME}/.nvm" || printf %s "${XDG_CONFIG_HOME}/nvm")"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
fi

# Load NVM
export NVM_DIR="$([ -z "${XDG_CONFIG_HOME-}" ] && printf %s "${HOME}/.nvm" || printf %s "${XDG_CONFIG_HOME}/nvm")"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

# Check if Node.js v21 is installed
if nvm ls 21 > /dev/null 2>&1; then
    print_in_color green "Node.js v21 is already installed."
else
    print_in_color yellow "Node.js v21 is not installed. Installing Node.js v21..."
    nvm install 21
fi


# Add user to docker group
print_in_color yellow "Adding $USER to docker group..."
if sudo usermod -aG docker $USER; then
    print_in_color green "Successfully added $USER to docker group."
else
    print_in_color red "Failed to add $USER to docker group."
    exit 1
fi

# Verify docker group membership
if groups | grep -q '\bdocker\b'; then
    print_in_color green "Confirmed: User is now in the docker group."
else
    print_in_color red "User is not in the docker group. Please log out and log back in to apply changes."
    exit 1
fi

# Use sudo to execute commands with the new group membership
print_in_color yellow "Applying new group membership..."
if sudo -g docker bash -c 'groups | grep -q "\bdocker\b"'; then
    print_in_color green "Successfully applied new group membership."
else
    print_in_color red "Failed to apply new group membership."
    exit 1
fi

echo "Running install.sh..."
source install.sh

touch ~/.kamiwaza-installed

print_in_color green "Script completed successfully."