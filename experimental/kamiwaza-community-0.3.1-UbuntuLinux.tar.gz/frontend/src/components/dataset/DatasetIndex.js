import React from 'react';
import DatasetSearch from './DatasetSearch';
import DatasetList from './DatasetList';
import DatasetDetails from './DatasetDetails';

const DatasetIndex = () => {
  return (
    <div className='main-content'>
      <h1>Datasets</h1>
      <DatasetSearch />
      <DatasetList />
    </div>
  );
};

export default DatasetIndex;
