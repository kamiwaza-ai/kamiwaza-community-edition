#!/bin/bash

# Get the directory of the script
script_dir=$(dirname "$(readlink -f "$0")")

# Add script directory to PYTHONPATH if dev file layout
if [[ "$script_dir" == *"kamiwaza"* ]] && [[ ! -f "$script_dir/launch.py" ]]; then
    export PYTHONPATH="${PYTHONPATH}:${script_dir}"
fi

# Activate the virtual environment
if [ ! -f venv/bin/activate ] ; then
    echo "venv/bin/activate not found, you are running from the wrong directory or have not run install.sh"
    exit 1
fi

source venv/bin/activate

export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python
export ray_dashboard_host="0.0.0.0"

# Determine the number of CPUs
if [[ "$OSTYPE" == "darwin"* ]]; then
    # On macOS, limit to performance cores if possible
    num_cpus=$(sysctl -n hw.perflevel0.logicalcpu_max)
    if [ -z "$num_cpus" ]; then
        num_cpus=$(sysctl -n hw.ncpu)
    fi
else
    num_cpus=$(grep -c ^processor /proc/cpuinfo)
fi

# Determine the number of GPUs using nvidia-smi, be graceful if it fails
if command -v nvidia-smi &> /dev/null; then
    num_gpus=$(nvidia-smi --list-gpus | wc -l)
else
    num_gpus=0
fi

# Check if running on macOS
if [[ "$OSTYPE" == "darwin"* ]]; then
    num_gpus=0
fi

# Override with environment variables if set
if [ -n "$KAMIWAZA_NUM_CPUS" ]; then
    num_cpus=$KAMIWAZA_NUM_CPUS
fi

if [ -n "$KAMIWAZA_NUM_GPUS" ]; then
    num_gpus=$KAMIWAZA_NUM_GPUS
fi

# Start ray with appropriate parameters
if [ "$num_gpus" -gt 0 ]; then
    ray start --num-cpus $num_cpus --num-gpus $num_gpus --head --dashboard-host 0.0.0.0
else
    ray start --num-cpus $num_cpus --head --dashboard-host 0.0.0.0
fi
