#!/bin/bash
set -x

# Split EXCLUDE_CONTAINERS into an array if it is comma separated
EXCLUDE_CONTAINERS=${KAMIWAZA_EXCLUDE_CONTAINERS:-qdrant,nonexistant}
excluded_containers=(${EXCLUDE_CONTAINERS//,/ })

# Test for KAMIWAZA_ROOT in the environment and set/export it if not set
if [ -z "${KAMIWAZA_ROOT}" ]; then
    script_dir=$(dirname "$0")
    # Yes, these paths both lead to the same result; however, highlighting
    # that launch.py can be in ROOT or ROOT/kamiwaza, depending on the
    # install methods/env, but either way we want the upper folder
    if [ -f "$script_dir/launch.py" ]; then
        export KAMIWAZA_ROOT=$(cd "$script_dir" && pwd)
    elif [ -f "$script_dir/kamiwaza/launch.py" ]; then
        export KAMIWAZA_ROOT=$(cd "$script_dir" && pwd)
    fi
fi

# Determine platform
if [[ "$(uname)" == "Darwin" ]]; then
    platform='osx'
else
    platform='linux'
fi

# Determine architecture
arch_raw=$(uname -m)
case "$arch_raw" in
    "x86_64")
        arch='amd64'
        ;;
    "aarch64"|"arm64")
        arch='arm64'
        ;;
    *)
        echo "Unsupported architecture: $arch_raw"
        exit 1
        ;;
esac

# Determine CPU or GPU
if command -v nvidia-smi &> /dev/null && nvidia-smi > /dev/null 2>&1; then
    cpugpu='gpu'
else
    cpugpu='cpu'
fi

# Check for KAMIWAZA_ENV, set to "default" if not set
KAMIWAZA_ENV=${KAMIWAZA_ENV:-default}

# Get the component argument if provided
component_arg=$1

# Pull retagged containers
# Read version from kamiwaza.version.json if not set
if [ -z "${KAMIWAZA_VERSION_MAJOR}" ] || [ -z "${KAMIWAZA_VERSION_MINOR}" ] || [ -z "${KAMIWAZA_VERSION_PATCH}" ]; then
    if [ -f "${KAMIWAZA_ROOT}/kamiwaza.version.json" ]; then
        # Using sed instead of grep -P for better compatibility
        KAMIWAZA_VERSION_MAJOR=$(sed -n 's/.*"KAMIWAZA_VERSION_MAJOR": *\([^,}]*\).*/\1/p' "${KAMIWAZA_ROOT}/kamiwaza.version.json" | tr -d '"')
        KAMIWAZA_VERSION_MINOR=$(sed -n 's/.*"KAMIWAZA_VERSION_MINOR": *\([^,}]*\).*/\1/p' "${KAMIWAZA_ROOT}/kamiwaza.version.json" | tr -d '"')
        KAMIWAZA_VERSION_PATCH=$(sed -n 's/.*"KAMIWAZA_VERSION_PATCH": *\([^,}]*\).*/\1/p' "${KAMIWAZA_ROOT}/kamiwaza.version.json" | tr -d '"')

        # Check if any of the version components are empty
        if [ -z "${KAMIWAZA_VERSION_MAJOR}" ] || [ -z "${KAMIWAZA_VERSION_MINOR}" ] || [ -z "${KAMIWAZA_VERSION_PATCH}" ]; then
            echo "Error: Failed to read version components from kamiwaza.version.json properly"
            exit 1
        fi
    else
        echo "Error: kamiwaza.version.json not found and version not set in environment"
        exit 1
    fi
fi

kamiwaza_version="${KAMIWAZA_VERSION_MAJOR}.${KAMIWAZA_VERSION_MINOR}.${KAMIWAZA_VERSION_PATCH}"
kamiwaza_prefix="mattwallace/kamiwaza"
vanilla_containers=("vllm/vllm-openai:v0.5.3.post1")
# Check if the processor is Ampere
is_ampere=false
if command -v lscpu &> /dev/null; then
    if lscpu | grep -qi 'ampere'; then
        is_ampere=true
        vanilla_containers+=("amperecomputingai/llama.cpp:latest")
    fi
fi

for container in "${vanilla_containers[@]}"; do
    base_name=$(echo "$container" | awk -F'/' '{print $NF}' | awk -F':' '{print $1}')
    version_tag=$(echo "$container" | awk -F':' '{print $2}')
    new_image_name="${kamiwaza_prefix}-${base_name}:${kamiwaza_version}-${version_tag}-${arch}-${cpugpu}"
    new_image_name=$(echo "$new_image_name" | tr '[:upper:]' '[:lower:]')

    echo "Pulling $new_image_name..."
    if ! docker pull "$new_image_name"; then
        echo "#### ERROR: Failed to pull image $new_image_name"
    fi
done

# Main loop to process components
for component_path in $(find kamiwaza/deployment -mindepth 1 -maxdepth 1 -type d | grep -v '/envs$'); do
    component=$(basename $component_path)
    
    # If a component argument is provided, skip components that don't match
    if [[ -n "$component_arg" && "$component" != *"$component_arg"* ]]; then
        continue
    fi

    # Check if the component is excluded
    exclude=false
    for excluded in "${excluded_containers[@]}"; do
        if [[ "$component" == *"$excluded"* ]]; then
            exclude=true
            break
        fi
    done
    if [[ "$exclude" == true ]]; then
        echo "Skipping $component because it is excluded"
        continue
    fi

    # Determine the appropriate architecture suffixes to create directories for
    arch_suffixes=() # Initialize an empty array to hold potential architecture suffixes
    if [[ -d "kamiwaza/deployment/${component}/${arch}" ]]; then
        arch_suffixes+=("${arch}")
    fi
    if [[ -d "kamiwaza/deployment/${component}/${arch}-cpu" ]]; then
        arch_suffixes+=("${arch}-cpu")
    fi
    if [[ -d "kamiwaza/deployment/${component}/${arch}-gpu" ]]; then
        arch_suffixes+=("${arch}-gpu")
    fi

    # Create environment specific directories based on the architecture suffixes found
    for suffix in "${arch_suffixes[@]}"; do
        mkdir -p "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}"
    done

    # Copy files from both architecture and architecture with CPU/GPU suffix if they exist
    for suffix in "${arch_suffixes[@]}"; do
        for file in docker-compose.yml prelaunch.sh postlaunch.sh; do
            if [[ -f "kamiwaza/deployment/${component}/${suffix}/${file}" ]]; then
                cp "kamiwaza/deployment/${component}/${suffix}/${file}" "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}/"
            fi
        done
        # Copy any other *.yml files in the source to the target
        for yml_file in kamiwaza/deployment/${component}/${suffix}/*.yml; do
            if [[ -f "$yml_file" ]]; then
                cp "$yml_file" "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}/"
            fi
        done
        # Copy any *.py files in the source to the target
        for py_file in kamiwaza/deployment/${component}/${suffix}/*.py; do
            if [[ -f "$py_file" ]]; then
                cp "$py_file" "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}/"
            fi
        done
    done

    # Determine the appropriate architecture folder considering CPU/GPU suffix for further operations
    if [[ "$cpugpu" == "gpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-gpu" ]]; then
        arch_folder="${arch}-gpu"
    elif [[ -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}" ]]; then
        arch_folder="${arch}"
    elif [[ "$cpugpu" == "cpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-cpu" ]]; then
        arch_folder="${arch}-cpu"
    else
        echo "No suitable architecture folder found for component: ${component}"
        continue
    fi

    # Navigate to the component directory
    cd "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch_folder}"

    # Execute lifecycle scripts if they exist
    [[ -f "prelaunch.sh" ]] && bash "prelaunch.sh" > prelaunch.log 2>&1
    docker compose -f "docker-compose.yml" -p "${KAMIWAZA_ENV}-${component}" up -d
    [[ -f "launch.sh" ]] && sleep 5 && bash "launch.sh" > launch.log 2>&1
    [[ -f "postlaunch.sh" ]] && sleep 5 && bash "postlaunch.sh" > postlaunch.log 2>&1

    # Return to the original directory
    cd - > /dev/null
done
exit 0