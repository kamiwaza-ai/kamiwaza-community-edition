import React from 'react';
import { renderWithTheme } from '../../../test-utils';
import NewsPreview from '../NewsPreview';
import axios from 'axios';

jest.mock('axios');
const mockedAxios = axios;

const mockData = {
  quadrants: {
    updates: {
      title: 'Updates',
      items: [
        { id: 1, title: 'u1' },
        { id: 2, title: 'u2' },
        { id: 3, title: 'u3' },
        { id: 4, title: 'u4' }
      ]
    },
    news: { title: 'Latest News', items: [{ id: 5, title: 'n1' }] },
    events: { title: 'Events', items: [] },
    general: { title: 'General', items: [] }
  }
};

beforeEach(() => {
  sessionStorage.clear();
  mockedAxios.get.mockClear();
  mockedAxios.get.mockResolvedValue({ data: mockData });
});

describe('NewsPreview', () => {
  test('renders preview items and view more link', async () => {
    const { findByText } = renderWithTheme(<NewsPreview />);
    expect(mockedAxios.get).toHaveBeenCalled();

    expect(await findByText('u1')).toBeInTheDocument();
    expect(await findByText('View more')).toBeInTheDocument();
  });

  test('uses cached data when available', async () => {
    sessionStorage.setItem('newsPreviewData', JSON.stringify({ data: mockData, timestamp: Date.now() }));
    const { findByText } = renderWithTheme(<NewsPreview />);
    expect(mockedAxios.get).not.toHaveBeenCalled();
    expect(await findByText('u1')).toBeInTheDocument();
  });
});
