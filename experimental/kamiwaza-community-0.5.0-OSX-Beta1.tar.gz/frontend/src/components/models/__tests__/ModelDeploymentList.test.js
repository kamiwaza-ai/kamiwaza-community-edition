import React from 'react';
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import axios from 'axios';
import ModelDeploymentList from '../ModelDeploymentList';

// Mock axios
jest.mock('axios');
const mockedAxios = axios;

// Mock child components
jest.mock('../../common/Spinner', () => {
  return function MockSpinner() {
    return <div data-testid="spinner">Loading...</div>;
  };
});

jest.mock('../../common/ErrorComponent', () => {
  return function MockErrorComponent({ message }) {
    return <div data-testid="error-component">Error: {message}</div>;
  };
});

jest.mock('../ModelDeploymentDetail', () => {
  return function MockModelDeploymentDetailModal({ deploymentId, isOpen, onClose, onDeploymentStopped }) {
    return isOpen ? (
      <div data-testid="deployment-detail-modal">
        <div>Deployment ID: {deploymentId}</div>
        <button onClick={onClose}>Close</button>
        <button onClick={onDeploymentStopped}>Deployment Stopped</button>
      </div>
    ) : null;
  };
});

// Mock BASE_URL
jest.mock('../../../const', () => ({
  BASE_URL: 'http://localhost:8000'
}));

// Mock window.location
delete window.location;
window.location = { 
  hostname: 'localhost',
  protocol: 'http:'
};

// Mock MUI Dialog to make it testable
jest.mock('@mui/material/Dialog', () => {
  return function MockDialog({ open, children, onClose }) {
    return open ? <div role="dialog">{children}</div> : null;
  };
});

// Test data factory
const createMockDeployment = (overrides = {}) => ({
  id: `dep-${Math.random().toString(36).substr(2, 9)}`,
  m_id: 'model-123',
  m_name: 'Test Model',
  engine_name: 'vllm',
  m_config_name: 'Config A',
  lb_port: 8080,
  status: 'RUNNING',
  ...overrides
});

describe('ModelDeploymentList', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    // Default mock for successful empty response
    mockedAxios.get.mockResolvedValue({ data: [] });
    mockedAxios.delete.mockResolvedValue({ data: { success: true } });
  });

  describe('Rendering States', () => {
    test('renders loading state initially', () => {
      render(<ModelDeploymentList />);
      expect(screen.getByTestId('spinner')).toBeInTheDocument();
    });

    test('renders error state on fetch failure', async () => {
      mockedAxios.get.mockRejectedValueOnce(new Error('Network error'));
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByTestId('error-component')).toBeInTheDocument();
        expect(screen.getByText('Error: Network error')).toBeInTheDocument();
      });
    });

    test('renders empty state when no deployments', async () => {
      mockedAxios.get.mockResolvedValueOnce({ data: [] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('No deployed models found')).toBeInTheDocument();
      });
    });

    test('renders deployment table with data', async () => {
      const mockDeployments = [
        createMockDeployment({ m_name: 'GPT-4' }),
        createMockDeployment({ m_name: 'Claude-3' })
      ];
      
      mockedAxios.get.mockResolvedValueOnce({ data: mockDeployments });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('GPT-4')).toBeInTheDocument();
        expect(screen.getByText('Claude-3')).toBeInTheDocument();
      });
    });

    test('shows selection checkboxes when onSelectionChange provided', async () => {
      const mockDeployments = [createMockDeployment()];
      mockedAxios.get.mockResolvedValueOnce({ data: mockDeployments });
      
      const handleSelectionChange = jest.fn();
      render(<ModelDeploymentList onSelectionChange={handleSelectionChange} />);
      
      await waitFor(() => {
        // Should have header checkbox and row checkbox
        const checkboxes = screen.getAllByRole('checkbox');
        expect(checkboxes).toHaveLength(2);
      });
    });

    test('hides selection checkboxes when onSelectionChange not provided', async () => {
      const mockDeployments = [createMockDeployment()];
      mockedAxios.get.mockResolvedValueOnce({ data: mockDeployments });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        const checkboxes = screen.queryAllByRole('checkbox');
        expect(checkboxes).toHaveLength(0);
      });
    });
  });

  describe('Data Fetching', () => {
    test('fetches deployments on mount', async () => {
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(mockedAxios.get).toHaveBeenCalledWith(
          'http://localhost:8000/serving/deployments'
        );
      });
    });

    test('includes model_id in query when provided', async () => {
      render(<ModelDeploymentList model_id="model-456" />);
      
      await waitFor(() => {
        expect(mockedAxios.get).toHaveBeenCalledWith(
          'http://localhost:8000/serving/deployments?model_id=model-456'
        );
      });
    });

    test('refetches when refreshDeployments prop changes', async () => {
      const { rerender } = render(<ModelDeploymentList refreshDeployments={1} />);
      
      await waitFor(() => {
        expect(mockedAxios.get).toHaveBeenCalledTimes(1);
      });
      
      rerender(<ModelDeploymentList refreshDeployments={2} />);
      
      await waitFor(() => {
        expect(mockedAxios.get).toHaveBeenCalledTimes(2);
      });
    });
  });

  describe('Deployment Display', () => {
    test('displays deployment information correctly', async () => {
      const deployment = createMockDeployment({
        m_name: 'Test Model',
        engine_name: 'vllm',
        m_config_name: 'Custom Config',
        lb_port: 9090
      });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
        expect(screen.getByText('vllm')).toBeInTheDocument();
        expect(screen.getByText('Custom Config')).toBeInTheDocument();
        expect(screen.getByText('9090')).toBeInTheDocument();
        expect(screen.getByText('localhost')).toBeInTheDocument();
      });
    });

    test('shows defaults for missing fields', async () => {
      const deployment = createMockDeployment({
        engine_name: null,
        m_config_name: null
      });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Unknown')).toBeInTheDocument();
        expect(screen.getByText('Default Config')).toBeInTheDocument();
      });
    });

    test('filters out stopped deployments', async () => {
      const deployments = [
        createMockDeployment({ m_name: 'Active Model', status: 'RUNNING' }),
        createMockDeployment({ m_name: 'Stopped Model', status: 'STOPPED' })
      ];
      
      mockedAxios.get.mockResolvedValueOnce({ data: deployments });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Active Model')).toBeInTheDocument();
        expect(screen.queryByText('Stopped Model')).not.toBeInTheDocument();
      });
    });

    test('shows Failed status for failed deployments', async () => {
      const deployment = createMockDeployment({
        status: 'FAILED',
        lb_port: 8080
      });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Failed')).toBeInTheDocument();
        expect(screen.queryByText('/v1/chat/completions')).not.toBeInTheDocument();
      });
    });

    test('shows deployments with INITIALIZING status', async () => {
      const deployment = createMockDeployment({
        status: 'INITIALIZING',
        m_name: 'Initializing Model',
        lb_port: 8080
      });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Initializing Model')).toBeInTheDocument();
        // INITIALIZING deployments should still show endpoint info
        expect(screen.getByText('/v1/chat/completions')).toBeInTheDocument();
      });
    });
  });

  describe('API Links', () => {
    test('displays chat completions endpoint', async () => {
      const deployment = createMockDeployment({ lb_port: 8080 });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        // The endpoint is displayed as text with a tooltip, not a link
        const endpoint = screen.getByText('/v1/chat/completions');
        expect(endpoint).toBeInTheDocument();
        // It should have a tooltip
        expect(endpoint).toHaveAttribute('aria-label', 'Use the Test button to interact with this endpoint');
      });
    });

    test('shows API Docs link only for vllm engine', async () => {
      const vllmDeployment = createMockDeployment({ 
        engine_name: 'vllm',
        lb_port: 8080 
      });
      const otherDeployment = createMockDeployment({ 
        id: 'dep-2',
        engine_name: 'llamacpp',
        lb_port: 8081 
      });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [vllmDeployment, otherDeployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        const apiDocsLinks = screen.getAllByText('/docs');
        expect(apiDocsLinks).toHaveLength(1);
        expect(apiDocsLinks[0]).toHaveAttribute('href', 'http://localhost:8080/docs');
      });
    });

    test('handles deployments without port', async () => {
      const deployment = createMockDeployment({ 
        lb_port: 0 
      });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.queryByText('/v1/chat/completions')).not.toBeInTheDocument();
        // Check that the cell exists but is empty (contains only nbsp)
        const rows = screen.getAllByRole('row');
        expect(rows).toHaveLength(2); // header + 1 data row
      });
    });
  });

  describe('Selection Functionality', () => {
    test('select all checkbox selects all active deployments', async () => {
      const user = userEvent.setup();
      const deployments = [
        createMockDeployment({ id: 'dep-1', m_name: 'Model 1', status: 'RUNNING' }),
        createMockDeployment({ id: 'dep-2', m_name: 'Model 2', status: 'RUNNING' }),
        createMockDeployment({ id: 'dep-3', m_name: 'Model 3', status: 'STOPPED' }) // Should be filtered out
      ];
      
      mockedAxios.get.mockResolvedValueOnce({ data: deployments });
      
      const handleSelectionChange = jest.fn();
      render(<ModelDeploymentList onSelectionChange={handleSelectionChange} />);
      
      await waitFor(() => {
        expect(screen.getByText('Model 1')).toBeInTheDocument();
      });
      
      const headerCheckbox = screen.getAllByRole('checkbox')[0];
      await user.click(headerCheckbox);
      
      expect(handleSelectionChange).toHaveBeenCalledWith(['dep-1', 'dep-2']);
    });

    test('individual checkbox toggles selection', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment({ id: 'dep-1' });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      const handleSelectionChange = jest.fn();
      render(<ModelDeploymentList 
        onSelectionChange={handleSelectionChange}
        selectedDeployments={[]}
      />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      const rowCheckbox = screen.getAllByRole('checkbox')[1];
      await user.click(rowCheckbox);
      
      expect(handleSelectionChange).toHaveBeenCalledWith(['dep-1']);
    });

    test('shows indeterminate state for partial selection', async () => {
      const deployments = [
        createMockDeployment({ id: 'dep-1', m_name: 'Model 1' }),
        createMockDeployment({ id: 'dep-2', m_name: 'Model 2' })
      ];
      
      mockedAxios.get.mockResolvedValueOnce({ data: deployments });
      
      render(<ModelDeploymentList 
        onSelectionChange={jest.fn()}
        selectedDeployments={['dep-1']}
      />);
      
      await waitFor(() => {
        expect(screen.getByText('Model 1')).toBeInTheDocument();
      });
      
      // For MUI checkboxes, the indeterminate state is represented by data attributes
      const checkboxes = screen.getAllByRole('checkbox');
      const headerCheckbox = checkboxes[0];
      
      // Check if the checkbox has both checked and unchecked items (indeterminate state)
      expect(checkboxes).toHaveLength(3); // header + 2 row checkboxes
      expect(checkboxes[1]).toBeChecked(); // First row is selected
      expect(checkboxes[2]).not.toBeChecked(); // Second row is not selected
    });
  });

  describe('Stop Deployment', () => {
    test('opens confirmation dialog on stop click', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment({ m_name: 'Model to Stop' });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Model to Stop')).toBeInTheDocument();
      });
      
      const stopButton = screen.getByText('Stop');
      await user.click(stopButton);
      
      await waitFor(() => {
        // Use getAllByText since "Stop Deployment" appears as both dialog title and button text
        const stopDeploymentElements = screen.getAllByText('Stop Deployment');
        expect(stopDeploymentElements.length).toBeGreaterThan(0);
      });
      
      expect(screen.getByText(/Are you sure you want to stop the deployment for/)).toBeInTheDocument();
      
      // Use getAllByText since the model name appears in both table and dialog
      const modelNameElements = screen.getAllByText('Model to Stop');
      expect(modelNameElements.length).toBeGreaterThan(1);
    });

    test('cancels stop operation', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment();
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      await user.click(screen.getByText('Stop'));
      
      await waitFor(() => {
        const stopDeploymentElements = screen.getAllByText('Stop Deployment');
        expect(stopDeploymentElements.length).toBeGreaterThan(0);
      });
      
      await user.click(screen.getByText('Cancel'));
      
      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
      });
      
      expect(mockedAxios.delete).not.toHaveBeenCalled();
    });

    test('confirms stop operation and refreshes list', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment({ id: 'dep-123' });
      
      mockedAxios.get
        .mockResolvedValueOnce({ data: [deployment] })
        .mockResolvedValueOnce({ data: [] }); // After stop
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      await user.click(screen.getByText('Stop'));
      
      const confirmButton = screen.getByRole('button', { name: 'Stop Deployment' });
      await user.click(confirmButton);
      
      await waitFor(() => {
        expect(mockedAxios.delete).toHaveBeenCalledWith(
          'http://localhost:8000/serving/deployment/dep-123',
          { params: { force: true } }
        );
      });
      
      // Should refresh the list
      await waitFor(() => {
        expect(mockedAxios.get).toHaveBeenCalledTimes(2);
        expect(screen.getByText('No deployed models found')).toBeInTheDocument();
      });
    });

    test('shows loading state while stopping', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment({ id: 'dep-123' });
      
      // Delay the delete response
      mockedAxios.delete.mockImplementation(() => 
        new Promise(resolve => setTimeout(() => resolve({ data: { success: true } }), 100))
      );
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      const stopButton = screen.getByText('Stop');
      await user.click(stopButton);
      
      const confirmButton = screen.getByRole('button', { name: 'Stop Deployment' });
      await user.click(confirmButton);
      
      // Should show loading state
      expect(screen.getByText('Stopping...')).toBeInTheDocument();
      
      // Button in table should also show loading
      const tableStopButton = screen.getByText('Stopping');
      expect(tableStopButton).toBeInTheDocument();
    });

    test('handles stop error with alert', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment();
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      mockedAxios.delete.mockRejectedValueOnce(new Error('Stop failed'));
      
      // Mock window.alert
      const alertSpy = jest.spyOn(window, 'alert').mockImplementation();
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      await user.click(screen.getByText('Stop'));
      await user.click(screen.getByRole('button', { name: 'Stop Deployment' }));
      
      await waitFor(() => {
        expect(alertSpy).toHaveBeenCalledWith('Failed to stop deployment. Please try again.');
      });
      
      alertSpy.mockRestore();
    });
  });

  describe('Details Modal', () => {
    test('opens detail modal on Details click', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment({ id: 'dep-123' });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      const detailsButton = screen.getByText('Details');
      await user.click(detailsButton);
      
      expect(screen.getByTestId('deployment-detail-modal')).toBeInTheDocument();
      expect(screen.getByText('Deployment ID: dep-123')).toBeInTheDocument();
    });

    test('closes modal on close callback', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment();
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      await user.click(screen.getByText('Details'));
      
      const closeButton = within(screen.getByTestId('deployment-detail-modal')).getByText('Close');
      await user.click(closeButton);
      
      expect(screen.queryByTestId('deployment-detail-modal')).not.toBeInTheDocument();
    });

    test('refreshes list when deployment stopped from modal', async () => {
      const user = userEvent.setup();
      const deployment = createMockDeployment();
      
      mockedAxios.get
        .mockResolvedValueOnce({ data: [deployment] })
        .mockResolvedValueOnce({ data: [] }); // After refresh
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        expect(screen.getByText('Test Model')).toBeInTheDocument();
      });
      
      await user.click(screen.getByText('Details'));
      
      const stoppedButton = within(screen.getByTestId('deployment-detail-modal')).getByText('Deployment Stopped');
      await user.click(stoppedButton);
      
      await waitFor(() => {
        expect(mockedAxios.get).toHaveBeenCalledTimes(2);
      });
    });
  });

  describe('Model Link Navigation', () => {
    test('model name links to model page', async () => {
      const deployment = createMockDeployment({ 
        m_id: 'model-456',
        m_name: 'GPT-4'
      });
      
      mockedAxios.get.mockResolvedValueOnce({ data: [deployment] });
      
      render(<ModelDeploymentList />);
      
      await waitFor(() => {
        const modelLink = screen.getByRole('link', { name: 'GPT-4' });
        expect(modelLink).toHaveAttribute('href', '/models/model-456');
      });
    });
  });
});