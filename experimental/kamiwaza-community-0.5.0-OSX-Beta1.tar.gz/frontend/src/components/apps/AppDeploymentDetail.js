import React, { useState, useEffect } from 'react';
import { styled } from '@mui/material/styles';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Divider,
  Alert
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import RefreshIcon from '@mui/icons-material/Refresh';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import axios from 'axios';
import Spinner from '../common/Spinner';
import { BASE_URL } from '../../const';

// Styled components
const StyledDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialog-paper': {
    borderRadius: 12,
    backgroundColor: theme.palette.background.paper,
    backgroundImage: 'linear-gradient(rgba(0, 192, 127, 0.03), rgba(0, 0, 0, 0.03))',
    minWidth: 800,
  },
}));

const StyledDialogTitle = styled(DialogTitle)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  paddingBottom: theme.spacing(1),
}));

const TitleText = styled(Typography)(({ theme }) => ({
  fontSize: '1.5rem',
  fontWeight: 600,
  color: theme.palette.primary.main,
}));

const InfoSection = styled(Box)(({ theme }) => ({
  marginBottom: theme.spacing(3),
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  fontSize: '1.1rem',
  fontWeight: 600,
  marginBottom: theme.spacing(1.5),
  color: theme.palette.text.primary,
}));

const InfoGrid = styled(Box)(({ theme }) => ({
  display: 'grid',
  gridTemplateColumns: 'repeat(2, 1fr)',
  gap: theme.spacing(2),
  marginBottom: theme.spacing(2),
}));

const InfoItem = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
}));

const InfoLabel = styled(Typography)(({ theme }) => ({
  fontSize: '0.875rem',
  color: theme.palette.text.secondary,
  marginBottom: theme.spacing(0.5),
}));

const InfoValue = styled(Typography)(({ theme }) => ({
  fontSize: '1rem',
  fontWeight: 500,
}));

const EnvVarBox = styled(Box)(({ theme }) => ({
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  border: '1px solid rgba(255, 255, 255, 0.08)',
  borderRadius: 8,
  padding: theme.spacing(2),
  fontFamily: 'monospace',
  fontSize: '0.875rem',
  overflowX: 'auto',
}));

const StatusChip = styled(Chip)(({ theme, status }) => ({
  fontWeight: 500,
  ...(status === 'RUNNING' && {
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    color: '#4caf50',
    borderColor: '#4caf50',
  }),
  ...(status === 'DEPLOYED' && {
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    color: '#4caf50',
    borderColor: '#4caf50',
  }),
  ...(status === 'STOPPED' && {
    backgroundColor: 'rgba(158, 158, 158, 0.1)',
    color: '#9e9e9e',
    borderColor: '#9e9e9e',
  }),
  ...(status === 'FAILED' && {
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
    color: '#f44336',
    borderColor: '#f44336',
  }),
  ...(status === 'STARTING' && {
    backgroundColor: 'rgba(255, 152, 0, 0.1)',
    color: '#ff9800',
    borderColor: '#ff9800',
  }),
  ...(status === 'PULLING_IMAGES' && {
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    color: '#2196f3',
    borderColor: '#2196f3',
  }),
  ...(status === 'REQUESTED' && {
    backgroundColor: 'rgba(156, 39, 176, 0.1)',
    color: '#9c27b0',
    borderColor: '#9c27b0',
  }),
}));

const StyledTableContainer = styled(TableContainer)(({ theme }) => ({
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  borderRadius: 8,
  border: '1px solid rgba(255, 255, 255, 0.08)',
}));

const getStatusMessage = (status, imageStatus) => {
  switch (status) {
    case 'PULLING_IMAGES':
      if (imageStatus?.images?.length > 0) {
        const pulledCount = Object.values(imageStatus.image_status || {}).filter(Boolean).length;
        const totalCount = imageStatus.images.length;
        return `Pulling Images... (${pulledCount}/${totalCount})`;
      }
      return 'Pulling Images...';
    case 'REQUESTED':
      return 'Preparing Deployment...';
    case 'DEPLOYED':
      return 'Running';
    case 'FAILED':
      return 'Failed';
    case 'STOPPED':
      return 'Stopped';
    default:
      return status;
  }
};

const AppDeploymentDetail = ({ deploymentId, isOpen, onClose, onDeploymentStopped }) => {
  const [deployment, setDeployment] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (isOpen && deploymentId) {
      fetchDeploymentDetails();
    }
  }, [isOpen, deploymentId]);

  const fetchDeploymentDetails = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${BASE_URL}/apps/deployment/${deploymentId}`);
      setDeployment(response.data);
    } catch (err) {
      console.error('Error fetching deployment details:', err);
      setError(err.response?.data?.detail || 'Failed to load deployment details');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString();
  };

  const getPortUrl = (portMapping) => {
    const browserHost = window.location.hostname;
    return `http://${browserHost}:${portMapping.host_port}`;
  };

  if (!isOpen) return null;

  return (
    <StyledDialog open={isOpen} onClose={onClose} maxWidth="md" fullWidth>
      <StyledDialogTitle>
        <TitleText>Deployment Details</TitleText>
        <Box>
          <IconButton onClick={fetchDeploymentDetails} disabled={loading}>
            <RefreshIcon />
          </IconButton>
          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Box>
      </StyledDialogTitle>

      <Divider />

      <DialogContent>
        {loading && <Spinner />}
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        
        {deployment && !loading && (
          <>
            <InfoSection>
              <SectionTitle>General Information</SectionTitle>
              <InfoGrid>
                <InfoItem>
                  <InfoLabel>Name</InfoLabel>
                  <InfoValue>{deployment.name}</InfoValue>
                </InfoItem>
                <InfoItem>
                  <InfoLabel>Status</InfoLabel>
                  <StatusChip 
                    label={getStatusMessage(deployment.status, deployment.image_status)} 
                    size="small" 
                    variant="outlined"
                    status={deployment.status}
                  />
                </InfoItem>
                <InfoItem>
                  <InfoLabel>Created At</InfoLabel>
                  <InfoValue>{formatDate(deployment.created_at)}</InfoValue>
                </InfoItem>
                <InfoItem>
                  <InfoLabel>Deployed At</InfoLabel>
                  <InfoValue>{formatDate(deployment.deployed_at)}</InfoValue>
                </InfoItem>
              </InfoGrid>
              
              {deployment.status === 'DEPLOYED' && deployment.lb_port && (
                <Box sx={{ mt: 2 }}>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<OpenInNewIcon />}
                    href={`http://${window.location.hostname}:${deployment.lb_port}`}
                    target="_blank"
                    sx={{ textTransform: 'none' }}
                  >
                    Open Application
                  </Button>
                  <Typography variant="caption" sx={{ display: 'block', mt: 1, color: 'text.secondary' }}>
                    Access via Traefik load balancer on port {deployment.lb_port}
                  </Typography>
                </Box>
              )}

              {/* Image pulling information */}
              {(deployment.status === 'PULLING_IMAGES' || (deployment.image_status && !deployment.image_status.all_images_pulled)) && (
                <Box sx={{ mt: 2 }}>
                  <Alert severity="info" sx={{ fontSize: '0.875rem' }}>
                    {deployment.status === 'PULLING_IMAGES' ? (
                      <>
                        <strong>Pulling container images...</strong>
                        <br />
                        This may take some time depending on your bandwidth and image sizes.
                        {deployment.image_status?.images && (
                          <Box sx={{ mt: 1, fontSize: '0.8rem' }}>
                            Images: {deployment.image_status.images.join(', ')}
                          </Box>
                        )}
                      </>
                    ) : (
                      <>
                        <strong>Note:</strong> Some container images may need to be downloaded on first deployment, 
                        which could extend deployment time.
                      </>
                    )}
                  </Alert>
                </Box>
              )}
            </InfoSection>

            <InfoSection>
              <SectionTitle>Configuration</SectionTitle>
              <InfoGrid>
                <InfoItem>
                  <InfoLabel>Min Instances</InfoLabel>
                  <InfoValue>{deployment.min_copies}</InfoValue>
                </InfoItem>
                <InfoItem>
                  <InfoLabel>Max Instances</InfoLabel>
                  <InfoValue>{deployment.max_copies || 'Unlimited'}</InfoValue>
                </InfoItem>
                <InfoItem>
                  <InfoLabel>Starting Instances</InfoLabel>
                  <InfoValue>{deployment.starting_copies}</InfoValue>
                </InfoItem>
                <InfoItem>
                  <InfoLabel>Load Balancer Port</InfoLabel>
                  <InfoValue>{deployment.lb_port || 'Auto-assigned'}</InfoValue>
                </InfoItem>
              </InfoGrid>
            </InfoSection>

            {deployment.env_vars && Object.keys(deployment.env_vars).length > 0 && (
              <InfoSection>
                <SectionTitle>Environment Variables</SectionTitle>
                <EnvVarBox>
                  {Object.entries(deployment.env_vars).map(([key, value], index) => (
                    <Box key={index} sx={{ mb: 0.5 }}>
                      <span style={{ color: '#00c07f' }}>{key}</span>
                      <span style={{ color: '#666' }}>=</span>
                      <span>{value}</span>
                    </Box>
                  ))}
                </EnvVarBox>
              </InfoSection>
            )}

            {deployment.instances && deployment.instances.length > 0 && (
              <InfoSection>
                <SectionTitle>Instances</SectionTitle>
                <StyledTableContainer component={Paper}>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Instance ID</TableCell>
                        <TableCell>Host</TableCell>
                        <TableCell>Status</TableCell>
                        <TableCell>Ports</TableCell>
                        <TableCell>Direct Access</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {deployment.instances.map((instance) => (
                        <TableRow key={instance.id}>
                          <TableCell>{instance.id.slice(0, 8)}...</TableCell>
                          <TableCell>{instance.host_name || 'N/A'}</TableCell>
                          <TableCell>
                            <StatusChip 
                              label={getStatusMessage(instance.status, deployment.image_status)} 
                              size="small" 
                              variant="outlined"
                              status={instance.status}
                            />
                          </TableCell>
                          <TableCell>
                            {instance.port_mappings?.map((pm, idx) => (
                              <Box key={idx} sx={{ fontSize: '0.875rem' }}>
                                {pm.container_port} → {pm.host_port}
                                {pm.port_name && ` (${pm.port_name})`}
                              </Box>
                            )) || 'N/A'}
                          </TableCell>
                          <TableCell>
                            {instance.status === 'DEPLOYED' && instance.port_mappings?.length > 0 && (
                              <Button
                                size="small"
                                startIcon={<OpenInNewIcon />}
                                href={getPortUrl(instance.port_mappings.find(pm => pm.is_primary) || instance.port_mappings[0])}
                                target="_blank"
                                variant="outlined"
                                sx={{ fontSize: '0.75rem' }}
                              >
                                Direct
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </StyledTableContainer>
              </InfoSection>
            )}
          </>
        )}
      </DialogContent>

      <DialogActions sx={{ p: 2 }}>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </StyledDialog>
  );
};

export default AppDeploymentDetail; 