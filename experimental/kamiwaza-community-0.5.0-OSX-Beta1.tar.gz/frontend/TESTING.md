# Frontend Testing Guide

This document establishes testing standards, patterns, and best practices for the Kamiwaza frontend codebase.

## Table of Contents

- [Testing Philosophy](#testing-philosophy)
- [Testing Pyramid](#testing-pyramid)
- [Project Structure](#project-structure)
- [Writing Tests](#writing-tests)
- [Test Categories](#test-categories)
- [Component Testing Patterns](#component-testing-patterns)
- [Test Utilities](#test-utilities)
- [Best Practices](#best-practices)
- [Common Patterns](#common-patterns)
- [Debugging Tests](#debugging-tests)
- [CI/CD Integration](#cicd-integration)

## Testing Philosophy

### Core Principles

1. **Test Behavior, Not Implementation** - Focus on what the user sees and does, not internal component state or implementation details
2. **User-Centric Testing** - Write tests from the user's perspective using accessible queries and user interactions
3. **Confidence Over Coverage** - Aim for tests that give high confidence in functionality rather than hitting arbitrary coverage percentages
4. **Fast Feedback Loop** - Tests should run quickly and provide immediate feedback during development

### Testing Strategy

Focus on unit tests for individual components, with integration tests for component interactions and E2E tests for critical user workflows.

### Unit Tests (Primary Focus)
- **Purpose**: Test individual components in isolation
- **Speed**: Fast
- **Scope**: Single component behavior, props handling, user interactions
- **Tools**: Jest, React Testing Library

### Integration Tests
- **Purpose**: Test component interactions, context usage, routing
- **Speed**: Medium
- **Scope**: Multiple components working together
- **Tools**: Jest, React Testing Library with full provider tree

### E2E Tests
- **Purpose**: Critical user workflows (separate testing infrastructure)
- **Speed**: Slower
- **Scope**: Full application flows
- **Tools**: Cypress/Playwright (not covered in this document)

## Project Structure

### File Organization

```
frontend/src/
├── components/
│   ├── common/
│   │   ├── __tests__/
│   │   │   ├── Spinner.test.js
│   │   │   ├── ErrorComponent.test.js
│   │   │   └── ConfirmModal.test.js
│   │   ├── Spinner.js
│   │   ├── ErrorComponent.js
│   │   └── ConfirmModal.js
│   └── models/
│       ├── __tests__/
│       │   └── ModelList.test.js
│       └── ModelList.js
├── test-utils.js          ← Shared testing utilities
├── setupTests.js          ← Jest setup and global mocks
└── __tests__/             ← Global integration tests
    └── README.md
```

### Naming Conventions

- **Test Files**: `ComponentName.test.js`
- **Test Directories**: `__tests__/` (co-located with components)
- **Test Descriptions**: Use descriptive `describe` and `test` blocks
- **Mock Files**: `__mocks__/ComponentName.js`

## Writing Tests

### Basic Test Structure

```javascript
import React from 'react';
import { renderWithTheme, userEvent } from '../../../test-utils';
import ComponentName from '../ComponentName';

describe('ComponentName', () => {
  // Test data setup
  const defaultProps = {
    title: 'Default Title',
    onAction: jest.fn()
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Rendering', () => {
    test('renders without crashing', () => {
      renderWithTheme(<ComponentName {...defaultProps} />);
    });

    test('displays correct content', () => {
      const { getByText } = renderWithTheme(<ComponentName {...defaultProps} />);
      expect(getByText('Default Title')).toBeInTheDocument();
    });
  });

  describe('User Interactions', () => {
    test('handles button click', async () => {
      const user = userEvent.setup();
      const { getByRole } = renderWithTheme(<ComponentName {...defaultProps} />);

      await user.click(getByRole('button'));

      expect(defaultProps.onAction).toHaveBeenCalledTimes(1);
    });
  });

  describe('Edge Cases', () => {
    test('handles missing props gracefully', () => {
      const { container } = renderWithTheme(<ComponentName />);
      expect(container).toBeInTheDocument();
    });
  });
});
```

### Required Test Categories

Every component should have tests for:

1. **Rendering** - Component renders without crashing
2. **Content Display** - Correct props/content are displayed
3. **User Interactions** - Click, type, keyboard events work correctly
4. **Accessibility** - ARIA attributes, roles, keyboard navigation
5. **Edge Cases** - Missing props, error states, empty data

## Test Categories

### 1. Presentation Components

Components that only display data without complex logic.

```javascript
// Example: Spinner, StatusBadge, UserAvatar
describe('StatusBadge', () => {
  test('displays correct status text and color', () => {
    const { getByText } = renderWithTheme(<StatusBadge status="active" />);
    const badge = getByText('Active');
    expect(badge).toHaveClass('status-active');
  });
});
```

### 2. Interactive Components

Components with user interactions and event handlers.

```javascript
// Example: Buttons, Forms, Modals
describe('SearchInput', () => {
  test('calls onSearch when user types and presses Enter', async () => {
    const mockOnSearch = jest.fn();
    const user = userEvent.setup();
    const { getByRole } = renderWithTheme(<SearchInput onSearch={mockOnSearch} />);

    const input = getByRole('textbox');
    await user.type(input, 'test query');
    await user.keyboard('{Enter}');

    expect(mockOnSearch).toHaveBeenCalledWith('test query');
  });
});
```

### 3. Container Components

Components that manage state and connect to contexts/APIs.

```javascript
// Example: ModelList, UserProfile, DashboardHome
describe('ModelList', () => {
  test('displays loading spinner while fetching models', () => {
    const { getByTestId } = renderWithProviders(<ModelList />, {
      authValue: { user: testData.user }
    });

    expect(getByTestId('loading-spinner')).toBeInTheDocument();
  });
});
```

### 4. Form Components

Components with validation, submission, and form state.

```javascript
// Example: LoginForm, ModelConfigForm, UserRegistration
describe('LoginForm', () => {
  test('shows validation error for invalid email', async () => {
    const user = userEvent.setup();
    const { getByLabelText, getByText } = renderWithTheme(<LoginForm />);

    await user.type(getByLabelText(/email/i), 'invalid-email');
    await user.click(getByRole('button', { name: /submit/i }));

    expect(getByText(/invalid email format/i)).toBeInTheDocument();
  });
});
```

## Component Testing Patterns

### Query Priority (React Testing Library)

Use queries in this priority order:

1. **Accessible Queries** (Preferred)
   ```javascript
   getByRole('button', { name: /submit/i })
   getByLabelText(/username/i)
   getByPlaceholderText(/search/i)
   getByText(/welcome/i)
   ```

2. **Semantic Queries**
   ```javascript
   getByDisplayValue(/current value/i)
   getByAltText(/profile picture/i)
   getByTitle(/tooltip text/i)
   ```

3. **Test IDs** (Last Resort)
   ```javascript
   getByTestId('complex-component')
   ```

### Async Testing

```javascript
// For async operations
test('loads and displays user data', async () => {
  const { findByText } = renderWithProviders(<UserProfile />);

  // Wait for async operation to complete
  const userName = await findByText(/john doe/i);
  expect(userName).toBeInTheDocument();
});

// For user interactions that trigger async updates
test('submits form successfully', async () => {
  const user = userEvent.setup();
  const { getByRole, findByText } = renderWithTheme(<ContactForm />);

  await user.click(getByRole('button', { name: /submit/i }));

  // Wait for success message
  expect(await findByText(/form submitted/i)).toBeInTheDocument();
});
```

### Window-Level Event Testing

```javascript
// For components that listen to window events (keyboard shortcuts, etc.)
// Use fireEvent for window-level events - it's more reliable than userEvent for this case
import { fireEvent } from '@testing-library/react';

test('user can close modal with Escape key', () => {
  renderWithTheme(<Modal showModal={true} onClose={mockClose} />);

  // fireEvent is preferred for window-level keyboard events
  // Include key, code, and keyCode for maximum compatibility
  fireEvent.keyDown(window, { key: 'Escape', code: 'Escape', keyCode: 27 });

  expect(mockClose).toHaveBeenCalledTimes(1);
});

// For element-focused keyboard events, prefer userEvent
test('user can submit form with Enter key', async () => {
  const user = userEvent.setup();
  const mockSubmit = jest.fn();
  const { getByRole } = renderWithTheme(<SearchForm onSubmit={mockSubmit} />);

  const input = getByRole('textbox');
  await user.type(input, 'search query');
  await user.keyboard('{Enter}'); // Works well for focused elements

  expect(mockSubmit).toHaveBeenCalledWith('search query');
});
```

#### When to Use fireEvent vs userEvent for Keyboard Events

- **Use fireEvent** for:
  - Window-level event listeners (escape to close modals, global shortcuts)
  - Document-level event dispatching
  - Cases where you need precise control over event properties

- **Use userEvent** for:
  - Element-focused interactions (typing in inputs, pressing enter on buttons)
  - Most user interactions that simulate real user behavior
  - When you want the most realistic event sequence

## Material-UI Component Testing

Material-UI components can present unique challenges for testing due to their complex DOM structure:

```javascript
// ❌ May not work reliably with MUI TextField
const input = getByLabelText('Username');

// ✅ More reliable approach for MUI form fields
const input = container.querySelector('input[name="username"]');

// ✅ Still use semantic queries when they work
const button = getByRole('button', { name: 'Submit' });
const alert = getByRole('alert');
```

**Key considerations:**
- MUI generates random IDs that break label associations
- Use `container.querySelector('[name="fieldname"]')` for form inputs
- Test behavior (focus, values) rather than HTML attributes when possible
- Semantic queries work fine for buttons, alerts, and other accessible elements

## Test Utilities

### Available Utilities

```javascript
import {
  renderWithTheme,      // Theme provider only
  renderWithProviders,  // Full provider tree (theme, router, auth, etc.)
  testData,            // Mock data factories
  createMockFetch,     // Fetch mocking utility
  userEvent            // User interaction utilities
} from '../test-utils';
```

### Usage Examples

```javascript
// Simple component testing
const { getByText } = renderWithTheme(<SimpleComponent />);

// Component needing full context
const { getByText } = renderWithProviders(<ComplexComponent />, {
  authValue: {
    user: testData.user,
    loading: false
  },
  serverInfoValue: {
    serverOs: 'linux',
    isLoading: false
  }
});

// Using test data
const mockModel = testData.model;
const { getByText } = renderWithTheme(<ModelCard model={mockModel} />);
```

### Custom Render Functions

Create custom render functions for specific component families:

```javascript
// For testing components that need specific context
const renderWithModelContext = (ui, options = {}) => {
  const modelValue = {
    models: options.models || [],
    loading: options.loading || false,
    error: options.error || null
  };

  return renderWithProviders(ui, {
    ...options,
    modelContextValue: modelValue
  });
};
```

## Best Practices

### DO ✅

1. **Write Tests First When Fixing Bugs**
   ```javascript
   test('handles empty API response gracefully', () => {
     // Write failing test first, then fix the bug
   });
   ```

2. **Test User Workflows**
   ```javascript
   test('user can search, select, and delete a model', async () => {
     // Test complete user journey
   });
   ```

3. **Use Descriptive Test Names**
   ```javascript
   test('shows error message when API request fails')
   test('disables submit button when form is invalid')
   ```

4. **Mock External Dependencies**
   ```javascript
   jest.mock('../services/apiService');
   ```

5. **Test Accessibility**
   ```javascript
   expect(getByRole('button')).toHaveAttribute('aria-label', 'Close modal');
   ```

### DON'T ❌

1. **Don't Test Implementation Details**
   ```javascript
   // ❌ Bad - testing CSS classes and styling
   expect(container.querySelector('.btn-primary')).toBeInTheDocument();
   expect(element).toHaveClass('d-flex justify-content-center');

   // ❌ Bad - testing internal library specifics
   expect(container.querySelector('.MuiButton-root')).toBeInTheDocument();

   // ✅ Good - testing user-visible behavior
   expect(getByRole('button', { name: 'Submit' })).toBeInTheDocument();
   expect(getByText('Modal Content')).toBeInTheDocument();
   ```

2. **Don't Use Shallow Rendering**
   ```javascript
   // ❌ Avoid enzyme's shallow()
   // ✅ Use React Testing Library's render()
   ```

3. **Don't Test Third-Party Libraries**
   ```javascript
   // ❌ Don't test Material-UI's Button implementation
   // ✅ Test your component's behavior with the Button
   ```

4. **Don't Over-Mock**
   ```javascript
   // ❌ Mocking everything makes tests brittle
   // ✅ Mock only external dependencies and network calls
   ```

### Error Handling Tests

```javascript
describe('Error Handling', () => {
  test('displays error message when API fails', async () => {
    // Mock API failure
    global.fetch.mockRejectedValueOnce(new Error('API Error'));

    const { findByText } = renderWithProviders(<DataComponent />);

    expect(await findByText(/something went wrong/i)).toBeInTheDocument();
  });

  test('handles network timeout gracefully', async () => {
    global.fetch.mockImplementationOnce(
      () => new Promise((resolve, reject) =>
        setTimeout(() => reject(new Error('Timeout')), 100)
      )
    );

    const { findByText } = renderWithProviders(<DataComponent />);

    expect(await findByText(/request timed out/i)).toBeInTheDocument();
  });
});
```

## Common Patterns

### Form Testing Pattern

```javascript
const fillAndSubmitForm = async (user, formData) => {
  // Fill form fields
  for (const [field, value] of Object.entries(formData)) {
    const input = getByLabelText(new RegExp(field, 'i'));
    await user.clear(input);
    await user.type(input, value);
  }

  // Submit form
  await user.click(getByRole('button', { name: /submit/i }));
};

test('submits form with valid data', async () => {
  const user = userEvent.setup();
  const mockSubmit = jest.fn();
  const { getByLabelText, getByRole } = renderWithTheme(
    <ContactForm onSubmit={mockSubmit} />
  );

  await fillAndSubmitForm(user, {
    name: 'John Doe',
    email: 'john@example.com',
    message: 'Hello world'
  });

  expect(mockSubmit).toHaveBeenCalledWith({
    name: 'John Doe',
    email: 'john@example.com',
    message: 'Hello world'
  });
});
```

### Modal Testing Pattern

```javascript
const testModalBehavior = (ModalComponent, triggerSelector) => {
  test('opens and closes modal correctly', async () => {
    const user = userEvent.setup();
    const { getByText, queryByText } = renderWithTheme(<ModalComponent />);

    // Modal initially closed
    expect(queryByText('Modal Content')).not.toBeInTheDocument();

    // Open modal
    await user.click(getByText(triggerSelector));
    expect(getByText('Modal Content')).toBeInTheDocument();

    // Close modal with X button
    await user.click(getByLabelText('close'));
    expect(queryByText('Modal Content')).not.toBeInTheDocument();
  });

  test('closes modal with Escape key', async () => {
    const user = userEvent.setup();
    const { getByText, queryByText } = renderWithTheme(<ModalComponent />);

    await user.click(getByText(triggerSelector));
    expect(getByText('Modal Content')).toBeInTheDocument();

    await user.keyboard('{Escape}');
    expect(queryByText('Modal Content')).not.toBeInTheDocument();
  });
};
```

### List Component Testing Pattern

```javascript
describe('ModelList', () => {
  test('displays all models from props', () => {
    const models = [testData.model, { ...testData.model, id: '2', name: 'Model 2' }];
    const { getByText } = renderWithTheme(<ModelList models={models} />);

    models.forEach(model => {
      expect(getByText(model.name)).toBeInTheDocument();
    });
  });

  test('shows empty state when no models', () => {
    const { getByText } = renderWithTheme(<ModelList models={[]} />);
    expect(getByText(/no models found/i)).toBeInTheDocument();
  });

  test('handles model selection', async () => {
    const mockOnSelect = jest.fn();
    const user = userEvent.setup();
    const { getByText } = renderWithTheme(
      <ModelList models={[testData.model]} onSelect={mockOnSelect} />
    );

    await user.click(getByText(testData.model.name));
    expect(mockOnSelect).toHaveBeenCalledWith(testData.model);
  });
});
```

## Debugging Tests

### Debug Failing Tests

```javascript
import { screen } from '@testing-library/react';

test('debug failing test', () => {
  const { debug } = renderWithTheme(<ProblematicComponent />);

  // Print entire DOM tree
  debug();

  // Print specific element
  debug(screen.getByTestId('specific-element'));

  // Use screen.logTestingPlaygroundURL() for interactive debugging
  screen.logTestingPlaygroundURL();
});
```

### Common Debugging Techniques

1. **Use `screen.debug()`** - Print DOM structure
2. **Check element queries** - Use Testing Playground
3. **Verify async operations** - Add `await` where needed
4. **Check mock implementations** - Ensure mocks return expected data
5. **Inspect console errors** - React warnings often indicate issues

## CI/CD Integration

### Running Tests

```bash
# Run all tests
npm test

# Run tests in CI mode
npm run test:ci

# Run with coverage
npm run test:coverage

# Run specific test file
npm test -- ModelList.test.js

# Run tests matching pattern
npm test -- --testNamePattern="user interaction"

# Run tests in watch mode during development
npm run test:watch
```


### Git Hooks

Pre-commit hook can be installed to ensure tests pass:

```bash
#!/bin/sh
npm run test:ci
```

## Performance Considerations

### Test Performance

- Keep test files under 100 tests each
- Use `beforeEach` for common setup
- Avoid unnecessary DOM queries in loops
- Mock heavy dependencies (charts, maps, etc.)

### Memory Management

```javascript
afterEach(() => {
  // Clean up mocks
  jest.clearAllMocks();

  // Clean up DOM
  cleanup();
});
```

## Contributing

### Adding New Test Patterns

1. Follow existing patterns in this document
2. Add examples to this guide
3. Update test utilities if needed
4. Ensure new patterns work with existing infrastructure

### Updating This Guide

This document should be updated when:
- New testing utilities are added
- Testing patterns change
- New best practices are established
- Tools or configurations are updated

---

**Remember**: The goal is confidence in our code through comprehensive, maintainable tests that give fast feedback and enable safe refactoring.
