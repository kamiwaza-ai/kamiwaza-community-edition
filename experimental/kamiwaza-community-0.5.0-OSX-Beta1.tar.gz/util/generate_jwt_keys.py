from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
import os

def generate_jwt_keys(runtime_dir: str) -> None:
    """
    Generate JWT keypair and save to specified directory.
    Args:
        runtime_dir: Directory to store the keys
    """
    os.makedirs(runtime_dir, exist_ok=True)
    
    private_key_path = os.path.join(runtime_dir, 'jwt_private_key.pem')
    public_key_path = os.path.join(runtime_dir, 'jwt_public_key.pem')
    
    # Generate keys only if they don't exist
    if not (os.path.exists(private_key_path) and os.path.exists(public_key_path)):
        # Generate a private key
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        
        # Get the public key
        public_key = private_key.public_key()
        
        # Serialize the private key
        pem_private = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        # Serialize the public key
        pem_public = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        # Write the keys to files
        with open(private_key_path, 'wb') as f:
            f.write(pem_private)
            
        with open(public_key_path, 'wb') as f:
            f.write(pem_public)
        
        print(f"JWT keypair generated and saved in {runtime_dir}")
    else:
        print(f"JWT keypair already exists in {runtime_dir}")

if __name__ == "__main__":
    # Try to get KAMIWAZA_ROOT from environment first
    kamiwaza_root = os.environ.get('KAMIWAZA_ROOT')
    if not kamiwaza_root:
        # Fallback: assume it's one directory up from current file
        kamiwaza_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    runtime_dir = os.path.join(kamiwaza_root, 'runtime')
    generate_jwt_keys(runtime_dir)
