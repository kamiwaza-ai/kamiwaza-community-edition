#!/bin/bash

set -e

# Check if script is being run as root/sudo
if [ "$EUID" -eq 0 ]; then
    echo "This script should be run as the installed user, not with sudo or by root."
    exit 1
fi

# Detect operating system
IS_MACOS=false
if [[ "$OSTYPE" == "darwin"* ]]; then
    IS_MACOS=true
fi


# Ensure the script can be run from any directory
cd "$(dirname "${BASH_SOURCE[0]}")"
source ../set-kamiwaza-root.sh

if [ -f ${KAMIWAZA_ROOT:-..}/.kamiwaza_install_community ]; then
    export KAMIWAZA_COMMUNITY=true
fi

if [ ! -f ${KAMIWAZA_ROOT:-.}/env.sh ] && [ "${KAMIWAZA_COMMUNITY:-}" = "true" ]; then
    bash ${KAMIWAZA_ROOT:-..}/first-boot.sh --community
fi

# Source configurations
if [ -f /etc/kamiwaza/env.sh ]; then
    source /etc/kamiwaza/env.sh
elif [ -f ../env.sh ]; then
    source ../env.sh
elif [ ! -f ../.kamiwaza_install_community ]; then
    echo " ###### WARNING ######: /etc/kamiwaza/env.sh does not exist. Contact support@kamiwaza.ai"
fi

# Locations
LOGROTATE_CONF="/etc/logrotate.d/kamiwaza"

# Check if KAMIWAZA_LOG_DIR is already set
if [ -n "${KAMIWAZA_LOG_DIR:-}" ]; then
    # Verify the user-specified directory is writable
    if [ -d "$KAMIWAZA_LOG_DIR" ] && [ -w "$KAMIWAZA_LOG_DIR" ]; then
        LOG_DIR="$KAMIWAZA_LOG_DIR"
        echo "Using user-specified log directory: $LOG_DIR"
    else
        echo "Warning: KAMIWAZA_LOG_DIR ($KAMIWAZA_LOG_DIR) is not writable, falling back to auto-detection"
        KAMIWAZA_LOG_DIR=""  # Clear it so we fall through to auto-detection
    fi
fi

# If not set or not writable, auto-detect
if [ -z "${LOG_DIR:-}" ]; then
    LOG_DIRS=("/opt/kamiwaza/logs" "/var/log" "/tmp")
    # Test each log directory for writeability
    for dir in "${LOG_DIRS[@]}"; do
        if [ -d "$dir" ] && [ -w "$dir" ]; then
            LOG_DIR="$dir"
            break
        fi
    done
fi

if [ -z "${LOG_DIR:-}" ]; then
    echo "No writable log directory found in: ${LOG_DIRS[*]}"
    exit 1
fi

# Export for child processes
export KAMIWAZA_LOG_DIR="$LOG_DIR"

# Immediately rotate logs for a clean start
rotate_logs() {
    # Rotate logs in each configured directory
    for log_dir in "/opt/kamiwaza/logs" "/var/log" "/tmp"; do
        # Skip if directory doesn't exist
        [ ! -d "$log_dir" ] && continue
        
        # Rotate each log file up to 3 times before startup
        for logfile in kamiwazad-azure_disk_mount.log kamiwazad-containers.log kamiwazad-core.log kamiwazad-frontend.log kamiwazad-jupyter.log kamiwazad-ray.log kamiwazad.log; do
            if [ -f "${log_dir}/${logfile}" ]; then
                for i in $(seq 3 -1 1); do
                    if [ -f "${log_dir}/${logfile}.${i}" ]; then
                        mv "${log_dir}/${logfile}.${i}" "${log_dir}/${logfile}.$((i+1))"
                    fi
                done
                mv "${log_dir}/${logfile}" "${log_dir}/${logfile}.1"
            fi
        done
    done
}

# Worker detection logic
if [ -f "/etc/kamiwaza/config/is_worker" ]; then
    export KAMIWAZAD_IS_WORKER=1
elif [ -n "${KAMIWAZA_HEAD_IP:-}" ]; then
    ifconfig | grep inet | awk '{print $2}' | grep -q "^${KAMIWAZA_HEAD_IP}$" > /dev/null 2>&1
    export KAMIWAZAD_IS_WORKER=$?
else
    export KAMIWAZAD_IS_WORKER=0
fi

if [ "${KAMIWAZAD_IS_WORKER:-999}" -eq 0 ]; then
    touch /tmp/kamiwazad.starting        
fi

# Activate virtual environment and install dependencies
source "${KAMIWAZA_ROOT:-}/venv/bin/activate"
pip3 install -q python-dotenv psutil pyyaml || exit 1


# Define paths
PYTHON_INTERPRETER="${KAMIWAZA_ROOT:-}/venv/bin/python"
KAMIWAZA_SCRIPT="${KAMIWAZA_ROOT:-}/startup/kamiwazad.py"
PID_FILE="/tmp/kamiwazad.pid"
LOG_FILE="$LOG_DIR/kamiwazad.log"

if [ -z "${KAMIWAZA_ROOT:-}" ]; then
    echo "KAMIWAZA_ROOT is not set. Repair your install or contact support@kamiwaza.ai"
    exit 1
fi

cd "${KAMIWAZA_ROOT}"

setup_logging() {
    # Create log directory if it doesn't exist
    if [ ! -d "$LOG_DIR" ]; then
        if ! mkdir -p "$LOG_DIR" 2>/dev/null; then
            if [ "$IS_MACOS" = true ]; then
                sudo mkdir -p "$LOG_DIR" 2>/dev/null || LOG_DIR="/tmp"
            else
                sudo -n mkdir -p "$LOG_DIR" 2>/dev/null || LOG_DIR="/tmp"
            fi
        fi

        # If sudo mkdir worked, set permissions
        if [ -d "$LOG_DIR" ] && [ "$LOG_DIR" != "/tmp" ]; then
            if [ "$IS_MACOS" = true ]; then
                sudo chown "$USER:$(id -g)" "$LOG_DIR"
                sudo chmod 755 "$LOG_DIR"
            else
                sudo -n chown "$USER:$(id -g)" "$LOG_DIR"
                sudo -n chmod 755 "$LOG_DIR"
            fi
        fi
    fi

    # Touch log file and set permissions if it doesn't exist
    if [ ! -f "$LOG_FILE" ]; then
        if ! touch "$LOG_FILE" 2>/dev/null; then
            if [ "$IS_MACOS" = true ]; then
                sudo touch "$LOG_FILE"
            else
                sudo -n touch "$LOG_FILE"
            fi
        fi
        if [ -f "$LOG_FILE" ]; then
            if [ "$IS_MACOS" = true ]; then
                sudo chown "$USER:$(id -g)" "$LOG_FILE"
                sudo chmod 644 "$LOG_FILE"
            else
                sudo -n chown "$USER:$(id -g)" "$LOG_FILE"
                sudo -n chmod 644 "$LOG_FILE"
            fi
        fi
    fi
}

start() {
    local missing_only=false
    if [ "${1:-}" = "--missing" ]; then
        missing_only=true
    fi

    
    if [ -f $PID_FILE ]; then
        PID=$(cat $PID_FILE)
        if kill -0 $PID 2>/dev/null; then
            if [ "$missing_only" = true ]; then
                echo "Checking for missing services..."
                "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" start --missing
                return
            else
                echo "kamiwazad is already running (PID: $PID)"
                return
            fi
        else
            echo "Stale PID file found. Removing and starting kamiwazad..."
            rm $PID_FILE
        fi
    fi

    # Setup logging infrastructure
    setup_logging
    
    # Rotate logs before starting
    rotate_logs

    # Run one-time setup if not already completed (debian installations only)
    SETUP_MARKER_FILE="${KAMIWAZA_ROOT}/.kamiwaza_setup_complete"
    if [ ! -f "$SETUP_MARKER_FILE" ] && [ -f "/etc/debian_version" ]; then
        echo "Running one-time Kamiwaza setup (debian installation detected)..."
        export PATH="${KAMIWAZA_ROOT}/venv/bin:$PATH"
        if source "${KAMIWAZA_ROOT}/venv/bin/activate" && \
           source "${KAMIWAZA_ROOT}/env.sh" && \
           export USER_ACCEPTED_KAMIWAZA_LICENSE=yes && \
           export KAMIWAZA_RUN_FROM_INSTALL=yes && \
           "${KAMIWAZA_ROOT}/setup.sh" --non-interactive; then
            touch "$SETUP_MARKER_FILE"
            echo "One-time setup completed successfully"
        else
            echo "Warning: One-time setup failed, but continuing startup..."
        fi
    fi

    # Process cloud-init files if present
    if [ -f "/tmp/kamiwaza_public_key" ] && [ -f "/tmp/kamiwaza_known_host" ]; then
        echo "Ingesting Kamiwaza keys..."
        
        if ! grep -qf "/tmp/kamiwaza_known_host" "${CUSTOMER_KNOWN_HOSTS:-}"; then
            cat "/tmp/kamiwaza_known_host" >> "${CUSTOMER_KNOWN_HOSTS:-}"
            echo "Added known hosts entry from cloud-init"
        fi

        if [ ! -f "${CUSTOMER_PRIVATE_KEY:-}" ]; then
            cp "/tmp/kamiwaza_public_key" "${CUSTOMER_PRIVATE_KEY:-}"
            chmod 600 "${CUSTOMER_PRIVATE_KEY:-}"
            echo "Installed customer private key from cloud-init"
        fi

        rm -f "/tmp/kamiwaza_public_key" "/tmp/kamiwaza_known_host"
        echo "Removed temporary cloud-init files"
    fi
    
    echo "Starting kamiwazad..."
    nohup "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" start ${1:-} 1>"$LOG_FILE" 2>&1 & 
    PID=$!
    echo $PID > $PID_FILE
    
    # Wait briefly to check if process is still running
    sleep 1
    if kill -0 $PID 2>/dev/null; then
        echo "kamiwazad started with PID: $PID"
        echo "Logs available at: $LOG_FILE"
    else
        echo "Failed to start kamiwazad. Check logs at: $LOG_FILE"
        rm -f $PID_FILE
        exit 1
    fi
}

stop() {
    local force_stop=false
    if [ -f $PID_FILE ]; then
        PID=$(cat $PID_FILE)
        if kill -0 $PID 2>/dev/null; then
            echo "kamiwazad is running (PID: $PID)"
            echo "Stopping kamiwazad daemon first..."
            "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" stop
            kill $PID
            rm $PID_FILE
            echo "kamiwazad daemon stopped"
        else
            echo "kamiwazad daemon not running (stale PID file found)"
            rm $PID_FILE
            force_stop=true
        fi
    else
        echo "kamiwazad daemon not running"
        force_stop=true
    fi

    # Even if kamiwazad isn't running, try to stop services
    if [ "$force_stop" = true ]; then
        echo "No running daemon found - attempting direct service shutdown..."
        echo "This may take a moment as we check each service..."
        "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" stop
    fi
}

status() {
    local check_all=false
    if [ "${1:-}" = "-a" ]; then
        check_all=true
    fi

    if [ -f $PID_FILE ]; then
        PID=$(cat $PID_FILE)
        if ps -p $PID > /dev/null; then
            echo "kamiwazad is running (PID: $PID)"
            "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" status
        else
            echo "kamiwazad is not running (stale PID file found)"
            rm $PID_FILE
            if [ "$check_all" = true ]; then
                echo "Checking service statuses directly..."
                "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" status -a
            fi
        fi
    else
        echo "kamiwazad is not running"
        if [ "$check_all" = true ]; then
            echo "Checking service statuses directly..."
            "$PYTHON_INTERPRETER" "$KAMIWAZA_SCRIPT" status -a
        fi
    fi
}
doctor() {
    echo "==== Doctor Diagnostic Report ===="
    echo
    echo "[1/4] Checking for processes listening on ports 3000, 7777, 8265, 443..."
    for port in 3000 7777 8265 443; do
        echo "--- Port $port ---"
        lsof -i :$port || echo "No process found on port $port"
    done
    echo
    echo "[2/4] Listing Docker containers (docker ps -a)..."
    if command -v docker >/dev/null 2>&1; then
        if docker info >/dev/null 2>&1; then
            docker ps -a
        else
            echo "Docker daemon is not reachable or not running."
        fi
    else
        echo "Docker is not installed."
    fi
    echo
    echo "[3/4] Checking KAMIWAZA_ROOT and environment variables..."
    echo "KAMIWAZA_ROOT: ${KAMIWAZA_ROOT:-<not set>}"
    echo "KAMIWAZA_COMMUNITY: ${KAMIWAZA_COMMUNITY:-<not set>}"
    echo "KAMIWAZA_HEAD_IP: ${KAMIWAZA_HEAD_IP:-<not set>}"
    echo "PYTHONPATH: ${PYTHONPATH:-<not set>}"
    echo "USER: ${USER:-<not set>}"
    echo "PATH: $PATH"
    echo
    echo "[4/4] Checking Docker daemon reachability..."
    if command -v docker >/dev/null 2>&1; then
        docker info >/dev/null 2>&1 && echo "Docker daemon is reachable." || echo "Docker daemon is NOT reachable."
    else
        echo "Docker is not installed."
    fi
    echo
    echo "==== End of Doctor Report ===="
    echo
    echo "[5/5] Running kamiwaza status..."
    status
}

version() {
    echo "==== Kamiwaza Version Information ===="
    echo

    local version_file="${KAMIWAZA_ROOT:-.}/kamiwaza.version.json"

    if [ -f "$version_file" ]; then
        echo "Version details:"
        echo "Full version: $(grep -o '"KAMIWAZA_VERSION_MAJOR":"[^"]*"' "$version_file" | sed 's/.*"KAMIWAZA_VERSION_MAJOR":"\([^"]*\)".*/\1/').$(grep -o '"KAMIWAZA_VERSION_MINOR":"[^"]*"' "$version_file" | sed 's/.*"KAMIWAZA_VERSION_MINOR":"\([^"]*\)".*/\1/').$(grep -o '"KAMIWAZA_VERSION_PATCH":"[^"]*"' "$version_file" | sed 's/.*"KAMIWAZA_VERSION_PATCH":"\([^"]*\)".*/\1/')"
    else
        echo "Version file not found at: $version_file"
        echo "This may indicate an incomplete installation."
    fi

    echo
    echo "==== End of Version Information ===="
}

case "${1:-}" in
    start)
        start "${2:-}"  # Pass second argument to start
        ;;
    stop)
        stop
        ;;
    restart)
        stop
        start
        ;;
    status)
        status "${2:-}"  # Pass the second argument to status
        ;;
    doctor)
        doctor
        ;;
    version)
        version
        exit 0
        ;;

    *)
        echo "Usage: $0 {start|stop|restart|status [-a]}"
        exit 1
        ;;
esac

exit 0