#!/bin/bash

# Idempotent YOLO Hardened bastion-host-installer.sh

# Function to check if a file exists
file_exists() {
    if [ ! -f "$1" ]; then
        echo "Error: File $1 not found."
        exit 1
    fi
}

# Backup SSH configuration and authorized_keys (only if backups don't exist)
backup_file() {
    local file="$1"
    local backup_file="$file.backup"
    if [ -f "$backup_file" ]; then
        echo "Backup for $file already exists, skipping backup."
    else
        sudo cp "$file" "$backup_file"
    fi
}

backup_file /etc/ssh/sshd_config
backup_file ~/.ssh/authorized_keys

# Update and upgrade the system
sudo apt-get update && sudo apt-get upgrade -y

# Install necessary packages (this is idempotent by default)
sudo apt-get install -y docker.io fail2ban ufw auditd chrony cron

# Harden SSH (idempotent sed operations)
sudo sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?X11Forwarding.*/X11Forwarding no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?AllowTcpForwarding.*/AllowTcpForwarding yes/' /etc/ssh/sshd_config
grep -qxF "AllowUsers kamiwaza" /etc/ssh/sshd_config || echo "AllowUsers kamiwaza" | sudo tee -a /etc/ssh/sshd_config

# Set up UFW (Uncomplicated Firewall)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw --force enable

# Configure fail2ban (only if not already configured)
if [ ! -f /etc/fail2ban/jail.local ]; then
    sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
    sudo sed -i 's/bantime  = 10m/bantime  = 1h/' /etc/fail2ban/jail.local
    sudo sed -i 's/findtime  = 10m/findtime  = 30m/' /etc/fail2ban/jail.local
    sudo sed -i 's/maxretry = 5/maxretry = 3/' /etc/fail2ban/jail.local
fi
sudo systemctl enable fail2ban && sudo systemctl start fail2ban

# Set up auditd
sudo sed -i 's/^max_log_file = .*/max_log_file = 8/' /etc/audit/auditd.conf
sudo sed -i 's/^num_logs = .*/num_logs = 5/' /etc/audit/auditd.conf
sudo systemctl enable auditd && sudo systemctl start auditd

# Harden system settings (idempotent)
grep -qxF "kernel.sysrq = 0" /etc/sysctl.conf || echo "kernel.sysrq = 0" | sudo tee -a /etc/sysctl.conf
grep -qxF "net.ipv4.tcp_syncookies = 1" /etc/sysctl.conf || echo "net.ipv4.tcp_syncookies = 1" | sudo tee -a /etc/sysctl.conf
sudo sysctl -p

# Secure shared memory (idempotent)
grep -qxF "tmpfs /run/shm tmpfs defaults,noexec,nosuid 0 0" /etc/fstab || echo "tmpfs /run/shm tmpfs defaults,noexec,nosuid 0 0" | sudo tee -a /etc/fstab

# Create a service account for running containers (only if it doesn't exist)
id -u docker-service &>/dev/null || sudo useradd -r -s /sbin/nologin docker-service

# Create directories for customer configs and certs (idempotent)
sudo mkdir -p /etc/reverse-bastion/configs /etc/reverse-bastion/certs
sudo chown docker-service:docker-service /etc/reverse-bastion/configs /etc/reverse-bastion/certs
sudo chmod 700 /etc/reverse-bastion/configs /etc/reverse-bastion/certs

# Create a script to start customer containers (overwrite existing for updates)
sudo tee /usr/local/bin/start-customer-container.sh << EOF
#!/bin/bash

if [ "\$#" -ne 1 ]; then
    echo "Usage: \$0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=\$1
CONFIG_FILE="/etc/reverse-bastion/configs/\${CUSTOMER_NAME}.conf"

if [ ! -f "\$CONFIG_FILE" ]; then
    echo "Error: Configuration file \$CONFIG_FILE not found."
    exit 1
fi

source "\$CONFIG_FILE"

docker run --rm -d --name \$CUSTOMER_NAME \\
    --user docker-service \\
    --restart unless-stopped \\
    --cap-drop=ALL \\
    --security-opt=no-new-privileges \\
    -e SSH_PORT=\$HIGH_PORT \\
    -p 0.0.0.0:\$HIGH_PORT:22 \\
    -v \$SERVER_CERT_PATH:/etc/ssh/server.crt:ro \\
    -v \$SERVER_KEY_PATH:/etc/ssh/server.key:ro \\
    customer-bastion:latest

echo "Started container for \$CUSTOMER_NAME on port \$HIGH_PORT"
EOF

sudo chmod 700 /usr/local/bin/start-customer-container.sh
sudo chown docker-service:docker-service /usr/local/bin/start-customer-container.sh

# Check if Dockerfile exists
file_exists "./customer-Dockerfile"

# Build the customer-specific Docker image (always rebuild for updates)
sudo docker build -t customer-bastion:latest -f ./customer-Dockerfile .

# Set up log rotation for Docker (overwrite existing for updates)
sudo tee /etc/logrotate.d/docker << EOF
/var/lib/docker/containers/*/*.log {
    rotate 7
    daily
    compress
    missingok
    delaycompress
    copytruncate
}
EOF

# Enable and start Docker
sudo systemctl enable docker && sudo systemctl start docker

# Add kamiwaza user to docker group to allow docker commands without sudo (idempotent)
sudo usermod -aG docker kamiwaza

# Set up ClamAV for antivirus scanning (idempotent install)
sudo apt-get install -y clamav clamav-daemon
sudo freshclam
sudo systemctl enable clamav-daemon && sudo systemctl start clamav-daemon

# Schedule regular system updates (only add if not already present)
(crontab -l 2>/dev/null | grep -q "apt-get update && apt-get upgrade -y") || (crontab -l 2>/dev/null; echo "0 2 * * 0 apt-get update && apt-get upgrade -y") | crontab -

# Create a "rescue" script that reverts SSH changes (overwrite existing for updates)
sudo tee /root/rescue_ssh.sh << EOF
#!/bin/bash
cp /etc/ssh/sshd_config.backup /etc/ssh/sshd_config
cp ~/.ssh/authorized_keys.backup ~/.ssh/authorized_keys
systemctl restart sshd
ufw disable
EOF

sudo chmod 700 /root/rescue_ssh.sh

echo "Idempotent YOLO hardened bastion host setup complete."
echo "IMPORTANT: Your original SSH config and authorized_keys have been backed up (if they weren't already)."
echo "If you get locked out, use emergency console access to run: sudo /root/rescue_ssh.sh"
echo "Then you can SSH in with your original credentials and fix the issue."
echo "After confirming access, you may want to remove the rescue script for security."

# Restart SSH service to apply changes
sudo systemctl restart sshd
