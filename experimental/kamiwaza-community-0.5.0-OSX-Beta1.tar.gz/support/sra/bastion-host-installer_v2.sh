#!/bin/bash

# Idempotent YOLO Hardened bastion-host-installer_v2.sh for SRA v2 architecture

# Function to check if a file exists
file_exists() {
    if [ ! -f "$1" ]; then
        echo "Error: File $1 not found."
        exit 1
    fi
}

# Backup SSH configuration and authorized_keys (only if backups don't exist)
backup_file() {
    local file="$1"
    local backup_file="$file.backup"
    if [ -f "$backup_file" ]; then
        echo "Backup for $file already exists, skipping backup."
    else
        sudo cp "$file" "$backup_file"
    fi
}

backup_file /etc/ssh/sshd_config
backup_file ~/.ssh/authorized_keys

# Update and upgrade the system
sudo apt-get update && sudo apt-get upgrade -y

# Install necessary packages (this is idempotent by default)
sudo apt-get install -y docker.io fail2ban ufw auditd chrony cron

# Harden SSH (idempotent sed operations)
sudo sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?X11Forwarding.*/X11Forwarding no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?AllowTcpForwarding.*/AllowTcpForwarding yes/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?Port.*/Port 22/' /etc/ssh/sshd_config
grep -qxF "Port 52101" /etc/ssh/sshd_config || echo "Port 52101" | sudo tee -a /etc/ssh/sshd_config
grep -qxF "AcceptEnv REMOTEUSER" /etc/ssh/sshd_config || echo "AcceptEnv REMOTEUSER" | sudo tee -a /etc/ssh/sshd_config
grep -qxF "AllowUsers kamiwaza kzcustomer kzengineer" /etc/ssh/sshd_config || echo "AllowUsers kamiwaza kzcustomer kzengineer" | sudo tee -a /etc/ssh/sshd_config

# Set up UFW (Uncomplicated Firewall)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 52101/tcp
sudo ufw --force enable

# Configure fail2ban (only if not already configured)
if [ ! -f /etc/fail2ban/jail.local ]; then
    sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
    sudo sed -i 's/bantime  = 10m/bantime  = 1h/' /etc/fail2ban/jail.local
    sudo sed -i 's/findtime  = 10m/findtime  = 30m/' /etc/fail2ban/jail.local
    sudo sed -i 's/maxretry = 5/maxretry = 3/' /etc/fail2ban/jail.local
fi
sudo systemctl enable fail2ban && sudo systemctl start fail2ban

# Set up auditd
sudo sed -i 's/^max_log_file = .*/max_log_file = 8/' /etc/audit/auditd.conf
sudo sed -i 's/^num_logs = .*/num_logs = 5/' /etc/audit/auditd.conf
sudo systemctl enable auditd && sudo systemctl start auditd

# Harden system settings (idempotent)
grep -qxF "kernel.sysrq = 0" /etc/sysctl.conf || echo "kernel.sysrq = 0" | sudo tee -a /etc/sysctl.conf
grep -qxF "net.ipv4.tcp_syncookies = 1" /etc/sysctl.conf || echo "net.ipv4.tcp_syncookies = 1" | sudo tee -a /etc/sysctl.conf
sudo sysctl -p

# Create service users if they don't exist
id -u kzcustomer &>/dev/null || sudo useradd -m -s /bin/bash kzcustomer
id -u kzengineer &>/dev/null || sudo useradd -m -s /bin/bash kzengineer

# Set up directories and permissions
sudo mkdir -p /home/kzcustomer/.ssh /home/kzengineer/.ssh
sudo chown -R kzcustomer:kzcustomer /home/kzcustomer/.ssh
sudo chown -R kzengineer:kzengineer /home/kzengineer/.ssh
sudo chmod 700 /home/kzcustomer/.ssh /home/kzengineer/.ssh

# Create directory for customer management
sudo mkdir -p /home/kamiwaza/customers/certs /home/kamiwaza/customers/metadata /home/kamiwaza/sra/logs
sudo chown -R kamiwaza:kamiwaza /home/kamiwaza/customers /home/kamiwaza/sra
sudo chmod 700 /home/kamiwaza/customers /home/kamiwaza/sra

# Create the connection log file for tracking reverse tunnels
if [ ! -f /home/kzcustomer/ssh_tunnel_connections.log ]; then
    sudo touch /home/kzcustomer/ssh_tunnel_connections.log
    sudo chown kzcustomer:kzcustomer /home/kzcustomer/ssh_tunnel_connections.log
    sudo chmod 644 /home/kzcustomer/ssh_tunnel_connections.log
fi

# Create proxy_to_client.sh script for engineers
sudo tee /home/kzengineer/proxy_to_client.sh << EOF
#!/bin/bash
exec ssh -i ~/.ssh/id_ed25519 \\
-o StrictHostKeyChecking=no \\
-o UserKnownHostsFile=/dev/null \\
-L localhost:8443:localhost:8443 -L localhost:8080:localhost:8080 \\
-L localhost:8265:localhost:8265 -L localhost:51100:localhost:51100 \\
-L localhost:51101:localhost:51101 -L localhost:51200:localhost:51200 \\
-p 2222 \\
\`tail -1 /home/kzcustomer/ssh_tunnel_connections.log | awk '{print \$NF}'\`@localhost
EOF

sudo chown kzengineer:kzengineer /home/kzengineer/proxy_to_client.sh
sudo chmod 755 /home/kzengineer/proxy_to_client.sh

# Generate id_ed25519 key for kzengineer if it doesn't exist
if [ ! -f /home/kzengineer/.ssh/id_ed25519 ]; then
    sudo -u kzengineer ssh-keygen -t ed25519 -f /home/kzengineer/.ssh/id_ed25519 -N "" -C "kzengineer@sra.kamiwaza.ai"
fi

# Create a script to update kzcustomer authorized_keys
sudo tee /usr/local/bin/update_kzcustomer_authorized_keys.sh << EOF
#!/bin/bash
# Usage: update_kzcustomer_authorized_keys.sh <customer_name>

if [ \$# -ne 1 ]; then
    echo "Usage: \$0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=\$1
CUSTOMER_AUTH_KEYS="/home/kamiwaza/customers/certs/\${CUSTOMER_NAME}/kzcustomer_authorized_keys"

if [ ! -f "\$CUSTOMER_AUTH_KEYS" ]; then
    echo "Error: Customer authorized_keys file not found: \$CUSTOMER_AUTH_KEYS"
    exit 1
fi

# Append to kzcustomer's authorized_keys
cat "\$CUSTOMER_AUTH_KEYS" >> /home/kzcustomer/.ssh/authorized_keys
sort -u /home/kzcustomer/.ssh/authorized_keys -o /home/kzcustomer/.ssh/authorized_keys
chmod 600 /home/kzcustomer/.ssh/authorized_keys
chown kzcustomer:kzcustomer /home/kzcustomer/.ssh/authorized_keys

echo "Updated kzcustomer's authorized_keys with \$CUSTOMER_NAME's key."
EOF

sudo chmod 755 /usr/local/bin/update_kzcustomer_authorized_keys.sh

# Create a script to update kzengineer authorized_keys
sudo tee /usr/local/bin/update_kzengineer_authorized_keys.sh << EOF
#!/bin/bash
# Usage: update_kzengineer_authorized_keys.sh <public_key_file>

if [ \$# -ne 1 ]; then
    echo "Usage: \$0 <public_key_file>"
    exit 1
fi

if [ ! -f "\$1" ]; then
    echo "Error: Public key file not found: \$1"
    exit 1
fi

# Add command prefix to the public key
echo "command=\"/home/kzengineer/proxy_to_client.sh\",no-agent-forwarding,no-X11-forwarding \$(cat \$1)" >> /home/kzengineer/.ssh/authorized_keys
sort -u /home/kzengineer/.ssh/authorized_keys -o /home/kzengineer/.ssh/authorized_keys
chmod 600 /home/kzengineer/.ssh/authorized_keys
chown kzengineer:kzengineer /home/kzengineer/.ssh/authorized_keys

echo "Updated kzengineer's authorized_keys with the provided public key."
EOF

sudo chmod 755 /usr/local/bin/update_kzengineer_authorized_keys.sh

# Set up log rotation for SSH logs
sudo tee /etc/logrotate.d/ssh_logs << EOF
/home/kzcustomer/ssh_tunnel_connections.log {
    rotate 7
    daily
    compress
    missingok
    notifempty
    create 644 kzcustomer kzcustomer
}
EOF

# Create a "rescue" script that reverts SSH changes (overwrite existing for updates)
sudo tee /root/rescue_ssh.sh << EOF
#!/bin/bash
cp /etc/ssh/sshd_config.backup /etc/ssh/sshd_config
cp ~/.ssh/authorized_keys.backup ~/.ssh/authorized_keys
systemctl restart sshd
ufw disable
EOF

sudo chmod 700 /root/rescue_ssh.sh

echo "SRA v2 bastion host setup complete."
echo "IMPORTANT: Your original SSH config and authorized_keys have been backed up."
echo "If you get locked out, use emergency console access to run: sudo /root/rescue_ssh.sh"
echo ""
echo "New architecture is set up with:"
echo "- Port 52101 open for incoming customer connections"
echo "- kzcustomer user for reverse tunnels"
echo "- kzengineer user for support access"
echo "- Reverse tunnel on localhost:2222"
echo ""
echo "To add a new customer, run:"
echo "1. ./create-customer-bastion_v2.sh <customer_name>"
echo "2. /usr/local/bin/update_kzcustomer_authorized_keys.sh <customer_name>"
echo ""
echo "To add an engineer's key, run:"
echo "/usr/local/bin/update_kzengineer_authorized_keys.sh <engineer_public_key_file>"

# Restart SSH service to apply changes
sudo systemctl restart sshd 