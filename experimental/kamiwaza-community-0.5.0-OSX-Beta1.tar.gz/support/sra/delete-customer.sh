#!/bin/bash

set -euo pipefail

# Configuration
BASTION_HOST="sra.kamiwaza.ai"
# Check if KAMIWAZA_BASTION_USER environment variable is set
# If set, use the environment variable value; otherwise, use the default
DEFAULT_BASTION_USER="kamiwaza"
BASTION_USER="${KAMIWAZA_BASTION_USER:-$DEFAULT_BASTION_USER}"
REMOTE_SCRIPT_DIR="/home/kamiwaza/sra"
REMOTE_SCRIPT="delete-customer-bastion.sh"

# Function to validate customer name
validate_customer_name() {
    if [[ ! $1 =~ ^[a-z0-9_]+$ ]]; then
        echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name>"
    echo ""
    echo "Environment variables:"
    echo "  KAMIWAZA_BASTION_USER - Override default bastion user (default: $DEFAULT_BASTION_USER)"
    exit 1
fi

CUSTOMER_NAME=$1

# Validate customer name
validate_customer_name "$CUSTOMER_NAME"

# Set up sudo prefix if using a different user
SUDO_PREFIX=""
if [ "$BASTION_USER" != "$DEFAULT_BASTION_USER" ]; then
    SUDO_PREFIX="sudo -u $DEFAULT_BASTION_USER "
    echo "Using bastion user: $BASTION_USER (with sudo to $DEFAULT_BASTION_USER)"
else
    echo "Using bastion user: $BASTION_USER"
fi

# Execute the remote script
ssh "$BASTION_USER@$BASTION_HOST" "${SUDO_PREFIX}bash $REMOTE_SCRIPT_DIR/$REMOTE_SCRIPT $CUSTOMER_NAME"

echo "Customer deletion request for $CUSTOMER_NAME has been sent to the bastion host."
