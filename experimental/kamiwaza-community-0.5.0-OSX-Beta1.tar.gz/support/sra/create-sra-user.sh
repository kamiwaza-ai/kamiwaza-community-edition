#!/bin/bash

set -euo pipefail

SRA_KEY_FILE="$HOME/.ssh/id_sra"
SRA_KEY_TYPE="ed25519"  # You can change this if you prefer RSA or another type

# Check if the key already exists
if [ -f "$SRA_KEY_FILE" ]; then
    echo "Error: SRA key already exists at $SRA_KEY_FILE"
    echo "If you need to generate a new key, please remove the existing one first."
    exit 1
fi

echo "Generating SRA key pair. You will be prompted to enter a passphrase."
echo "Please use a strong, unique passphrase for enhanced security."

# Generate the key with high security settings, prompting for the passphrase
ssh-keygen -t "$SRA_KEY_TYPE" -f "$SRA_KEY_FILE" -C "$USER@$HOSTNAME"

echo "SRA key pair has been generated:"
echo "Private key: $SRA_KEY_FILE"
echo "Public key: ${SRA_KEY_FILE}.pub"
echo ""
echo "Please keep the private key and passphrase secure."
echo "Use copy-sra-user.sh to upload the public key to the bastion host."
