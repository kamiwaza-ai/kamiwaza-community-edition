# SRA Kamiwaza - Secure Remote Access System

This repository contains scripts and configuration files for Kamiwaza's Secure Remote Access (SRA) system, which enables secure remote support connections to customer environments.

## Repository Overview

The SRA Kamiwaza system consists of a set of shell scripts and Docker configurations that facilitate:

1. Creating and managing secure tunnels for customer support access
2. Managing customer-specific SSH certificates and keys
3. Provisioning and deprovisioning customer environments
4. Establishing and maintaining secure connections

## Shell Scripts Documentation

### Kamiwaza remote support engineer script

#### `connect-to-customer.sh`
- **Purpose**: Lives on Kamiwaza support engineers' clients. Run when needed to connect to a customer instance. Support-side script to connect to a customer environment
- **Scope**: Establishes a connection to a specific customer's environment using their assigned port
- **Usage**: `./connect-to-customer.sh -p <customer-port> -c <customer_name>`
- **Features**:
  - Checks for available ports before establishing connection (8080, 8443, 8265, 51100, 51101, 51200)
  - On OSX, also checks port 443 for socat forwarding
  - Provides clear error messages if ports are already in use, including process name and PID
  - Handles OSX-specific port forwarding using socat
  - Automatically cleans up port forwarding processes on exit
- **Port Requirements**:
  - 8080: HTTP access
  - 8443: HTTPS access
  - 8265: Additional service port
  - 51100, 51101, 51200: Additional service ports
  - 443: OSX-specific port for socat forwarding

### Customer Management Scripts

#### `create-customer.sh`
- **Purpose**: Lives on Kamiwaza SRA admin's client. Entry point script to create a new customer environment
- **Scope**: Prompts for customer name and executes the remote creation script on the bastion host
- **Usage**: `./create-customer.sh` (will prompt for customer name)

#### `create-customer-bastion.sh`
- **Purpose**: Lives on Bastion host. Invoked by Kamiwaza SRA admin via create-customer.sh. Creates customer-specific resources on the bastion host
- **Scope**: Generates certificates, SSH keys, assigns ports, and creates metadata files
- **Usage**: Called by `create-customer.sh`, not meant for direct use

#### `delete-customer.sh`
- **Purpose**: Lives on Kamiwaza SRA admin's client. Entry point script to remove a customer environment
- **Scope**: Prompts for customer name and executes the remote deletion script on the bastion host
- **Usage**: `./delete-customer.sh` (will prompt for customer name)

#### `delete-customer-bastion.sh`
- **Purpose**: Lives on Bastion host. Invoked by Kamiwaza SRA admin via delete-customer.sh. Removes customer-specific resources from the bastion host
- **Scope**: Deletes certificates, SSH keys, and metadata files
- **Usage**: Called by `delete-customer.sh`, not meant for direct use

### Connection Management Scripts

#### `connect-support.sh`
- **Purpose**: Lives on customer's Kamiwaza instance.  Customer-side script to establish a persistent secure connection to Kamiwaza support.
- **Note:**:  This is persisted across kamiwaza startups if "enabled:" is set to "true" in the remote_support section of kamiwaza/startup.kamiwaza.yml
- **Scope**: Creates a tmux session, establishes an SSH tunnel with reverse port forwarding, and monitors connection health
- **Usage**: `./connect-support.sh -p <port>` where port is the customer-specific port


### Container Management Scripts

#### `start-customer.sh`
- **Purpose**: Lives on Kamiwaza SRA admin's client. Entry point script to start a customer's container
- **Scope**: Calls the bastion host script to start the customer's SSH container
- **Usage**: `./start-customer.sh` (will prompt for customer name)

#### `start-customer-bastion.sh`
- **Purpose**: Lives on Bastion host. Starts a customer's container on the bastion host
- **Scope**: Uses Docker to start the customer-specific SSH container with proper configurations (including the keys of all the support engineers)
- **Usage**: Called by `start-customer.sh`, not meant for direct use

#### `terminate-customer.sh`
- **Purpose**: Lives on Kamiwaza SRA admin's client. Entry point script to stop a customer's container
- **Scope**: Calls the bastion host script to stop the customer's SSH container
- **Usage**: `./terminate-customer.sh` (will prompt for customer name)

#### `terminate-customer-bastion.sh`
- **Purpose**: Lives on Bastion host. Stops a customer's container on the bastion host
- **Scope**: Uses Docker to stop and remove the customer-specific SSH container
- **Usage**: Called by `terminate-customer.sh`, not meant for direct use

### User Management Scripts

#### `create-sra-user.sh`
- **Purpose**: Lives on Kamiwaza SRA admin's client. Creates a user for secure remote access on the target system
- **Scope**: Sets up the user account, SSH keys, and permissions
- **Usage**: `./create-sra-user.sh <username>`

#### `copy-sra-user.sh`
- **Purpose**: Lives on Kamiwaza SRA admin's client. Installs support engineer user configuration to bastian host
- **Scope**: Transfers SSH keys and user configuration to the target system
- **Usage**: `./copy-sra-user.sh <target_host>`

### Utility Scripts

#### `get-customer-keys.sh`
- **Purpose**: Lives on Kamiwaza SRA admin's client. Retrieves SSH keys and certificates for a specific customer
- **Scope**: Generates a package with all necessary connection files for the customer
- **Usage**: `./get-customer-keys.sh <customer_name>`

#### `entrypoint.sh`
- **Purpose**: Docker container entrypoint script
- **Scope**: Sets up SSH configuration within the container and starts the SSH daemon
- **Usage**: Called by Docker when starting containers, not meant for direct use

#### `bastion-host-installer.sh`
- **Purpose**: Sets up the bastion host with necessary dependencies and configurations
- **Scope**: Installs Docker, configures the system, and sets up directory structure
- **Usage**: `./bastion-host-installer.sh` (typically run once during initial setup)

## Docker Configuration

The repository includes a `Dockerfile` that defines a secure Alpine-based SSH container used for establishing remote access connections. This container:

1. Uses Alpine Linux for a minimal footprint
2. Configures OpenSSH with secure settings
3. Creates a non-root user for SSH connections
4. Sets up proper permissions and configurations
5. Uses the `entrypoint.sh` script for runtime setup

## Usage Flow

1. Admin creates a customer environment using `create-customer.sh`
2. Customer receives their connection files
3. When support is needed, customer runs `connect-support.sh`
4. Support personnel connect to the customer using `connect-to-customer.sh`
5. When no longer needed, the connection can be terminated

## Support User Workflow

To add support users to the SRA system:

1. Run the `create-sra-user.sh` script with the desired username:
   ```
   ./create-sra-user.sh <username>
   ```
   This will:
   - Create a new user account on the target system
   - Set up SSH keys for the user
   - Configure appropriate permissions

2. For deploying the user to additional systems, use the `copy-sra-user.sh` script:
   ```
   ./copy-sra-user.sh <target_host>
   ```
   This will transfer the user configuration and SSH keys to the specified target host.

3. The newly created user will then be able to access the SRA system and connect to customer environments.

## Security Features

- Customer-specific SSH certificates and keys
- Non-reused ports for different customers
- Secure tunneling with SSH
- Connection monitoring and auto-recovery
- No password authentication, only key-based
- Restricted permissions on sensitive files 


Can be kicked off via Kamiwaza autostart YAML file. 
Non GPU Azure VM. 