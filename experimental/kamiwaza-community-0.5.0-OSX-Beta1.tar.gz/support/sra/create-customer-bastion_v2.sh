#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
CERTS_DIR="$CUSTOMERS_DIR/certs"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"
PORT_RANGE_START=52102
PORT_RANGE_END=53000
DEFAULT_PORT=52102  

# Function to validate customer name
validate_customer_name() {
    if [[ ! $1 =~ ^[a-z0-9_]+$ ]]; then
        echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
        exit 1
    fi
}

# Function to find next available port
find_next_available_port() {
    # First check if the default port is available
    if ! grep -q "CUSTOMER_PORT=$DEFAULT_PORT" $METADATA_DIR/*.env 2>/dev/null; then
        echo $DEFAULT_PORT
        return
    fi
    
    # Otherwise, find another available port
    for port in $(seq $(($PORT_RANGE_START + 1)) $PORT_RANGE_END); do
        if ! grep -q "CUSTOMER_PORT=$port" $METADATA_DIR/*.env 2>/dev/null; then
            echo $port
            return
        fi
    done
    echo "Error: No available ports in the specified range." >&2
    exit 1
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=$1

# Validate customer name
validate_customer_name "$CUSTOMER_NAME"

# Check if customer already exists
if [ -d "$CUSTOMERS_DIR/$CUSTOMER_NAME" ]; then
    echo "Error: Customer $CUSTOMER_NAME already exists."
    exit 1
fi

# Create necessary directories
mkdir -p "$CUSTOMERS_DIR/$CUSTOMER_NAME"
mkdir -p "$CERTS_DIR/$CUSTOMER_NAME"
mkdir -p "$METADATA_DIR"
mkdir -p "$LOGS_DIR"

# Generate customer-specific SSH key for reverse tunnel
ssh-keygen -t ed25519 -f "$CERTS_DIR/$CUSTOMER_NAME/reverse_tunnel_key" -N "" -C "${CUSTOMER_NAME}@sra.kamiwaza.ai"

# Find next available port (or use default 52101)
CUSTOMER_PORT=$(find_next_available_port)

# Generate authorized_keys entry for kzcustomer
cat > "$CERTS_DIR/$CUSTOMER_NAME/kzcustomer_authorized_keys" << EOF
command="/home/kzcustomer/force_command.sh",no-agent-forwarding,no-X11-forwarding,no-pty,no-user-rc,permitlisten="127.0.0.1:2222",permitlisten="127.0.0.1:8080",permitlisten="127.0.0.1:8443",permitlisten="127.0.0.1:8265",permitlisten="127.0.0.1:51100",permitlisten="127.0.0.1:51101",permitlisten="127.0.0.1:51200",permitlisten="127.0.0.1:6100",permitlisten="127.0.0.1:7100",permitlisten="127.0.0.1:8100" $(cat "$CERTS_DIR/$CUSTOMER_NAME/reverse_tunnel_key.pub")
EOF

# Create the engineers directory for future engineer keys
mkdir -p "$CERTS_DIR/$CUSTOMER_NAME/engineers"

# Generate forward tunnel key for kzengineer (used for proxy to client)
ssh-keygen -t ed25519 -f "$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key" -N "" -C "kzengineer@bastion-$CUSTOMER_NAME"
chmod 600 "$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key"
chmod 644 "$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key.pub"
echo "Forward tunnel key generated for engineers"

# Create customer metadata file
cat > "$METADATA_DIR/$CUSTOMER_NAME.env" <<EOF
CUSTOMER_NAME=$CUSTOMER_NAME
CUSTOMER_PORT=$CUSTOMER_PORT
CUSTOMER_REVERSE_TUNNEL_KEY=$CERTS_DIR/$CUSTOMER_NAME/reverse_tunnel_key
CUSTOMER_REVERSE_TUNNEL_KEY_PUB=$CERTS_DIR/$CUSTOMER_NAME/reverse_tunnel_key.pub
CUSTOMER_FORWARD_TUNNEL_KEY=$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key
CUSTOMER_FORWARD_TUNNEL_KEY_PUB=$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key.pub
EOF

# Log the creation
echo "$(date): Created customer $CUSTOMER_NAME with port $CUSTOMER_PORT" >> "$LOGS_DIR/sra_operations.log"

echo "Customer $CUSTOMER_NAME created successfully with port $CUSTOMER_PORT"
echo "Reverse Tunnel Key Fingerprint: $(ssh-keygen -lf $CERTS_DIR/$CUSTOMER_NAME/reverse_tunnel_key.pub)"

# Create customer setup instructions
cat > "$CUSTOMERS_DIR/$CUSTOMER_NAME/setup_instructions.txt" << EOF
# Kamiwaza SRA v2 - Customer Setup Instructions

Thank you for choosing Kamiwaza for your secure remote access needs.
Follow these instructions to set up your secure connection:

## Step 1: Using the connect-support script

Run the connect-support_v2.sh script to start your user-level SSH daemon and establish the reverse tunnel:

\`\`\`
./connect-support_v2.sh -p $CUSTOMER_PORT
\`\`\`

This script will automatically:
1. Set up and start the user-level SSH daemon
2. Generate the necessary SSH host keys
3. Install the Kamiwaza engineer access key to your authorized_keys
4. Establish the reverse tunnel to the bastion host on port $CUSTOMER_PORT
5. Monitor and maintain the connection

Your assigned port is: $CUSTOMER_PORT

## Step 2: Verification

After running the connect-support script, verify that:
1. The reverse tunnel is established (you'll see confirmation in the script output)
2. The engineer access key has been added to your ~/.ssh/authorized_keys

If you encounter any issues, please contact support@kamiwaza.ai
EOF

# Create a deployment package for the customer
mkdir -p "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package"
cp "$CERTS_DIR/$CUSTOMER_NAME/reverse_tunnel_key" "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package/reverse_tunnel_key"
chmod 600 "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package/reverse_tunnel_key"
cp "$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key.pub" "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package/forward_tunnel_key.pub"
cp "$CUSTOMERS_DIR/$CUSTOMER_NAME/setup_instructions.txt" "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package/"
cp "connect-support_v2.sh" "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package/"
chmod +x "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package/connect-support_v2.sh"

# Create a tarball of the deployment package
tar -czf "$CUSTOMERS_DIR/$CUSTOMER_NAME/sra_deployment_package.tar.gz" -C "$CUSTOMERS_DIR/$CUSTOMER_NAME/deployment_package" .

echo ""
echo "Please provide the deployment package to the customer:"
echo "  $CUSTOMERS_DIR/$CUSTOMER_NAME/sra_deployment_package.tar.gz"
echo ""
echo "This package contains:"
echo "1. Private key for the reverse tunnel"
echo "2. Public key for the forward tunnel"
echo "3. Setup instructions"
echo "4. Connect-support script"
echo ""
echo "After customer setup is complete, add their public key to enable engineer access."
echo ""
echo "To start the bastion container for this customer, run:"
echo "./start-customer-bastion_v2.sh $CUSTOMER_NAME" 
