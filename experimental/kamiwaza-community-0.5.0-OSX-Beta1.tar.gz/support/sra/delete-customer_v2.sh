#!/bin/bash

set -euo pipefail

echo NEED TO FIX THIS TO USE AN ALTERNATIVE ADMIN USERNAME ON THE SRA HOST. 
echo For now: ssh to sra.kamiwaza.ai then su into kamiwaza and run the bastion script from there.
exit 1
# Configuration
BASTION_HOST="sra.kamiwaza.ai"
# Check if KAMIWAZA_BASTION_USER environment variable is set
# If set, use the environment variable value; otherwise, use the default
DEFAULT_BASTION_USER="kamiwaza"
BASTION_USER="${KAMIWAZA_BASTION_USER:-$DEFAULT_BASTION_USER}"
REMOTE_SCRIPT_DIR="/home/kamiwaza/sra"
REMOTE_SCRIPT="delete-customer-bastion_v2.sh"  # Using v2 script

# Function to validate customer name
validate_customer_name() {
    if [[ ! $1 =~ ^[a-z0-9_]+$ ]]; then
        echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name> [--force]"
    echo ""
    echo "Options:"
    echo "  --force          Skip confirmation prompt for deletion"
    echo ""
    echo "Environment variables:"
    echo "  KAMIWAZA_BASTION_USER - Override default bastion user (default: $DEFAULT_BASTION_USER)"
    exit 1
fi

CUSTOMER_NAME=$1
FORCE_OPTION=""

# Check for --force flag
if [ $# -gt 1 ]; then
    if [ "$2" == "--force" ]; then
        FORCE_OPTION="--force"
        echo "Force option enabled. Deletion will proceed without remote confirmation."
    fi
fi

# Validate customer name
validate_customer_name "$CUSTOMER_NAME"

# Set up sudo prefix if using a different user
SUDO_PREFIX=""
if [ "$BASTION_USER" != "$DEFAULT_BASTION_USER" ]; then
    SUDO_PREFIX="sudo -u $DEFAULT_BASTION_USER "
    echo "Using bastion user: $BASTION_USER (with sudo to $DEFAULT_BASTION_USER)"
else
    echo "Using bastion user: $BASTION_USER"
fi

# Execute the remote script
ssh "$BASTION_USER@$BASTION_HOST" "${SUDO_PREFIX}bash $REMOTE_SCRIPT_DIR/$REMOTE_SCRIPT $CUSTOMER_NAME $FORCE_OPTION"

echo "Customer deletion for $CUSTOMER_NAME completed using SRA v2 architecture." 