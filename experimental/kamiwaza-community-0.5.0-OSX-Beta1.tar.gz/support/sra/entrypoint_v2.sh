#!/bin/sh

set -e

# Copy the server certificate and key
cp /run/secrets/ssh_host_rsa_key.pub /etc/ssh/ssh_host_rsa_key.pub
cp /run/secrets/ssh_host_rsa_key /etc/ssh/ssh_host_rsa_key
chmod 644 /etc/ssh/ssh_host_rsa_key.pub
chmod 600 /etc/ssh/ssh_host_rsa_key

# Set up the authorized_keys file for the kzcustomer
if [ -f /run/secrets/customer_authorized_keys ]; then
    cp /run/secrets/customer_authorized_keys /home/kzcustomer/.ssh/authorized_keys
    chown kzcustomer:kzcustomer /home/kzcustomer/.ssh/authorized_keys
    chmod 600 /home/kzcustomer/.ssh/authorized_keys
fi

# Set up the authorized_keys file for the kzengineer
if [ -f /run/secrets/engineer_authorized_keys ]; then
    cp /run/secrets/engineer_authorized_keys /home/kzengineer/.ssh/authorized_keys
    chown kzengineer:kzengineer /home/kzengineer/.ssh/authorized_keys
    chmod 600 /home/kzengineer/.ssh/authorized_keys
fi

# Set up proxy_to_client.sh script for engineers
cat > /home/kzengineer/proxy_to_client.sh << EOF
#!/bin/bash
exec ssh -i ~/.ssh/id_ed25519 \\
-o StrictHostKeyChecking=no \\
-o UserKnownHostsFile=/dev/null \\
-p 2222 \\
\`grep Connection /home/kzcustomer/ssh_tunnel_connections.log | |tail -1 | awk '{print \$NF}'\`@localhost
EOF

chmod 755 /home/kzengineer/proxy_to_client.sh
chown kzengineer:kzengineer /home/kzengineer/proxy_to_client.sh


cat > /home/kzcustomer/force_command.sh << EOF
#!/bin/bash

logfile=/home/kzcustomer/ssh_tunnel_connections.log

echo "$(date): Connection from $SSH_CLIENT, sshdPID:$PPID, Remoteuser: $REMOTEUSER" >> "$logfile"
echo "This account only permits creating a reverse tunnel"

# Parent PID automatically available
while kill -0 "$PPID" 2>/dev/null; do
    sleep 60
done

echo "$(date): Disconnection from $SSH_CLIENT, sshdPID:$PPID, Remoteuser: $REMOTEUSER" >> "$logfile"
EOF

chmod 755 /home/kzcustomer/force_command.sh
chown kzcustomer:kzcustomer /home/kzcustomer/force_command.sh



# Copy the pre-generated engineer key for forward tunneling
if [ -f /run/secrets/forward_tunnel_key ]; then
    cp /run/secrets/forward_tunnel_key /home/kzengineer/.ssh/id_ed25519
    cp /run/secrets/forward_tunnel_key.pub /home/kzengineer/.ssh/id_ed25519.pub
    chown kzengineer:kzengineer /home/kzengineer/.ssh/id_ed25519*
    chmod 600 /home/kzengineer/.ssh/id_ed25519
    chmod 644 /home/kzengineer/.ssh/id_ed25519.pub
    echo "Using pre-generated forward tunnel key for engineers"
else
    echo "WARNING: No forward tunnel key found, this may cause issues with forward tunneling"
fi

# Create the connection log file if it doesn't exist
touch /home/kzcustomer/ssh_tunnel_connections.log
chown kzcustomer:kzcustomer /home/kzcustomer/ssh_tunnel_connections.log
chmod 644 /home/kzcustomer/ssh_tunnel_connections.log

# Start SSH server with verbose logging
/usr/sbin/sshd -D -e 