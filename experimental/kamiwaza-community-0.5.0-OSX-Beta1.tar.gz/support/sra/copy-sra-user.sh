#!/bin/bash

set -euo pipefail

# Default configuration
BASTION_HOST="sra.kamiwaza.ai"
# Check if KAMIWAZA_BASTION_USER environment variable is set
# If set, use the environment variable value; otherwise, use the default
DEFAULT_BASTION_USER="kamiwaza"
BASTION_USER="${KAMIWAZA_BASTION_USER:-$DEFAULT_BASTION_USER}"
SRA_KEY_FILE="$HOME/.ssh/id_sra"
REMOTE_DIR="/home/kamiwaza/support-access"
REMOTE_USER="$USER"
REMOTE_HOSTNAME="$HOSTNAME"

# Function to display usage information
show_usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  -k, --key FILE       Specify the SSH public key file to use (default: ${SRA_KEY_FILE}.pub)"
    echo "  -u, --user USER      Specify the remote username (default: $REMOTE_USER)"
    echo "  -h, --host HOST      Specify the remote hostname (default: $REMOTE_HOSTNAME)"
    echo "  --help              Show this help message"
    echo ""
    echo "Environment variables:"
    echo "  KAMIWAZA_BASTION_USER - Override default bastion user (default: $DEFAULT_BASTION_USER)"
    echo ""
    echo "Example:"
    echo "  $0 -k ~/.ssh/custom_key.pub -u john -h webserver1"
    exit 1
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -k|--key)
            if [ -z "${2:-}" ]; then
                echo "Error: -k|--key requires a file argument"
                exit 1
            fi
            SRA_KEY_FILE="${2%%.pub}"  # Remove .pub extension if present
            shift 2
            ;;
        -u|--user)
            if [ -z "${2:-}" ]; then
                echo "Error: -u|--user requires a username argument"
                exit 1
            fi
            REMOTE_USER="$2"
            shift 2
            ;;
        -h|--host)
            if [ -z "${2:-}" ]; then
                echo "Error: -h|--host requires a hostname argument"
                exit 1
            fi
            REMOTE_HOSTNAME="$2"
            shift 2
            ;;
        --help)
            show_usage
            ;;
        *)
            echo "Unknown option: $1"
            show_usage
            ;;
    esac
done

# Check if the SRA key exists
if [ ! -f "${SRA_KEY_FILE}.pub" ]; then
    echo "Error: SRA public key not found at ${SRA_KEY_FILE}.pub"
    echo "Please provide a valid public key file using the -k option,"
    echo "or run create-sra-user.sh first to generate your SRA key pair."
    exit 1
fi

# Generate a unique filename for the public key on the bastion host
REMOTE_KEY_NAME="${REMOTE_USER}_${REMOTE_HOSTNAME}_$(date +%Y%m%d%H%M%S).pub"

# Set up sudo prefix and commands based on user
if [ "$BASTION_USER" != "$DEFAULT_BASTION_USER" ]; then
    echo "Using bastion user: $BASTION_USER (will use sudo for file operations)"
    # We need to use sudo to root to handle ownership and movement
    MOVE_CMD="sudo bash -c 'chown $DEFAULT_BASTION_USER:$DEFAULT_BASTION_USER /tmp/${REMOTE_KEY_NAME} && mv /tmp/${REMOTE_KEY_NAME} ${REMOTE_DIR}/${REMOTE_KEY_NAME} && chmod 644 ${REMOTE_DIR}/${REMOTE_KEY_NAME}'"
else
    echo "Using bastion user: $BASTION_USER"
    MOVE_CMD="mv /tmp/${REMOTE_KEY_NAME} ${REMOTE_DIR}/${REMOTE_KEY_NAME} && chmod 644 ${REMOTE_DIR}/${REMOTE_KEY_NAME}"
fi

echo "Configuration:"
echo "- Using key file: ${SRA_KEY_FILE}.pub"
echo "- Remote username: $REMOTE_USER"
echo "- Remote hostname: $REMOTE_HOSTNAME"
echo ""
echo "Attempting to copy your SRA public key to the bastion host..."

# Create a temporary file for the key
TEMP_KEY_FILE=$(mktemp)
cat "${SRA_KEY_FILE}.pub" > "$TEMP_KEY_FILE"

# Copy the public key to the bastion host's support-access directory
if scp "$TEMP_KEY_FILE" "${BASTION_USER}@${BASTION_HOST}:/tmp/${REMOTE_KEY_NAME}" && \
   ssh "${BASTION_USER}@${BASTION_HOST}" "$MOVE_CMD"; then
    rm -f "$TEMP_KEY_FILE"
    echo "Success! Your SRA public key has been copied to the bastion host."
    echo "Key location on bastion: ${REMOTE_DIR}/${REMOTE_KEY_NAME}"
else
    rm -f "$TEMP_KEY_FILE"
    echo "Error: Unable to copy your key to the bastion host."
    echo "Please ensure you have the correct permissions and the bastion host is reachable."
    echo ""
    echo "If the issue persists, please contact your system administrator and provide them with the following information:"
    echo "1. Your username: $REMOTE_USER"
    echo "2. Your hostname: $REMOTE_HOSTNAME"
    echo "3. Your SRA public key (content of ${SRA_KEY_FILE}.pub):"
    cat "${SRA_KEY_FILE}.pub"
    echo ""
    echo "Ask them to manually add your public key to ${REMOTE_DIR} on the bastion host."
    exit 1
fi
