#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
CERTS_DIR="$CUSTOMERS_DIR/certs"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"
PORT_RANGE_START=52100
PORT_RANGE_END=53000

# Function to validate customer name
validate_customer_name() {
    if [[ ! $1 =~ ^[a-z0-9_]+$ ]]; then
        echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
        exit 1
    fi
}

# Function to find next available port
find_next_available_port() {
    for port in $(seq $PORT_RANGE_START $PORT_RANGE_END); do
        if ! grep -q "CUSTOMER_HIGH_PORT=$port" $METADATA_DIR/*.env 2>/dev/null; then
            echo $port
            return
        fi
    done
    echo "Error: No available ports in the specified range." >&2
    exit 1
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=$1

# Validate customer name
validate_customer_name "$CUSTOMER_NAME"

# Check if customer already exists
if [ -d "$CUSTOMERS_DIR/$CUSTOMER_NAME" ]; then
    echo "Error: Customer $CUSTOMER_NAME already exists."
    exit 1
fi

# Create necessary directories
mkdir -p "$CUSTOMERS_DIR/$CUSTOMER_NAME"
mkdir -p "$CERTS_DIR/$CUSTOMER_NAME"
mkdir -p "$METADATA_DIR"
mkdir -p "$LOGS_DIR"

# Generate customer-specific certificates
openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
    -keyout "$CERTS_DIR/$CUSTOMER_NAME/server.key" \
    -out "$CERTS_DIR/$CUSTOMER_NAME/server.crt" \
    -subj "/CN=$CUSTOMER_NAME.sra.kamiwaza.ai"

# Generate customer-specific SSH key for container access
ssh-keygen -t rsa -b 4096 -f "$CERTS_DIR/$CUSTOMER_NAME/container_access_key" -N "" -C "${CUSTOMER_NAME}@sra.kamiwaza.ai"

# Find next available high port
CUSTOMER_HIGH_PORT=$(find_next_available_port)

# Generate known_hosts entry
KNOWN_HOSTS_ENTRY=$(ssh-keygen -f "$CERTS_DIR/$CUSTOMER_NAME/server.key" -y | sed "s/^/[sra.kamiwaza.ai]:$CUSTOMER_HIGH_PORT /")
echo "$KNOWN_HOSTS_ENTRY" > "$CERTS_DIR/$CUSTOMER_NAME/kamiwaza_known_hosts"

# Create customer metadata file
cat > "$METADATA_DIR/$CUSTOMER_NAME.env" <<EOF
CUSTOMER_NAME=$CUSTOMER_NAME
CUSTOMER_HIGH_PORT=$CUSTOMER_HIGH_PORT
CUSTOMER_SERVER_CERT=$CERTS_DIR/$CUSTOMER_NAME/server.crt
CUSTOMER_SERVER_KEY=$CERTS_DIR/$CUSTOMER_NAME/server.key
CUSTOMER_CONTAINER_ACCESS_KEY=$CERTS_DIR/$CUSTOMER_NAME/container_access_key
CUSTOMER_CONTAINER_ACCESS_KEY_PUB=$CERTS_DIR/$CUSTOMER_NAME/container_access_key.pub
EOF

# Log the creation
echo "$(date): Created customer $CUSTOMER_NAME with high port $CUSTOMER_HIGH_PORT" >> "$LOGS_DIR/sra_operations.log"

echo "Customer $CUSTOMER_NAME created successfully with high port $CUSTOMER_HIGH_PORT"
echo "Server Certificate Fingerprint: $(openssl x509 -in $CERTS_DIR/$CUSTOMER_NAME/server.crt -noout -fingerprint -sha256)"
echo "Container Access Key Fingerprint: $(ssh-keygen -lf $CERTS_DIR/$CUSTOMER_NAME/container_access_key.pub)"
echo "Known Hosts Entry:"
cat "$CERTS_DIR/$CUSTOMER_NAME/kamiwaza_known_hosts"

# Output instructions for the customer
echo ""
echo "Please provide the following files to the customer:"
echo "1. Private key: $CERTS_DIR/$CUSTOMER_NAME/container_access_key"
echo "2. Known hosts file: $CERTS_DIR/$CUSTOMER_NAME/kamiwaza_known_hosts"
echo ""
echo "Instruct the customer to add the known hosts entry to their ~/.ssh/known_hosts file with the following command:"
echo "cat kamiwaza_known_hosts >> ~/.ssh/known_hosts"
echo ""
echo "Also, instruct the customer to set the correct permissions for the private key:"
echo "chmod 600 ~/.ssh/kamiwaza_support_key"
echo ""
echo "To connect, the customer should use the following command:"
echo "./connect-support.sh -p $CUSTOMER_HIGH_PORT"
