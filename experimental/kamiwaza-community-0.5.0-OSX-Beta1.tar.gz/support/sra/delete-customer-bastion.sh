#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
CERTS_DIR="$CUSTOMERS_DIR/certs"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"

# Function to validate customer name
validate_customer_name() {
    if [[ ! $1 =~ ^[a-z0-9_]+$ ]]; then
        echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=$1

# Validate customer name
validate_customer_name "$CUSTOMER_NAME"

# Check if customer exists
if [ ! -d "$CUSTOMERS_DIR/$CUSTOMER_NAME" ] && [ ! -f "$METADATA_DIR/${CUSTOMER_NAME}.env" ]; then
    echo "Error: Customer $CUSTOMER_NAME does not exist."
    exit 1
fi

# Stop and remove the customer's container if it's running
if docker ps -a --format '{{.Names}}' | grep -q "^sra_${CUSTOMER_NAME}$"; then
    echo "Stopping and removing container for customer $CUSTOMER_NAME..."
    docker stop "sra_${CUSTOMER_NAME}" || true
    docker rm "sra_${CUSTOMER_NAME}" || true
fi

# Remove customer directories
echo "Removing customer directories..."
rm -rf "$CUSTOMERS_DIR/$CUSTOMER_NAME"
rm -rf "$CERTS_DIR/$CUSTOMER_NAME"

# Remove customer metadata file
echo "Removing customer metadata..."
rm -f "$METADATA_DIR/${CUSTOMER_NAME}.env"

# Log the deletion
echo "$(date): Deleted customer $CUSTOMER_NAME" >> "$LOGS_DIR/sra_operations.log"

echo "Customer $CUSTOMER_NAME has been successfully deleted."
