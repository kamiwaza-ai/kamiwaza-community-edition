#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
CERTS_DIR="$CUSTOMERS_DIR/certs"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"

# Function to check if a customer exists
check_customer_exists() {
    local customer_name="$1"
    if [ ! -f "$METADATA_DIR/$customer_name.env" ] && [ ! -d "$CUSTOMERS_DIR/$customer_name" ] && [ ! -d "$CERTS_DIR/$customer_name" ]; then
        echo "Error: Customer $customer_name does not exist or metadata not found."
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name> [--force]"
    exit 1
fi

CUSTOMER_NAME=$1
FORCE=false

# Check for --force flag
if [ $# -gt 1 ]; then
    if [ "$2" == "--force" ]; then
        FORCE=true
    fi
fi

# Validate customer name
if [[ ! $CUSTOMER_NAME =~ ^[a-z0-9_]+$ ]]; then
    echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
    exit 1
fi

# Check if customer exists
check_customer_exists "$CUSTOMER_NAME"

# Source customer-specific environment variables if available
if [ -f "$METADATA_DIR/$CUSTOMER_NAME.env" ]; then
    source "$METADATA_DIR/$CUSTOMER_NAME.env"
    echo "Found customer metadata: Port $CUSTOMER_PORT"
fi

# Get the actual container name used
CONTAINER_NAME="${CUSTOMER_NAME}-bastion"

# Stop and remove the customer's container if it exists
CONTAINER_RUNNING=$(docker ps -q -f "name=^${CONTAINER_NAME}$")
CONTAINER_EXISTS=$(docker ps -a -q -f "name=^${CONTAINER_NAME}$")

if [ -n "$CONTAINER_RUNNING" ]; then
    echo "Stopping container for customer $CUSTOMER_NAME (ID: $CONTAINER_RUNNING)..."
    docker stop "$CONTAINER_NAME"
    echo "Container stopped."
fi

if [ -n "$CONTAINER_EXISTS" ]; then
    echo "Removing container for customer $CUSTOMER_NAME (ID: $CONTAINER_EXISTS)..."
    docker rm "$CONTAINER_NAME"
    echo "Container removed."
fi

# Confirm with the user before proceeding with deletion
if [ "$FORCE" = false ]; then
    read -p "Are you sure you want to delete all data for customer $CUSTOMER_NAME? This action cannot be undone. (y/n): " CONFIRM
    if [[ ! $CONFIRM =~ ^[Yy]$ ]]; then
        echo "Deletion cancelled."
        exit 0
    fi
fi

# Remove customer directories and files
echo "Removing customer directories..."
rm -rf "$CUSTOMERS_DIR/$CUSTOMER_NAME"
rm -rf "$CERTS_DIR/$CUSTOMER_NAME"

# Remove customer metadata file
if [ -f "$METADATA_DIR/$CUSTOMER_NAME.env" ]; then
    echo "Removing customer metadata..."
    rm -f "$METADATA_DIR/$CUSTOMER_NAME.env"
fi

# Log the deletion
echo "$(date): Deleted customer $CUSTOMER_NAME" >> "$LOGS_DIR/sra_operations.log"

echo "Customer $CUSTOMER_NAME has been successfully deleted from the system."
if [ -n "${CUSTOMER_PORT:-}" ]; then
    echo "Port $CUSTOMER_PORT is now available for reassignment."
fi
echo "All associated customer data, keys, and configurations have been removed." 