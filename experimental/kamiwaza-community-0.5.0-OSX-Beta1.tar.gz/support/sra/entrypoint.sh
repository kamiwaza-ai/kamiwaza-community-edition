#!/bin/sh

set -e

# Copy the server certificate and key
cp /run/secrets/ssh_host_rsa_key.pub /etc/ssh/ssh_host_rsa_key.pub
cp /run/secrets/ssh_host_rsa_key /etc/ssh/ssh_host_rsa_key
chmod 644 /etc/ssh/ssh_host_rsa_key.pub
chmod 600 /etc/ssh/ssh_host_rsa_key

# Set up the authorized_keys file for the sshuser
mkdir -p /home/sshuser/.ssh
cp /run/secrets/authorized_keys /home/sshuser/.ssh/authorized_keys
chown -R sshuser:sshuser /home/sshuser/.ssh
chmod 700 /home/sshuser/.ssh
chmod 600 /home/sshuser/.ssh/authorized_keys

# Ensure correct ownership and permissions for sshuser's home directory
chown sshuser:sshuser /home/sshuser
chmod 755 /home/sshuser

# Create a .profile file for sshuser to set environment variables
cat << EOF > /home/sshuser/.profile
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/home/sshuser
export USER=sshuser
EOF
chown sshuser:sshuser /home/sshuser/.profile
chmod 644 /home/sshuser/.profile

# Start SSH server with verbose logging
/usr/sbin/sshd -D -e