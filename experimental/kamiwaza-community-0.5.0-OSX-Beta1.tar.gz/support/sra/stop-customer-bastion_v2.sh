#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"

# Function to check if a customer exists
check_customer_exists() {
    local customer_name="$1"
    if [ ! -f "$METADATA_DIR/$customer_name.env" ]; then
        echo "Error: Customer $customer_name does not exist or metadata not found."
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name> [--force]"
    exit 1
fi

CUSTOMER_NAME=$1
FORCE=false

# Check for --force flag
if [ $# -gt 1 ]; then
    if [ "$2" == "--force" ]; then
        FORCE=true
    fi
fi

# Check if customer exists
check_customer_exists "$CUSTOMER_NAME"

# Source customer-specific environment variables
source "$METADATA_DIR/$CUSTOMER_NAME.env"

# Get the actual container name used
CONTAINER_NAME="${CUSTOMER_NAME}-bastion"

# Check if the container is running - use more reliable detection
CONTAINER_RUNNING=$(docker ps -q -f "name=^${CONTAINER_NAME}$")
CONTAINER_EXISTS=$(docker ps -a -q -f "name=^${CONTAINER_NAME}$")

if [ -z "$CONTAINER_RUNNING" ]; then
    echo "Container for customer $CUSTOMER_NAME is not running."
    if [ -z "$CONTAINER_EXISTS" ]; then
        echo "Container for customer $CUSTOMER_NAME does not exist."
        if [ "$FORCE" = false ]; then
            echo "No action needed. Use --force to clean up metadata anyway."
            exit 0
        fi
    else
        echo "Container exists but is not running. It will be removed."
    fi
else
    echo "Stopping container for customer $CUSTOMER_NAME (ID: $CONTAINER_RUNNING)..."
    docker stop "$CONTAINER_NAME"
    echo "Container stopped."
fi

# Remove the container - check again in case something changed
CONTAINER_EXISTS=$(docker ps -a -q -f "name=^${CONTAINER_NAME}$")
if [ -n "$CONTAINER_EXISTS" ]; then
    echo "Removing container for customer $CUSTOMER_NAME (ID: $CONTAINER_EXISTS)..."
    docker rm "$CONTAINER_NAME"
    echo "Container removed."
fi

# Log the termination
echo "$(date): Terminated container for customer $CUSTOMER_NAME" >> "$LOGS_DIR/sra_operations.log"

echo "Customer $CUSTOMER_NAME's bastion container has been terminated."
echo "The port $CUSTOMER_PORT can now be reassigned to another customer if needed."
echo "The customer's metadata and keys are still preserved."
echo "To restart the container, use: ./start-customer-bastion_v2.sh $CUSTOMER_NAME" 