#!/bin/bash

set -euo pipefail

DOCKER_IMAGE="kamiwaza-sra-bastion:v2"
LOGS_DIR="/home/kamiwaza/sra/logs"

# Build the new image
docker build -t "$DOCKER_IMAGE" -f Dockerfile_v2 .

# Log the update
echo "$(date): Updated SSH container image" >> "$LOGS_DIR/container_operations.log"

echo "SSH container image updated successfully"
                                                                                                                                                        
