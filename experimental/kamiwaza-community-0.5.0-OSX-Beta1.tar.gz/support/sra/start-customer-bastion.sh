#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"
SUPPORT_ACCESS_DIR="/home/kamiwaza/support-access"
DOCKER_IMAGE="sra-ssh-container:latest"

# Function to validate customer name
validate_customer_name() {
    if [[ ! $1 =~ ^[a-z0-9_]+$ ]]; then
        echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=$1

# Validate customer name
validate_customer_name "$CUSTOMER_NAME"

# Check if customer exists
if [ ! -f "$METADATA_DIR/${CUSTOMER_NAME}.env" ]; then
    echo "Error: Customer $CUSTOMER_NAME does not exist."
    exit 1
fi

# Source customer metadata
source "$METADATA_DIR/${CUSTOMER_NAME}.env"

# Check if container is already running
if docker ps --format '{{.Names}}' | grep -q "^sra_${CUSTOMER_NAME}$"; then
    echo "Error: Container for customer $CUSTOMER_NAME is already running."
    exit 1
fi

# Aggregate authorized keys
TEMP_AUTH_KEYS=$(mktemp)

# Check if CUSTOMER_CONTAINER_ACCESS_KEY_PUB is set
if [ -z "${CUSTOMER_CONTAINER_ACCESS_KEY_PUB:-}" ]; then
    echo "Error: CUSTOMER_CONTAINER_ACCESS_KEY_PUB is not set in the customer metadata file."
    exit 1
fi

# Add customer's public key
cat "$CUSTOMER_CONTAINER_ACCESS_KEY_PUB" > "$TEMP_AUTH_KEYS"

# Add engineer public keys
for key in "$SUPPORT_ACCESS_DIR"/*.pub; do
    cat "$key" >> "$TEMP_AUTH_KEYS"
done

# Start the container
docker run -d --rm \
    --name "sra_${CUSTOMER_NAME}" \
    -p "${CUSTOMER_HIGH_PORT}:22" \
    -v "${CUSTOMER_SERVER_CERT}:/run/secrets/ssh_host_rsa_key.pub:ro" \
    -v "${CUSTOMER_SERVER_KEY}:/run/secrets/ssh_host_rsa_key:ro" \
    -v "${TEMP_AUTH_KEYS}:/run/secrets/authorized_keys:ro" \
    "$DOCKER_IMAGE"

# Check if container started successfully
if [ $? -eq 0 ]; then
    echo "Container for customer $CUSTOMER_NAME started successfully on port $CUSTOMER_HIGH_PORT"
    echo "$(date): Started container for customer $CUSTOMER_NAME on port $CUSTOMER_HIGH_PORT" >> "$LOGS_DIR/container_operations.log"
else
    echo "Error: Failed to start container for customer $CUSTOMER_NAME"
    echo "$(date): Failed to start container for customer $CUSTOMER_NAME" >> "$LOGS_DIR/container_operations.log"
    rm "$TEMP_AUTH_KEYS"
    exit 1
fi

# Clean up the temporary file
rm "$TEMP_AUTH_KEYS"

# Output the server certificate fingerprint for verification
FINGERPRINT=$(openssl x509 -in "$CUSTOMER_SERVER_CERT" -noout -fingerprint -sha256 | cut -d= -f2)
echo "Server Certificate Fingerprint (SHA256): $FINGERPRINT"

# List authorized users for this container
echo "Authorized users for this container:"
echo "1. Customer: $CUSTOMER_NAME"
echo "2. Kamiwaza Engineers:"
for key in "$SUPPORT_ACCESS_DIR"/*.pub; do
    username=$(basename "$key" .pub)
    echo "   - $username"
done
