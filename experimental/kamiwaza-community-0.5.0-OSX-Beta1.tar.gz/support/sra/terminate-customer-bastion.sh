#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"

# Function to validate customer name
validate_customer_name() {
    if [[ ! $1 =~ ^[a-z0-9_]+$ ]]; then
        echo "Error: Customer name must contain only lowercase letters, numbers, and underscores."
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=$1

# Validate customer name
validate_customer_name "$CUSTOMER_NAME"

# Check if customer exists
if [ ! -f "$METADATA_DIR/${CUSTOMER_NAME}.env" ]; then
    echo "Error: Customer $CUSTOMER_NAME does not exist."
    exit 1
fi

# Source customer metadata
source "$METADATA_DIR/${CUSTOMER_NAME}.env"

# Check if container is running
if ! docker ps --format '{{.Names}}' | grep -q "^sra_${CUSTOMER_NAME}$"; then
    echo "Note: Container for customer $CUSTOMER_NAME is not currently running."
    exit 0
fi

# Stop the container
echo "Stopping container for customer $CUSTOMER_NAME..."
if docker stop "sra_${CUSTOMER_NAME}"; then
    echo "Container for customer $CUSTOMER_NAME has been stopped successfully."
    echo "$(date): Stopped container for customer $CUSTOMER_NAME" >> "$LOGS_DIR/container_operations.log"
else
    echo "Error: Failed to stop container for customer $CUSTOMER_NAME"
    echo "$(date): Failed to stop container for customer $CUSTOMER_NAME" >> "$LOGS_DIR/container_operations.log"
    exit 1
fi

# Wait for a moment and check if the container still exists
echo "Waiting for container to be removed..."
sleep 5

if docker ps -a --format '{{.Names}}' | grep -q "^sra_${CUSTOMER_NAME}$"; then
    echo "Container still exists after stopping. Attempting to remove..."
    if docker rm -f "sra_${CUSTOMER_NAME}"; then
        echo "Container for customer $CUSTOMER_NAME has been forcefully removed."
        echo "$(date): Forcefully removed container for customer $CUSTOMER_NAME" >> "$LOGS_DIR/container_operations.log"
    else
        echo "Warning: Failed to forcefully remove container for customer $CUSTOMER_NAME"
        echo "$(date): Failed to forcefully remove container for customer $CUSTOMER_NAME" >> "$LOGS_DIR/container_operations.log"
        echo "Please check the container status manually and remove if necessary."
    fi
else
    echo "Container has been successfully removed by Docker."
fi

echo "Container termination process for customer $CUSTOMER_NAME has completed."
