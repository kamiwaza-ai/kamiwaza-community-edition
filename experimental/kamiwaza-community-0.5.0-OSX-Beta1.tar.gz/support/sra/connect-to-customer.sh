#!/bin/bash

set -euo pipefail

# Example usage on a OSX: sudo socat TCP-LISTEN:443,fork TCP:localhost:8443

# Configuration
BASTION_HOST="sra.kamiwaza.ai"
CUSTOMER_PORT=""
CUSTOMER_NAME=""
ENGINEER_KEY="$HOME/.ssh/id_sra"
SOCAT_PID=""

# Function to check if a port is in use
check_port() {
    local port="$1"
    local process_info
    
    # Check if port is in use on localhost only
    if process_info=$(lsof -i "127.0.0.1:$port" -sTCP:LISTEN 2>/dev/null); then
        # Extract process name and PID from lsof output
        local process_name=$(echo "$process_info" | awk 'NR==2 {print $1}')
        local process_pid=$(echo "$process_info" | awk 'NR==2 {print $2}')
        echo "Error: Port $port is already in use by $process_name (PID: $process_pid)"
        return 1
    fi
    return 0
}

# Function to check all required ports
check_required_ports() {
    local ports=(8080 8443 8265 51100 51101 51200)
    
    echo "Checking required ports..."
    for port in "${ports[@]}"; do
        if ! check_port "$port"; then
            exit 1
        fi
    done
    
    # On OSX, also check port 443
    if [[ "$(uname)" == "Darwin" ]]; then
        if ! check_port "443"; then
            exit 1
        fi
    fi
    
    echo "All required ports are available."
}

# Function to clean up socat process on exit
cleanup() {
    if [ -n "${SOCAT_PID:-}" ]; then
        echo "Cleaning up socat process..."
        sudo kill $SOCAT_PID 2>/dev/null || true
    fi
}

# Set up trap for clean exit
trap cleanup EXIT INT TERM

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -p|--port)
        CUSTOMER_PORT="$2"
        shift
        shift
        ;;
        -c|--customer)
        CUSTOMER_NAME="$2"
        shift
        shift
        ;;
        *)
        echo "Unknown option: $1"
        exit 1
        ;;
    esac
done

# Check if required arguments are provided
if [ -z "$CUSTOMER_PORT" ] || [ -z "$CUSTOMER_NAME" ]; then
    echo "Usage: $0 -p <port> -c <customer_name>"
    exit 1
fi

# Check if the engineer's key exists
if [ ! -f "$ENGINEER_KEY" ]; then
    echo "Error: Engineer's key not found at $ENGINEER_KEY"
    echo "Please ensure you have the correct key in place."
    exit 1
fi

# Check all required ports before proceeding
check_required_ports

# Function to establish SSH connection to the customer's session
connect_ssh() {
    local port="$1"
    local key="$2"
    local host="$3"
    local customer="$4"

    # Check if running on OSX and set up port forwarding if needed
    if [[ "$(uname)" == "Darwin" ]]; then
        echo "Detected OSX system, setting up port forwarding..."
        if ! command -v socat &> /dev/null; then
            echo "Error: socat is required for port forwarding on OSX."
            echo "Please install it using: brew install socat"
            exit 1
        fi
        
        # Get sudo authentication upfront
        echo "Please enter your sudo password for port forwarding setup..."
        if ! sudo -v; then
            echo "Error: Failed to authenticate for sudo access."
            exit 1
        fi
        
        # Start socat in background with existing sudo credentials
        echo "Starting port forwarding (443 -> 8443)..."
        sudo -n socat TCP-LISTEN:443,fork TCP:localhost:8443 &
        SOCAT_PID=$!
        
        # Wait a moment for socat to start
        sleep 1
        
        if ! ps -p $SOCAT_PID > /dev/null; then
            echo "Error: Failed to start port forwarding. Please check your sudo permissions."
            exit 1
        fi
        
        echo "Port forwarding established (PID: $SOCAT_PID)"
    fi

    echo "Connecting to $host on port $port..."
    ssh -i "$key" \
        -t -t \
        -o SendEnv="TERM COLUMNS LINES" \
        -o StrictHostKeyChecking=no \
        -L 8080:localhost:8080 \
        -L 8443:localhost:8443 \
        -L 8265:localhost:8265 \
        -L 51100:localhost:51100 \
        -L 51101:localhost:51101 \
        -L 51200:localhost:51200 \
        -p "$port" \
        "sshuser@$host" \
        "stty cols 239 rows 64 ; export TERM=xterm-256color; socat -d -d - TCP4:localhost:$port"
}

# Establish the SSH connection
connect_ssh "$CUSTOMER_PORT" "$ENGINEER_KEY" "$BASTION_HOST" "$CUSTOMER_NAME"

echo "Connected to customer $CUSTOMER_NAME. Local ports are now forwarded:"
echo "  8080 -> remote 80 (HTTP)"
if [[ "$(uname)" == "Darwin" ]]; then
    echo "  443 -> remote 443 (HTTPS) [OSX port forwarding]"
fi
echo "  8443 -> remote 8443 (HTTPS)"
echo "  8265 -> remote 8265"
echo "  51100 -> remote 51100"
echo "  51101 -> remote 51101"
echo "  51200 -> remote 51200"
echo ""
echo "To disconnect, press Ctrl+C or close this terminal."
