#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
CERTS_DIR="$CUSTOMERS_DIR/certs"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"

# Function to check if a customer exists
check_customer_exists() {
    local customer_name="$1"
    if [ ! -f "$METADATA_DIR/$customer_name.env" ]; then
        echo "Error: Customer $customer_name does not exist or metadata not found."
        exit 1
    fi
}

# Check if required arguments are provided
if [ $# -lt 2 ]; then
    echo "Usage: $0 <customer_name> <engineer_key_file> [engineer_name]"
    echo "  customer_name   : The name of the customer to add the engineer key to"
    echo "  engineer_key_file : Path to the engineer's public key file"
    echo "  engineer_name   : Optional name for the engineer (defaults to filename)"
    exit 1
fi

CUSTOMER_NAME=$1
ENGINEER_KEY_FILE=$2
ENGINEER_NAME="${3:-}"

# Check if customer exists
check_customer_exists "$CUSTOMER_NAME"

# Check if the key file exists
if [ ! -f "$ENGINEER_KEY_FILE" ]; then
    echo "Error: Engineer key file $ENGINEER_KEY_FILE does not exist."
    exit 1
fi

# Make sure the key file is a public key
if ! grep -q "ssh-" "$ENGINEER_KEY_FILE"; then
    echo "Error: $ENGINEER_KEY_FILE does not appear to be a valid SSH public key."
    echo "Please provide a file containing a public key (typically ending in .pub)."
    exit 1
fi

# Source customer-specific environment variables
source "$METADATA_DIR/$CUSTOMER_NAME.env"

# Create the engineers directory if it doesn't exist
ENGINEER_KEYS_DIR="$CERTS_DIR/$CUSTOMER_NAME/engineers"
mkdir -p "$ENGINEER_KEYS_DIR"

# If engineer name isn't provided, derive it from the key file name
if [ -z "$ENGINEER_NAME" ]; then
    # Extract filename without extension
    ENGINEER_NAME=$(basename "$ENGINEER_KEY_FILE" | sed 's/\.[^.]*$//')
fi

# Sanitize the engineer name for use as a filename
ENGINEER_NAME_SAFE=$(echo "$ENGINEER_NAME" | tr -cd '[:alnum:]_-')

# Copy the engineer's public key
cp "$ENGINEER_KEY_FILE" "$ENGINEER_KEYS_DIR/${ENGINEER_NAME_SAFE}.pub"

echo "Added engineer key for $ENGINEER_NAME_SAFE to customer $CUSTOMER_NAME."

# Check if the customer's bastion container is running
if docker ps | grep -q "$CUSTOMER_NAME-bastion"; then
    echo "The customer's bastion container is currently running."
    echo "The new engineer key will be applied when the container is restarted."
    echo "To restart the container, run:"
    echo "./terminate-customer-bastion_v2.sh $CUSTOMER_NAME"
    echo "./start-customer-bastion_v2.sh $CUSTOMER_NAME"
else
    echo "The customer's bastion container is not currently running."
    echo "The new engineer key will be applied when the container is started."
    echo "To start the container, run:"
    echo "./start-customer-bastion_v2.sh $CUSTOMER_NAME"
fi

# Log the action
echo "$(date): Added engineer key for $ENGINEER_NAME_SAFE to customer $CUSTOMER_NAME" >> "$LOGS_DIR/sra_operations.log" 