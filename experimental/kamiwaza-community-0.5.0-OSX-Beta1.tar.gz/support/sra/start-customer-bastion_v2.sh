#!/bin/bash

set -euo pipefail

# Configuration
CUSTOMERS_DIR="/home/kamiwaza/customers"
CERTS_DIR="$CUSTOMERS_DIR/certs"
METADATA_DIR="$CUSTOMERS_DIR/metadata"
LOGS_DIR="/home/kamiwaza/sra/logs"
SUPPORT_ACCESS_DIR="/home/kamiwaza/support-access"
DOCKER_IMAGE="kamiwaza-sra-bastion:v2" # Updated Docker image name for v2

# Function to check if a customer exists
check_customer_exists() {
    local customer_name="$1"
    if [ ! -f "$METADATA_DIR/$customer_name.env" ]; then
        echo "Error: Customer $customer_name does not exist or metadata not found."
        echo "Please create the customer first with create-customer-bastion_v2.sh"
        exit 1
    fi
}

# Check if customer name is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <customer_name>"
    exit 1
fi

CUSTOMER_NAME=$1

# Check if customer exists
check_customer_exists "$CUSTOMER_NAME"

# Source customer-specific environment variables
source "$METADATA_DIR/$CUSTOMER_NAME.env"

# Create customer-specific SSH config directory if it doesn't exist
CUSTOMER_SSH_DIR="/home/kamiwaza/ssh_configs/$CUSTOMER_NAME"
mkdir -p "$CUSTOMER_SSH_DIR"

echo "Starting container for customer $CUSTOMER_NAME on port $CUSTOMER_PORT..."

# Create required secrets directory for the container
SECRETS_DIR="/tmp/$CUSTOMER_NAME-secrets"
mkdir -p "$SECRETS_DIR"

# Prepare the authorized_keys for kzcustomer
# Using the authorized_keys created during customer creation
cp "$CERTS_DIR/$CUSTOMER_NAME/kzcustomer_authorized_keys" "$SECRETS_DIR/customer_authorized_keys"

# Check if there are engineer public keys for this customer
ENGINEER_KEYS_DIR="$CERTS_DIR/$CUSTOMER_NAME/engineers"
rm -f "$SECRETS_DIR/engineer_authorized_keys"
touch "$SECRETS_DIR/engineer_authorized_keys"

# First check customer-specific engineer keys (if directory exists and not empty)
if [ -d "$ENGINEER_KEYS_DIR" ] && [ "$(ls -A "$ENGINEER_KEYS_DIR" 2>/dev/null)" ]; then
    # Combine all customer-specific engineer public keys with appropriate restrictions
    for key_file in "$ENGINEER_KEYS_DIR"/*.pub; do
        echo "command=\"/home/kzengineer/proxy_to_client.sh\",no-agent-forwarding,no-X11-forwarding $(cat "$key_file")" >> "$SECRETS_DIR/engineer_authorized_keys"
    done
    echo "Added $(ls -1 "$ENGINEER_KEYS_DIR"/*.pub 2>/dev/null | wc -l) customer-specific engineer keys."
fi

# Add support engineer keys from SUPPORT_ACCESS_DIR (common keys for all customers)
if [ -d "$SUPPORT_ACCESS_DIR" ] && [ "$(ls -A "$SUPPORT_ACCESS_DIR"/*.pub 2>/dev/null)" ]; then
    for key_file in "$SUPPORT_ACCESS_DIR"/*.pub; do
        echo "command=\"/home/kzengineer/proxy_to_client.sh\",no-agent-forwarding,no-X11-forwarding $(cat "$key_file")" >> "$SECRETS_DIR/engineer_authorized_keys"
    done
    echo "Added $(ls -1 "$SUPPORT_ACCESS_DIR"/*.pub 2>/dev/null | wc -l) support engineer keys."
else
    echo "Warning: No support engineer keys found in $SUPPORT_ACCESS_DIR."
fi

# Check if there are any engineer keys at all
if [ ! -s "$SECRETS_DIR/engineer_authorized_keys" ]; then
    echo "Warning: No engineer keys found for customer $CUSTOMER_NAME."
    echo "Engineers will not be able to connect until keys are added."
fi

# Prepare SSH host keys
if [ ! -f "$CERTS_DIR/$CUSTOMER_NAME/ssh_host_rsa_key" ]; then
    echo "Generating SSH host keys for customer $CUSTOMER_NAME..."
    ssh-keygen -t rsa -b 4096 -f "$CERTS_DIR/$CUSTOMER_NAME/ssh_host_rsa_key" -N ""
fi
cp "$CERTS_DIR/$CUSTOMER_NAME/ssh_host_rsa_key" "$SECRETS_DIR/ssh_host_rsa_key"
cp "$CERTS_DIR/$CUSTOMER_NAME/ssh_host_rsa_key.pub" "$SECRETS_DIR/ssh_host_rsa_key.pub"

# Copy the engineer forward tunnel key to the secrets directory
if [ -f "$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key" ]; then
    cp "$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key" "$SECRETS_DIR/forward_tunnel_key"
    cp "$CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key.pub" "$SECRETS_DIR/forward_tunnel_key.pub"
    echo "Using pre-generated forward tunnel key for engineers"
else
    echo "WARNING: No forward tunnel key found at $CERTS_DIR/$CUSTOMER_NAME/forward_tunnel_key"
    echo "Please recreate the customer using the latest create-customer-bastion_v2.sh script"
fi

# Create a log file for the container
touch "$LOGS_DIR/$CUSTOMER_NAME-bastion.log"

# Check if a container with the same name is already running
if docker ps -a --format '{{.Names}}' | grep -q "^$CUSTOMER_NAME-bastion$"; then
    echo "Container $CUSTOMER_NAME-bastion already exists."
    if docker ps --format '{{.Names}}' | grep -q "^$CUSTOMER_NAME-bastion$"; then
        echo "Container is currently running. Stopping it before starting a new one."
        docker stop "$CUSTOMER_NAME-bastion"
    fi
    docker rm "$CUSTOMER_NAME-bastion"
fi

# Start the Docker container for this customer
docker run -d --restart unless-stopped \
    --name "$CUSTOMER_NAME-bastion" \
    -p "$CUSTOMER_PORT:22" \
    -v "$SECRETS_DIR/ssh_host_rsa_key:/run/secrets/ssh_host_rsa_key:ro" \
    -v "$SECRETS_DIR/ssh_host_rsa_key.pub:/run/secrets/ssh_host_rsa_key.pub:ro" \
    -v "$SECRETS_DIR/customer_authorized_keys:/run/secrets/customer_authorized_keys:ro" \
    -v "$SECRETS_DIR/engineer_authorized_keys:/run/secrets/engineer_authorized_keys:ro" \
    -v "$SECRETS_DIR/forward_tunnel_key:/run/secrets/forward_tunnel_key:ro" \
    -v "$SECRETS_DIR/forward_tunnel_key.pub:/run/secrets/forward_tunnel_key.pub:ro" \
    -v "$LOGS_DIR/$CUSTOMER_NAME-bastion.log:/var/log/bastion.log" \
    --log-driver=json-file \
    --log-opt max-size=10m \
    --log-opt max-file=3 \
    "$DOCKER_IMAGE"

# Clean up the temp secrets
rm -rf "$SECRETS_DIR"

# Wait a moment to see if container starts successfully
sleep 2

# Get the container ID to check status more reliably
CONTAINER_ID=$(docker ps -q -f "name=^${CUSTOMER_NAME}-bastion$")

if [ -n "$CONTAINER_ID" ]; then
    # Container started successfully - verify it's actually running 
    CONTAINER_STATUS=$(docker inspect --format='{{.State.Status}}' "$CONTAINER_ID")
    
    if [ "$CONTAINER_STATUS" = "running" ]; then
        echo "Container $CUSTOMER_NAME-bastion started successfully (ID: $CONTAINER_ID)."
        echo "Customer can now connect using:"
        echo "-----"
        echo "connect-support_v2.sh -p $CUSTOMER_PORT"
        echo "-----"
        echo "Engineers can connect once the customer establishes the reverse tunnel using:"
        echo "-----"
        echo "connect-to-customer_v2.sh -p $CUSTOMER_PORT -c $CUSTOMER_NAME"
        echo "-----"
        
        # List authorized engineers for this container
        echo "Authorized engineers for this container:"
        if [ -d "$ENGINEER_KEYS_DIR" ] && [ "$(ls -A "$ENGINEER_KEYS_DIR" 2>/dev/null)" ]; then
            echo "Customer-specific engineers:"
            for key in "$ENGINEER_KEYS_DIR"/*.pub; do
                username=$(basename "$key" .pub)
                echo "   - $username"
            done
        fi
        
        if [ -d "$SUPPORT_ACCESS_DIR" ] && [ "$(ls -A "$SUPPORT_ACCESS_DIR"/*.pub 2>/dev/null)" ]; then
            echo "Kamiwaza support engineers:"
            for key in "$SUPPORT_ACCESS_DIR"/*.pub; do
                username=$(basename "$key" .pub)
                echo "   - $username"
            done
        fi
    else
        echo "Error: Container started but is in '$CONTAINER_STATUS' state."
        echo "Check logs with: docker logs $CUSTOMER_NAME-bastion"
        exit 1
    fi
else
    echo "Error: Container failed to start or exited immediately."
    echo "Check logs with: docker logs $CUSTOMER_NAME-bastion"
    exit 1
fi

# Log the starting of the container
echo "$(date): Started container for customer $CUSTOMER_NAME on port $CUSTOMER_PORT" >> "$LOGS_DIR/sra_operations.log" 