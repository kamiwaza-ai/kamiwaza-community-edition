#!/bin/bash
set -x

# Determine platform
if [[ "$(uname)" == "Darwin" ]]; then
    platform='osx'
else
    platform='linux'
fi

# Determine architecture
arch_raw=$(uname -m)
case "$arch_raw" in
    "x86_64")
        arch='amd64'
        ;;
    "aarch64"|"arm64")
        arch='arm64'
        ;;
    *)
        echo "Unsupported architecture: $arch_raw"
        exit 1
        ;;
esac

# Determine CPU or GPU
if command -v nvidia-smi &> /dev/null && nvidia-smi > /dev/null 2>&1; then
    cpugpu='gpu'
else
    cpugpu='cpu'
fi

# Check for KAMIWAZA_ENV, set to "default" if not set
KAMIWAZA_ENV=${KAMIWAZA_ENV:-default}
# Main loop to process components
for component in $(find kamiwaza/deployment -mindepth 1 -maxdepth 1 -type d | grep -v '/envs$'); do
    component=$(basename $component)
    # Determine the appropriate architecture suffixes to create directories for
    arch_suffixes=() # Initialize an empty array to hold potential architecture suffixes
    if [[ -d "kamiwaza/deployment/${component}/${arch}" ]]; then
        arch_suffixes+=("${arch}")
    fi
    if [[ -d "kamiwaza/deployment/${component}/${arch}-cpu" ]]; then
        arch_suffixes+=("${arch}-cpu")
    fi
    if [[ -d "kamiwaza/deployment/${component}/${arch}-gpu" ]]; then
        arch_suffixes+=("${arch}-gpu")
    fi

    # Create environment specific directories based on the architecture suffixes found
    for suffix in "${arch_suffixes[@]}"; do
        mkdir -p "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}"
    done

    # Copy files from both architecture and architecture with CPU/GPU suffix if they exist
    for suffix in "${arch_suffixes[@]}"; do
        for file in docker-compose.yml prelaunch.sh postlaunch.sh; do
            if [[ -f "kamiwaza/deployment/${component}/${suffix}/${file}" ]]; then
                cp "kamiwaza/deployment/${component}/${suffix}/${file}" "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${suffix}/"
            fi
        done
    done

    # Determine the appropriate architecture folder considering CPU/GPU suffix for further operations
    if [[ "$cpugpu" == "gpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-gpu" ]]; then
        arch_folder="${arch}-gpu"
    elif [[ -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}" ]]; then
        arch_folder="${arch}"
    elif [[ "$cpugpu" == "cpu" && -d "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch}-cpu" ]]; then
        arch_folder="${arch}-cpu"
    else
        echo "No suitable architecture folder found for component: ${component}"
        continue
    fi

    # Navigate to the component directory
    cd "kamiwaza/deployment/envs/${KAMIWAZA_ENV}/${component}/${arch_folder}"

    # Execute lifecycle scripts if they exist
    [[ -f "prelaunch.sh" ]] && bash "prelaunch.sh"
    docker-compose -f "docker-compose.yml" -p "${KAMIWAZA_ENV}-${component}" up -d
    [[ -f "launch.sh" ]] && sleep 5 && bash "launch.sh"
    [[ -f "postlaunch.sh" ]] && sleep 5 && bash "postlaunch.sh"

    # Return to the original directory
    cd - > /dev/null
done
exit 0
