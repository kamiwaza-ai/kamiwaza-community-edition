import sys
import time
import os
import argparse
import uvicorn
import subprocess
import signal
import inspect
from fastapi import FastAPI, Request
from kamiwaza.services.models.api import model_router
from kamiwaza.serving.api import serving_router, serving_exception_handlers, start_ray
from kamiwaza.serving.inference import inference_router
from kamiwaza.serving.config import settings as serving_settings
from kamiwaza.cluster.config import settings as cluster_settings
from kamiwaza.services.vectordb.api import vectordb_router
from kamiwaza.services.catalog.api import catalog_router
from kamiwaza.services.prompts.api import promptd_api
from kamiwaza.services.embedding.api import embedding_router
from kamiwaza.services.activity.api import activity_router
from kamiwaza.cluster.api import cluster_router
from kamiwaza.cluster.services import ClusterService
from kamiwaza.node.api import node_router
from kamiwaza.services.activity.middleware import activity_logger  # import the middleware
from kamiwaza.scheduler.launch import task_schedule
from kamiwaza.cluster.util.dns import node_hostname
from kamiwaza.cluster.util.bootstrap import bootstrap_config

import ray
from ray import serve
import logging
from fastapi.middleware.cors import CORSMiddleware

logger = logging.getLogger(__name__)
root_logger = logging.getLogger()

if os.getenv("KAMIWAZA_DEBUG_MODE", "False") == "True":
    logger.setLevel(logging.DEBUG)
    root_logger.setLevel(logging.DEBUG)
else:
    logger.setLevel(logging.INFO)
    root_logger.setLevel(logging.INFO)

# We technically should have KAMIWAZA_ROOT from launch.py but we will allow
# this to work the original way. Main wraps this now so that imported libs can
# save config files in the correct spot

@ray.remote
def test_env_vars():
    kamiwaza_root = os.getenv("KAMIWAZA_ROOT")
    kamiwaza_lib_root = os.getenv("KAMIWAZA_LIB_ROOT")
    
    if kamiwaza_root and kamiwaza_lib_root:
        return f"Environment variables are set:\nKAMIWAZA_ROOT: {kamiwaza_root}\nKAMIWAZA_LIB_ROOT: {kamiwaza_lib_root}"
    else:
        return "Environment variables are not set."

# flush first cache
config_cache_dir = os.path.join(os.getenv('KAMIWAZA_ROOT', '/tmp'), '.kamiwaza', 'config_cache')
if os.path.exists(config_cache_dir):
    for file_name in os.listdir(config_cache_dir):
        file_path = os.path.join(config_cache_dir, file_name)
        if os.path.isfile(file_path):
            os.unlink(file_path)

KAMIWAZA_ROOT = os.path.dirname(os.path.abspath(__file__))
os.environ["KAMIWAZA_ROOT"] = KAMIWAZA_ROOT
config_cache_dir = os.path.join(os.getenv('KAMIWAZA_ROOT', '/tmp'), '.kamiwaza', 'config_cache')

if os.path.exists(os.path.join(os.environ["KAMIWAZA_ROOT"], "runtime", "runtime_config.json")):
    os.unlink(os.path.join(os.environ["KAMIWAZA_ROOT"], "runtime", "runtime_config.json"))

#flush real cache
if os.path.exists(config_cache_dir):
    for file_name in os.listdir(config_cache_dir):
        file_path = os.path.join(config_cache_dir, file_name)
        if os.path.isfile(file_path):
            os.unlink(file_path)

cluster_module_file = inspect.getfile(ClusterService)
cluster_dir = os.path.dirname(cluster_module_file)
KAMIWAZA_LIB_ROOT = os.path.abspath(os.path.join(cluster_dir, '..'))
logger.debug(f"lib root is {KAMIWAZA_LIB_ROOT}")
os.environ["KAMIWAZA_LIB_ROOT"] = KAMIWAZA_LIB_ROOT


# Enhanced command line argument parsing to include help message and Ray connection parameters
parser = argparse.ArgumentParser(description="Launch the Kamiwaza service in either cluster or standalone mode.",
                                 usage="Use '--standalone' to run without clustering. Specify '--ray-host' and '--ray-port' to connect to an existing Ray cluster. Without these flags, it runs in cluster mode by default. Ray should be run with 'ray start --head'")
parser.add_argument("--standalone", action="store_true", help="Run in standalone mode without clustering")
parser.add_argument("--ray-host", type=str, default=None, help="Specify the Ray head node host")
parser.add_argument("--ray-port", type=int, default=None, help="Specify the Ray head node port")
args = parser.parse_args()
# Set cluster mode based on the presence of the --standalone flag
clusterMode = not args.standalone

os.environ["KAMIWAZA_CLUSTER_MODE"] = str(clusterMode).lower()

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# TODO: More restrictive CORS policy

# Apply exception handlers
for exc_class, handler in serving_exception_handlers.items():
    app.add_exception_handler(exc_class, handler)

# Attach all the Kamiwaza module API routers
app.include_router(model_router, tags=["models"])
app.include_router(serving_router, prefix="/serving", tags=["serving"])
app.include_router(vectordb_router, prefix="/vectordb", tags=["vectordb"])
app.include_router(catalog_router, prefix="/catalog", tags=["catalog"])
app.include_router(promptd_api, prefix="/prompts", tags=["prompts"])
app.include_router(embedding_router, prefix="/embedding", tags=["embedding"])
app.include_router(cluster_router, prefix="/cluster", tags=["cluster"])
app.include_router(activity_router, prefix="/activity", tags=["activity"])
app.middleware("http")(activity_logger)  # inject the middleware into the fastapi endpoint



# Special on/off for inference via kamiwaza module
if serving_settings.enable_inference:
    app.include_router(inference_router, prefix="/inference", tags=["inference"])

# handle typical (clusterMode) deployment vs single-user/developer laptop
if clusterMode:
    # If we are in cluster mode, we will run the node service in a separate app
    nodeapp = FastAPI()
    nodeapp.include_router(node_router, prefix="/node", tags=["node"])
else:
    # If we are in single-system mode, we aren't wrapping FastAPI in Ray, so just include the node router
    app.include_router(node_router, prefix="/node", tags=["node"])

if clusterMode:
    ### The "Ray" launch; we only expect this to be skipped if we are deployed
    ### into an existing ray cluster
    if not ray.is_initialized():
        if not serving_settings.ray_init_address:
            logger.warning(f"WARNING: Kamiwaza is not in standalone mode, and serving.settings.ray_init_address is not set; will try to detect ray via /tmp/ray/ray_current_cluster and start as head if not detected")

        runtime_env = {
            "env_vars": {
                "KAMIWAZA_ROOT": KAMIWAZA_ROOT,
                "KAMIWAZA_LIB_ROOT": KAMIWAZA_LIB_ROOT
            }
        }
        
        start_ray(
            address=None if not args.ray_host else f"{args.ray_host}{':' if args.ray_port else ''}{args.ray_port if args.ray_port else ''}",
            runtime_env=runtime_env
        )

        # loop until ray starts
        ray_wait = 0
        while not ray.is_initialized():
            ray_wait += 1
            if ray_wait > 30:
                logger.error("Ray is not initialized after 10 seconds. Giving up on waiting for ray.")
                break
            time.sleep(1)

        primary_hostname = node_hostname()
        if primary_hostname:
            os.environ["KAMIWAZA_PRIMARY_NODE"] = primary_hostname
            runtime_env["env_vars"]["KAMIWAZA_PRIMARY_NODE"] = primary_hostname
            runtime_env["env_vars"]["KAMIWAZA_RUNNING"] = "true"

        ## Here we restart ray to update the new runtime env since we "booted"
        ## Another way to go about this would be to put hostname discovery into
        ## its own module that does nothing but that, return it from a subprocess
        ## and start ray; on the other hand, it probably saves very little,
        ## because we then still have to start ray twice and we have a 
        ## child process to manage.
        ray.shutdown()
        start_ray(
            address=None if not args.ray_host else f"{args.ray_host}{':' if args.ray_port else ''}{args.ray_port if args.ray_port else ''}",
            runtime_env=runtime_env
        )
                # loop until ray starts
        ray_wait = 0
        while not ray.is_initialized():
            ray_wait += 1
            if ray_wait > 30:
                logger.error("Ray is not initialized after 10 seconds. Giving up on waiting for ray.")
                break
            time.sleep(1)
        bootstrap_config()

    result = test_env_vars.remote()
    print(ray.get(result))


    # Wrapper for Ray Serve; we are using the original FastAPI endpoints so it has no methods,
    # Updated to use Ray Serve's HTTPOptions for Ray version 2.10, following the new API structure
    @serve.deployment
    @serve.ingress(app)
    class FastAPIWrapper:
        pass

    logger.debug("Starting Ray Serve")
    http_options = serve.config.HTTPOptions(host="0.0.0.0", port=7777)
    serve.start(detached=True, http_options=http_options)
    serve.run(FastAPIWrapper.bind(), route_prefix="/")

    logger.debug("Starting Cluster Service")
    try:
        cluster_service = ClusterService()
        cluster_service.cluster_init()
    except Exception as e:
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        tb_str = traceback.format_exception(exc_type, exc_value, exc_traceback)
        logger.error(f"Error initializing cluster: {''.join(tb_str)}; exiting")
        exit(1)


    logger.debug("Starting Scheduled Tasks")
    task_schedule.start_scheduled_tasks()

    # /node endpoint comes up in separate service, which has the benefit of blocking
    # ray from exiting when serve.run() is "done" (aka initialized)
    if __name__ == "__main__":
        uvicorn.run(nodeapp, host="0.0.0.0", port=7788)

else:
    # It's a bit of a misnomer, of course, because cluster_Service is also kamiwaza metadata
    # We could do other things like disable the cluster page, since you won't ever have use
    # of placement groups in single-node mode, but consistency here. We do this
    # after check for clusterMode because we want cluster_init() to pick up the ray
    # info generated by ray_init()

    # this should do local resolution now because no ray
    primary_hostname = node_hostname()
    if primary_hostname:
        os.environ["KAMIWAZA_PRIMARY_NODE"] = primary_hostname

    try:
        cluster_service = ClusterService()
        cluster_service.cluster_init()
    except Exception as e:
        # TODO: again, probably this becomes fatal at some point
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        tb_str = traceback.format_exception(exc_type, exc_value, exc_traceback)
        logger.error(f"Non-Fatal: Error initializing cluster: {''.join(tb_str)}; will continue but default resources or node may not be registered")

    task_schedule.start_scheduled_tasks()

    if __name__ == "__main__":
        # run all the APIs together, single-node mode
        logger.debug("Kamiwaza: Debug logging active")
        print("Starting uvicorn in non-clusterMode")
        uvicorn.run(app, host="0.0.0.0", port=7777)


