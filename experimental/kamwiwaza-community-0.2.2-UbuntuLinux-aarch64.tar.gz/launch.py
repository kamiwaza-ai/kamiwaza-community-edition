import os

# TODO: investigate a better way to deal with python etcd3 lib being dated.
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'

import subprocess
import logging
import sys
from kamiwaza.util.config import RuntimeConfig
#test

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

KAMIWAZA_ROOT = os.path.dirname(os.path.abspath(__file__))
os.environ["KAMIWAZA_ROOT"] = KAMIWAZA_ROOT
os.environ["KAMIWAZA_LAUNCH_HOST"] = "true"

if os.environ.get("KAMIWAZA_DEBUG_MODE", "False") == "True":
    logging.getLogger().setLevel(logging.DEBUG)

rc = RuntimeConfig()
rc.set_config('initialized', True)

# Path to main.py
main_py_path = os.path.join(KAMIWAZA_ROOT, 'main.py')

# Check for the --standalone flag and other arguments in the command line
standalone_flag = '--standalone' if '--standalone' in sys.argv else ''
ray_host = next((arg for arg in sys.argv if arg.startswith('--ray-host=')), '')
ray_port = next((arg for arg in sys.argv if arg.startswith('--ray-port=')), '')

# Call main.py using subprocess with the standalone flag and other arguments if present
env = os.environ.copy()
subprocess_args = ['python', main_py_path]
if standalone_flag:
    subprocess_args.append(standalone_flag)
if ray_host:
    subprocess_args.append(ray_host)
if ray_port:
    subprocess_args.append(ray_port)
try:
    subprocess.run(subprocess_args, check=True, env=env)
except subprocess.CalledProcessError as e:
    logger.error(f"Error occurred while running main.py: {str(e)}")
    raise
