# Steps for Successful Install

# 1. Test for requirements.txt
# 2. Test for config file
# 3. Test for Docker files
# 4. Test for/launch containers
# 5. Create databases
# 6. License stuff?

import os
import re
import importlib
import sys
import subprocess
import time
from typing import Optional

def get_highest_version(spec: str) -> Optional[str]:
    """
    Parses version specs like '>=3.3,<3.4' and returns the highest 'x.y' version possible under the conditions.
    """
    parts = spec.split(',')
    min_version = 0  # Set a default minimal version that's low
    max_version = float('inf')  # Set a default maximal version that's very high
    
    for part in parts:
        match = re.match(r'([><=]+)\s*(\d+\.\d+)', part.strip())
        if match:
            operator, version = match.groups()
            version = float(version)  # Convert to float for comparison
            if '<' in operator and version < max_version:
                max_version = version
            if ('>' in operator or '=' in operator) and version > min_version:
                min_version = version
    
    if max_version != float('inf'):
        # Calculate the highest version that is still less than the upper bound
        candidate_version = max_version - 0.1  # Decrement to stay below max if necessary
        if candidate_version >= min_version:
            version_to_use = f"{int(candidate_version)}.{int((candidate_version % 1) * 10)}"
            print(f"Setting spark version to: {version_to_use}")
            return version_to_use

    # If no upper bound is provided, return the highest version that meets the minimum condition
    if min_version != 0:
        version_to_use = f"{int(min_version)}.{int((min_version % 1) * 10)}"
        print(f"Setting spark version to: {version_to_use}")
        return version_to_use

    # Return None if no valid version could be determined (unlikely case)
    return None

# Ensure the script is invoked from install.sh or setup.sh
if not os.getenv('KAMIWAZA_RUN_FROM_INSTALL'):
    print("\033[91mWarning: This script should not be run directly.\033[0m")
    print("Please run install.sh or setup.sh instead.")
    print("If you know what you are doing and have been instructed to run this script directly, set the environment variable 'KAMIWAZA_RUN_FROM_INSTALL=yes' and try again.")
    sys.exit(1)
# Check if we are in a virtual environment
if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
    print(f"Virtual environment detected: {sys.prefix}")
else:
    print("\033[91mWarning: Not running in a virtual environment\033[0m - careful")  # Red warning
    if not '-y' in sys.argv:
        user_input = input("Do you want to continue without a virtual environment? Type 'yes' to proceed: ")
        if user_input.lower() != 'yes':
            print("Exiting the installation.")
            sys.exit(1)

# Define the paths to check for requirements.txt
paths_to_check = ['../requirements.txt', './requirements.txt']


# Define a mapping for special cases where pip name differs from import name
special_cases = {
    'acryl-datahub': 'datahub',  # Assuming 'datahub' is the import name
    'argon2-cffi': 'argon2',
    'argon2-cffi-bindings': 'argon2',
    'avro-gen3': 'avro',  # Assuming 'avro_gen3' is the import name
    'grpcio': 'grpc',
    'google-api-core': 'google.api_core',
    'google-auth': 'google.auth',
    'googleapis-common-protos': 'google.api_core.protobuf_helpers',
    'ipython': 'IPython',
    'Jinja2': 'jinja2',
    'Pillow': 'PIL',
    'protobuf': 'google.protobuf',
    'psycopg2-binary': 'psycopg2',
    'pycairo': 'cairo',
    # Add any additional special cases here
    'Babel': 'babel',
    'beautifulsoup4': 'bs4',
    'Deprecated': 'deprecated',
    'dnspython': 'dns',
    'linear-tsv': 'tsv',
    'MarkupSafe': 'markupsafe',
    'nvidia-ml-py': 'pynvml',
    'progressbar2': 'progressbar',
    'py-cpuinfo': 'cpuinfo',
    'Pygments': 'pygments',
    'PyGObject': 'gi',
    'PySocks': 'socks',
    'python-dateutil': 'dateutil',
    'python-dotenv': 'dotenv',
    'python-json-logger': 'pythonjsonlogger',
    'python-multipart': 'multipart',
    'PyYAML': 'yaml',
    'pyzmq': 'zmq',
    'scikit-learn': 'sklearn',
    'Send2Trash': 'send2trash',
    'SQLAlchemy': 'sqlalchemy',
    'types-python-dateutil': 'types_dateutil',
    'websocket-client': 'websocket',
    'Werkzeug': 'werkzeug',
    'rpds-py': 'rpds',
    'matplotlib-inline': None, # notebooks only
    'opencensus-context': 'opencensus.common.runtime_context',
    'py-spy': None, # cli only
    'mwparserfromhell': None,
    'macholib': None, # TODO: validate this is only for mwparserfromhell
    'ruamel.yaml.clib': None, # clib because ruamel.yaml is universal wheel build, no great way to detect clib install, but should be in as dependency
}

def get_import_name(pip_name):
    return pip_name.replace('-', '_')

# Iterate over the paths
for path in paths_to_check:
    if os.path.isfile(path):
        with open(path, 'r') as f:
            lines = f.readlines()

        # Ensure pydeequ is moved to the last line if present
        lines = [line for line in lines if "pydeequ" not in line.strip()] + \
                [line for line in lines if "pydeequ" in line.strip()]

        for line in lines:
            line = line.strip()
            if line.startswith('pyspark'):
                truncated_version = get_highest_version(line)
                os.environ["SPARK_VERSION"] = truncated_version
                print(f"Based on pyspark package, set SPARK_VERSION to {truncated_version}")
            if '==' in line:
                module_name, version = line.split('==')
            else:
                module_name = line
                version = None

            # Check for special cases or apply general replacement rule
            printable_module_name = module_name
            if module_name in special_cases:
                if special_cases[module_name] is None:
                    print(f"{module_name}: \033[94mSkipping, special package\033[0m")  # Blue "Skipping, special package"
                    continue
                printable_module_name = printable_module_name + " (as " + special_cases[module_name] + ")"
                import_name = special_cases[module_name]
            else:
                import_name = get_import_name(module_name)

            try:
                importlib.import_module(import_name)
                print(f"{module_name}: \033[92mYes\033[0m")  # Green "Yes"
            except ImportError:
                print(f"{module_name}: \033[91mNo\033[0m")  # Red "No"
        break

    
###### 2. Test for config fiels
print("**** Testing for expected config files...")

# Define the paths to check for config files, removing the leading './' for proper concatenation later
config_paths_to_check = [
    'kamiwaza/cluster/config.py',
    'kamiwaza/serving/config.py',
    'kamiwaza/node/config.py',
    'kamiwaza/services/catalog/config.py',
    'kamiwaza/services/vectordb/config.py',
    'kamiwaza/services/models/config.py',
    'kamiwaza/services/retrieval/config.py',
    'kamiwaza/services/prompts/config.py'
]

def get_site_packages_path(venv_path: Optional[str] = None) -> Optional[str]:
    """
    Retrieves the site-packages path from the virtual environment if available.
    
    Args:
        venv_path: The path to the virtual environment.
        
    Returns:
        The site-packages path if the virtual environment is detected, otherwise None.
    """
    if venv_path:
        return os.path.join(venv_path, 'lib', f"python{sys.version_info.major}.{sys.version_info.minor}", 'site-packages')
    return None

def check_config_path(config_path: str, site_packages_path: Optional[str] = None) -> None:
    """
    Checks if the config file exists at the given path or within the site-packages directory.
    
    Args:
        config_path: The path to the config file to check.
        site_packages_path: The site-packages directory path.
    """
    # Check directly in the provided path
    if os.path.isfile(config_path):
        print(f"{config_path}: \033[92mYes\033[0m")  # Green "Yes"
    # Construct the path within the site-packages and check
    elif site_packages_path:
        # Construct the path relative to the site-packages directory
        venv_config_path = os.path.join(site_packages_path, config_path)
        if os.path.isfile(venv_config_path):
            print(f"{config_path} (in venv): \033[92mYes\033[0m")  # Green "Yes"
        else:
            print(f"{config_path}: \033[91mNo\033[0m")  # Red "No"
    else:
        print(f"{config_path}: \033[91mNo\033[0m")  # Red "No"

# Retrieve the virtual environment path from the environment variable
venv_path = os.getenv('VIRTUAL_ENV')
site_packages_path = get_site_packages_path(venv_path)

# Iterate over the config paths
for config_path in config_paths_to_check:
    check_config_path(config_path, site_packages_path)


##### 3. Install the containers
print("*** Composing docker containers... ")

# launch the containers, because we need them up for the install
try:
    result = subprocess.run(['./containers-up.sh'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(result.stdout.decode('utf-8'))
except Exception as e:
    print(f"Failed to run containers-up.sh: {e}")
    pass

print("*** Waiting for containers to start...")
time.sleep(15)

print("*** Ensuring containers are up")
try:
    result = subprocess.run(['./containers-up.sh'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(result.stdout.decode('utf-8'))
except Exception as e:
    print(f"Failed to run containers-up.sh: {e}")
    print("Second pass container failure: FATAL. Contact support@kamiwaza.ai")
    exit(1)


##### 5. Create databases
# for models, prompts, vectordbs, run non-destructive table creator
print("*** Initializing Database...")
RESET_ALL_DATABASES = False
## Cluster Service

from kamiwaza.cluster.setup import setup
setup(reset_db=RESET_ALL_DATABASES)
del setup

from kamiwaza.services.models.setup import setup as msetup
msetup(reset_db=RESET_ALL_DATABASES) 
del msetup

from kamiwaza.services.prompts.setup import setup as psetup
psetup(reset_db=RESET_ALL_DATABASES)
del psetup

from kamiwaza.services.activity.setup import setup as asetup
asetup(reset_db=RESET_ALL_DATABASES)
del asetup

from kamiwaza.serving.setup import setup as ssetup
ssetup(reset_db=True)
del ssetup

