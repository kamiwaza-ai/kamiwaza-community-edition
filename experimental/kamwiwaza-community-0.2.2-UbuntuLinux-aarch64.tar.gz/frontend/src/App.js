import React, { useState, useEffect } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/common/Header';
import Navbar from './components/common/Navbar';
import ModelIndex from './components/models/ModelIndex';
import ModelDetail from './components/models/ModelDetail';
import ModelFilesContext from './components/models/ModelFilesContext';
import ModelHubSearch from './components/models/ModelHubSearch';
import CatalogList from './components/dataset/DatasetList';
import ActivityFeed from './components/activity/ActivityFeed';
import DatasetDetails from './components/dataset/DatasetDetails';
import ClusterList from './components/cluster/ClusterList';
import ClusterHome from './components/cluster/ClusterHome';
import ClusterDetails from './components/cluster/ClusterDetails';
import LocationDetails from './components/cluster/LocationDetails';
import NodeDetails from './components/cluster/NodeDetails';
import HardwareDetails from './components/cluster/HardwareDetails';
import UserDetails from './components/cluster/UserDetails';
import UserList from './components/cluster/UserList';
import LocationList from './components/cluster/LocationList';
import NodeList from './components/cluster/NodeList';
import HardwareList from './components/cluster/HardwareList';
import RunningNodeDetail from './components/cluster/RunningNodeDetail';
import RunningNodeList from './components/cluster/RunningNodeList';
import Homepage from './components/home/Homepage';
import VectorDBHome from './components/vectordbs/VectorDbHome';
import VectorDBList from './components/vectordbs/VectorDBList';
import VectorDBDetails from './components/vectordbs/VectorDBDetails';
import theme from './Theme'; // Import the theme from Theme.js
import ModelConfigDetail from './components/models/ModelConfigDetail';
import Cookies from 'js-cookie'; // Import js-cookie for handling cookies
import { BASE_URL } from './const';

function App() {
  const [modelFiles, setModelFiles] = useState([]);
  const [hostResolvable, setHostResolvable] = useState(false);

  useEffect(() => {
    const testHostResolvable = async () => {
      try {
        // Fetch the hostname from the API host
        const hostnameResponse = await fetch(`${BASE_URL}/cluster/get_hostname`);
        const { hostname } = await hostnameResponse.json();

        // Test if the hostname is reachable
        const img = new Image();
        img.src = `http://${hostname}/favicon.ico`; // Attempt to load a resource from the hostname

        img.onload = () => {
          setHostResolvable(true);
          Cookies.set('hostnamesResolve', 'true', { expires: 1 }); // Set a cookie for 1 day
        };

        img.onerror = () => {
          setHostResolvable(false);
          Cookies.set('hostnamesResolve', 'false', { expires: 1 });
        };
      } catch (error) {
        setHostResolvable(false);
        Cookies.set('hostnamesResolve', 'false', { expires: 1 });
      }
    };

    testHostResolvable();
  }, []);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <ModelFilesContext.Provider value={{ modelFiles, setModelFiles }}>
        <Router>
          <Header />
          <Navbar />
          <div className="app-content" style={{ padding: theme.spacing(3) }}>
            <Routes>
              {/* Define the route for the home page */}
              <Route path="/" element={<Homepage />} />

              {/* Define the route for the models section */}
              <Route path="/models" element={<ModelIndex />} />
              {/* Define the route for the model detail section */}
              <Route path="/models/:model_id" element={<ModelDetail />} />
              {/* Define the route for the model search section */}
              <Route path="/models/search" element={<ModelHubSearch />} />
              <Route path="/model_configs/:model_config_id" element={<ModelConfigDetail />} />

              {/* Define the route for the catalog section */}
              <Route path="/catalog" element={<CatalogList />} />
              {/* Define the route for the dataset detail section */}
              <Route path="/catalog/dataset/*" element={<DatasetDetails />} />

              {/* Define the route for the activity section */}
              <Route path="/activity" element={<ActivityFeed />} />

              {/* Location and other Details Routes */}
              <Route path="/cluster/locations/:location_id" element={<LocationDetails />} />

              {/* Cluster RunningNode Details */}
              <Route path="/cluster/runningnodes/:node_id" element={<RunningNodeDetail />} />
              <Route path="/cluster/runningnodes/" element={<RunningNodeList />} />

              {/* Define the route for the cluster section */}
              <Route path="/cluster/home" element={<ClusterHome />} />
              <Route path="/cluster/:cluster_id" element={<ClusterDetails />} />
              <Route path="/cluster/" element={<ClusterList />} />
              <Route path="/cluster/locations/:location_id" element={<LocationDetails />} />
              <Route path="/cluster/node/:node_id" element={<NodeDetails />} />
              <Route path="/cluster/hardware/:hardware_id" element={<HardwareDetails />} />
              <Route path="/cluster/users/:user_id" element={<UserDetails />} />
              <Route path="/cluster/users" element={<UserList />} />
              <Route path="/cluster/locations" element={<LocationList />} />
              <Route path="/cluster/nodes" element={<NodeList />} />
              <Route path="/cluster/hardware" element={<HardwareList />} />

              {/* Define the route for the VectorDBs section */}
              <Route path="/vectordbs/home" element={<VectorDBHome />} />
              <Route path="/vectordbs" element={<VectorDBList />} />
              <Route path="/vectordbs/:vectordb_id" element={<VectorDBDetails />} />

              {/* Define the route for the API documentation section */}
              <Route path="/apiDocs" element={() => { window.open(`${BASE_URL}/docs`, '_blank'); return null; }} />
            </Routes>
          </div>
        </Router>
      </ModelFilesContext.Provider>
    </ThemeProvider>
  );
}

export default App;
