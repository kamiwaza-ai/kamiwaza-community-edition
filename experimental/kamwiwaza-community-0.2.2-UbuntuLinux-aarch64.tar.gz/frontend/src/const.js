// Dynamically construct the API URL based on the current host
const API_PORT = '7777'; // API port
const LAB_PORT = '8888';
export const BASE_URL = `${window.location.protocol}//${window.location.hostname}:${API_PORT}`;
export const LAB_URL = `${window.location.protocol}//${window.location.hostname}:${LAB_PORT}`;

