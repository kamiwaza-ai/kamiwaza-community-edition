import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../../const';
import { useParams } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const HardwareDetails = () => {
    const [hardware, setHardware] = useState(null); // Initialize as null or an empty object
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    let { hardware_id } = useParams();

    useEffect(() => {
        const fetchHardwareDetails = async () => {
            setLoading(true);
            try {
                const uri = `${BASE_URL}/cluster/hardware/${hardware_id}`;
                const response = await axios.get(uri);
                if (response.status === 200) {
                    setHardware(response.data); // Expecting a single object
                } else {
                    throw new Error(`Failed to fetch hardware details from ${uri}`);
                }
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchHardwareDetails();
    }, [hardware_id]);

    return (
        <StyledMainContent>
            <StyledButton component={Link} to="/cluster/home" variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Hardware Home
            </StyledButton>
            <StyledHeader>Hardware Details</StyledHeader>
            {loading && <Spinner />}
            {error && <ErrorComponent message={error.message} />}
            {hardware ? (
                <div className="hardware-card">
                    <StyledHeader>{hardware.name}</StyledHeader>
                    <StyledParagraph><strong>ID:</strong> {hardware.id}</StyledParagraph>
                    <StyledParagraph><strong>Node ID:</strong> {hardware.node_id ? hardware.node_id : "No Node (Historical) - may be attached to new Node"}</StyledParagraph>
                    <StyledParagraph><strong>Local Node ID:</strong> {hardware.local_node_id}</StyledParagraph>
                    <StyledParagraph><strong>Cluster IP:</strong> {hardware.cluster_ip}</StyledParagraph>
                    <StyledParagraph><strong>GPUs:</strong> {hardware.gpus ? hardware.gpus.join(', ') : 'N/A'}</StyledParagraph>
                    <StyledParagraph><strong>Processors:</strong> {hardware.processors ? hardware.processors.join(', ') : 'N/A'}</StyledParagraph>
                    <StyledParagraph><strong>OS:</strong> {hardware.os}</StyledParagraph>
                    <StyledParagraph><strong>Platform:</strong> {hardware.platform}</StyledParagraph>
                    <StyledParagraph><strong>Configuration:</strong> {hardware.configuration ? hardware.configuration : "N/A"}</StyledParagraph>
                    <StyledParagraph><strong>Created At:</strong> {new Date(hardware.created_at).toLocaleString()}</StyledParagraph>
                </div>
            ) : (
                !loading && <StyledParagraph>No hardware details available.</StyledParagraph>
            )}
        </StyledMainContent>
    );
};

export default HardwareDetails;