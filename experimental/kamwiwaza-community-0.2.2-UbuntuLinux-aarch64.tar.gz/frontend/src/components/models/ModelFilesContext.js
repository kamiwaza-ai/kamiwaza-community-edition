// ModelFilesContext.js
import { createContext, useState, useEffect } from 'react';
import axios from 'axios';
import { BASE_URL } from '../../const';

const ModelFilesContext = createContext();

export const ModelFilesProvider = ({ children }) => {
  const [statusModelFiles, setStatusModelFiles] = useState([]);
  const [showDownloadStatus, setShowDownloadStatus] = useState(false);

  useEffect(() => {
    const fetchDownloadStatus = async () => {
      try {
        const response = await axios.get(`${BASE_URL}/model_files/download_status/`);
        // Merge response with existing state
        console.log(response)
        updateStatusModelFiles(response.data);
        if (response.data.length > 0) {
          setShowDownloadStatus(true);
        } else {
          setShowDownloadStatus(false);
        }
      } catch (error) {
        console.error('Error fetching download status:', error);
      }
    };

    const intervalId = setInterval(fetchDownloadStatus, 2000); // Adjust polling interval as needed

    return () => clearInterval(intervalId);
  }, []);

  // Update statusModelFiles by merging new data with existing, respecting completed downloads
  const updateStatusModelFiles = (newData) => {
    setStatusModelFiles(prev => {
        // Create a copy of the previous state to modify
        let updatedData = [...prev];

        // Mark items as not downloading if they are not present in the new data
        updatedData.forEach(item => {
            if (!newData.some(newItem => newItem.id === item.id)) {
                item.dl_requested_at = null;
            }
        });

        // Iterate over the new data to add or update items
        newData.forEach(newItem => {
            const existingItemIndex = updatedData.findIndex(item => item.id === newItem.id);
            if (existingItemIndex !== -1) {
                // Update existing item with new data
                updatedData[existingItemIndex] = { ...updatedData[existingItemIndex], ...newItem };
            } else {
                // Add new item
                updatedData.push(newItem);
            }
        });

        return updatedData;
    });
  };

  // Method to clear completed downloads, to be called by user action
  // This method now checks if the download is completed based on the presence of 'storage_location' and absence of 'dl_requested_at'
  const clearCompletedDownloads = () => {
    //setStatusModelFiles(prev => prev.filter(item => !(item.storage_location && !item.dl_requested_at)));
    setStatusModelFiles(prev => prev.filter(item => !(!item.dl_requested_at)));
  };

  const value = {
    statusModelFiles,
    updateStatusModelFiles,
    clearCompletedDownloads,
  };

  return <ModelFilesContext.Provider value={value}>{children}</ModelFilesContext.Provider>;
};

export default ModelFilesContext;
