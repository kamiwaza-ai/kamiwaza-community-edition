import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledTable, StyledTableCell, 
  StyledButton, StyledConfirmModal, StyledModalContent, StyledIconButton, StyledCloseButton, StyledNegativeButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import { BASE_URL } from '../../const';

/**
 * Modal component to display the details of a model deployment.
 * @param {Object} props - Component props.
 * @param {string} props.deploymentId - The ID of the deployment to display details for.
 * @param {boolean} props.isOpen - Controls the visibility of the modal.
 * @param {Function} props.onClose - Callback function to close the modal.
 * @param {Function} props.onDeploymentStopped - Callback function to trigger refresh of the deployment list.
 */
const ModelDeploymentDetailModal = ({ deploymentId, isOpen, onClose, onDeploymentStopped }) => {
    const [deploymentDetail, setDeploymentDetail] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [confirmStop, setConfirmStop] = useState(false);

    useEffect(() => {
        const fetchDeploymentDetail = async () => {
            if (!deploymentId) return;
            setLoading(true);
            try {
                const response = await axios.get(`${BASE_URL}/serving/deployment/${deploymentId}`);
                setDeploymentDetail(response.data);
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchDeploymentDetail();
    }, [deploymentId]);

    const handleStopDeployment = async () => {
        try {
            await axios.delete(`${BASE_URL}/serving/deployment/${deploymentId}`);
            onClose(); // Close the modal after stopping the deployment
            onDeploymentStopped(); // Trigger refresh of the deployment list
        } catch (err) {
            setError(err);
        }
    };

    if (!isOpen) return null; // Do not render the modal if it is not open

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    return (
        <StyledConfirmModal open={isOpen} onClose={onClose}>
            <StyledModalContent>
                <StyledIconButton onClick={onClose} aria-label="close" style={{ alignSelf: 'flex-end' }}>
                    <StyledCloseButton />
                </StyledIconButton>
                {deploymentDetail ? (
                    <>
                        <StyledHeader>Deployment Detail</StyledHeader>
                        <StyledTable>
                            <tbody>
                                <tr><StyledTableCell>Model Name</StyledTableCell><StyledTableCell>{deploymentDetail.m_name}</StyledTableCell></tr>
                                <tr><StyledTableCell>Host</StyledTableCell><StyledTableCell>{deploymentDetail.host_name}</StyledTableCell></tr>
                                <tr><StyledTableCell>Port</StyledTableCell><StyledTableCell>{deploymentDetail.listen_port}</StyledTableCell></tr>
                                <tr><StyledTableCell>Status</StyledTableCell><StyledTableCell>{deploymentDetail.status}</StyledTableCell></tr>
                            </tbody>
                        </StyledTable>
                        <StyledNegativeButton onClick={() => setConfirmStop(true)}>Stop Deployment</StyledNegativeButton>
                    </>
                ) : (
                    <StyledParagraph>Deployment detail not found.</StyledParagraph>
                )}
                <StyledConfirmModal open={confirmStop} onClose={() => setConfirmStop(false)}>
                    <StyledModalContent>
                        <p>This will stop this model deployment. It will immediately become unavailable. Are you sure?</p>
                        <StyledButton onClick={handleStopDeployment}>Yes, Stop</StyledButton>
                        <StyledButton onClick={() => setConfirmStop(false)}>No, Cancel</StyledButton>
                    </StyledModalContent>
                </StyledConfirmModal>
            </StyledModalContent>
        </StyledConfirmModal>
    );
};

export default ModelDeploymentDetailModal;