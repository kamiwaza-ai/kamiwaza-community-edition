import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { StyledMainContent, StyledHeader, StyledParagraph, StyledTable, StyledTableCell, StyledButton, StyledNegativeButton } from '../../StyledComponents';
import Spinner from '../common/Spinner';
import ErrorComponent from '../common/ErrorComponent';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { BASE_URL } from '../../const';

const ModelConfigDetail = () => {
    const [modelConfig, setModelConfig] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { model_config_id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        const fetchModelConfigDetail = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`${BASE_URL}/model_configs/${model_config_id}`);
                setModelConfig(response.data);
                setLoading(false);
            } catch (err) {
                setError(err);
                setLoading(false);
            }
        };

        fetchModelConfigDetail();
    }, [model_config_id]);

    const handleDelete = async () => {
        setLoading(true);
        try {
            await axios.delete(`${BASE_URL}/model_configs/${model_config_id}`);
            navigate(`/models/${modelConfig?.m_id}`);
        } catch (err) {
            setError(err);
            setLoading(false);
        }
    };

    if (loading) return <Spinner />;
    if (error) return <ErrorComponent message={error.message} />;

    return (
        <StyledMainContent>
            <StyledButton component={Link} to={`/models/${modelConfig?.m_id}`} variant="outlined" startIcon={<ArrowBackIosIcon />}>
                Back to Config List
            </StyledButton>
            {modelConfig ? (
                <>
                    <StyledTable>
                        <tbody>
                            <tr><StyledTableCell>Name</StyledTableCell><StyledTableCell>{modelConfig.name}</StyledTableCell></tr>
                            <tr><StyledTableCell>Description</StyledTableCell><StyledTableCell>{modelConfig.description}</StyledTableCell></tr>
                            {modelConfig.config && Object.entries(modelConfig.config).map(([key, value]) => (
                                <tr key={key}>
                                    <StyledTableCell>{key}</StyledTableCell>
                                    <StyledTableCell>{typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value}</StyledTableCell>
                                </tr>
                            ))}
                        </tbody>
                    </StyledTable>
                    {!modelConfig.default && (
                        <StyledNegativeButton variant="contained" onClick={handleDelete}>
                            Delete Config
                        </StyledNegativeButton>
                    )}
                </>
            ) : (
                <StyledParagraph>Model Config not found</StyledParagraph>
            )}
        </StyledMainContent>
    );
};

export default ModelConfigDetail;