# Operator Notes

## Database Reset

```bash
import os
os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"

from kamiwaza.services.prompts.setup import setup as psetup
psetup(reset_db=True)

from kamiwaza.services.models.setup import setup as msetup
msetup(reset_db=True)

from kamiwaza.cluster.setup import setup as csetup
csetup(reset_db=True)

from kamiwaza.services.activity.setup import setup as asetup
asetup(reset_db=True)

from kamiwaza.serving.setup import setup as ssetup
ssetup(reset_db=True)
```
