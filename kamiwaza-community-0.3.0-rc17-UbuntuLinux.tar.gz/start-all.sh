#!/bin/bash

# start-all.sh should be in path with the venv; this should have the installer,
# etc. It may/may not have launch.py (dependant on environmentals)

START_DIR=$(dirname "${BASH_SOURCE[0]}")
START_DIR=$(realpath "${START_DIR}")
cd "${START_DIR}"

if [ ! -f containers-up.sh ] ; then
    echo "containers-up.sh not found, this is in the wrong directory or your install may have issues; support@kamiwaza.ai or discord"
    exit 1
fi

if [ ! -f restart-or-start-lab.sh ] ; then
    echo "restart-or-start-lab.sh not found, this is in the wrong directory or your install may have issues; support@kamiwaza.ai or discord"
    exit 1
fi

if [ ! -f start-ray.sh ] ; then
    echo "start-ray.sh not found, this is in the wrong directory or your install may have issues; support@kamiwaza.ai or discord"
    exit 1
fi

if [ ! -f venv/bin/activate ] ; then
    echo "venv/bin/activate not found, you are running from the wrong directory or have not run install.sh"
    exit 1
fi

# Attempt to fetch metadata from Azure's instance metadata service - if we are we will
# attempt to mount an ephemeral disk or, if present, an unmounted managed disk of
# appropriate (250G+) size
metadata=$(timeout 2s curl -H "Metadata: true" -s -f "http://169.254.169.254/metadata/instance?api-version=2021-02-01")

# Check if the curl command was successful and the response contains "AzurePublicCloud"
if [[ $? -eq 0 && $metadata == *"AzurePublicCloud"* ]]; then
    # Metadata was successfully fetched and contains "AzurePublicCloud"
    AZUREVM=1
else
    # The request failed or did not contain "AzurePublicCloud"
    AZUREVM=0
fi

# If in Azure, proceed with disk mount script
if [[ $AZUREVM -eq 1 ]] ; then
    if [ -f ../mountlocal.sh ] ; then
        cd ..
        bash ./mountlocal.sh
        cd -
    elif [ -f ./mountlocal.sh ] ; then
        bash ./mountlocal.sh
    fi
fi

cd "${START_DIR}"
echo "Starting containers..."
bash containers-up.sh && sleep 5 && bash containers-up.sh > container_start.log 2>&1
echo "Done; container startup in container_start.log (both output and errors)"

cd "$START_DIR"
# Running the restart-or-start-lab.sh script and capturing its output
echo "Starting Jupyter lab..."
bash restart-or-start-lab.sh > lab_startall_start.log 2>&1

sleep 1

# Grep for the JupyterLab URL token from the lab_start.log in either cwd or ./notebooks and print it
echo "JupyterLab URL(s):"
if [ -f jupyter_lab.log ]; then
    grep -E "http://.*token=|https://.*token=" jupyter_lab.log
elif [ -f ./notebooks/jupyter_lab.log ]; then
    grep -E "http://.*token=|https://.*token=" ./notebooks/jupyter_lab.log
else
    echo "lab_start.log not found in either cwd (`pwd`) or ./notebooks"
fi

deactivate || true

cd "$START_DIR"

# we basically want ray to have this but it does do it on its own (start-ray.sh) :shrug:
source venv/bin/activate

# Call the start-ray.sh script to start Ray
bash start-ray.sh

cd frontend
npm install
npm install -g webpack webpack-cli webpack-dev-server
nohup npm start > npm.log 2>&1 &
cd -

cd "$START_DIR"
deactivate || true
source venv/bin/activate

# dev env things; not present in community/enterprise
if [ -f "dev-env.sh" ]; then
    source dev-env.sh
fi

if [ -f "launch.py" ]; then
    python launch.py
elif [ -f "kamiwaza/launch.py" ]; then
    python kamiwaza/launch.py
else
    echo "launch.py not found in the current directory or in kamiwaza/"
    exit 1
fi