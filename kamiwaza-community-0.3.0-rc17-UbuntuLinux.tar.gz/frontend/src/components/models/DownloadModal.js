// DownloadModal.js
//{"result":true,"message":"Download initiated","files":[933137470090870785]}
import React, { useContext, useState } from 'react';
import { StyledModal, StyledButton, StyledCheckbox, StyledFormControlLabel, StyledModalContent } from '../../StyledComponents';
import axios from 'axios'; // Ensure axios is imported
import { BASE_URL } from '../../const';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { StyledIconButton } from '../../StyledComponents';
import CloseIcon from '@mui/icons-material/Close';
import ModelFilesContext from './ModelFilesContext'; // Import ModelFilesContext

const DownloadModal = ({ model, closeModal, showModal, setModelFiles }) => {
    const [selectedFiles, setSelectedFiles] = useState(model.files.map(file => file.name));
    const { updateStatusModelFiles, setShowDownloadStatus } = useContext(ModelFilesContext); // Correctly get setShowDownloadStatus from context

    const handleDownload = async () => {
        try {
            const response = await axios.post(`${BASE_URL}/models/download/`, {
                model: model.repo_modelId,
                version: model.version || '',
                files_to_download: selectedFiles,
                hub: model.hub
            });
            // Use updateStatusModelFiles to immediately add the new download items to the global state
            if (response.data.result && Array.isArray(response.data.files)) {
                const filesForUpdate = response.data.files.map(fileId => ({
                    id: fileId,
                    // Add any other expected properties with placeholder values
                }));
                updateStatusModelFiles(filesForUpdate);
            }
        } catch (err) {
            console.error('Download error:', err);
            // Handle download error
        }
        closeModal();
    };

    const toggleFileSelection = (filename) => {
        setSelectedFiles(selectedFiles.includes(filename)
            ? selectedFiles.filter(file => file !== filename)
            : [...selectedFiles, filename]);
    };

    return (
        <>
            <StyledModal open={showModal} onClose={closeModal}>
                <StyledModalContent>
                    <Box className="filedownload-modal"
                        sx={{
                            margin: 2, // Add some margin around the content
                            padding: 2, // Add some padding inside the box for spacing
                            border: '1px solid grey', // Add a border for visual separation
                            boxShadow: 10,
                            borderRadius: '4px', // Optional: round the corners of the modal
                        }}
                    >
                        <StyledIconButton
                            aria-label="close"
                            onClick={closeModal}
                        >
                            <CloseIcon />
                        </StyledIconButton>
                        <Typography variant="h6" component="h2">
                            Select files to download for {model.name}
                        </Typography>
                        <Box>
                            <StyledFormControlLabel
                                control={
                                    <StyledCheckbox
                                        checked={selectedFiles.length === model.files.length}
                                        onChange={(event) => {
                                            setSelectedFiles(event.target.checked ? model.files.map(file => file.name) : []);
                                        }}
                                        name="selectAll"
                                    />
                                }
                                label="Select/Unselect All"
                                labelPlacement="end"
                            />
                            <br />
                            {model.files.map((file, index) => (
                                <React.Fragment key={file.name}>
                                    <StyledFormControlLabel
                                        control={
                                            <StyledCheckbox
                                                checked={selectedFiles.includes(file.name)}
                                                onChange={() => toggleFileSelection(file.name)}
                                                name={file.name}
                                            />
                                        }
                                        label={`${file.name} - ${file.size > 1e9 ? (file.size / 1e9).toFixed(2) + ' GB' : (file.size / 1e6).toFixed(2) + ' MB'} `}
                                        labelPlacement="end"
                                    />
                                    <br />
                                </React.Fragment>
                            ))}
                        </Box>
                        <Box>
                            <StyledButton variant="outlined" onClick={closeModal}>
                                Close
                            </StyledButton>
                            <StyledButton variant="contained" onClick={handleDownload}>
                                Download Selected Files
                            </StyledButton>
                        </Box>
                    </Box>
                </StyledModalContent>
            </StyledModal>
        </>
    );
};

export default DownloadModal;
