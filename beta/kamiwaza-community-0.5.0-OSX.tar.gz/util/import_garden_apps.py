#!/usr/bin/env python3
"""
Import and replace app templates from the garden JSON file.

This script imports app templates from garden/default/apps.json and replaces
existing templates with the same names. If there are active deployments based
on those templates, it will abort unless --shutdown is specified.

Works with the unified Docker Compose architecture where all apps are deployed
using docker compose, regardless of service count.
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any
from uuid import UUID

# Add the kamiwaza root to the path so we can import modules
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent / 'kamiwaza'))

from kamiwaza.lib.util import get_kamiwaza_root
from kamiwaza.serving.garden.apps.templates import TemplateService
from kamiwaza.serving.garden.apps.apps import AppService
from kamiwaza.serving.schemas.templates import CreateAppTemplate, TemplateSource, TemplateVisibility, RiskTier
from kamiwaza.serving.schemas.serving import AppDeployment
from kamiwaza.db.engine import DatabaseManager
from kamiwaza.serving.config import settings

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class GardenAppImporter:
    """Handles importing and replacing app templates from the garden JSON file."""
    
    def __init__(self):
        """Initialize the importer with required services."""
        # Initialize database connection
        DatabaseManager.get_instance('main', settings.database_url)
        
        self.template_service = TemplateService()
        self.app_service = AppService()
        
    def load_garden_apps(self, garden_file_path: str) -> List[Dict]:
        """Load app templates from the garden JSON file."""
        try:
            from kamiwaza.util.garden import load_garden_apps as load_apps
            apps = load_apps(garden_file_path)
            logger.info(f"Loaded {len(apps)} app templates from {garden_file_path}")
            return apps
        except FileNotFoundError:
            logger.error(f"Garden file not found: {garden_file_path}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in garden file: {e}")
            raise
    
    def find_existing_template(self, name: str) -> Optional[Dict]:
        """Find an existing template by name."""
        templates = self.template_service.list_templates()
        for template in templates:
            if template.name == name:
                return template
        return None
    
    def find_deployments_for_template(self, template_id: UUID) -> List[AppDeployment]:
        """Find all deployments that use the specified template."""
        deployments = self.app_service.list_deployments()
        return [d for d in deployments if d.template_id == template_id and d.status not in ['STOPPED', 'FAILED']]
    
    def find_all_deployments_for_template(self, template_id: UUID) -> List[AppDeployment]:
        """Find ALL deployments that use the specified template, regardless of status."""
        deployments = self.app_service.list_deployments()
        return [d for d in deployments if d.template_id == template_id]
    
    def cleanup_stopped_deployments(self, template_id: UUID) -> bool:
        """Clean up stopped/failed deployments for a template to avoid foreign key constraints."""
        try:
            from kamiwaza.db.engine import DatabaseManager
            from kamiwaza.serving.models.models import DBAppDeployment, DBAppInstance, DBAppPortMapping
            
            # Get database session
            SessionLocal = DatabaseManager.get_session('main')
            
            with SessionLocal() as db:
                # First, find deployments that need to be cleaned up
                deployments_to_cleanup = db.query(DBAppDeployment).filter(
                    DBAppDeployment.template_id == template_id,
                    DBAppDeployment.status.in_(['STOPPED', 'FAILED', 'DELETED'])
                ).all()
                
                if not deployments_to_cleanup:
                    logger.info("No stopped deployments to clean up")
                    return True
                
                deployment_ids = [d.id for d in deployments_to_cleanup]
                logger.info(f"Found {len(deployment_ids)} stopped deployments to clean up")
                
                # Delete port mappings first (they reference instances)
                port_mappings_deleted = db.query(DBAppPortMapping).filter(
                    DBAppPortMapping.instance_id.in_(
                        db.query(DBAppInstance.id).filter(
                            DBAppInstance.deployment_id.in_(deployment_ids)
                        )
                    )
                ).delete(synchronize_session=False)
                
                if port_mappings_deleted > 0:
                    logger.info(f"Deleted {port_mappings_deleted} port mappings")
                
                # Delete instances (they reference deployments)
                instances_deleted = db.query(DBAppInstance).filter(
                    DBAppInstance.deployment_id.in_(deployment_ids)
                ).delete(synchronize_session=False)
                
                if instances_deleted > 0:
                    logger.info(f"Deleted {instances_deleted} instances")
                
                # Finally delete deployments
                deployments_deleted = db.query(DBAppDeployment).filter(
                    DBAppDeployment.id.in_(deployment_ids)
                ).delete(synchronize_session=False)
                
                db.commit()
                
                if deployments_deleted > 0:
                    logger.info(f"Cleaned up {deployments_deleted} stopped/failed deployments for template {template_id}")
                
                return True
                
        except Exception as e:
            logger.error(f"Error cleaning up stopped deployments: {e}")
            return False
    
    async def shutdown_deployments(self, deployments: List[AppDeployment]) -> bool:
        """Shutdown all specified deployments."""
        success = True
        for deployment in deployments:
            try:
                logger.info(f"Shutting down deployment: {deployment.name} ({deployment.id})")
                result = await self.app_service.stop_deployment(deployment.id)
                if not result:
                    logger.error(f"Failed to shutdown deployment: {deployment.name}")
                    success = False
                else:
                    logger.info(f"Successfully shutdown deployment: {deployment.name}")
            except Exception as e:
                logger.error(f"Error shutting down deployment {deployment.name}: {e}")
                success = False
        return success
    
    def create_template_from_garden_app(self, garden_app: Dict[str, Any]) -> CreateAppTemplate:
        """Convert a garden app definition to a CreateAppTemplate."""
        return CreateAppTemplate(
            name=garden_app['name'],
            compose_yml=garden_app['compose_yml'],
            env_defaults=garden_app.get('env_defaults', {}),
            source_type=TemplateSource.kamiwaza,  # Garden apps are kamiwaza-sourced
            visibility=TemplateVisibility.public,  # Garden apps are public by default
            risk_tier=RiskTier.guided,  # Default to guided tier for garden apps
            version=garden_app.get('version', '1.0.0'),  # Use version from garden or default
            validate_containers=False  # Don't validate during import
        )
    
    def extract_tags_from_compose(self, compose_yml: str) -> List[str]:
        """Extract tags based on services found in the compose file."""
        tags = []
        compose_lower = compose_yml.lower()
        
        # Check for common services/technologies
        if 'nginx' in compose_lower:
            tags.extend(['web', 'nginx'])
        if 'postgres' in compose_lower:
            tags.extend(['database', 'postgresql'])
        if 'mysql' in compose_lower or 'mariadb' in compose_lower:
            tags.extend(['database', 'mysql'])
        if 'redis' in compose_lower:
            tags.extend(['cache', 'redis'])
        if 'mongo' in compose_lower:
            tags.extend(['database', 'mongodb'])
        if 'rabbitmq' in compose_lower or 'kafka' in compose_lower:
            tags.extend(['messaging'])
        if 'elasticsearch' in compose_lower:
            tags.extend(['search', 'elasticsearch'])
        
        # Remove duplicates while preserving order
        seen = set()
        unique_tags = []
        for tag in tags:
            if tag not in seen:
                seen.add(tag)
                unique_tags.append(tag)
                
        return unique_tags
    
    async def import_template(self, garden_app: Dict, shutdown_deployments: bool = False) -> bool:
        """Import a single template, handling existing templates and deployments."""
        template_name = garden_app['name']
        logger.info(f"Processing template: {template_name}")
        
        # Check if template already exists
        existing_template = self.find_existing_template(template_name)
        
        if existing_template:
            logger.info(f"Found existing template: {template_name} (ID: {existing_template.id})")
            
            # Check for active deployments
            active_deployments = self.find_deployments_for_template(existing_template.id)
            
            if active_deployments:
                logger.warning(f"Found {len(active_deployments)} active deployments using template {template_name}")
                
                if shutdown_deployments:
                    logger.info("Shutting down active deployments...")
                    success = await self.shutdown_deployments(active_deployments)
                    if not success:
                        logger.error(f"Failed to shutdown all deployments for template {template_name}")
                        return False
                    
                    # Wait a moment for shutdown to complete
                    import asyncio
                    await asyncio.sleep(2)
                else:
                    logger.error(f"Cannot replace template {template_name} - active deployments exist. Use --shutdown to force.")
                    return False
            
            # Clean up any stopped/failed deployments to avoid foreign key constraints
            logger.info(f"Cleaning up stopped deployments for template: {template_name}")
            cleanup_success = self.cleanup_stopped_deployments(existing_template.id)
            if not cleanup_success:
                logger.error(f"Failed to cleanup stopped deployments for template {template_name}")
                return False
            
            # Delete the existing template
            logger.info(f"Deleting existing template: {template_name}")
            try:
                self.template_service.delete_template(existing_template.id)
            except Exception as e:
                logger.error(f"Failed to delete existing template {template_name}: {e}")
                return False
        
        # Create the new template
        try:
            create_template = self.create_template_from_garden_app(garden_app)
            new_template = self.template_service.create_template(create_template)
            logger.info(f"Successfully created template: {template_name} (ID: {new_template.id})")
            logger.info(f"  Version: {new_template.version}")
            logger.info(f"  Source: {new_template.source_type}")
            logger.info(f"  Visibility: {new_template.visibility}")
            logger.info(f"  Risk Tier: {new_template.risk_tier}")
            logger.info(f"  Environment defaults: {list(new_template.env_defaults.keys()) if new_template.env_defaults else 'None'}")
            return True
        except Exception as e:
            logger.error(f"Failed to create template {template_name}: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    async def import_all_templates(self, garden_apps: List[Dict], shutdown_deployments: bool = False) -> bool:
        """Import all templates from the garden apps list."""
        success_count = 0
        total_count = len(garden_apps)
        
        for garden_app in garden_apps:
            try:
                success = await self.import_template(garden_app, shutdown_deployments)
                if success:
                    success_count += 1
            except Exception as e:
                logger.error(f"Unexpected error processing template {garden_app.get('name', 'unknown')}: {e}")
                import traceback
                traceback.print_exc()
        
        logger.info(f"Import complete: {success_count}/{total_count} templates imported successfully")
        return success_count == total_count


async def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Import and replace app templates from garden JSON file"
    )
    parser.add_argument(
        '--garden-file',
        default=None,
        help='Path to the garden JSON file (default: garden/default/apps.json)'
    )
    parser.add_argument(
        '--shutdown',
        action='store_true',
        help='Shutdown active deployments before replacing templates'
    )
    parser.add_argument(
        '--all',
        action='store_true',
        help='Import all apps from the garden file (default: only hello-web and ai-chatbot)'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose logging'
    )
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Determine garden file path
    if args.garden_file:
        garden_file_path = args.garden_file
    else:
        try:
            from kamiwaza.util.garden import get_garden_apps_path
            garden_file_path = get_garden_apps_path()
        except FileNotFoundError:
            logger.error("Could not determine KAMIWAZA_ROOT. Please specify --garden-file explicitly.")
            sys.exit(1)
    
    if not os.path.exists(garden_file_path):
        logger.error(f"Garden file not found: {garden_file_path}")
        sys.exit(1)
    
    logger.info(f"Using garden file: {garden_file_path}")
    
    try:
        importer = GardenAppImporter()
        garden_apps = importer.load_garden_apps(garden_file_path)
        
        # Filter apps if not importing all
        if not args.all:
            target_apps = ['hello-web', 'ai-chatbot']
            filtered_apps = [app for app in garden_apps if app['name'] in target_apps]
            
            if not filtered_apps:
                logger.warning(f"No target apps found in garden file. Looking for: {target_apps}")
                sys.exit(0)
            
            logger.info(f"Found {len(filtered_apps)} target apps to import: {[app['name'] for app in filtered_apps]}")
            apps_to_import = filtered_apps
        else:
            logger.info(f"Importing all {len(garden_apps)} apps from garden file")
            apps_to_import = garden_apps
        
        success = await importer.import_all_templates(apps_to_import, args.shutdown)
        
        if success:
            logger.info("All templates imported successfully!")
            sys.exit(0)
        else:
            logger.error("Some templates failed to import")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"Script failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    import asyncio
    asyncio.run(main()) 