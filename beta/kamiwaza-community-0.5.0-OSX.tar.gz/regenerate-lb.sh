#!/bin/bash

# Note: if Kamiwaza is running this will destroy all non-default load
# balancer configs, which will make all deployments of models unreachable;
# a kamiwaza restart is recommended after running this (or before)

docker compose -p default-kamiwaza-traefik down -v
docker compose -p default-kamiwaza-etcd down -v
bash containers-up.sh etcd
bash containers-up.sh traefik

