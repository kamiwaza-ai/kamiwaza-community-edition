**FurryFriends Pet Supplies: Sanitation Protocols**

---

Maintaining a clean and sanitary environment is essential at FurryFriends Pet Supplies to ensure the health and safety of our customers, pets, and employees. These sanitation protocols outline the necessary cleaning routines, approved cleaning products, and procedures to uphold a safe and healthy store environment.

---

### **1. Cleaning Routines for Pet Product Areas**

#### **a. Daily Cleaning Tasks**
- **Dusting and Wiping Surfaces:**
  - **Procedure:** Dust all shelves, display units, and product surfaces using microfiber cloths.
  - **Frequency:** At the end of each business day.
  - **Approved Products:** Eco-friendly, pet-safe surface cleaners (e.g., EcoClean Multi-Surface Cleaner).

- **Floor Cleaning:**
  - **Procedure:** Sweep and mop all flooring areas to remove pet hair, dirt, and debris.
  - **Frequency:** Twice daily—morning before store opens and evening after closing.
  - **Approved Products:** Pet-safe floor cleaners (e.g., SafePet Floor Solution).

- **Product Rotation:**
  - **Procedure:** Check expiration dates and rotate stock to ensure older products are sold first.
  - **Frequency:** Daily during restocking.

#### **b. Weekly Cleaning Tasks**
- **Deep Cleaning Shelves and Displays:**
  - **Procedure:** Remove all products, vacuum shelves, and sanitize surfaces.
  - **Frequency:** Weekly on designated cleaning days.
  - **Approved Products:** Disinfectant wipes approved for pet areas (e.g., PetSafe Disinfectant Wipes).

- **Inventory Storage Areas:**
  - **Procedure:** Clean and organize backstock areas, ensuring no spills or leaks.
  - **Frequency:** Weekly.

---

### **2. Cleaning Feeding and Water Stations**

#### **a. Daily Cleaning Tasks**
- **Food and Water Bowls:**
  - **Procedure:** Empty, wash, and sanitize all pet feeding and water bowls.
  - **Frequency:** After each customer purchase and at the end of the day.
  - **Approved Products:** Dish soap and hot water, followed by a pet-safe sanitizer (e.g., SafePet Surface Sanitizer).

- **Feeding Areas:**
  - **Procedure:** Wipe down tables and counters where feeding demonstrations occur.
  - **Frequency:** After each demonstration and daily after closing.
  - **Approved Products:** Eco-friendly, pet-safe cleaners.

#### **b. Weekly Cleaning Tasks**
- **Deep Sanitation of Feeding Stations:**
  - **Procedure:** Disassemble any removable parts of feeding stations, clean thoroughly, and reassemble.
  - **Frequency:** Weekly.
  - **Approved Products:** Pet-safe disinfectants (e.g., PetSafe Deep Clean Sanitizer).

---

### **3. Cleaning Restrooms**

#### **a. Daily Cleaning Tasks**
- **Surfaces and Fixtures:**
  - **Procedure:** Clean and disinfect sinks, countertops, toilet seats, and handles.
  - **Frequency:** Every two hours during business hours and at least twice daily.
  - **Approved Products:** Hospital-grade disinfectants safe for restroom use (e.g., Clorox Healthcare Disinfecting Wipes).

- **Floors:**
  - **Procedure:** Sweep and mop restroom floors.
  - **Frequency:** Every two hours during business hours and at least twice daily.
  - **Approved Products:** Floor cleaners appropriate for restroom surfaces.

- **Restocking Supplies:**
  - **Procedure:** Ensure soap dispensers, paper towels, and toilet paper are fully stocked.
  - **Frequency:** Refill as needed throughout the day.

#### **b. Weekly Cleaning Tasks**
- **Deep Cleaning Fixtures:**
  - **Procedure:** Scrub and sanitize all fixtures, including urinals and vents.
  - **Frequency:** Weekly.
  - **Approved Products:** Heavy-duty disinfectants (e.g., Lysol Professional Cleaner).

---

### **4. Cleaning High-Touch Surfaces**

#### **a. Daily Cleaning Tasks**
- **Door Handles and Entryways:**
  - **Procedure:** Disinfect all door handles, push plates, and entryway surfaces.
  - **Frequency:** Every hour during business hours and after each customer interaction.
  - **Approved Products:** EPA-approved disinfectants effective against viruses and bacteria (e.g., Lysol Disinfectant Spray).

- **Checkout Counters and POS Systems:**
  - **Procedure:** Wipe down checkout areas, touch screens, and credit card machines.
  - **Frequency:** After each transaction and hourly.
  - **Approved Products:** Electronics-safe disinfectant wipes (e.g., 70% Isopropyl Alcohol Wipes).

- **Shopping Carts and Baskets:**
  - **Procedure:** Disinfect handles and other high-touch areas.
  - **Frequency:** After each customer use and hourly.
  - **Approved Products:** Pet-safe disinfectant sprays or wipes.

#### **b. Weekly Cleaning Tasks**
- **Deep Disinfection of High-Touch Areas:**
  - **Procedure:** Perform a comprehensive clean of all high-touch surfaces using appropriate disinfectants.
  - **Frequency:** Weekly.
  - **Approved Products:** High-strength disinfectants (e.g., Quaternary Ammonium Compounds).

---

### **5. Approved Cleaning Products**

All cleaning products used at FurryFriends Pet Supplies must be approved to ensure they are safe for pets, customers, and employees. Approved products include:

- **Surface Cleaners:** EcoClean Multi-Surface Cleaner, SafePet Floor Solution.
- **Disinfectants:** PetSafe Disinfectant Wipes, Clorox Healthcare Disinfecting Wipes, Lysol Professional Cleaner.
- **Floor Cleaners:** Pet-safe solutions appropriate for store flooring.
- **Specialty Cleaners:** Electronics-safe disinfectants like 70% Isopropyl Alcohol Wipes.

**Note:** Always follow the manufacturer’s instructions for dilution, application, and safety precautions when using cleaning products.

---

### **6. Instructions for Maintaining a Safe and Healthy Environment**

#### **a. General Practices**
- **Proper Ventilation:**
  - Ensure that all areas are well-ventilated during and after cleaning to allow for drying and to dissipate any cleaning agent fumes.
  
- **Storage of Cleaning Supplies:**
  - Store all cleaning products in a designated, secure area away from pets and customers.
  - Keep cleaning supplies out of reach of animals to prevent accidental ingestion or exposure.

#### **b. Employee Responsibilities**
- **Adherence to Protocols:**
  - Follow all sanitation protocols diligently to maintain consistency and effectiveness.
  
- **Training:**
  - Participate in regular training sessions on proper cleaning techniques and the safe use of cleaning products.
  
- **Reporting Issues:**
  - Immediately report any spills, leaks, or sanitation concerns to the store manager for prompt action.

#### **c. Customer Safety**
- **Clear Signage:**
  - Place signs indicating wet floors or temporarily closed areas during and after cleaning to prevent slips and falls.
  
- **Minimize Customer Disruption:**
  - Schedule intensive cleaning tasks during off-peak hours to reduce interference with customers’ shopping experience.

#### **d. Pet Safety**
- **Isolation During Cleaning:**
  - Keep pets away from cleaning areas to prevent stress or exposure to cleaning agents.
  
- **Safe Cleaning Practices:**
  - Ensure all cleaning agents are pet-safe and properly diluted to avoid harming animals.
  
- **Immediate Cleanup:**
  - Promptly clean up any pet-related spills or accidents to maintain hygiene and prevent the spread of diseases.

---

### **7. Frequency of Cleaning**

- **Multiple Times Daily:**
  - High-touch surfaces, restrooms, and feeding stations.
  
- **Twice Daily:**
  - Pet product areas and floors.
  
- **Weekly:**
  - Deep cleaning of shelves, displays, restrooms, and high-touch areas.
  
- **As Needed:**
  - Spills, accidents, or any unforeseen sanitation issues.

---

### **8. Maintaining Records and Compliance**

- **Cleaning Logs:**
  - Maintain detailed logs of all cleaning activities, including date, time, area cleaned, and employee responsible.
  
- **Compliance Checks:**
  - Regularly review sanitation protocols to ensure compliance with local health regulations and industry standards.
  
- **Continuous Improvement:**
  - Solicit feedback from employees on the effectiveness of sanitation practices and make adjustments as necessary.

---

**FurryFriends Pet Supplies** is committed to upholding the highest standards of cleanliness and hygiene. By following these sanitation protocols, we ensure a safe, healthy, and welcoming environment for our customers, their pets, and our dedicated team members.

---

*Thank you for your dedication to maintaining a pristine and healthy store environment! Your efforts help us provide the best experience for our furry, feathered, and finned friends.*