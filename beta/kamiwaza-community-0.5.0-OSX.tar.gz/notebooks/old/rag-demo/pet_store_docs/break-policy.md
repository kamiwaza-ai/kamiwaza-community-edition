**FurryFriends Pet Supplies: Employee Break Policy**

---

At FurryFriends Pet Supplies, we believe that well-rested and happy employees provide the best service to our customers and their beloved pets. Our break policy is designed to ensure that everyone has the opportunity to recharge while maintaining a smooth and efficient store operation. Below are the guidelines for taking 15-minute and 30-minute breaks, including when and how to take them, as well as procedures during busy and slow periods.

---

### **1. Types of Breaks**

#### **a. 15-Minute Breaks**
- **Purpose:** Short rests to recharge and stay focused throughout the workday.
- **Eligibility:** Available to all employees working shifts longer than 4 hours.
- **Frequency:** Up to two 15-minute breaks per shift.

#### **b. 30-Minute Breaks**
- **Purpose:** Extended breaks for meals or longer rest periods.
- **Eligibility:** Available to all employees working shifts longer than 6 hours.
- **Frequency:** One 30-minute break per shift.

---

### **2. When to Take Breaks**

#### **a. During Slow Periods**
- **Flexibility:** Employees are encouraged to take breaks during slower times to minimize disruption to store operations.
- **Coordination:** Notify your supervisor to arrange break times that ensure adequate store coverage.

#### **b. During Busy Periods**
- **Staggered Breaks:** Breaks should be scheduled so that there is always sufficient staff on the floor to assist customers.
- **Advance Planning:** Employees should plan their breaks in advance during anticipated busy times (e.g., weekends, holidays) and coordinate with team members to cover shifts.

---

### **3. How to Log Breaks**

#### **a. Time-Tracking System**
- **Clock In/Out:** Use the store’s designated time-tracking system to log the start and end times of all breaks.
- **Accuracy:** Ensure all break times are accurately recorded to maintain transparency and proper payroll processing.

#### **b. Manual Logs**
- **Backup Method:** In case of technical issues, use the manual break log sheet provided at the break room.
- **Supervisor Verification:** Have your supervisor sign off on manual logs at the end of your shift.

---

### **4. Break Scheduling Guidelines**

#### **a. Scheduling 15-Minute Breaks**
- **Timing:** Ideally, take one break in the first half of your shift and the second break in the second half.
- **Duration:** Each break should last no longer than 15 minutes.
- **Coverage:** Ensure that taking a break does not leave the store understaffed.

#### **b. Scheduling 30-Minute Breaks**
- **Timing:** Schedule your 30-minute break approximately midway through your shift.
- **Duration:** The break should be exactly 30 minutes to ensure fairness and consistency.
- **Coverage:** Arrange with your team to cover duties while you are on your break.

---

### **5. Policies for Breaks During Different Store Conditions**

#### **a. Busy Periods**
- **Prioritize Store Needs:** During peak hours, breaks may need to be taken at specific times to ensure the store remains fully staffed.
- **Communication:** Keep open communication with your team and supervisor about your break times.
- **Flexibility:** Be prepared to adjust your break schedule if unexpected busy periods arise.

#### **b. Slow Periods**
- **Maximize Flexibility:** Take advantage of slower times to enjoy your breaks without impacting store operations.
- **Encourage Team Cooperation:** Help each other find the best times to take breaks, promoting a supportive work environment.

---

### **6. General Break Rules**

- **No Extended Breaks:** Breaks must adhere to the designated time limits of 15 or 30 minutes.
- **No Accumulation:** Break times should not be accumulated or carried over to the next shift.
- **Break Locations:** Take breaks in designated break areas to ensure safety and cleanliness.
- **Respect Store Hours:** Ensure that all breaks are taken within your scheduled shift hours.

---

### **7. Employee Responsibilities**

- **Plan Ahead:** Schedule your breaks in advance whenever possible, especially during busy times.
- **Communicate:** Inform your supervisor if you need to adjust your break schedule due to unforeseen circumstances.
- **Respect Coverage:** Ensure that your break does not negatively impact store operations or burden your colleagues.
- **Adhere to Logging Procedures:** Accurately log all break times using the approved methods.

---

### **8. Supervisor Responsibilities**

- **Manage Break Schedules:** Coordinate break times to maintain adequate store coverage.
- **Support Employees:** Assist employees in finding suitable times for breaks, especially during high-traffic periods.
- **Monitor Compliance:** Ensure that all employees adhere to break policies and accurately log their break times.
- **Address Issues:** Handle any conflicts or issues related to break scheduling promptly and fairly.

---

**FurryFriends Pet Supplies** is committed to supporting our team members’ well-being while providing excellent service to our customers and their pets. By following these break guidelines, we can ensure a harmonious and productive work environment for everyone.

---

*Thank you for your hard work and dedication! Your well-being is important to us, and we’re here to support you every step of the way.*