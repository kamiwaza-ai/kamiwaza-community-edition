#!/bin/bash
set -e

# Source environment if exists
if [ -f "set-kamiwaza-root.sh" ]; then
  source set-kamiwaza-root.sh
elif [ -f "../set-kamiwaza-root.sh" ] ; then
	source ../set-kamiwaza-root.sh
fi

KAMIWAZA_ROOT=${KAMIWAZA_ROOT:-.}
cd "${KAMIWAZA_ROOT}/frontend"

# Delete PM2 processes first
npx pm2 delete kamiwaza-frontend 2>/dev/null || pm2 delete kamiwaza-frontend 2>/dev/null || true

# Then stop any remaining processes
pkill -f kamiwaza-frontend || true

# Verify all processes are stopped
if ps auxww | grep 'kamiwaza-frontend' | grep -v grep > /dev/null; then
  echo "Warning: Some processes may still be running"
  exit 1
else
  echo "All processes successfully stopped"
  exit 0
fi
