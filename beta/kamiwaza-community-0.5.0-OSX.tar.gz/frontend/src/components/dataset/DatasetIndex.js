import React from 'react';
import DatasetSearch from './DatasetSearch';
import DatasetList from './DatasetList';
import DatasetDetails from './DatasetDetails';
import { StyledMainContent, StyledHeader } from '../../StyledComponents';

const DatasetIndex = () => {
  return (
    <StyledMainContent>
      <StyledHeader>Datasets</StyledHeader>
      <DatasetSearch />
      <DatasetList />
    </StyledMainContent>
  );
};

export default DatasetIndex;
