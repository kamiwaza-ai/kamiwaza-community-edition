import React, { useContext, useState, useEffect } from 'react';
import { styled } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  Box, 
  IconButton,
  Avatar,
  Menu,
  MenuItem,
  Tooltip,
  Badge,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import DeveloperModeIcon from '@mui/icons-material/DeveloperMode';

const StyledAppBar = styled(AppBar)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  color: theme.palette.text.primary,
  boxShadow: 'none',
  borderBottom: `1px solid ${theme.palette.divider}`,
  position: 'fixed',
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
}));

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  paddingLeft: theme.spacing(2),
  paddingRight: theme.spacing(2),
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  height: 64,
}));

const StyledTitle = styled(Typography)(({ theme }) => ({
  flexGrow: 1,
  fontWeight: 600,
  fontSize: '1.25rem',
  marginLeft: theme.spacing(2),
  backgroundImage: 'linear-gradient(90deg, #00c07f, #00c0a0)',
  backgroundClip: 'text',
  textFillColor: 'transparent',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
}));

const ActionButtonsContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
}));

const UserDisplayName = styled(Typography)(({ theme }) => ({
  marginRight: theme.spacing(1),
  fontWeight: 500,
  fontSize: '0.9rem',
}));

const StyledIconButton = styled(IconButton)(({ theme }) => ({
  width: 40,
  height: 40,
  borderRadius: 20,
  color: theme.palette.text.primary,
  '&:hover': {
    backgroundColor: 'rgba(255,255,255,0.1)',
  }
}));

const UserAvatar = styled(Avatar)(({ theme }) => ({
  width: 40,
  height: 40,
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  cursor: 'pointer',
  '&:hover': {
    boxShadow: '0 0 0 2px rgba(0,192,127,0.5)',
  }
}));

const StyledButton = styled(Button)(({ theme }) => ({
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(1, 2),
  transition: 'all 0.2s',
  fontWeight: 500,
  textTransform: 'none',
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  '&:hover': {
    backgroundColor: theme.palette.primary.dark,
    transform: 'translateY(-2px)',
  },
}));

const Header = ({ onToggleSidebar, sidebarOpen }) => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const [advancedMode, setAdvancedMode] = useState(false);
  const [showDisableDialog, setShowDisableDialog] = useState(false);

  useEffect(() => {
    // Check if advanced mode is enabled in localStorage
    const savedMode = localStorage.getItem('advancedDeveloperMode');
    setAdvancedMode(savedMode === 'true');
  }, []);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
    handleCloseMenu();
  };

  const handleOpenMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const getInitials = (name) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const handleAdvancedModeClick = () => {
    setShowDisableDialog(true);
  };

  const handleDisableConfirm = () => {
    setAdvancedMode(false);
    localStorage.setItem('advancedDeveloperMode', 'false');
    setShowDisableDialog(false);
    // Reload page to apply changes
    window.location.reload();
  };

  return (
    <StyledAppBar position="fixed">
      <StyledToolbar>
        {/* Logo and Page Title */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {!advancedMode && (
            <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={onToggleSidebar}
              edge="start"
              sx={{ mr: 1 }}
              data-tour="hamburger-menu"
            >
              <MenuIcon />
            </IconButton>
          )}
          <img 
            src="/kamiwaza-logo-with-text.png" 
            alt="Kamiwaza Logo" 
            style={{ height: '50px' }} 
          />
          
          {advancedMode && (
            <Chip
              icon={<DeveloperModeIcon />}
              label="Advanced Developer Mode: On"
              onClick={handleAdvancedModeClick}
              color="primary"
              variant="outlined"
              size="small"
              sx={{ 
                cursor: 'pointer',
                '&:hover': {
                  backgroundColor: 'rgba(0, 192, 127, 0.1)',
                }
              }}
            />
          )}
        </Box>

        {/* Right-aligned action buttons */}
        <ActionButtonsContainer>
          <Tooltip title="Notifications">
            <StyledIconButton color="inherit">
              <Badge badgeContent={0} color="primary">
                <NotificationsIcon />
              </Badge>
            </StyledIconButton>
          </Tooltip>
          
          <Tooltip title="Help">
            <StyledIconButton color="inherit">
              <HelpOutlineIcon />
            </StyledIconButton>
          </Tooltip>

          {user ? (
            <>
              <UserDisplayName variant="body2">
                {`Welcome, ${user.username}`}
              </UserDisplayName>
              
              <Tooltip title="Account settings">
                <UserAvatar onClick={handleOpenMenu}>
                  {getInitials(user.username)}
                </UserAvatar>
              </Tooltip>
              
              <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleCloseMenu}
                PaperProps={{
                  elevation: 3,
                  sx: {
                    mt: 1.5,
                    backgroundColor: 'background.paper',
                    boxShadow: '0 8px 16px rgba(0,0,0,0.3)',
                    borderRadius: 2,
                    minWidth: 180,
                  },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              >
                <MenuItem onClick={handleCloseMenu}>Profile</MenuItem>
                <MenuItem onClick={handleCloseMenu}>Settings</MenuItem>
                <MenuItem onClick={handleLogout}>Logout</MenuItem>
              </Menu>
            </>
          ) : (
            <StyledButton onClick={() => navigate('/login')}>
              Login
            </StyledButton>
          )}
        </ActionButtonsContainer>
      </StyledToolbar>

      <Dialog
        open={showDisableDialog}
        onClose={() => setShowDisableDialog(false)}
      >
        <DialogTitle>Disable Advanced Developer Mode?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            This will switch to the simplified interface designed for novice users. 
            Some advanced features will be hidden. Do you want to continue?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowDisableDialog(false)}>Cancel</Button>
          <Button onClick={handleDisableConfirm} color="primary" variant="contained">
            Yes, Disable
          </Button>
        </DialogActions>
      </Dialog>
    </StyledAppBar>
  );
};

export default Header;
