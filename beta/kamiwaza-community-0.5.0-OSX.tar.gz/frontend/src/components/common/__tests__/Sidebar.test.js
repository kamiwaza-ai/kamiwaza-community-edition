import React from 'react';
import { renderWithProviders, userEvent, testData } from '../../../test-utils';
import Sidebar from '../Sidebar';

// Mock constants
jest.mock('../../../const', () => ({
  BASE_URL: 'http://localhost:8000',
  LAB_URL: 'http://localhost:8888'
}));

describe('Sidebar', () => {
  const defaultProps = {
    open: true,
    onToggle: jest.fn()
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Rendering', () => {
    test('renders sidebar with logo and menu items', () => {
      const { getByAltText, getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Check logo
      expect(getByAltText('Kamiwaza Logo')).toBeInTheDocument();
      expect(getByText('KAMIWAZA')).toBeInTheDocument();

      // Check core menu items
      expect(getByText('Home')).toBeInTheDocument();
      expect(getByText('Models')).toBeInTheDocument();
      expect(getByText('App Garden')).toBeInTheDocument();
      expect(getByText('Catalog')).toBeInTheDocument();
      expect(getByText('Activity')).toBeInTheDocument();
      expect(getByText('Cluster')).toBeInTheDocument();
      expect(getByText('VectorDBs')).toBeInTheDocument();
      expect(getByText('Notebooks')).toBeInTheDocument();
      expect(getByText('API Docs')).toBeInTheDocument();
    });

    test('renders in collapsed state when open is false', () => {
      const { queryByText, getByAltText, container, debug } = renderWithProviders(
        <Sidebar open={false} onToggle={defaultProps.onToggle} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Logo should still be visible
      expect(getByAltText('Kamiwaza Logo')).toBeInTheDocument();
      
      // Logo text should be hidden when collapsed
      expect(queryByText('KAMIWAZA')).not.toBeInTheDocument();
      
      // Menu items should still be rendered but text should be visually hidden
      const listItems = container.querySelectorAll('.MuiListItem-root');
      expect(listItems.length).toBeGreaterThan(0);
      
      // Check that sidebar drawer has collapsed styling
      const drawer = container.querySelector('.MuiDrawer-root');
      expect(drawer).toBeInTheDocument();
    });

    test('displays admin menu item for superuser', () => {
      const superUser = { ...testData.user, is_superuser: true };
      
      const { getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: superUser,
            loading: false
          }
        }
      );

      expect(getByText('Admin')).toBeInTheDocument();
    });

    test('does not display admin menu item for regular user', () => {
      const regularUser = { ...testData.user, is_superuser: false };
      
      const { queryByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: regularUser,
            loading: false
          }
        }
      );

      expect(queryByText('Admin')).not.toBeInTheDocument();
    });
  });

  describe('Toggle Functionality', () => {
    test('calls onToggle when toggle button is clicked', async () => {
      const user = userEvent.setup();
      const mockToggle = jest.fn();
      
      const { container } = renderWithProviders(
        <Sidebar open={true} onToggle={mockToggle} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Find toggle button (should contain ChevronLeft when open)
      const toggleButton = container.querySelector('button[aria-label]') || 
                          container.querySelector('button');
      
      await user.click(toggleButton);
      expect(mockToggle).toHaveBeenCalledTimes(1);
    });

    test('shows correct chevron icons based on open state', () => {
      const { container, rerender } = renderWithProviders(
        <Sidebar open={true} onToggle={defaultProps.onToggle} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // When open, should show ChevronLeft (collapse icon)
      let chevronLeft = container.querySelector('[data-testid="ChevronLeftIcon"]');
      expect(chevronLeft).toBeInTheDocument();

      // Re-render with open=false
      rerender(
        <Sidebar open={false} onToggle={defaultProps.onToggle} />
      );

      // When closed, should show ChevronRight (expand icon)
      let chevronRight = container.querySelector('[data-testid="ChevronRightIcon"]');
      expect(chevronRight).toBeInTheDocument();
    });
  });

  describe('Navigation Links', () => {
    test('renders internal navigation links correctly', () => {
      const { getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          },
          initialEntries: ['/']
        }
      );

      // Check that internal links are rendered as React Router Links
      const homeLink = getByText('Home').closest('a');
      const modelsLink = getByText('Models').closest('a');
      
      expect(homeLink).toHaveAttribute('href', '/');
      expect(modelsLink).toHaveAttribute('href', '/models');
    });

    test('renders external links with correct attributes', () => {
      const { getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Check external links have proper attributes
      const notebooksLink = getByText('Notebooks').closest('a');
      const apiDocsLink = getByText('API Docs').closest('a');

      expect(notebooksLink).toHaveAttribute('href', 'http://localhost:8888/lab');
      expect(notebooksLink).toHaveAttribute('target', '_blank');
      expect(notebooksLink).toHaveAttribute('rel', 'noopener noreferrer');

      expect(apiDocsLink).toHaveAttribute('href', 'http://localhost:8000/docs');
      expect(apiDocsLink).toHaveAttribute('target', '_blank');
      expect(apiDocsLink).toHaveAttribute('rel', 'noopener noreferrer');
    });
  });

  describe('Active State Highlighting', () => {
    test('renders menu items correctly on home page', () => {
      const { getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          },
          initialEntries: ['/']
        }
      );

      // All menu items should be present and functional
      expect(getByText('Home')).toBeInTheDocument();
      expect(getByText('Models')).toBeInTheDocument();
      expect(getByText('App Garden')).toBeInTheDocument();
      
      // The home item should be rendered (active state styling tested via visual regression)
      const homeItem = getByText('Home').closest('.MuiListItem-root');
      expect(homeItem).toBeInTheDocument();
    });

    test('renders menu items correctly on models page', () => {
      const { getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          },
          initialEntries: ['/models/123']
        }
      );

      const modelsItem = getByText('Models').closest('.MuiListItem-root');
      expect(modelsItem).toBeInTheDocument();
      
      // Models link should be rendered and accessible
      const modelsLink = getByText('Models').closest('a');
      expect(modelsLink).toHaveAttribute('href', '/models');
    });

    test('navigation structure remains consistent across routes', () => {
      const { getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          },
          initialEntries: ['/catalog']
        }
      );

      // All navigation items should be present regardless of current route
      expect(getByText('Home')).toBeInTheDocument();
      expect(getByText('Models')).toBeInTheDocument();
      expect(getByText('Catalog')).toBeInTheDocument();
      expect(getByText('App Garden')).toBeInTheDocument();
    });
  });

  describe('User Authentication States', () => {
    test('renders correctly when user is null', () => {
      const { getByText, queryByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: null,
            loading: false
          }
        }
      );

      // Should still show menu items
      expect(getByText('Home')).toBeInTheDocument();
      expect(getByText('Models')).toBeInTheDocument();
      
      // Should not show admin
      expect(queryByText('Admin')).not.toBeInTheDocument();
    });

    test('renders correctly when user is undefined', () => {
      const { getByText, queryByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: undefined,
            loading: false
          }
        }
      );

      expect(getByText('Home')).toBeInTheDocument();
      expect(queryByText('Admin')).not.toBeInTheDocument();
    });
  });

  describe('Responsive Behavior', () => {
    test('renders all menu items when sidebar is collapsed', () => {
      const { container } = renderWithProviders(
        <Sidebar open={false} onToggle={defaultProps.onToggle} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // All menu items should still be rendered when collapsed
      const listItems = container.querySelectorAll('.MuiListItem-root');
      expect(listItems.length).toBeGreaterThan(0);
      
      // Icons should be present for navigation
      const icons = container.querySelectorAll('.MuiListItemIcon-root');
      expect(icons.length).toBeGreaterThan(0);
      
      // Drawer should be present
      const drawer = container.querySelector('.MuiDrawer-root');
      expect(drawer).toBeInTheDocument();
    });

    test('renders all menu items when sidebar is open', () => {
      const { container, getByText } = renderWithProviders(
        <Sidebar open={true} onToggle={defaultProps.onToggle} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Menu text should be visible when open
      expect(getByText('Home')).toBeInTheDocument();
      expect(getByText('Models')).toBeInTheDocument();
      expect(getByText('App Garden')).toBeInTheDocument();
      
      // Menu items should be rendered
      const listItems = container.querySelectorAll('.MuiListItem-root');
      expect(listItems.length).toBeGreaterThan(0);
    });
  });

  describe('Accessibility', () => {
    test('logo has proper alt text', () => {
      const { getByAltText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      expect(getByAltText('Kamiwaza Logo')).toBeInTheDocument();
    });

    test('navigation items are keyboard accessible', () => {
      const { getByText } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Check that links are focusable (they should have proper tabIndex)
      const homeLink = getByText('Home').closest('a');
      const modelsLink = getByText('Models').closest('a');

      expect(homeLink).toBeInTheDocument();
      expect(modelsLink).toBeInTheDocument();
      
      // Links should be focusable by default
      expect(homeLink.tabIndex).not.toBe(-1);
      expect(modelsLink.tabIndex).not.toBe(-1);
    });

    test('maintains proper semantic structure', () => {
      const { container } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Should have proper list structure
      const list = container.querySelector('ul[role="list"], .MuiList-root');
      expect(list).toBeInTheDocument();

      const listItems = container.querySelectorAll('li, .MuiListItem-root');
      expect(listItems.length).toBeGreaterThan(0);
    });
  });

  describe('Edge Cases', () => {
    test('handles missing onToggle prop gracefully', () => {
      const { container } = renderWithProviders(
        <Sidebar open={true} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      // Should render without crashing
      expect(container).toBeInTheDocument();
    });

    test('handles missing open prop gracefully', () => {
      const { container } = renderWithProviders(
        <Sidebar onToggle={defaultProps.onToggle} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      expect(container).toBeInTheDocument();
    });

    test('renders without crashing with minimal props', () => {
      const { container } = renderWithProviders(
        <Sidebar />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      expect(container).toBeInTheDocument();
    });
  });

  describe('Menu Item Configuration', () => {
    test('displays all expected menu items in correct order', () => {
      const { container } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: testData.user,
            loading: false
          }
        }
      );

      const menuTexts = Array.from(
        container.querySelectorAll('.MuiListItemText-primary')
      ).map(el => el.textContent);

      const expectedItems = [
        'Home', 'Notebooks', 'Models', 'App Garden', 
        'Catalog', 'Activity', 'Cluster', 'VectorDBs', 'API Docs'
      ];

      expectedItems.forEach(item => {
        expect(menuTexts).toContain(item);
      });
    });

    test('includes admin item for superuser in correct position', () => {
      const superUser = { ...testData.user, is_superuser: true };
      
      const { container } = renderWithProviders(
        <Sidebar {...defaultProps} />,
        {
          authValue: {
            user: superUser,
            loading: false
          }
        }
      );

      const menuTexts = Array.from(
        container.querySelectorAll('.MuiListItemText-primary')
      ).map(el => el.textContent);

      expect(menuTexts).toContain('Admin');
      // Admin should be the last item
      expect(menuTexts[menuTexts.length - 1]).toBe('Admin');
    });
  });
});