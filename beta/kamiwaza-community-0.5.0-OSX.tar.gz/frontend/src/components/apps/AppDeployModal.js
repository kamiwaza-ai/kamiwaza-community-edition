import React, { useState, useEffect } from 'react';
import { styled } from '@mui/material/styles';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Typography,
  Alert,
  CircularProgress,
  IconButton,
  Divider,
  Chip,
  Grid,
  Tooltip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Checkbox,
  FormHelperText
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import RocketLaunchIcon from '@mui/icons-material/RocketLaunch';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import axios from 'axios';
import { BASE_URL } from '../../const';
import yaml from 'js-yaml';

// Styled components
const StyledDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialog-paper': {
    borderRadius: 12,
    backgroundColor: theme.palette.background.paper,
    backgroundImage: 'linear-gradient(rgba(0, 192, 127, 0.03), rgba(0, 0, 0, 0.03))',
    minWidth: 700,
    maxHeight: '90vh',
  },
}));

const StyledDialogTitle = styled(DialogTitle)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  paddingBottom: theme.spacing(1),
}));

const TitleText = styled(Typography)(({ theme }) => ({
  fontSize: '1.5rem',
  fontWeight: 600,
  color: theme.palette.primary.main,
}));

const StyledDialogContent = styled(DialogContent)(({ theme }) => ({
  paddingTop: theme.spacing(2),
}));

const FormSection = styled(Box)(({ theme }) => ({
  marginBottom: theme.spacing(3),
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  fontSize: '1rem',
  fontWeight: 600,
  marginBottom: theme.spacing(1.5),
  color: theme.palette.text.primary,
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
}));

const InfoBox = styled(Box)(({ theme }) => ({
  backgroundColor: 'rgba(0, 192, 127, 0.05)',
  border: '1px solid rgba(0, 192, 127, 0.2)',
  borderRadius: 8,
  padding: theme.spacing(2),
  marginBottom: theme.spacing(2),
}));

const InfoRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  marginBottom: theme.spacing(0.5),
  '&:last-child': {
    marginBottom: 0,
  },
}));

const StyledTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    '&:hover fieldset': {
      borderColor: theme.palette.primary.main,
    },
  },
}));

const DeployButton = styled(Button)(({ theme }) => ({
  textTransform: 'none',
  fontWeight: 500,
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  '&:hover': {
    backgroundColor: theme.palette.primary.dark,
  },
  '&:disabled': {
    backgroundColor: theme.palette.action.disabledBackground,
  },
}));

const EnvVarRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  gap: theme.spacing(1),
  alignItems: 'flex-start',
  marginBottom: theme.spacing(1),
}));

const PortMappingBox = styled(Box)(({ theme }) => ({
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  border: '1px solid rgba(255, 255, 255, 0.08)',
  borderRadius: 8,
  padding: theme.spacing(1.5),
  marginBottom: theme.spacing(1),
}));

const InfoIcon = styled(InfoOutlinedIcon)(({ theme }) => ({
  fontSize: '1.1rem',
  color: theme.palette.text.secondary,
}));

const AppDeployModal = ({ template, open, onClose, onSuccess }) => {
  const [deploymentName, setDeploymentName] = useState(
    `${template.name}-${Date.now().toString(36)}`
  );
  const [instances, setInstances] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [envVars, setEnvVars] = useState([]);
  const [portMappings, setPortMappings] = useState([]);
  
  // Model preference states
  const [preferredModelType, setPreferredModelType] = useState(template.preferred_model_type || 'any');
  const [failIfModelTypeUnavailable, setFailIfModelTypeUnavailable] = useState(template.fail_if_model_type_unavailable || false);
  const [preferredModelName, setPreferredModelName] = useState(template.preferred_model_name || '');
  const [failIfModelNameUnavailable, setFailIfModelNameUnavailable] = useState(template.fail_if_model_name_unavailable || false);

  useEffect(() => {
    // Initialize environment variables from template defaults
    const initialEnvVars = [];
    
    // Add template defaults first
    if (template.env_defaults) {
      const defaultVars = Object.entries(template.env_defaults).map(([key, value]) => ({
        key,
        value,
        isDefault: true,
        source: 'template'
      }));
      initialEnvVars.push(...defaultVars);
    }
    
    // Add system defaults that the backend will automatically set
    const systemDefaults = [
      { key: 'NODE_TLS_REJECT_UNAUTHORIZED', value: 'false', isDefault: true, source: 'system' },
      { key: 'OPENAI_BASE_URI', value: 'http://host.docker.internal:{lb_port}/v1', isDefault: true, source: 'system' },
      { key: 'OPENAI_BASE_URL', value: 'http://host.docker.internal:{lb_port}/v1', isDefault: true, source: 'system' }
    ];
    
    // Only add system defaults if they're not already in template defaults
    systemDefaults.forEach(sysDefault => {
      const existsInTemplate = initialEnvVars.some(envVar => envVar.key === sysDefault.key);
      if (!existsInTemplate) {
        initialEnvVars.push(sysDefault);
      }
    });
    
    setEnvVars(initialEnvVars);

    // Extract port mappings from compose file
    if (template.compose_yml) {
      try {
        const compose = yaml.load(template.compose_yml);
        const extractedPorts = [];
        
        if (compose.services) {
          Object.values(compose.services).forEach(service => {
            if (service.ports) {
              service.ports.forEach((port, index) => {
                const portStr = String(port);
                let containerPort;
                
                // Handle different port formats: "8080", "8080:8080", "0.0.0.0:8080:8080"
                if (portStr.includes(':')) {
                  const parts = portStr.split(':');
                  containerPort = parts[parts.length - 1];
                } else {
                  containerPort = portStr;
                }
                
                extractedPorts.push({
                  container_port: parseInt(containerPort),
                  port_name: index === 0 ? 'primary' : `port-${index + 1}`,
                  is_primary: index === 0
                });
              });
            }
          });
        }
        
        setPortMappings(extractedPorts.slice(0, 3)); // Limit to 3 ports
      } catch (err) {
        console.error('Error parsing compose file:', err);
      }
    }
  }, [template]);

  const handleAddEnvVar = () => {
    setEnvVars([...envVars, { key: '', value: '', isDefault: false, source: 'user' }]);
  };

  const handleRemoveEnvVar = (index) => {
    setEnvVars(envVars.filter((_, i) => i !== index));
  };

  const handleEnvVarChange = (index, field, value) => {
    const updated = [...envVars];
    updated[index] = { 
      ...updated[index], 
      [field]: value, 
      isDefault: false,  // Mark as modified when user changes it
      source: updated[index].source || 'user'  // Preserve source or mark as user
    };
    setEnvVars(updated);
  };

  const handleDeploy = async () => {
    setLoading(true);
    setError(null);

    try {
      // Convert env vars array to object
      const envVarsObject = {};
      envVars.forEach(({ key, value }) => {
        if (key && key.trim()) {
          envVarsObject[key] = value;
        }
      });

      // Prepare port mappings for deployment
      const deploymentPortMappings = portMappings.map(pm => ({
        container_port: pm.container_port,
        port_name: pm.port_name,
        is_primary: pm.is_primary
      }));

      const deploymentData = {
        name: deploymentName,
        template_id: template.id,
        starting_copies: instances,
        min_copies: 1,
        max_copies: instances,
        env_vars: Object.keys(envVarsObject).length > 0 ? envVarsObject : null,
        port_mappings: deploymentPortMappings.length > 0 ? deploymentPortMappings : null,
        // Add model preferences
        preferred_model_type: preferredModelType,
        fail_if_model_type_unavailable: failIfModelTypeUnavailable,
        preferred_model_name: preferredModelName || null,
        fail_if_model_name_unavailable: failIfModelNameUnavailable
      };

      const response = await axios.post(`${BASE_URL}/apps/deploy_app`, deploymentData);
      
      if (response.status === 200) {
        onSuccess();
      }
    } catch (err) {
      console.error('Error deploying app:', err);
      setError(err.response?.data?.detail || 'Failed to deploy application');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      setError(null);
      onClose();
    }
  };

  return (
    <StyledDialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <StyledDialogTitle>
        <TitleText>Deploy Application</TitleText>
        <IconButton onClick={handleClose} disabled={loading}>
          <CloseIcon />
        </IconButton>
      </StyledDialogTitle>

      <Divider />

      <StyledDialogContent>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <FormSection>
          <SectionTitle>Application Template</SectionTitle>
          <InfoBox>
            <InfoRow>
              <Typography variant="body2" color="text.secondary">Name:</Typography>
              <Typography variant="body2" fontWeight={500}>
                {template.name.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </Typography>
            </InfoRow>
            <InfoRow>
              <Typography variant="body2" color="text.secondary">Version:</Typography>
              <Typography variant="body2" fontWeight={500}>
                {template.version || '1.0.0'}
              </Typography>
            </InfoRow>
            <InfoRow>
              <Typography variant="body2" color="text.secondary">Source:</Typography>
              <Typography variant="body2" fontWeight={500}>
                {template.source_type === 'kamiwaza' ? 'Official' : 'Community'}
              </Typography>
            </InfoRow>
          </InfoBox>
        </FormSection>

        <FormSection>
          <SectionTitle>Deployment Configuration</SectionTitle>
          
          <StyledTextField
            fullWidth
            label="Deployment Name"
            value={deploymentName}
            onChange={(e) => setDeploymentName(e.target.value)}
            margin="normal"
            required
            disabled={loading}
            helperText="A unique name for this deployment"
          />

          <StyledTextField
            fullWidth
            label="Number of Instances"
            type="number"
            value={instances}
            onChange={(e) => setInstances(Math.max(1, parseInt(e.target.value) || 1))}
            margin="normal"
            required
            disabled={loading}
            inputProps={{ min: 1, max: 10 }}
            helperText="Number of container instances to run"
          />
        </FormSection>

        {portMappings.length > 0 && (
          <FormSection>
            <SectionTitle>
              Port Mappings
              <Tooltip title="Container ports that will be exposed. External ports are automatically assigned.">
                <InfoIcon />
              </Tooltip>
            </SectionTitle>
            {portMappings.map((pm, index) => (
              <PortMappingBox key={index}>
                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Container Port
                    </Typography>
                    <Typography variant="body1" fontWeight={500}>
                      {pm.container_port}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Port Name
                    </Typography>
                    <Typography variant="body1" fontWeight={500}>
                      {pm.port_name}
                      {pm.is_primary && (
                        <Chip 
                          label="Primary" 
                          size="small" 
                          color="primary" 
                          sx={{ ml: 1 }}
                        />
                      )}
                    </Typography>
                  </Grid>
                </Grid>
              </PortMappingBox>
            ))}
            <Alert severity="info" sx={{ mt: 1 }}>
              External ports will be automatically assigned from the available range.
            </Alert>
          </FormSection>
        )}

        <FormSection>
          <SectionTitle>
            <SmartToyIcon sx={{ fontSize: '1.2rem' }} />
            Model Preferences
            <Tooltip title="Configure which AI model type this application should use">
              <InfoIcon />
            </Tooltip>
          </SectionTitle>
          
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel>Preferred Model Type</InputLabel>
                <Select
                  value={preferredModelType}
                  onChange={(e) => setPreferredModelType(e.target.value)}
                  disabled={loading}
                  label="Preferred Model Type"
                >
                  <MenuItem value="any">Any Available Model</MenuItem>
                  <MenuItem value="large">Large (High Quality)</MenuItem>
                  <MenuItem value="fast">Fast (Low Latency)</MenuItem>
                  <MenuItem value="reasoning">Reasoning (CoT/Thinking)</MenuItem>
                  <MenuItem value="vl">Vision/Multimodal</MenuItem>
                </Select>
                <FormHelperText>
                  Select the type of model best suited for this application
                </FormHelperText>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Box sx={{ mt: 3 }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={failIfModelTypeUnavailable}
                      onChange={(e) => setFailIfModelTypeUnavailable(e.target.checked)}
                      disabled={loading || preferredModelType === 'any'}
                    />
                  }
                  label="Fail if preferred type unavailable"
                />
              </Box>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <StyledTextField
                fullWidth
                label="Preferred Model Name"
                value={preferredModelName}
                onChange={(e) => setPreferredModelName(e.target.value)}
                margin="normal"
                disabled={loading}
                placeholder="e.g., qwen, 72b, llama"
                helperText="Optional: Substring to match in model name"
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Box sx={{ mt: 3 }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={failIfModelNameUnavailable}
                      onChange={(e) => setFailIfModelNameUnavailable(e.target.checked)}
                      disabled={loading || !preferredModelName}
                    />
                  }
                  label="Fail if model name not found"
                />
              </Box>
            </Grid>
          </Grid>
          
          {(preferredModelType !== 'any' || preferredModelName) && (
            <Alert severity="info" sx={{ mt: 2 }}>
              {preferredModelType !== 'any' && (
                <Typography variant="body2">
                  Will look for a <strong>{preferredModelType}</strong> model
                  {!failIfModelTypeUnavailable && ' (with fallback to other types if unavailable)'}.
                </Typography>
              )}
              {preferredModelName && (
                <Typography variant="body2">
                  Will look for models containing "<strong>{preferredModelName}</strong>"
                  {!failIfModelNameUnavailable && ' (will use any model if not found)'}.
                </Typography>
              )}
            </Alert>
          )}
        </FormSection>

        <FormSection>
          <SectionTitle>
            Environment Variables
            <Tooltip title="Configure environment variables for your application">
              <InfoIcon />
            </Tooltip>
          </SectionTitle>
          
          {envVars.map((envVar, index) => (
            <EnvVarRow key={index}>
              <StyledTextField
                label="Key"
                value={envVar.key}
                onChange={(e) => handleEnvVarChange(index, 'key', e.target.value)}
                disabled={loading || (envVar.isDefault && envVar.source === 'system')}
                size="small"
                sx={{ flex: 1 }}
                InputProps={{
                  endAdornment: envVar.isDefault && (
                    <Chip 
                      label={envVar.source === 'system' ? 'System' : 'Template'} 
                      size="small" 
                      variant="outlined"
                      color={envVar.source === 'system' ? 'secondary' : 'primary'}
                    />
                  )
                }}
              />
              <StyledTextField
                label="Value"
                value={envVar.value}
                onChange={(e) => handleEnvVarChange(index, 'value', e.target.value)}
                disabled={loading}
                size="small"
                sx={{ flex: 1.5 }}
                helperText={envVar.source === 'system' && envVar.value.includes('host.docker.internal') ? 
                  'This value will be automatically set from deployed kamiwaza models' : ''}
              />
              <IconButton
                onClick={() => handleRemoveEnvVar(index)}
                disabled={loading || (envVar.isDefault && envVar.source === 'system')}
                size="small"
                color="error"
                title={envVar.isDefault && envVar.source === 'system' ? 
                  'System environment variables cannot be removed' : 'Remove environment variable'}
              >
                <DeleteIcon />
              </IconButton>
            </EnvVarRow>
          ))}
          
          <Button
            startIcon={<AddIcon />}
            onClick={handleAddEnvVar}
            disabled={loading}
            size="small"
            sx={{ mt: 1 }}
          >
            Add Environment Variable
          </Button>
        </FormSection>
      </StyledDialogContent>

      <DialogActions sx={{ p: 2, pt: 0 }}>
        <Button onClick={handleClose} disabled={loading}>
          Cancel
        </Button>
        <DeployButton
          onClick={handleDeploy}
          disabled={loading || !deploymentName.trim()}
          startIcon={loading ? <CircularProgress size={20} /> : <RocketLaunchIcon />}
        >
          {loading ? 'Deploying...' : 'Deploy'}
        </DeployButton>
      </DialogActions>
    </StyledDialog>
  );
};

export default AppDeployModal; 