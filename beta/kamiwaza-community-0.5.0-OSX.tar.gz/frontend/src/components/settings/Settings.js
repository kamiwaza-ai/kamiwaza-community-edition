import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import { 
  Typography, 
  Box, 
  Paper,
  Tabs,
  Tab,
  Switch,
  FormControlLabel,
  Stack,
  Divider
} from '@mui/material';
import TourSettings from './TourSettings';

const ContentContainer = styled(Box)(({ theme }) => ({
  maxWidth: '100%',
  margin: '0 auto',
  padding: theme.spacing(3, 2),
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  color: theme.palette.primary.main,
  fontSize: '1.8rem',
  fontWeight: 700,
  marginBottom: theme.spacing(3),
  paddingBottom: theme.spacing(1.5),
  position: 'relative',
  '&:after': {
    content: '""',
    position: 'absolute',
    left: 0,
    bottom: 0,
    width: '80px',
    height: '3px',
    background: 'linear-gradient(90deg, #00c07f, transparent)'
  }
}));

const TabPanel = styled(Box)(({ theme }) => ({
  padding: theme.spacing(3, 0),
}));

function TabPanelContent(props) {
  const { children, value, index, ...other } = props;
  return (
    <TabPanel
      role="tabpanel"
      hidden={value !== index}
      id={`settings-tabpanel-${index}`}
      aria-labelledby={`settings-tab-${index}`}
      {...other}
    >
      {value === index && children}
    </TabPanel>
  );
}

const Settings = () => {
  const [tabValue, setTabValue] = useState(0);
  const [advancedMode, setAdvancedMode] = useState(
    localStorage.getItem('advancedDeveloperMode') === 'true'
  );

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleAdvancedModeToggle = (event) => {
    const newValue = event.target.checked;
    setAdvancedMode(newValue);
    localStorage.setItem('advancedDeveloperMode', newValue.toString());
    // Reload to apply changes
    window.location.reload();
  };

  return (
    <ContentContainer>
      <SectionTitle variant="h4">Settings</SectionTitle>
      
      <Paper sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="settings tabs"
            textColor="primary"
            indicatorColor="primary"
          >
            <Tab label="General" />
            <Tab label="Interface" />
            <Tab label="Tours & Help" />
          </Tabs>
        </Box>

        <TabPanelContent value={tabValue} index={0}>
          <Typography variant="h6" gutterBottom>
            General Settings
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Core application settings and preferences.
          </Typography>
          <Box sx={{ mt: 3 }}>
            <Typography variant="body1" color="text.secondary">
              No general settings available yet.
            </Typography>
          </Box>
        </TabPanelContent>

        <TabPanelContent value={tabValue} index={1}>
          <Typography variant="h6" gutterBottom>
            Interface Settings
          </Typography>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Customize how Kamiwaza looks and behaves.
          </Typography>
          
          <Stack spacing={3} sx={{ mt: 3 }}>
            <Box>
              <FormControlLabel
                control={
                  <Switch 
                    checked={advancedMode} 
                    onChange={handleAdvancedModeToggle}
                    color="primary"
                  />
                }
                label="Advanced Developer Mode"
              />
              <Typography variant="caption" display="block" color="text.secondary" sx={{ mt: 1, ml: 4.5 }}>
                Enable advanced features like model hub search, detailed configurations, and manual deployment options.
                When disabled, provides a simplified interface ideal for new users.
              </Typography>
            </Box>
            
            <Divider />
            
            <Box>
              <Typography variant="subtitle2" gutterBottom>
                Theme Settings
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Theme customization coming soon.
              </Typography>
            </Box>
          </Stack>
        </TabPanelContent>

        <TabPanelContent value={tabValue} index={2}>
          <Typography variant="h6" gutterBottom>
            Tours & Help
          </Typography>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Manage guided tours and help resources.
          </Typography>
          
          <Box sx={{ mt: 3 }}>
            <TourSettings />
          </Box>
        </TabPanelContent>
      </Paper>
    </ContentContainer>
  );
};

export default Settings;