import React from 'react';
import { renderWithProviders, userEvent, testData } from '../../../test-utils';
import Login from '../Login';

// Mock useNavigate
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));

describe('Login', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Rendering', () => {
    test('renders login form when user is not authenticated', () => {
      const { getByRole, container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      // Look for input fields more directly
      const usernameInput = container.querySelector('input[name="username"]');
      const passwordInput = container.querySelector('input[name="password"]');
      
      expect(usernameInput).toBeInTheDocument();
      expect(passwordInput).toBeInTheDocument();
      expect(getByRole('button', { name: 'Login' })).toBeInTheDocument();
    });

    test('displays Kamiwaza branding', () => {
      const { getByAltText } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      // The logo now includes the text, so we only need to check for the logo image
      expect(getByAltText('Kamiwaza Logo')).toBeInTheDocument();
      
      // NOTE: If the logo is changed back to icon-only, restore these individual letter tests:
      // expect(getByText('K')).toBeInTheDocument();
      // expect(getByText('A')).toBeInTheDocument();
      // expect(getByText('M')).toBeInTheDocument();
      // expect(getByText('I')).toBeInTheDocument();
      // expect(getByText('WAZA')).toBeInTheDocument();
    });

    test('displays "Sign In" heading', () => {
      const { getByText } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      expect(getByText('Sign In')).toBeInTheDocument();
    });

    test('does not render when user is already authenticated', () => {
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: testData.user,
          loading: false
        }
      });

      // Should return null when user is authenticated
      expect(container.firstChild).toBeNull();
    });
  });

  describe('Auto-redirect for authenticated users', () => {
    test('redirects to home when user is already logged in', () => {
      renderWithProviders(<Login />, {
        authValue: {
          user: testData.user,
          loading: false
        }
      });

      expect(mockNavigate).toHaveBeenCalledWith('/');
    });
  });

  describe('Form Input Handling', () => {
    test('updates username field when user types', async () => {
      const user = userEvent.setup();
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      const usernameInput = container.querySelector('input[name="username"]');
      await user.type(usernameInput, 'testuser');

      expect(usernameInput).toHaveValue('testuser');
    });

    test('updates password field when user types', async () => {
      const user = userEvent.setup();
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      const passwordInput = container.querySelector('input[name="password"]');
      await user.type(passwordInput, 'testpassword');

      expect(passwordInput).toHaveValue('testpassword');
    });

    test('username field receives focus on component mount', () => {
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      const usernameInput = container.querySelector('input[name="username"]');
      
      // Test the actual behavior - that the username field receives focus
      // This is more reliable than checking HTML attributes with MUI
      expect(document.activeElement).toBe(usernameInput);
    });

    test('form fields are required', () => {
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      expect(container.querySelector('input[name="username"]')).toBeRequired();
      expect(container.querySelector('input[name="password"]')).toBeRequired();
    });
  });

  describe('Password Visibility Toggle', () => {
    test('password field starts hidden', () => {
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      const passwordInput = container.querySelector('input[name="password"]');
      expect(passwordInput).toHaveAttribute('type', 'password');
    });

    test('toggles password visibility when eye icon is clicked', async () => {
      const user = userEvent.setup();
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      const passwordInput = container.querySelector('input[name="password"]');
      
      // Find the visibility toggle button (it should be an IconButton)
      const toggleButton = container.querySelector('button[type="button"]');
      expect(toggleButton).toBeInTheDocument();

      // Initially password type
      expect(passwordInput).toHaveAttribute('type', 'password');

      // Click to show password
      await user.click(toggleButton);
      expect(passwordInput).toHaveAttribute('type', 'text');

      // Click again to hide password
      await user.click(toggleButton);
      expect(passwordInput).toHaveAttribute('type', 'password');
    });
  });

  describe('Form Submission', () => {
    test('calls login function with correct credentials on form submit', async () => {
      const mockLogin = jest.fn().mockResolvedValue({});
      const user = userEvent.setup();

      const { container, getByRole } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      // Fill out form
      await user.type(container.querySelector('input[name="username"]'), 'testuser');
      await user.type(container.querySelector('input[name="password"]'), 'testpass');

      // Submit form
      await user.click(getByRole('button', { name: 'Login' }));

      expect(mockLogin).toHaveBeenCalledTimes(1);
      
      // Check that URLSearchParams was created with correct data
      const callArgs = mockLogin.mock.calls[0][0];
      expect(callArgs.get('username')).toBe('testuser');
      expect(callArgs.get('password')).toBe('testpass');
    });

    test('navigates to home page after successful login', async () => {
      const mockLogin = jest.fn().mockResolvedValue({});
      const user = userEvent.setup();

      const { container, getByRole } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      await user.type(container.querySelector('input[name="username"]'), 'testuser');
      await user.type(container.querySelector('input[name="password"]'), 'testpass');
      await user.click(getByRole('button', { name: 'Login' }));

      // Wait for async operations
      await new Promise(resolve => setTimeout(resolve, 0));

      expect(mockNavigate).toHaveBeenCalledWith('/');
    });

    test('prevents form submission with empty fields', async () => {
      const mockLogin = jest.fn();
      const user = userEvent.setup();

      const { getByRole } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      // Try to submit without filling fields
      await user.click(getByRole('button', { name: 'Login' }));

      // HTML5 validation should prevent submission
      expect(mockLogin).not.toHaveBeenCalled();
    });
  });

  describe('Error Handling', () => {
    test('displays error message for invalid credentials (401)', async () => {
      const mockLogin = jest.fn().mockRejectedValue({
        response: { status: 401 }
      });
      const user = userEvent.setup();

      const { container, getByRole, findByText } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      await user.type(container.querySelector('input[name="username"]'), 'wronguser');
      await user.type(container.querySelector('input[name="password"]'), 'wrongpass');
      await user.click(getByRole('button', { name: 'Login' }));

      expect(await findByText('Invalid username or password')).toBeInTheDocument();
    });

    test('displays service unavailable message for network errors', async () => {
      const mockLogin = jest.fn().mockRejectedValue({
        message: 'Network Error'
      });
      const user = userEvent.setup();

      const { container, getByRole, findByText } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      await user.type(container.querySelector('input[name="username"]'), 'testuser');
      await user.type(container.querySelector('input[name="password"]'), 'testpass');
      await user.click(getByRole('button', { name: 'Login' }));

      expect(await findByText('Service Unavailable. Please try again later.')).toBeInTheDocument();
    });

    test('displays generic error message for unexpected errors', async () => {
      const mockLogin = jest.fn().mockRejectedValue({
        message: 'Some unexpected error'
      });
      const user = userEvent.setup();

      const { container, getByRole, findByText } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      await user.type(container.querySelector('input[name="username"]'), 'testuser');
      await user.type(container.querySelector('input[name="password"]'), 'testpass');
      await user.click(getByRole('button', { name: 'Login' }));

      expect(await findByText('An unexpected error occurred. Please try again.')).toBeInTheDocument();
    });

    test('clears error message when form is resubmitted', async () => {
      const mockLogin = jest.fn()
        .mockRejectedValueOnce({ response: { status: 401 } })
        .mockResolvedValueOnce({});
      const user = userEvent.setup();

      const { container, getByRole, findByText, queryByText } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      // First submission with error
      await user.type(container.querySelector('input[name="username"]'), 'wronguser');
      await user.type(container.querySelector('input[name="password"]'), 'wrongpass');
      await user.click(getByRole('button', { name: 'Login' }));

      expect(await findByText('Invalid username or password')).toBeInTheDocument();

      // Clear fields and try again
      const usernameInput = container.querySelector('input[name="username"]');
      const passwordInput = container.querySelector('input[name="password"]');
      await user.clear(usernameInput);
      await user.clear(passwordInput);
      await user.type(usernameInput, 'correctuser');
      await user.type(passwordInput, 'correctpass');
      await user.click(getByRole('button', { name: 'Login' }));

      // Error should be cleared
      expect(queryByText('Invalid username or password')).not.toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    test('form fields have proper labels', () => {
      const { container } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      // Check that form inputs exist and have name attributes for accessibility
      expect(container.querySelector('input[name="username"]')).toBeInTheDocument();
      expect(container.querySelector('input[name="password"]')).toBeInTheDocument();
      
      // Check that labels exist in the document
      expect(container.querySelector('label[for]')).toBeInTheDocument();
    });

    test('submit button is accessible', () => {
      const { getByRole } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          loading: false
        }
      });

      const submitButton = getByRole('button', { name: 'Login' });
      expect(submitButton).toBeInTheDocument();
      expect(submitButton).toHaveAttribute('type', 'submit');
    });

    test('error messages have proper alert role', async () => {
      const mockLogin = jest.fn().mockRejectedValue({
        response: { status: 401 }
      });
      const user = userEvent.setup();

      const { container, getByRole, findByRole } = renderWithProviders(<Login />, {
        authValue: {
          user: null,
          login: mockLogin,
          loading: false
        }
      });

      await user.type(container.querySelector('input[name="username"]'), 'wronguser');
      await user.type(container.querySelector('input[name="password"]'), 'wrongpass');
      await user.click(getByRole('button', { name: 'Login' }));

      const errorAlert = await findByRole('alert');
      expect(errorAlert).toBeInTheDocument();
      expect(errorAlert).toHaveTextContent('Invalid username or password');
    });
  });
});