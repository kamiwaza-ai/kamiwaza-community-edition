import React, { useState, useEffect } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Box from '@mui/material/Box';
import useMediaQuery from '@mui/material/useMediaQuery';
import Header from './components/common/Header';
import Sidebar from './components/common/Sidebar';
import ModelIndex from './components/models/ModelIndex';
import ModelDetail from './components/models/ModelDetail';
import { ModelFilesProvider } from './components/models/ModelFilesContext';
import ModelHubSearch from './components/models/ModelHubSearch';
import CatalogList from './components/dataset/DatasetList';
import ActivityFeed from './components/activity/ActivityFeed';
import DatasetDetails from './components/dataset/DatasetDetails';
import ClusterList from './components/cluster/ClusterList';
import ClusterHome from './components/cluster/ClusterHome';
import ClusterDetails from './components/cluster/ClusterDetails';
import LocationDetails from './components/cluster/LocationDetails';
import NodeDetails from './components/cluster/NodeDetails';
import HardwareDetails from './components/cluster/HardwareDetails';
import UserDetails from './components/cluster/UserDetails';
import UserList from './components/cluster/UserList';
import LocationList from './components/cluster/LocationList';
import NodeList from './components/cluster/NodeList';
import HardwareList from './components/cluster/HardwareList';
import RunningNodeDetail from './components/cluster/RunningNodeDetail';
import RunningNodeList from './components/cluster/RunningNodeList';
import Homepage from './components/home/Homepage';
import VectorDBHome from './components/vectordbs/VectorDbHome';
import VectorDBList from './components/vectordbs/VectorDBList';
import VectorDBDetails from './components/vectordbs/VectorDBDetails';
import AdminPanel from './components/admin/AdminPanel';
import AppGarden from './components/apps/AppGarden';
import ToolShed from './components/tool/ToolShed';
import UnifiedTemplateManager from './components/garden/UnifiedTemplateManager';
import News from './components/news/News';
import Settings from './components/settings/Settings';
import theme from './Theme';
import ModelConfigDetail from './components/models/ModelConfigDetail';
import DownloadStatusModal from './components/models/DownloadStatus';
import Cookies from 'js-cookie';
import { BASE_URL } from './const';
import { AuthProvider } from './context/AuthContext'; // Import AuthProvider
import { ServerInfoProvider } from './context/ServerInfoContext'; // <-- Add this import
import { TourProvider } from './contexts/TourContext'; // Import TourProvider
import { ClusterProvider } from './contexts/ClusterContext'; // Import ClusterProvider
import Login from './components/auth/Login'; // Import Login component
import ProtectedRoute from './components/auth/ProtectedRoute'; // Import ProtectedRoute component

// AppContent component to use location hooks
function AppContent() {
  const [hostResolvable, setHostResolvable] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [advancedMode, setAdvancedMode] = useState(false);
  const isSmallScreen = useMediaQuery(theme.breakpoints.down('md'));
  const location = useLocation();

  useEffect(() => {
    // Check if advanced mode is enabled
    const savedMode = localStorage.getItem('advancedDeveloperMode');
    const isAdvanced = savedMode === 'true';
    setAdvancedMode(isAdvanced);

    // In novice mode, start with sidebar closed
    if (!isAdvanced) {
      setSidebarOpen(false);
    } else {
      // In advanced mode, follow normal responsive behavior
      if (isSmallScreen) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    }
  }, [isSmallScreen]);

  useEffect(() => {
    const testHostResolvable = async () => {
      try {
        const hostnameResponse = await fetch(`${BASE_URL}/cluster/get_hostname`);
        const { hostname } = await hostnameResponse.json();

        const img = new Image();
        img.src = `http://${hostname}/favicon.ico`;

        img.onload = () => {
          setHostResolvable(true);
          Cookies.set('hostnamesResolve', 'true', { expires: 1 });
        };

        img.onerror = () => {
          setHostResolvable(false);
          Cookies.set('hostnamesResolve', 'false', { expires: 1 });
        };
      } catch (error) {
        setHostResolvable(false);
        Cookies.set('hostnamesResolve', 'false', { expires: 1 });
      }
    };

    testHostResolvable();
  }, []);

  const handleToggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // Check if current path is login page
  const isLoginPage = location.pathname === '/login';

  return (
    <ModelFilesProvider>
      <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
        {/* Sidebar navigation component - only show when not on login page */}
        {!isLoginPage && <Sidebar open={sidebarOpen} onToggle={handleToggleSidebar} />}

        {/* Main content area */}
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            transition: theme.transitions.create('margin', {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.leavingScreen,
            }),
            marginLeft: 0,
            width: '100%',
          }}
        >
          {/* Header at the top of the main content - conditionally rendered for login page */}
          {!isLoginPage && (
            <Header onToggleSidebar={handleToggleSidebar} sidebarOpen={sidebarOpen} />
          )}

          {/* Routes container with padding */}
          <Box sx={{ p: isLoginPage ? 0 : 3, mt: isLoginPage ? 0 : 8 }}>
            <Routes>
              {/* Login route (unprotected) */}
              <Route path="/login" element={<Login />} />

              {/* Protected routes */}
              <Route
                path="/"
                element={
                  <ProtectedRoute>
                    <Homepage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin"
                element={
                  <ProtectedRoute>
                    <AdminPanel />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/apps"
                element={
                  <ProtectedRoute>
                    <AppGarden />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/tool-shed"
                element={
                  <ProtectedRoute>
                    <ToolShed />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/templates"
                element={
                  <ProtectedRoute>
                    <UnifiedTemplateManager />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/models"
                element={
                  <ProtectedRoute>
                    <ModelIndex />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/models/:model_id"
                element={
                  <ProtectedRoute>
                    <ModelDetail />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/models/search"
                element={
                  <ProtectedRoute>
                    <ModelHubSearch />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/model_configs/:model_config_id"
                element={
                  <ProtectedRoute>
                    <ModelConfigDetail />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/catalog"
                element={
                  <ProtectedRoute>
                    <CatalogList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/catalog/dataset/*"
                element={
                  <ProtectedRoute>
                    <DatasetDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/activity"
                element={
                  <ProtectedRoute>
                    <ActivityFeed />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/locations/:location_id"
                element={
                  <ProtectedRoute>
                    <LocationDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/runningnodes/:node_id"
                element={
                  <ProtectedRoute>
                    <RunningNodeDetail />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/runningnodes/"
                element={
                  <ProtectedRoute>
                    <RunningNodeList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/home"
                element={
                  <ProtectedRoute>
                    <ClusterHome />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/:cluster_id"
                element={
                  <ProtectedRoute>
                    <ClusterDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/"
                element={
                  <ProtectedRoute>
                    <ClusterList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/node/:node_id"
                element={
                  <ProtectedRoute>
                    <NodeDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/hardware/:hardware_id"
                element={
                  <ProtectedRoute>
                    <HardwareDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/users/:user_id"
                element={
                  <ProtectedRoute>
                    <UserDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/users"
                element={
                  <ProtectedRoute>
                    <UserList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/locations"
                element={
                  <ProtectedRoute>
                    <LocationList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/nodes"
                element={
                  <ProtectedRoute>
                    <NodeList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/cluster/hardware"
                element={
                  <ProtectedRoute>
                    <HardwareList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/vectordbs/home"
                element={
                  <ProtectedRoute>
                    <VectorDBHome />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/vectordbs"
                element={
                  <ProtectedRoute>
                    <VectorDBList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/vectordbs/:vectordb_id"
                element={
                  <ProtectedRoute>
                    <VectorDBDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/news"
                element={
                  <ProtectedRoute>
                    <News />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/settings"
                element={
                  <ProtectedRoute>
                    <Settings />
                  </ProtectedRoute>
                }
              />
            </Routes>
          </Box>
        </Box>

        {/* Download Status Modal - shown on all pages when downloads are active */}
        {!isLoginPage && <DownloadStatusModal />}
      </Box>
    </ModelFilesProvider>
  );
}

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <ServerInfoProvider>
          <ClusterProvider>
            <TourProvider>
              <Router>
                <AppContent />
              </Router>
            </TourProvider>
          </ClusterProvider>
        </ServerInfoProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
