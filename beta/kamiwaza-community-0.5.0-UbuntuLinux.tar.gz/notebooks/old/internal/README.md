# internal

Just a quick note that the notebooks in here are Kamiwaza tinkering and while you're welcome to look around,
don't expect them to make sense or run - they probably have fairly odd pre-requisites like datasets
or preprocessing you won't have