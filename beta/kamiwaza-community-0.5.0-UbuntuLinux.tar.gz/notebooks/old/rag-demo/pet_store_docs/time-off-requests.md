**FurryFriends Pet Supplies: Time-Off Request Policy**

---

At FurryFriends Pet Supplies, we understand the importance of work-life balance and strive to support our employees in managing their personal and professional responsibilities. This Time-Off Request Policy outlines the procedures and guidelines for requesting time off, ensuring that both employee needs and business operations are effectively balanced.

---

### **1. Requesting Time Off in Advance**

**Advance Notice:**
- **Standard Requests:** Employees are encouraged to submit time-off requests at least **two weeks** in advance to allow adequate time for scheduling and coverage.
- **Long-Term Planning:** For extended vacations or significant personal events, providing as much notice as possible is appreciated to facilitate planning.

**Submission Process:**
- **Online Portal:** Submit your time-off request through the FurryFriends Employee Portal under the "Time Off" section.
- **Written Request:** Alternatively, you may submit a written request to your immediate supervisor detailing the dates and reason for the time off.
  
**Approval Process:**
- **Manager Review:** Supervisors will review time-off requests based on staffing needs, seniority, and the order of submission.
- **Confirmation:** Employees will receive confirmation of their approved or denied requests within **three business days** of submission.
- **Scheduling Conflicts:** If multiple requests conflict, priority will be given based on the order of submission and operational requirements.

---

### **2. Policies Around Peak Holiday Seasons**

**High-Demand Periods:**
- **Peak Seasons:** Times such as **Thanksgiving, Christmas, New Year’s,** and other major holidays are considered peak seasons requiring maximum staffing.
- **Limited Availability:** During these periods, time-off requests may be limited to ensure adequate store coverage and maintain excellent customer service.

**Submission Guidelines:**
- **Early Planning:** Employees wishing to take time off during peak seasons should submit their requests **at least three months** in advance.
- **First-Come, First-Served:** Time-off during peak seasons will be granted based on the order of request submission and the necessity of maintaining store operations.

**Alternative Solutions:**
- **Flexible Scheduling:** Managers may offer alternative dates or flexible scheduling options to accommodate as many time-off requests as possible.
- **Rotation System:** Implementing a rotation system to fairly distribute available time off among employees during high-demand periods.

---

### **3. Sick Leave Procedures**

**Reporting Illness:**
- **Immediate Notification:** Employees should notify their supervisor **as soon as possible** if they are unable to work due to illness or medical reasons.
- **Preferred Method:** Notification can be made via phone call or through the designated communication channel outlined in the employee handbook.

**Documentation:**
- **Short-Term Illness:** For absences of **three consecutive days or fewer**, no medical documentation is required unless requested by management.
- **Extended Illness:** For absences exceeding three consecutive days, a **doctor’s note** may be required to verify the illness and qualify for sick leave benefits.

**Paid Sick Leave:**
- **Accrual:** Employees accrue sick leave based on their length of service, in accordance with local labor laws and company policies.
- **Usage:** Sick leave can be used for personal illness, medical appointments, or to care for an immediate family member who is ill.

**Return to Work:**
- **Health Clearance:** Employees returning from extended sick leave may need to provide a health clearance from a healthcare professional, depending on the nature of the illness and company policy.

---

### **4. Limitations on Consecutive Days Off**

**Maximum Consecutive Days:**
- **Regular Time Off:** Employees may request up to **five consecutive days** of time off for personal reasons or vacation.
- **Exceptions:** Requests for more than five consecutive days will be considered on a case-by-case basis and require additional justification and managerial approval.

**Approval Criteria:**
- **Operational Needs:** Approval is subject to the store’s staffing requirements and the ability to maintain adequate coverage.
- **Employee Tenure:** Employees with longer tenure or critical roles may have priority in obtaining consecutive days off.

**Mandatory Rest Periods:**
- **Minimum Days:** Employees are encouraged to take regular breaks and are limited to a maximum of **two weeks** of consecutive time off within a calendar year to ensure ongoing engagement and performance.

---

### **5. Additional Guidelines**

**Unplanned Absences:**
- **Emergencies:** In cases of emergency where prior notice is not possible, employees should inform their supervisor as soon as they are able.
- **Documentation:** Unplanned absences may require documentation depending on the length and reason for the absence.

**Time-Off Balances:**
- **Tracking:** Employees can view their available time-off balances through the Employee Portal.
- **Carryover Policy:** Unused time off may carry over to the next year up to a specified limit, as outlined in the employee handbook.

**Vacation Blackout Periods:**
- **Critical Times:** Certain periods may be designated as blackout times where time off is restricted due to high operational demand. These will be communicated in advance to allow for planning.

---

### **6. Questions and Support**

If you have any questions regarding the Time-Off Request Policy or need assistance with submitting a request, please contact your supervisor or the Human Resources department.

---

**FurryFriends Pet Supplies** is committed to supporting our employees’ needs while maintaining excellent service for our customers. By following these guidelines, we ensure a fair and organized approach to time off that benefits both our team and our community.

---

*Thank you for your dedication and hard work as a valued member of the FurryFriends family!*