**FurryFriends Pet Supplies: Employee Discount Policy**

---

At FurryFriends Pet Supplies, we value our employees and recognize their hard work and dedication. To show our appreciation, we offer a comprehensive employee discount program designed to support you in caring for your own pets and enhancing your shopping experience with us.

### **1. Eligibility**

- **Full-Time and Part-Time Employees:** All active employees, regardless of their employment status (full-time or part-time), are eligible for the employee discount.
- **Duration of Eligibility:** Eligibility begins on the first day of employment and continues as long as the employee remains in good standing with FurryFriends.
- **Exclusions:** Contractors, interns, and temporary staff are not eligible for the employee discount unless specified in their employment agreement.

### **2. Discount Details**

- **Standard Discount:** Employees receive a **20% discount** on all regular-priced merchandise.
- **Tiered Discounts for Tenure:**
  - **0-1 Year of Service:** 20% discount
  - **1-3 Years of Service:** 25% discount
  - **3+ Years of Service:** 30% discount
- **Special Promotions:** Employees are eligible to participate in store-wide sales and promotions, receiving the same discounts as customers in addition to their employee discount, unless otherwise stated.

### **3. Restrictions**

- **Excluded Items:** The employee discount **does not apply** to the following:
  - **Sale and Clearance Items:** Items marked as "Sale," "Clearance," or any other promotional markdowns are excluded from the discount.
  - **Gift Cards:** Purchase of gift cards is not eligible for the employee discount.
  - **Services:** Discounts are only applicable to merchandise purchases, not to services such as grooming or training.
- **Purchase Limits:** Employees may purchase up to **$500** worth of discounted merchandise per calendar month to prevent abuse of the discount program.
- **No Cash Value:** The discount cannot be redeemed for cash, nor can it be applied to previous purchases.

### **4. Purchase Procedures**

- **Using the Discount In-Store:**
  - **Employee ID:** Employees must present their valid employee ID at the time of purchase to apply the discount.
  - **Point of Sale (POS) System:** The discount will be automatically applied when the employee ID is scanned or entered into the POS system by the cashier.
- **Online Purchases:**
  - **Employee Login:** Employees must log in to their personal employee account on the FurryFriends website.
  - **Discount Code:** Use the unique employee discount code provided during onboarding at checkout.
  - **Verification:** Ensure that the discount is applied before finalizing the purchase. If issues arise, contact the store manager or HR department for assistance.
- **Special Orders:**
  - For special orders or bulk purchases, employees must obtain approval from their store manager to apply the discount.

### **5. Additional Guidelines**

- **Non-Transferable:** The employee discount is strictly for personal use and cannot be extended to family members, friends, or third parties.
- **Abuse of Discount:** Any misuse or abuse of the employee discount may result in disciplinary action, including revocation of discount privileges and potential termination of employment.
- **Changes to Policy:** FurryFriends reserves the right to modify or terminate the employee discount policy at any time. Employees will be notified of any changes through official communication channels.

### **6. Questions and Support**

If you have any questions regarding the employee discount policy or need assistance with applying your discount, please contact your store manager or the Human Resources department.

---

**FurryFriends Pet Supplies** is committed to rewarding our dedicated team members. We hope this discount program enhances your experience with us and supports you in providing the best care for your furry friends.

---

*Thank you for being a valued member of the FurryFriends family!*