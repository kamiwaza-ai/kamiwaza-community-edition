**FurryFriends Pet Supplies: Store Safety Protocols**

---

Ensuring the safety of our customers and employees is a top priority at FurryFriends Pet Supplies. To maintain a secure and welcoming environment, we have established comprehensive safety protocols that address general store safety, emergency procedures, and the specific responsibilities of our team members during various situations.

---

### **1. General Safety Protocols**

- **Maintain a Clean and Organized Store:**
  - Keep aisles and walkways clear of obstructions to prevent trips and falls.
  - Regularly organize shelves and displays to ensure products are safely stored and easily accessible.
  - Promptly clean up any spills, debris, or clutter.

- **Regular Safety Inspections:**
  - Conduct daily inspections to identify and rectify potential hazards such as loose wires, damaged shelves, or malfunctioning equipment.
  - Use a standardized checklist to ensure consistency in inspections.

- **Proper Signage and Lighting:**
  - Install clear signs for exits, fire extinguishers, first aid kits, and emergency equipment.
  - Ensure all areas are well-lit to enhance visibility and reduce the risk of accidents.

- **Employee Training:**
  - Provide comprehensive training for all employees on safety protocols, emergency procedures, and the proper use of safety equipment.
  - Conduct regular refresher courses and safety drills to reinforce training.

- **Security Measures:**
  - Implement security systems, including surveillance cameras and alarm systems, to protect against theft and ensure a safe shopping environment.
  - Train employees on how to respond to security threats or suspicious activities.

---

### **2. Emergency Procedures**

#### **a. Spills and Slips**

- **Immediate Action:**
  - Upon noticing a spill, the nearest employee should place a "Caution: Wet Floor" sign to alert customers and coworkers.
  - Use appropriate cleaning materials to promptly address and clean the spill.

- **Report and Document:**
  - Inform the store manager about the incident.
  - Complete an incident report detailing the cause, location, and actions taken.

- **Preventive Measures:**
  - Regularly check for leaks or sources of spills, especially in areas like pet food sections and water stations.
  - Ensure cleaning supplies are easily accessible to all employees.

#### **b. Fire Emergencies**

- **Evacuation Plan:**
  - Display the store’s evacuation map prominently at key locations.
  - Ensure all employees are familiar with primary and secondary exit routes.

- **Alarm Activation:**
  - If a fire is detected, immediately activate the nearest fire alarm pull station to alert everyone in the store.

- **Call Emergency Services:**
  - Dial 911 to report the fire, providing the exact location and any relevant details.

- **Safe Evacuation:**
  - Guide customers and employees to the nearest exit calmly and efficiently.
  - Avoid using elevators; use stairs instead.
  - Assemble at designated meeting points outside the building and conduct a headcount to ensure everyone is accounted for.

- **Use of Fire Extinguishers:**
  - Only trained employees should attempt to use fire extinguishers.
  - If the fire is small and manageable, use the appropriate type of extinguisher to put it out.

- **Post-Emergency Protocol:**
  - Do not re-enter the building until it has been declared safe by fire officials.
  - Assist emergency responders as needed and provide access to necessary areas.

#### **c. Medical Emergencies**

- **Assess the Situation:**
  - Quickly determine the nature and severity of the medical emergency (e.g., injury, allergic reaction, heart attack).

- **Call for Help:**
  - Dial 911 immediately, providing clear and concise information about the emergency and the location within the store.

- **Provide First Aid:**
  - Utilize the store’s first aid kit to administer basic care, such as applying bandages or assisting with CPR if trained.

- **Employee Roles:**
  - Assign one employee to assist the injured person.
  - Designate another employee to communicate with emergency responders.
  - Have a third employee manage customer flow to prevent congestion and maintain order.

- **Documentation:**
  - Record details of the incident, including the time, nature of the emergency, actions taken, and any witnesses.
  - Submit the incident report to management for review and follow-up.

---

### **3. Responsibilities of Employees**

- **Stay Calm and Composed:**
  - Maintain a level-headed demeanor to effectively manage emergencies and reassure customers and coworkers.

- **Follow Training and Protocols:**
  - Adhere strictly to the established safety protocols and emergency procedures.
  - Utilize training received to handle various situations appropriately.

- **Assist Customers:**
  - Help guide customers during evacuations or emergencies.
  - Provide support and reassurance to those in distress.

- **Proper Use of Safety Equipment:**
  - Know the locations and proper usage of fire extinguishers, first aid kits, and emergency alarms.
  - Ensure that safety equipment is readily accessible and in working condition.

- **Report Hazards and Incidents:**
  - Promptly report any safety hazards, accidents, or incidents to management.
  - Participate in incident reviews to help improve safety measures.

- **Participate in Safety Drills:**
  - Engage actively in regular safety drills to stay prepared for emergencies.
  - Provide feedback on drills to enhance the effectiveness of safety protocols.

- **Continuous Improvement:**
  - Stay informed about best practices in store safety and contribute ideas for enhancing the safety environment.
  - Encourage a culture of safety awareness among all team members.

---

**FurryFriends Pet Supplies** is committed to maintaining a safe and secure environment for everyone who walks through our doors. By adhering to these safety protocols and fostering a culture of preparedness and care, we ensure that our community remains a happy and healthy place for both pets and their owners.