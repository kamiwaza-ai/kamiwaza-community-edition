import sys
import asyncio
import time
import os
import argparse
import uvicorn
import inspect
from fastapi import FastAPI, APIRouter
from kamiwaza.services.models.api import model_router
from kamiwaza.serving.api import serving_router as serving_router, serving_exception_handlers, start_ray
from kamiwaza.serving.config import settings as serving_settings
from kamiwaza.cluster.config import settings as cluster_settings
from kamiwaza.services.vectordb.api import vectordb_router
from kamiwaza.services.catalog.api import catalog_router
from kamiwaza.services.prompts.api import promptd_api
from kamiwaza.services.embedding.api import embedding_router
from kamiwaza.services.activity.api import activity_router
from kamiwaza.services.auth.api import auth_router
from kamiwaza.cluster.api import cluster_router
from kamiwaza.services.retrieval.api import retrieval_router
from kamiwaza.services.news.api import news_router
from kamiwaza.serving.garden.apps.apps_api import app_router as app_serving_router, template_router as app_template_router
from kamiwaza.serving.garden.tool.tool_api import tool_router
from kamiwaza.serving.services import ServingService
from kamiwaza.cluster.services import ClusterService
from kamiwaza.serving.traefik import TraefikService
from kamiwaza.node.api import node_router
from kamiwaza.services.activity.middleware import activity_logger  # import the middleware
from kamiwaza.scheduler.launch import task_schedule
from kamiwaza.util.netutil import node_hostip
from kamiwaza.lib.util import get_kamiwaza_root, port_in_use, validate_license, is_community
from kamiwaza.cluster.util.bootstrap import bootstrap_config
from kamiwaza.services.auth.middleware import jwt_middleware
from kamiwaza.util.garden import initialize_garden_apps

import ray
from ray import serve
import logging
from fastapi.middleware.cors import CORSMiddleware
from logging.handlers import RotatingFileHandler

# Set up basic console logging first
console_handler = logging.StreamHandler(sys.stdout)
console_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(console_formatter)

logger = logging.getLogger(__name__)
root_logger = logging.getLogger()

if os.getenv("KAMIWAZA_DEBUG_MODE", "False") == "True":
    logger.setLevel(logging.DEBUG)
    root_logger.setLevel(logging.DEBUG)
    console_handler.setLevel(logging.DEBUG)
else:
    logger.setLevel(logging.INFO)
    root_logger.setLevel(logging.INFO)
    console_handler.setLevel(logging.INFO)

# Add console handler to root logger
root_logger.addHandler(console_handler)

def configure_ray_worker_logging():
    """Configure logging for Ray worker processes to write to log files and console."""
    try:
        # Check if logging is already configured to avoid duplicate handlers
        root_logger = logging.getLogger()
        if any(isinstance(handler, logging.FileHandler) and 'kamiwazad-core.log' in handler.baseFilename for handler in root_logger.handlers):
            logger.debug("Logging already configured, skipping")
            return
            
        # Use log directory from environment or fallback to /tmp
        log_dir = os.environ.get('KAMIWAZA_LOG_DIR')
        if not log_dir:
            log_dir = '/tmp'
            # Log warning after logger is configured below
        
        # Ensure log directory exists
        os.makedirs(log_dir, exist_ok=True)
        
        # Configure file handler for core logs (with rotation)
        core_log_file = os.path.join(log_dir, "kamiwazad-core.log")
        file_handler = RotatingFileHandler(core_log_file, maxBytes=50 * 1024 * 1024, backupCount=5)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        
        # Configure console handler for immediate output
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        
        # Configure VLLM-specific file handler (with rotation)
        vllm_log_file = os.path.join(log_dir, "kamiwazad-vllm.log")
        vllm_file_handler = RotatingFileHandler(vllm_log_file, maxBytes=50 * 1024 * 1024, backupCount=5)
        vllm_file_handler.setFormatter(formatter)
        vllm_file_handler.setLevel(logging.INFO)
        
        # Configure root logger with both file and console handlers
        root_logger = logging.getLogger()
        root_logger.addHandler(file_handler)
        root_logger.addHandler(console_handler)
        root_logger.setLevel(logging.INFO)
        
        # Configure specific module loggers
        module_loggers = [
            'kamiwaza.serving',
            'kamiwaza.services', 
            'kamiwaza.cluster',
            'kamiwaza.services.models',
            'kamiwaza.services.vectordb',
            'kamiwaza.services.catalog',
            'kamiwaza.services.prompts',
            'kamiwaza.services.embedding',
            'kamiwaza.services.activity',
            'kamiwaza.services.auth',
            'kamiwaza.services.retrieval',
            'kamiwaza.services.news',
            'kamiwaza.node',
            'kamiwaza.middleware',
            'kamiwaza.db',
            'kamiwaza.util',
            'kamiwaza.logger',
            'kamiwaza.scheduler',
            'vllm',
            'vllm.engine',
            'vllm.worker',
            'vllm.distributed',
            'ray',
            'ray.serve',
            'uvicorn',
            'fastapi',
            'httpx',
            'requests',
            'sqlalchemy',
            'pydantic'
        ]
        
        for logger_name in module_loggers:
            module_logger = logging.getLogger(logger_name)
            # Use VLLM-specific handler for VLLM modules
            if logger_name.startswith('vllm'):
                module_logger.addHandler(vllm_file_handler)
                module_logger.addHandler(console_handler)
            else:
                module_logger.addHandler(file_handler)
                module_logger.addHandler(console_handler)
            module_logger.setLevel(logging.INFO)
            # Prevent duplicate logs by not propagating to root if we're already handling it
            if logger_name != 'kamiwaza':
                module_logger.propagate = False
        
        # Set SQLAlchemy loggers to WARNING level to reduce noise (unless in debug mode)
        if os.getenv("KAMIWAZA_DEBUG_MODE", "False") != "True":
            for name in [
                'sqlalchemy',
                'sqlalchemy.engine',
                'sqlalchemy.orm',
                'sqlalchemy.pool',
            ]:
                logging.getLogger(name).setLevel(logging.WARNING)
        
        # Also configure the main logger
        main_logger = logging.getLogger(__name__)
        main_logger.addHandler(file_handler)
        main_logger.addHandler(console_handler)
        main_logger.setLevel(logging.INFO)
        
        logger.info("Ray worker logging configured successfully")
        logger.info(f"Log files configured: {core_log_file}, {vllm_log_file}")
        logger.info("Log rotation: maxBytes=52428800 (50MB), backupCount=5")
        logger.info(f"Log directory: {log_dir}")
        
        # Log if we're using fallback directory
        if not os.environ.get('KAMIWAZA_LOG_DIR') and not is_community():
            logger.warning(f"KAMIWAZA_LOG_DIR not set, using fallback directory: {log_dir}")
        else:
            logger.info(f"Using log directory from KAMIWAZA_LOG_DIR: {log_dir}")
    except Exception as e:
        # Fallback to console logging if file logging fails
        print(f"Failed to configure file logging in Ray worker: {e}")
        logging.basicConfig(level=logging.INFO)

# We technically should have KAMIWAZA_ROOT from launch.py but we will allow
# this to work the original way. Main wraps this now so that imported libs can
# save config files in the correct spot

@ray.remote
def test_env_vars():
    kamiwaza_root = os.getenv("KAMIWAZA_ROOT")
    kamiwaza_lib_root = os.getenv("KAMIWAZA_LIB_ROOT")
    
    if kamiwaza_root and kamiwaza_lib_root:
        return f"Environment variables are set:\nKAMIWAZA_ROOT: {kamiwaza_root}\nKAMIWAZA_LIB_ROOT: {kamiwaza_lib_root}"
    else:
        return "Environment variables are not set."

# Create PongRouter for liveness tests - only emerges when full service is up
pong_router = APIRouter()

@pong_router.get("/ping")
async def ping():
    """Simple ping endpoint for liveness testing."""
    return {"status": "pong", "timestamp": time.time()}

# flush first cache
config_cache_dir = os.path.join(os.getenv('KAMIWAZA_ROOT', '/tmp'), '.kamiwaza', 'config_cache')
if os.path.exists(config_cache_dir):
    for file_name in os.listdir(config_cache_dir):
        file_path = os.path.join(config_cache_dir, file_name)
        if os.path.isfile(file_path):
            os.unlink(file_path)

KAMIWAZA_ROOT = get_kamiwaza_root()
os.environ["KAMIWAZA_ROOT"] = KAMIWAZA_ROOT
config_cache_dir = os.path.join(os.getenv('KAMIWAZA_ROOT', '/tmp'), '.kamiwaza', 'config_cache')

if os.path.exists(os.path.join(os.environ["KAMIWAZA_ROOT"], "runtime", "runtime_config.json")):
    os.unlink(os.path.join(os.environ["KAMIWAZA_ROOT"], "runtime", "runtime_config.json"))

KAMIWAZA_SERVE_PORT = cluster_settings.ray_serve_port or 7777
os.environ["KAMIWAZA_SERVE_PORT"] = str(KAMIWAZA_SERVE_PORT)

if port_in_use(KAMIWAZA_SERVE_PORT):
    logger.error(f"Port {KAMIWAZA_SERVE_PORT} is already in use; if not our ray serve instance, startup will fail")

#flush real cache
if os.path.exists(config_cache_dir):
    for file_name in os.listdir(config_cache_dir):
        file_path = os.path.join(config_cache_dir, file_name)
        if os.path.isfile(file_path):
            os.unlink(file_path)

cluster_module_file = inspect.getfile(ClusterService)
cluster_dir = os.path.dirname(cluster_module_file)
KAMIWAZA_LIB_ROOT = os.path.abspath(os.path.join(cluster_dir, '..'))
logger.debug(f"lib root is {KAMIWAZA_LIB_ROOT}")
os.environ["KAMIWAZA_LIB_ROOT"] = KAMIWAZA_LIB_ROOT


# Enhanced command line argument parsing to include help message and Ray connection parameters
parser = argparse.ArgumentParser(description="Launch the Kamiwaza service in either cluster or standalone mode.",
                                 usage="Use '--standalone' to run without clustering. Specify '--ray-host' and '--ray-port' to connect to an existing Ray cluster. Without these flags, it runs in cluster mode by default. Ray should be run with 'ray start --head'")
parser.add_argument("--standalone", action="store_true", help="Run in standalone mode without clustering")
parser.add_argument("--ray-host", type=str, default=None, help="Specify the Ray head node host")
parser.add_argument("--ray-port", type=int, default=None, help="Specify the Ray head node port")
parser.add_argument("--no-url-prefix", action="store_true", help="Disable URL prefix for the FastAPI app")
args = parser.parse_args()

# Read environment variables from env.sh files if they exist
env_files_to_check = []

# Enterprise edition: /etc/kamiwaza/env.sh
if os.path.exists('/etc/kamiwaza/env.sh'):
    env_files_to_check.append('/etc/kamiwaza/env.sh')

# Community edition: kamiwaza_root/env.sh
try:
    community_env_path = os.path.join(KAMIWAZA_ROOT, 'env.sh')
    if os.path.exists(community_env_path):
        env_files_to_check.append(community_env_path)
except Exception:
    # If we can't find kamiwaza root, just continue
    pass

# Read from env files and set all environment variables if not already set
for env_file_path in env_files_to_check:
    try:
        # Read the entire env file without specifying required keys to get all variables
        with open(env_file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if 'export ' in line:
                    line = line.replace('export ', '')
                if '=' in line and not line.strip().startswith('#'):
                    key, value = line.strip().split('=', 1)
                    # Remove quotes if present
                    value = value.strip('"').strip("'")
                    # Set environment variable if not already set
                    if key not in os.environ:
                        os.environ[key] = value
                        logger.debug(f"Set environment variable {key} from {env_file_path}")
        break  # Use the first env file found
    except Exception as e:
        logger.debug(f"Could not read env file {env_file_path}: {e}")
        continue


# Set environment variables based on the parsed arguments
os.environ["KAMIWAZA_STANDALONE"] = str(args.standalone).lower()
os.environ["KAMIWAZA_RAY_HOST"] = args.ray_host if args.ray_host else ""
os.environ["KAMIWAZA_RAY_PORT"] = str(args.ray_port) if args.ray_port else ""
os.environ["KAMIWAZA_NO_URL_PREFIX"] = str(args.no_url_prefix).lower()

# Set cluster mode based on the presence of the --standalone flag
clusterMode = not args.standalone
os.environ["KAMIWAZA_CLUSTER_MODE"] = str(clusterMode).lower()

# Validate license early in startup process - non-gating
logger.info("Performing license validation...")
validate_license()

# Initialize FastAPI app with or without URL prefix based on the --no-url-prefix flag
if args.no_url_prefix:
    app = FastAPI()
else:
    app = FastAPI(root_path="/api")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# TODO: More restrictive CORS policy

# Apply exception handlers
for exc_class, handler in serving_exception_handlers.items():
    app.add_exception_handler(exc_class, handler)

# Attach all the Kamiwaza module API routers
app.include_router(pong_router, tags=["health"])
app.include_router(model_router, tags=["models"])
app.include_router(serving_router, prefix="/serving", tags=["serving"])
app.include_router(vectordb_router, prefix="/vectordb", tags=["vectordb"])
app.include_router(catalog_router, prefix="/catalog", tags=["catalog"])
app.include_router(promptd_api, prefix="/prompts", tags=["prompts"])
app.include_router(embedding_router, prefix="/embedding", tags=["embedding"])
app.include_router(cluster_router, prefix="/cluster", tags=["cluster"])
app.include_router(activity_router, prefix="/activity", tags=["activity"])
app.include_router(retrieval_router, prefix="/retrieval", tags=["retrieval"])
app.include_router(news_router, prefix="/news", tags=["news"])
app.include_router(app_serving_router, prefix="/apps", tags=["apps"])
app.include_router(app_template_router, prefix="/apps", tags=["app_templates"])
app.include_router(tool_router, tags=["Tool Shed"])

# NYI for 0.3.2
#app.include_router(lab_router, prefix="/lab", tags=["lab"])
app.include_router(auth_router, prefix="/auth", tags=["auth"])
app.middleware("http")(jwt_middleware)  # JWT middleware first
app.middleware("http")(activity_logger)  # Activity logger after


# Special on/off for inference via kamiwaza module
if serving_settings.enable_inference:
    logger.warning("Inference is set enabled, but the inference router is not enabled in this version")
    #app.include_router(inference_router, prefix="/inference", tags=["inference"])

# for consistency we don't do non-clusterMode any more, normalizing on always activating ray.
if clusterMode:
    # Every node runs its own node service, outside ray, on 7788; this is a somewhat placeholder-y
    # move for node-to-node comms, bypass-ray checks of various types, etc.
    nodeapp = FastAPI()
    nodeapp.include_router(node_router, prefix="/node", tags=["node"])
else:
    # In the legacy non-cluster mode, we simply included it in the single endpoint.
    app.include_router(node_router, prefix="/node", tags=["node"])

if clusterMode:
    # Ray launch; Kamiwaza "normal practice" is to launch with `start-ray.sh` and then this, which preserve environment variables well.
    # For endpoint/community there is a decent chance that we preload enough things that we don't implode without that, but best practice anyhow.
    if not ray.is_initialized():
        if not serving_settings.ray_init_address:
            logger.warning(f"WARNING: Kamiwaza is not in standalone mode, and serving.settings.ray_init_address is not set; will try to detect ray via /tmp/ray/ray_current_cluster and start as head if not detected")


        runtime_env = {
            "env_vars": {
                "KAMIWAZA_ROOT": KAMIWAZA_ROOT,
                "KAMIWAZA_LIB_ROOT": KAMIWAZA_LIB_ROOT,
                "PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION": "python"
            }
        }

        if 'PYTHONPATH' in os.environ:
            runtime_env['env_vars']['PYTHONPATH'] = os.environ['PYTHONPATH']

        # Prepare options dict to pass log_to_driver as per api.py
        options = {
            "log_to_driver": os.getenv("KAMIWAZA_DEBUG_RAY", "false") == "true"
        }
        start_ray(
            address=None if not args.ray_host else f"{args.ray_host}{':' if args.ray_port else ''}{args.ray_port if args.ray_port else ''}",
            runtime_env=runtime_env,
            options=options
        )

        # loop until ray starts
        ray_wait = 0
        while not ray.is_initialized():
            ray_wait += 1
            if ray_wait > 30:
                logger.error("Ray is not initialized after 30 seconds. Giving up on waiting for ray.")
                break
            time.sleep(1)

        logger.debug("Getting primary hostname from node_hostip()")
        primary_hostname = node_hostip()
        if primary_hostname:
            logger.debug(f"Setting KAMIWAZA_PRIMARY_NODE env var to {primary_hostname}")
            os.environ["KAMIWAZA_PRIMARY_NODE"] = primary_hostname

        if os.environ.get("KAMIWAZA_PRIMARY_NODE", None):
            logger.debug(f"Setting KAMIWAZA_PRIMARY_NODE in runtime_env to {os.environ.get('KAMIWAZA_PRIMARY_NODE')}")
            runtime_env["env_vars"]["KAMIWAZA_PRIMARY_NODE"] = os.environ.get("KAMIWAZA_PRIMARY_NODE")

        logger.debug("Setting KAMIWAZA_RUNNING=true in runtime_env")
        runtime_env["env_vars"]["KAMIWAZA_RUNNING"] = "true"
        os.environ["KAMIWAZA_RUNNING"] = "true"
        if "HF_TOKEN" in os.environ:
            runtime_env["env_vars"]["HF_TOKEN"] = os.environ["HF_TOKEN"]

        if "KAMIWAZA_COMMUNITY" in os.environ:
            runtime_env["env_vars"]["KAMIWAZA_COMMUNITY"] = os.environ["KAMIWAZA_COMMUNITY"]

        # push every env var that contains KAMIWAZA that is not already set in env_vars into it
        for key, value in os.environ.items():
            if "KAMIWAZA" in key and key not in runtime_env["env_vars"]:
                runtime_env["env_vars"][key] = value

        ## Here we restart ray to update the new runtime env since we "booted"
        ## Another way to go about this would be to put hostname discovery into
        ## its own module that does nothing but that, return it from a subprocess
        ## and start ray; on the other hand, it probably saves very little,
        ## because we then still have to start ray twice and we have a 
        ## child process to manage.

        ## Note: this does not actually restart ray, it restarts ray IN THIS PROCESS
        ## In kz ray is initialized by start-ray.sh
        ray.shutdown()

        # Prepare options dict to pass log_to_driver as per api.py
        options = {
            "log_to_driver": os.getenv("KAMIWAZA_DEBUG_RAY", "false") == "true"
        }
        start_ray(
            address=None if not args.ray_host else f"{args.ray_host}{':' if args.ray_port else ''}{args.ray_port if args.ray_port else ''}",
            runtime_env=runtime_env,
            options=options
        )

        # loop until ray starts
        ray_wait = 0
        while not ray.is_initialized():
            ray_wait += 1
            if ray_wait > 30:
                logger.error("Ray is not initialized after 30 seconds. Giving up on waiting for ray.")
                break
            time.sleep(1)
        bootstrap_config()

    result = test_env_vars.remote()
    logger.debug("Ray Remote vars: ", ray.get(result))

    # before we start the fastapi service back up, clean up any stale routes in Traefik
    ss = ServingService()
    deployments = ss.list_deployments()
    deployment_ids = [d.id for d in deployments]
    ts = TraefikService()
    asyncio.run(ts.flush_routes(prefixes_to_keep=deployment_ids))
    
    # clean up any stale pending deployment flags
    from kamiwaza.services.models.services import ModelService
    ms = ModelService()
    cleanup_result = asyncio.run(ms.cleanup_stale_pending_deployments())
    if cleanup_result["cleaned_count"] > 0:
        logger.info(f"Cleaned up {cleanup_result['cleaned_count']} stale pending deployment flags")
    elif cleanup_result["error"]:
        logger.warning(f"Error cleaning pending deployments: {cleanup_result['error']}")

    logger.debug("Starting Ray Serve")
    http_options = serve.config.HTTPOptions(host="0.0.0.0", port=KAMIWAZA_SERVE_PORT, request_timeout_s=900.0, location='EveryNode')
    serve.start(detached=True, http_options=http_options)

    # Wrapper for Ray Serve; we are using the original FastAPI endpoints so it has no methods,
    # Updated to use Ray Serve's HTTPOptions for Ray version 2.10, following the new API structure
    @serve.deployment
    
    @serve.ingress(app)
    class FastAPIWrapper:
        def __init__(self):
            # Configure logging for Ray worker processes
            configure_ray_worker_logging()

    try:
        serve.run(FastAPIWrapper.bind(), route_prefix="/api")
    except Exception as e:
        logger.error(f"Failed to start Ray Serve: {str(e)}")
        sys.exit(1)


    logger.debug("Starting Cluster Service")
    try:
        cluster_service = ClusterService()
        cluster_service.cluster_init()
    except Exception as e:
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        tb_str = traceback.format_exception(exc_type, exc_value, exc_traceback)
        logger.error(f"Error initializing cluster: {''.join(tb_str)}; exiting")
        exit(1)

    # Initialize garden apps information
    initialize_garden_apps()
    
    # Initialize model guide data
    logger.info("Initializing model guide data...")
    try:
        from kamiwaza.services.models.services import ModelService
        model_service = ModelService()
        import_result = asyncio.run(model_service.import_model_guide())
        if "error" not in import_result:
            logger.info("Model guide data initialized successfully")
        else:
            logger.warning(f"Failed to initialize model guide data: {import_result.get('error')}")
    except Exception as e:
        logger.warning(f"Failed to initialize model guide data: {e}")

    logger.debug("Starting Scheduled Tasks")
    task_schedule.start_scheduled_tasks()

    # /node endpoint comes up in separate service, which has the benefit of blocking
    # ray from exiting when serve.run() is "done" (aka initialized)
    if __name__ == "__main__":
        # Configure logging for node service
        configure_ray_worker_logging()
        uvicorn.run(nodeapp, host="0.0.0.0", port=7788)

else:
    # It's a bit of a misnomer, of course, because cluster_Service is also kamiwaza metadata
    # We could do other things like disable the cluster page, since you won't ever have use
    # of placement groups in single-node mode, but consistency here. We do this
    # after check for clusterMode because we want cluster_init() to pick up the ray
    # info generated by ray_init()

    # this should do local resolution now because no ray
    primary_hostname = node_hostip()
    if primary_hostname:
        os.environ["KAMIWAZA_PRIMARY_NODE"] = primary_hostname

    try:
        cluster_service = ClusterService()
        cluster_service.cluster_init()
    except Exception as e:
        # TODO: again, probably this becomes fatal at some point
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        tb_str = traceback.format_exception(exc_type, exc_value, exc_traceback)
        logger.error(f"Non-Fatal: Error initializing cluster: {''.join(tb_str)}; will continue but default resources or node may not be registered")

    # Initialize garden apps information
    initialize_garden_apps()
    
    # Initialize model guide data
    logger.info("Initializing model guide data...")
    try:
        from kamiwaza.services.models.services import ModelService
        model_service = ModelService()
        import_result = asyncio.run(model_service.import_model_guide())
        if "error" not in import_result:
            logger.info("Model guide data initialized successfully")
        else:
            logger.warning(f"Failed to initialize model guide data: {import_result.get('error')}")
    except Exception as e:
        logger.warning(f"Failed to initialize model guide data: {e}")

    task_schedule.start_scheduled_tasks()

    if __name__ == "__main__":
        # Configure logging for standalone mode
        configure_ray_worker_logging()
        # run all the APIs together, single-node mode
        logger.debug("Kamiwaza: Debug logging active (if you see this)")
        print("Starting uvicorn in non-clusterMode: unsupported, good luck!")
        uvicorn.run(app, host="0.0.0.0", port=KAMIWAZA_SERVE_PORT, workers=4, limit_concurrency=100)



