#!/usr/bin/env python3
"""
Import tool server templates from the garden/default/tools.json file.
This utility is similar to import_garden_apps.py but for tool servers.
"""
import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional
from uuid import UUID

# Add the kamiwaza root to the path so we can import modules
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent / 'kamiwaza'))

from kamiwaza.lib.util import get_kamiwaza_root
from kamiwaza.serving.garden.apps.templates import TemplateService
from kamiwaza.serving.garden.apps.apps import AppService
from kamiwaza.serving.schemas.templates import CreateAppTemplate, TemplateSource, TemplateVisibility, RiskTier
from kamiwaza.serving.schemas.serving import AppDeployment
from kamiwaza.db.engine import DatabaseManager
from kamiwaza.serving.config import settings

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Path to the tool servers JSON file
TOOL_SERVERS_JSON_PATH = Path(__file__).parent.parent / "garden" / "default" / "tools.json"


def load_tool_servers() -> List[Dict]:
    """Load tool server definitions from the JSON file."""
    if not TOOL_SERVERS_JSON_PATH.exists():
        logger.error(f"Tool servers file not found: {TOOL_SERVERS_JSON_PATH}")
        return []
    
    try:
        with open(TOOL_SERVERS_JSON_PATH, 'r') as f:
            servers = json.load(f)
            logger.info(f"Loaded {len(servers)} tool server definitions from {TOOL_SERVERS_JSON_PATH}")
            return servers
    except Exception as e:
        logger.error(f"Failed to load tool servers: {e}")
        return []


class ToolServerImporter:
    """Import tool server templates from tools.json file."""
    
    def __init__(self):
        """Initialize the importer with required services."""
        # Initialize database connection
        DatabaseManager.get_instance('main', settings.database_url)
        
        self.template_service = TemplateService()
        self.app_service = AppService()
    
    def find_existing_template(self, name: str) -> Optional[Dict]:
        """Find an existing template by name."""
        templates = self.template_service.list_templates()
        for template in templates:
            if template.name == name:
                return template
        return None
    
    def find_deployments_for_template(self, template_id: UUID) -> List[AppDeployment]:
        """Find all deployments that use the specified template."""
        deployments = self.app_service.list_deployments()
        return [d for d in deployments if d.template_id == template_id and d.status not in ['STOPPED', 'FAILED']]
    
    def cleanup_stopped_deployments(self, template_id: UUID) -> bool:
        """Clean up stopped/failed deployments for a template to avoid foreign key constraints."""
        try:
            from kamiwaza.db.engine import DatabaseManager
            from kamiwaza.serving.models.models import DBAppDeployment, DBAppInstance, DBAppPortMapping
            
            # Get database session
            SessionLocal = DatabaseManager.get_session('main')
            
            with SessionLocal() as db:
                # First, find deployments that need to be cleaned up
                deployments_to_cleanup = db.query(DBAppDeployment).filter(
                    DBAppDeployment.template_id == template_id,
                    DBAppDeployment.status.in_(['STOPPED', 'FAILED', 'DELETED'])
                ).all()
                
                if not deployments_to_cleanup:
                    logger.info("No stopped deployments to clean up")
                    return True
                
                deployment_ids = [d.id for d in deployments_to_cleanup]
                logger.info(f"Found {len(deployment_ids)} stopped deployments to clean up")
                
                # Delete port mappings first (they reference instances)
                port_mappings_deleted = db.query(DBAppPortMapping).filter(
                    DBAppPortMapping.instance_id.in_(
                        db.query(DBAppInstance.id).filter(
                            DBAppInstance.deployment_id.in_(deployment_ids)
                        )
                    )
                ).delete(synchronize_session=False)
                
                if port_mappings_deleted > 0:
                    logger.info(f"Deleted {port_mappings_deleted} port mappings")
                
                # Delete instances (they reference deployments)
                instances_deleted = db.query(DBAppInstance).filter(
                    DBAppInstance.deployment_id.in_(deployment_ids)
                ).delete(synchronize_session=False)
                
                if instances_deleted > 0:
                    logger.info(f"Deleted {instances_deleted} instances")
                
                # Finally delete deployments
                deployments_deleted = db.query(DBAppDeployment).filter(
                    DBAppDeployment.id.in_(deployment_ids)
                ).delete(synchronize_session=False)
                
                db.commit()
                
                if deployments_deleted > 0:
                    logger.info(f"Cleaned up {deployments_deleted} stopped/failed deployments for template {template_id}")
                
                return True
                
        except Exception as e:
            logger.error(f"Error cleaning up stopped deployments: {e}")
            return False
    
    async def shutdown_deployments(self, deployments: List[AppDeployment]) -> bool:
        """Shutdown all specified deployments."""
        success = True
        for deployment in deployments:
            try:
                logger.info(f"Shutting down deployment: {deployment.name} ({deployment.id})")
                result = await self.app_service.stop_deployment(deployment.id)
                if not result:
                    logger.error(f"Failed to shutdown deployment: {deployment.name}")
                    success = False
                else:
                    logger.info(f"Successfully shutdown deployment: {deployment.name}")
            except Exception as e:
                logger.error(f"Error shutting down deployment {deployment.name}: {e}")
                success = False
        return success
    
    async def import_tool_server(self, server_def: Dict, shutdown_existing: bool = False) -> bool:
        """Import a single tool server definition."""
        name = server_def.get("name", "")
        
        logger.info(f"Importing tool server: {name}")
        
        # Check if template already exists
        existing_template = self.find_existing_template(name)
        
        if existing_template:
            logger.info(f"Template '{name}' already exists with ID {existing_template.id}")
            
            # Check for active deployments
            active_deployments = self.find_deployments_for_template(existing_template.id)
            
            if active_deployments:
                if not shutdown_existing:
                    logger.warning(f"Template '{name}' has {len(active_deployments)} active deployment(s). Use --shutdown to replace.")
                    logger.warning("Active deployments:")
                    for dep in active_deployments:
                        logger.warning(f"  - {dep.name} (ID: {dep.id}, Status: {dep.status})")
                    return False
                else:
                    logger.info("Shutting down active deployments...")
                    success = await self.shutdown_deployments(active_deployments)
                    if not success:
                        logger.error(f"Failed to shutdown all deployments for template {name}")
                        return False
                    
                    # Wait a moment for shutdown to complete
                    import asyncio
                    await asyncio.sleep(2)
            
            # Clean up any stopped/failed deployments to avoid foreign key constraints
            logger.info(f"Cleaning up stopped deployments for template: {name}")
            cleanup_success = self.cleanup_stopped_deployments(existing_template.id)
            if not cleanup_success:
                logger.error(f"Failed to cleanup stopped deployments for template {name}")
                return False
            
            # Delete the existing template
            logger.info(f"Deleting existing template: {name}")
            try:
                self.template_service.delete_template(existing_template.id)
            except Exception as e:
                logger.error(f"Failed to delete existing template {name}: {e}")
                return False
        
        # Create new template
        try:
            # Convert the tool server definition to CreateAppTemplate format
            template_data = CreateAppTemplate(
                name=name,
                version=server_def.get("version", "1.0.0"),
                source_type=TemplateSource(server_def.get("source_type", "kamiwaza")),
                visibility=TemplateVisibility(server_def.get("visibility", "public")),
                compose_yml=server_def.get("compose_yml", ""),
                risk_tier=RiskTier(server_def.get("risk_tier", 1)),  # Default to guided
                verified=server_def.get("verified", False),
                env_defaults=server_def.get("env_defaults", {}),
                description=server_def.get("description", ""),
                # Tool-specific fields stored in env_defaults
                capabilities=server_def.get("capabilities", []),
                required_env_vars=server_def.get("required_env_vars", []),
                author=server_def.get("author", ""),
                homepage=server_def.get("homepage", "")
            )
            
            # Store tool-specific metadata in env_defaults
            env_defaults = server_def.get("env_defaults", {})
            env_defaults["_tool_image"] = server_def.get("image", "")
            env_defaults["_tool_capabilities"] = json.dumps(server_def.get("capabilities", []))
            env_defaults["_tool_required_env_vars"] = json.dumps(server_def.get("required_env_vars", []))
            template_data.env_defaults = env_defaults
            
            template = self.template_service.create_template(template_data)
            logger.info(f"✓ Successfully imported tool server: {name} (ID: {template.id})")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create template for '{name}': {e}")
            return False
    
    async def import_all(self, servers: List[Dict], shutdown_existing: bool = False) -> bool:
        """Import all tool server definitions."""
        success_count = 0
        total_count = len(servers)
        
        for server_def in servers:
            try:
                success = await self.import_tool_server(server_def, shutdown_existing)
                if success:
                    success_count += 1
            except Exception as e:
                logger.error(f"Unexpected error processing tool server {server_def.get('name', 'unknown')}: {e}")
                import traceback
                traceback.print_exc()
        
        logger.info(f"Import complete: {success_count}/{total_count} tool servers imported successfully")
        return success_count == total_count
    


async def main():
    """Main entry point for the import utility."""
    parser = argparse.ArgumentParser(description="Import tool server templates from tools.json")
    parser.add_argument("--all", action="store_true", help="Import all tool servers (default: only tool-websearch)")
    parser.add_argument("--shutdown", action="store_true", help="Shutdown existing deployments if template exists")
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose logging')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Load tool servers
    servers = load_tool_servers()
    if not servers:
        logger.error("No tool servers found to import")
        sys.exit(1)
    
    logger.info(f"Using tool servers file: {TOOL_SERVERS_JSON_PATH}")
    
    try:
        importer = ToolServerImporter()
        
        # Filter servers if not importing all
        if not args.all:
            # Default to only tool-websearch
            target_servers = ['tool-websearch']
            filtered_servers = [s for s in servers if s['name'] in target_servers]
            
            if not filtered_servers:
                logger.warning(f"No target servers found in tool file. Looking for: {target_servers}")
                sys.exit(0)
            
            logger.info(f"Found {len(filtered_servers)} target servers to import: {[s['name'] for s in filtered_servers]}")
            servers_to_import = filtered_servers
        else:
            logger.info(f"Importing all {len(servers)} tool servers from file")
            servers_to_import = servers
        
        success = await importer.import_all(servers_to_import, args.shutdown)
        
        if success:
            logger.info("All tool servers imported successfully!")
            sys.exit(0)
        else:
            logger.error("Some tool servers failed to import")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"Script failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())