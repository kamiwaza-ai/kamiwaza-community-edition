#!/bin/bash

# Add strict mode flags
set -euo pipefail

#set -x
# Set cwd to script dir
cd "$(dirname "${BASH_SOURCE[0]}")"

source set-kamiwaza-root.sh
source common.sh

# Improve venv handling
if [ -f venv/bin/activate ]; then
    # shellcheck disable=SC1091
    source venv/bin/activate
fi

# Test for venv env var
if [ -z "$VIRTUAL_ENV" ]; then
    echo " ### KAMIWAZA_STARTUP_ERROR: Virtual environment is not set"
    exit 1
fi


# from common.sh
setup_environment

show_help() {
    echo "Usage: $(basename "$0") [options]"
    echo ""
    echo "Options:"
    echo "  -h, --help            Show this help message and exit"
    echo "  --ray-head IP         Set the Ray head IP"
    echo "  --ray-port PORT       Set the Ray head port"
    echo "  [other options]       Other options to pass to launch.py"
}

# Check for help flag
for arg in "$@"; do
    case $arg in
        -h|--help)
            show_help
            exit 0
            ;;
    esac
done

#!/bin/bash

# Collect flags to pass to launch.py
flags="$@"

# Add ray head IP and port if set
if [ -n "${KAMIWAZA_HEAD_IP:-}" ] && [ -n "${KAMIWAZA_HEAD_PORT:-}" ]; then
    # Check if we are the head node by comparing our IP with KAMIWAZA_HEAD_IP
    if ifconfig | grep inet | awk '{print $2}' | grep -q "^${KAMIWAZA_HEAD_IP}$" > /dev/null 2>&1; then
        flags+=" --ray-head ${KAMIWAZA_HEAD_IP} --ray-port ${KAMIWAZA_HEAD_PORT}"
    fi
fi

launch_python_process() {
    # Run python in background and capture its PID
    if [ "$1" = "dev" ]; then
        python kamiwaza/launch.py $flags &
    else
        python launch.py $flags &
    fi
    # Capture the Python process PID
    echo $! > /tmp/kamiwaza-core.pid
    # Wait for the Python process to complete
    wait $!
    # Clean up PID file on exit
    rm -f /tmp/kamiwaza-core.pid
}

if [ -f launch.py ]; then
    launch_python_process "prod"
elif [ -f kamiwaza/launch.py ]; then
    # dev layout
    if [ -f "kamiwaza-shibboleth" ] && [ -z "${KAMIWAZA_NO_SET_PATH:-}" ]; then
        # If running in a repo layout where package is in-tree (kamiwaza/ exists), add CWD to PYTHONPATH
        if [ -d "kamiwaza" ]; then
            case ":${PYTHONPATH:-}:" in
                *:"$(pwd)":*) : ;;
                *) export PYTHONPATH="${PYTHONPATH:+${PYTHONPATH}:}$(pwd)" ;;
            esac
        fi
    fi
    launch_python_process "dev"
else
    echo " ### KAMIWAZA_STARTUP_ERROR: No launch.py found"
    exit 1
fi