import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../utils/api';
import { styled } from '@mui/material/styles';
import { 
  Typography, 
  Box, 
  Paper, 
  Table, 
  TableHead, 
  TableBody, 
  TableRow, 
  TableCell, 
  TableContainer, 
  Button, 
  TextField, 
  Grid, 
  Card, 
  CardContent, 
  CardHeader, 
  IconButton, 
  Tooltip, 
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tab,
  Tabs
} from '@mui/material';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CloseIcon from '@mui/icons-material/Close';
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import PeopleIcon from '@mui/icons-material/People';
import Spinner from '../common/Spinner';

// Styled components
const ContentContainer = styled(Box)(({ theme }) => ({
  maxWidth: '100%',
  margin: '0 auto',
  padding: theme.spacing(3, 2),
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  color: theme.palette.primary.main,
  fontSize: '1.8rem',
  fontWeight: 700,
  marginBottom: theme.spacing(2),
  paddingBottom: theme.spacing(1.5),
  position: 'relative',
  '&:after': {
    content: '""',
    position: 'absolute',
    left: 0,
    bottom: 0,
    width: '80px',
    height: '3px',
    background: 'linear-gradient(90deg, #00c07f, transparent)'
  }
}));

const TabsContainer = styled(Paper)(({ theme }) => ({
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  borderRadius: '12px 12px 0 0',
  boxShadow: 'none',
  borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
  marginBottom: theme.spacing(3),
  marginTop: theme.spacing(3),
}));

const StyledTabs = styled(Tabs)(({ theme }) => ({
  '& .MuiTabs-indicator': {
    backgroundColor: theme.palette.primary.main,
    height: 3,
  },
}));

const StyledTab = styled(Tab)(({ theme }) => ({
  textTransform: 'none',
  fontSize: '0.9rem',
  fontWeight: 500,
  padding: theme.spacing(2, 3),
  color: theme.palette.text.secondary,
  '&.Mui-selected': {
    color: theme.palette.primary.main,
    fontWeight: 600,
  },
  '&:hover': {
    color: theme.palette.text.primary,
    opacity: 1,
  },
  '& .MuiSvgIcon-root': {
    marginRight: theme.spacing(1),
    fontSize: '1.2rem',
  },
}));

const TabPanel = styled(Box)(({ theme }) => ({
  padding: theme.spacing(3, 0),
}));

const StyledCard = styled(Card)(({ theme }) => ({
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  borderRadius: 12,
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
  border: '1px solid rgba(255, 255, 255, 0.08)',
  marginBottom: theme.spacing(4),
}));

const StyledCardHeader = styled(CardHeader)(({ theme }) => ({
  borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
  '& .MuiCardHeader-title': {
    color: theme.palette.primary.main,
    fontWeight: 600,
  },
}));

const StyledTableContainer = styled(TableContainer)(({ theme }) => ({
  backgroundColor: 'rgba(255, 255, 255, 0.01)',
  borderRadius: 8,
  margin: theme.spacing(2, 0),
}));

const TableHeaderCell = styled(TableCell)(({ theme }) => ({
  backgroundColor: 'rgba(0, 0, 0, 0.2)',
  color: theme.palette.primary.main,
  fontWeight: 600,
  fontSize: '0.9rem',
  paddingTop: theme.spacing(1.5),
  paddingBottom: theme.spacing(1.5),
}));

const TableBodyCell = styled(TableCell)(({ theme }) => ({
  borderBottom: `1px solid rgba(255, 255, 255, 0.05)`,
}));

const ActionButton = styled(Button)(({ theme, color }) => ({
  marginRight: theme.spacing(1),
  textTransform: 'none',
  fontSize: '0.75rem',
  fontWeight: 500,
  padding: theme.spacing(0.5, 1.5),
  minWidth: 0,
  color: color === 'error' ? theme.palette.error.main : theme.palette.primary.main,
  borderColor: color === 'error' ? theme.palette.error.main : theme.palette.primary.main,
  '&:hover': {
    backgroundColor: color === 'error' ? 'rgba(244, 67, 54, 0.08)' : 'rgba(0, 192, 127, 0.08)',
  },
}));

const IconActionButton = styled(IconButton)(({ theme, color }) => ({
  color: color === 'error' ? theme.palette.error.main : theme.palette.primary.main,
  backgroundColor: color === 'error' ? 'rgba(244, 67, 54, 0.08)' : 'rgba(0, 192, 127, 0.08)',
  padding: theme.spacing(0.75),
  marginRight: theme.spacing(1),
  '&:hover': {
    backgroundColor: color === 'error' ? 'rgba(244, 67, 54, 0.15)' : 'rgba(0, 192, 127, 0.15)',
  },
}));

const StyledTextField = styled(TextField)(({ theme }) => ({
  margin: theme.spacing(1, 0),
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderColor: 'rgba(255, 255, 255, 0.15)',
    },
    '&:hover fieldset': {
      borderColor: 'rgba(255, 255, 255, 0.25)',
    },
    '&.Mui-focused fieldset': {
      borderColor: `${theme.palette.primary.main} !important`,
      borderWidth: '1px !important',
    },
    // Fix for autofill blue background
    '& input:-webkit-autofill, & input:-webkit-autofill:hover, & input:-webkit-autofill:focus, & input:-webkit-autofill:active': {
      WebkitBoxShadow: '0 0 0 30px #161b22 inset !important', // Match your background color
      WebkitTextFillColor: '#ffffff !important', // Match your text color
      caretColor: '#ffffff !important',
      borderRadius: 'inherit',
    },
  },
  '& .MuiInputLabel-root': {
    color: theme.palette.text.secondary,
  },
  '& .MuiInputBase-input': {
    color: theme.palette.text.primary,
    position: 'relative',
    '&:focus': {
      boxShadow: 'none',
    },
  },
  // Ensure there's only one border
  '& .MuiOutlinedInput-notchedOutline': {
    borderWidth: '1px !important',
  },
}));

const StyledDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialog-paper': {
    backgroundColor: theme.palette.background.paper,
    borderRadius: '12px',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    padding: theme.spacing(2),
    minWidth: '400px',
  },
}));

const StyledDialogTitle = styled(DialogTitle)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: theme.spacing(2, 3),
  color: theme.palette.primary.main,
  fontWeight: 600,
  '& svg': {
    marginRight: theme.spacing(1),
  },
}));

const CloseButton = styled(IconButton)(({ theme }) => ({
  color: theme.palette.text.secondary,
  '&:hover': {
    color: theme.palette.error.main,
    backgroundColor: 'rgba(255, 0, 0, 0.1)',
  },
}));

const DialogButton = styled(Button)(({ theme, cancel }) => ({
  textTransform: 'none',
  padding: theme.spacing(1, 3),
  fontWeight: 500,
  color: cancel ? theme.palette.text.primary : '#fff',
  backgroundColor: cancel ? 'rgba(255, 255, 255, 0.05)' : theme.palette.primary.main,
  border: cancel ? '1px solid rgba(255, 255, 255, 0.15)' : 'none',
  '&:hover': {
    backgroundColor: cancel ? 'rgba(255, 255, 255, 0.1)' : theme.palette.primary.dark,
  },
}));

const InfoIcon = styled(InfoOutlinedIcon)(({ theme }) => ({
  fontSize: '1.1rem',
  color: theme.palette.text.secondary,
  marginLeft: theme.spacing(1),
  cursor: 'pointer',
  transition: 'color 0.2s',
  '&:hover': {
    color: theme.palette.primary.main,
  },
}));

function TabPanelContent(props) {
  const { children, value, index, ...other } = props;

  return (
    <TabPanel
      role="tabpanel"
      hidden={value !== index}
      id={`admin-tabpanel-${index}`}
      aria-labelledby={`admin-tab-${index}`}
      {...other}
    >
      {value === index && children}
    </TabPanel>
  );
}

const AdminPanel = () => {
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({ username: '', email: '', password: '' });
  const [selectedUser, setSelectedUser] = useState(null);
  const [formKey, setFormKey] = useState(0);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [editUserOpen, setEditUserOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await api.get('/auth/users/');
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleNewUserChange = (e) => {
    setNewUser({ ...newUser, [e.target.id]: e.target.value });
  };

  const handleSelectedUserChange = (e) => {
    setSelectedUser({ ...selectedUser, [e.target.name]: e.target.value });
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    try {
      await api.post('/auth/users/local', newUser);
      setNewUser({ username: '', email: '', password: '' });
      fetchUsers();  // Refresh the user list after adding a new user
      setAddUserOpen(false);
      setTabValue(0);  // Switch back to the User Management tab
    } catch (error) {
      console.error('Error adding user:', error);
    }
  };

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    if (!selectedUser) return;
    try {
      await api.put(`/auth/users/${selectedUser.id}`, selectedUser);
      setSelectedUser(null);
      fetchUsers();
      setEditUserOpen(false);
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!userToDelete) return;
    try {
      await api.delete(`/auth/users/${userToDelete.id}`);
      fetchUsers();
      setDeleteConfirmOpen(false);
      setUserToDelete(null);
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const openEditDialog = (user) => {
    setSelectedUser(user);
    setEditUserOpen(true);
  };

  const openDeleteConfirm = (user) => {
    setUserToDelete(user);
    setDeleteConfirmOpen(true);
  };

  return (
    <ContentContainer>
      <SectionTitle variant="h4">
        Admin Panel
        <Tooltip title="Administrative functions for user management">
          <InfoIcon />
        </Tooltip>
      </SectionTitle>

      <TabsContainer>
        <StyledTabs 
          value={tabValue} 
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          aria-label="admin panel tabs"
        >
          <StyledTab icon={<PeopleIcon />} label="User Management" iconPosition="start" />
          <StyledTab icon={<PersonAddIcon />} label="Add New User" iconPosition="start" onClick={() => setAddUserOpen(true)} />
        </StyledTabs>
      </TabsContainer>

      <TabPanelContent value={tabValue} index={0}>
        <StyledCard>
          <StyledCardHeader 
            title="User List" 
            action={
              <Button
                startIcon={<PersonAddIcon />}
                size="small"
                onClick={() => setAddUserOpen(true)}
                sx={{ 
                  textTransform: 'none', 
                  color: 'primary.main',
                  '&:hover': {
                    backgroundColor: 'rgba(0, 192, 127, 0.08)',
                  },
                }}
              >
                Add User
              </Button>
            }
          />
          <CardContent>
            {loading ? (
              <Spinner />
            ) : (
              <StyledTableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableHeaderCell>Username</TableHeaderCell>
                      <TableHeaderCell>Email</TableHeaderCell>
                      <TableHeaderCell align="right">Actions</TableHeaderCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {users.length === 0 ? (
                      <TableRow>
                        <TableBodyCell colSpan={3} align="center" sx={{ py: 3 }}>
                          <Typography variant="body2" color="text.secondary">
                            No users found
                          </Typography>
                        </TableBodyCell>
                      </TableRow>
                    ) : (
                      users.map((user) => (
                        <TableRow key={user.id} hover>
                          <TableBodyCell>
                            {user.username}
                          </TableBodyCell>
                          <TableBodyCell>{user.email}</TableBodyCell>
                          <TableBodyCell align="right">
                            <IconActionButton 
                              size="small" 
                              onClick={() => openEditDialog(user)}
                              aria-label="edit user"
                            >
                              <EditIcon fontSize="small" />
                            </IconActionButton>
                            <IconActionButton 
                              size="small" 
                              color="error"
                              onClick={() => openDeleteConfirm(user)}
                              aria-label="delete user"
                            >
                              <DeleteIcon fontSize="small" />
                            </IconActionButton>
                          </TableBodyCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </StyledTableContainer>
            )}
          </CardContent>
        </StyledCard>
      </TabPanelContent>

      {/* Add User Dialog */}
      <StyledDialog open={addUserOpen} onClose={() => setAddUserOpen(false)} maxWidth="sm" fullWidth>
        <StyledDialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <PersonAddIcon />
            Add New User
          </Box>
          <CloseButton onClick={() => setAddUserOpen(false)}>
            <CloseIcon />
          </CloseButton>
        </StyledDialogTitle>
        
        <Divider />
        
        <DialogContent>
          <form onSubmit={handleAddUser} key={formKey} autoComplete="off">
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <StyledTextField
                  id="username"
                  name={`username_${Math.random()}`}
                  label="Username"
                  value={newUser.username}
                  onChange={handleNewUserChange}
                  autoComplete="off"
                  fullWidth
                  margin="normal"
                  inputProps={{
                    autoComplete: 'new-username',
                    form: {
                      autoComplete: 'off',
                    },
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <StyledTextField
                  id="email"
                  name={`email_${Math.random()}`}
                  label="Email"
                  value={newUser.email}
                  onChange={handleNewUserChange}
                  autoComplete="off"
                  fullWidth
                  margin="normal"
                  inputProps={{
                    autoComplete: 'new-email',
                    form: {
                      autoComplete: 'off',
                    },
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <StyledTextField
                  id="password"
                  name={`password_${Math.random()}`}
                  label="Password"
                  type="password"
                  value={newUser.password}
                  onChange={handleNewUserChange}
                  autoComplete="new-password"
                  fullWidth
                  margin="normal"
                  inputProps={{
                    autoComplete: 'new-password',
                    form: {
                      autoComplete: 'off',
                    },
                  }}
                />
              </Grid>
            </Grid>
          </form>
        </DialogContent>
        
        <DialogActions sx={{ p: 2 }}>
          <DialogButton cancel onClick={() => setAddUserOpen(false)}>
            Cancel
          </DialogButton>
          <DialogButton 
            onClick={handleAddUser}
            startIcon={<PersonAddIcon />}
          >
            Add User
          </DialogButton>
        </DialogActions>
      </StyledDialog>

      {/* Edit User Dialog */}
      <StyledDialog open={editUserOpen} onClose={() => setEditUserOpen(false)} maxWidth="sm" fullWidth>
        <StyledDialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <EditIcon />
            Edit User
          </Box>
          <CloseButton onClick={() => setEditUserOpen(false)}>
            <CloseIcon />
          </CloseButton>
        </StyledDialogTitle>
        
        <Divider />
        
        <DialogContent>
          {selectedUser && (
            <form onSubmit={handleUpdateUser}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <StyledTextField
                    name="username"
                    label="Username"
                    value={selectedUser.username}
                    onChange={handleSelectedUserChange}
                    fullWidth
                    margin="normal"
                  />
                </Grid>
                <Grid item xs={12}>
                  <StyledTextField
                    name="email"
                    label="Email"
                    value={selectedUser.email}
                    onChange={handleSelectedUserChange}
                    fullWidth
                    margin="normal"
                  />
                </Grid>
              </Grid>
            </form>
          )}
        </DialogContent>
        
        <DialogActions sx={{ p: 2 }}>
          <DialogButton cancel onClick={() => setEditUserOpen(false)}>
            Cancel
          </DialogButton>
          <DialogButton 
            onClick={handleUpdateUser}
            startIcon={<EditIcon />}
          >
            Update User
          </DialogButton>
        </DialogActions>
      </StyledDialog>

      {/* Delete Confirmation Dialog */}
      <StyledDialog open={deleteConfirmOpen} onClose={() => setDeleteConfirmOpen(false)} maxWidth="xs">
        <StyledDialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <DeleteIcon sx={{ color: 'error.main' }} />
            Confirm Deletion
          </Box>
          <CloseButton onClick={() => setDeleteConfirmOpen(false)}>
            <CloseIcon />
          </CloseButton>
        </StyledDialogTitle>
        
        <DialogContent>
          <Typography variant="body1">
            Are you sure you want to delete the user <strong>{userToDelete?.username}</strong>?
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            This action cannot be undone.
          </Typography>
        </DialogContent>
        
        <DialogActions sx={{ p: 2 }}>
          <DialogButton cancel onClick={() => setDeleteConfirmOpen(false)}>
            Cancel
          </DialogButton>
          <Button 
            onClick={handleDeleteConfirm}
            variant="contained"
            color="error"
            startIcon={<DeleteIcon />}
            sx={{ textTransform: 'none' }}
          >
            Delete User
          </Button>
        </DialogActions>
      </StyledDialog>
    </ContentContainer>
  );
};

export default AdminPanel;
