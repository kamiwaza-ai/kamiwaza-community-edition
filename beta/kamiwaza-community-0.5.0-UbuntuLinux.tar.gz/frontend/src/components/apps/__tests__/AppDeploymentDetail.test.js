import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from '@mui/material/styles';
import axios from 'axios';
import AppDeploymentDetail from '../AppDeploymentDetail';
import theme from '../../../Theme';

// Mock axios
jest.mock('axios');

describe('AppDeploymentDetail', () => {
  const mockOnClose = jest.fn();
  const mockOnDeploymentStopped = jest.fn();

  const mockDeploymentData = {
    name: 'Test App',
    status: 'DEPLOYED',
    created_at: new Date().toISOString(),
    deployed_at: new Date().toISOString(),
    lb_port: 8080,
    ports: [
      {
        container_port: 3000,
        host_port: 3001,
        protocol: 'tcp',
      },
    ],
    env_vars: {
      NODE_ENV: 'production',
    },
    volumes: [],
    instances: [],
  };

  beforeEach(() => {
    jest.clearAllMocks();
    axios.get.mockResolvedValue({ data: mockDeploymentData });
  });

  const renderComponent = (props = {}) => {
    const defaultProps = {
      deploymentId: 'test-deployment-id',
      isOpen: true,
      onClose: mockOnClose,
      onDeploymentStopped: mockOnDeploymentStopped,
      ...props,
    };

    return render(
      <ThemeProvider theme={theme}>
        <AppDeploymentDetail {...defaultProps} />
      </ThemeProvider>
    );
  };

  it('renders the dialog when open', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Deployment Details')).toBeInTheDocument();
    });
  });

  it('does not render when isOpen is false', () => {
    renderComponent({ isOpen: false });

    expect(screen.queryByText('Deployment Details')).not.toBeInTheDocument();
  });

  describe('Close button functionality', () => {
    it('renders close button with proper attributes', async () => {
      renderComponent();

      await waitFor(() => {
        const closeButtons = screen.getAllByRole('button');
        const closeButton = closeButtons.find(button =>
          button.querySelector('[data-testid="CloseIcon"]')
        );
        expect(closeButton).toBeInTheDocument();
        expect(closeButton).toHaveClass('MuiIconButton-sizeSmall');
      });
    });

    it('calls onClose when close button is clicked', async () => {
      renderComponent();

      await waitFor(() => {
        const closeButtons = screen.getAllByRole('button');
        const closeButton = closeButtons.find(button =>
          button.querySelector('[data-testid="CloseIcon"]')
        );
        fireEvent.click(closeButton);
        expect(mockOnClose).toHaveBeenCalledTimes(1);
      });
    });

    it('close button is positioned correctly next to refresh button', async () => {
      renderComponent();

      await waitFor(() => {
        const refreshButton = screen
          .getAllByRole('button')
          .find(button => button.querySelector('[data-testid="RefreshIcon"]'));
        const closeButton = screen
          .getAllByRole('button')
          .find(button => button.querySelector('[data-testid="CloseIcon"]'));

        // Both buttons should be in the same container
        expect(refreshButton.parentElement).toBe(closeButton.parentElement);
      });
    });

    it('both icon buttons have correct size attribute', async () => {
      renderComponent();

      await waitFor(() => {
        const iconButtons = screen
          .getAllByRole('button')
          .filter(
            button =>
              button.querySelector('[data-testid="RefreshIcon"]') ||
              button.querySelector('[data-testid="CloseIcon"]')
          );

        iconButtons.forEach(button => {
          expect(button.className).toMatch(/MuiIconButton-sizeSmall/);
        });
      });
    });
  });

  it('shows loading spinner while fetching data', () => {
    axios.get.mockReturnValueOnce(new Promise(() => {})); // Never resolves
    renderComponent();

    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('displays deployment details when data is loaded', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test App')).toBeInTheDocument();
      expect(screen.getByText('Running')).toBeInTheDocument(); // Status is shown as "Running" for DEPLOYED
    });
  });

  it('handles error state gracefully', async () => {
    const errorMessage = 'Failed to load deployment details';
    axios.get.mockRejectedValueOnce({
      response: { data: { detail: errorMessage } },
    });

    renderComponent();

    await waitFor(() => {
      expect(screen.getByText(errorMessage)).toBeInTheDocument();
    });
  });

  it('refresh button triggers data refetch', async () => {
    renderComponent();

    await waitFor(() => {
      const refreshButton = screen
        .getAllByRole('button')
        .find(button => button.querySelector('[data-testid="RefreshIcon"]'));

      // Initial call
      expect(axios.get).toHaveBeenCalledTimes(1);

      // Click refresh
      fireEvent.click(refreshButton);

      // Should make another call
      expect(axios.get).toHaveBeenCalledTimes(2);
    });
  });
});
