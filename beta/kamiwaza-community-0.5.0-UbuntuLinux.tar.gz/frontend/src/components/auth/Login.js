import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { styled } from '@mui/material/styles';
import { 
  Box, 
  TextField, 
  Button, 
  Paper, 
  Typography,
  Container,
  Alert,
  InputAdornment,
  IconButton
} from '@mui/material';
import { Visibility, VisibilityOff, PersonOutline, LockOutlined } from '@mui/icons-material';

const fontStack = `var(--app-font-stack)`;

const LoginContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '100vh',
  padding: theme.spacing(3),
  backgroundColor: theme.palette.background.default,
  fontFamily: fontStack,
}));

const LoginForm = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: 16,
  maxWidth: 450,
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(3),
  backgroundColor: theme.palette.background.paper,
  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)',
  position: 'relative',
  overflow: 'hidden',
  fontFamily: fontStack,
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '5px',
    background: 'linear-gradient(90deg, #00c07f, #00c0a0)',
  },
}));

const StyledTextField = styled(TextField)(({ theme }) => ({
  fontFamily: fontStack,
  '& .MuiOutlinedInput-root': {
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    '&:hover .MuiOutlinedInput-notchedOutline': {
      borderColor: theme.palette.primary.main,
    },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: `${theme.palette.primary.main} !important`,
      borderWidth: '1px !important',
    },
    '& input, & input::placeholder': {
      fontFamily: fontStack,
    },
    // Fix for autofill blue background
    '& input:-webkit-autofill, & input:-webkit-autofill:hover, & input:-webkit-autofill:focus, & input:-webkit-autofill:active': {
      WebkitBoxShadow: '0 0 0 30px #121212 inset !important', // Match your background color
      WebkitTextFillColor: '#ffffff !important', // Match your text color
      caretColor: '#ffffff !important',
      borderRadius: 'inherit',
      fontFamily: fontStack,
    },
  },
  '& .MuiInputLabel-root': {
    color: theme.palette.text.secondary,
    fontFamily: fontStack,
  },
  '& .MuiOutlinedInput-notchedOutline': {
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  // Fix for focus
  '& .MuiOutlinedInput-input': {
    padding: theme.spacing(1.5),
    '&:focus': {
      boxShadow: 'none',
    },
    fontFamily: fontStack,
  },
}));

const StyledButton = styled(Button)(({ theme }) => ({
  borderRadius: 8,
  padding: theme.spacing(1.2, 2),
  fontSize: '1rem',
  fontWeight: 600,
  textTransform: 'none',
  boxShadow: '0 4px 10px rgba(0, 192, 127, 0.3)',
  background: 'linear-gradient(90deg, #00c07f, #00c0a0)',
  transition: 'all 0.3s ease',
  fontFamily: fontStack,
  '&:hover': {
    boxShadow: '0 6px 15px rgba(0, 192, 127, 0.4)',
    transform: 'translateY(-2px)',
    background: 'linear-gradient(90deg, #00c07f, #00c0a0)',
  },
}));

const Logo = styled('img')(({ theme }) => ({
  height: 150,
  marginBottom: theme.spacing(2),
  display: 'block',
  margin: '0 auto',
}));

const LogoTitle = styled(Typography)(({ theme }) => ({
  fontSize: '2.2rem',
  fontWeight: 700,
  marginBottom: theme.spacing(4),
  backgroundImage: 'linear-gradient(90deg, #00c07f, #00c0a0)',
  backgroundClip: 'text',
  textFillColor: 'transparent',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  textAlign: 'center',
  width: '100%',
  fontFamily: fontStack,
}));

const Login = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const { login, user } = useContext(AuthContext);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // If user is already logged in, redirect to home page
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const formData = new URLSearchParams();
      formData.append('username', credentials.username);
      formData.append('password', credentials.password);
      await login(formData);
      navigate('/');
    } catch (err) {
      if (err.message === 'Network Error') {
        setError('Service Unavailable. Please try again later.');
      } else if (err.response && err.response.status === 401) {
        setError('Invalid username or password');
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
    }
  };

  // If user is already logged in, don't render the form
  if (user) {
    return null;
  }

  return (
    <LoginContainer>
      <Container maxWidth="sm" sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', mb: 4 }}>
          <Logo src="/kamiwaza-logo.png" alt="Kamiwaza Logo" />
        </Box>
        
        <LoginForm elevation={6}>
          <Typography variant="h5" fontWeight="600" align="center" gutterBottom sx={{ fontFamily: fontStack }}>
            Sign In
          </Typography>
          
          {error && (
            <Alert severity="error" sx={{ borderRadius: 2 }}>
              {error}
            </Alert>
          )}
          
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <StyledTextField
              label="Username"
              name="username"
              value={credentials.username}
              onChange={handleChange}
              fullWidth
              required
              autoFocus
              variant="outlined"
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <PersonOutline sx={{ color: 'text.secondary' }} />
                  </InputAdornment>
                ),
              }}
            />
            
            <StyledTextField
              label="Password"
              name="password"
              type={showPassword ? 'text' : 'password'}
              value={credentials.password}
              onChange={handleChange}
              fullWidth
              required
              variant="outlined"
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockOutlined sx={{ color: 'text.secondary' }} />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={handleTogglePasswordVisibility}
                      edge="end"
                      sx={{ color: 'text.secondary' }}
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
            
            <StyledButton 
              type="submit" 
              variant="contained" 
              fullWidth
              size="large"
            >
              Login
            </StyledButton>
          </form>
        </LoginForm>
      </Container>
    </LoginContainer>
  );
};

export default Login;
