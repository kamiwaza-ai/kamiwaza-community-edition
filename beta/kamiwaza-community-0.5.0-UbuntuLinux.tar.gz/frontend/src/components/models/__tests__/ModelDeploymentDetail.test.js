import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from '@mui/material/styles';
import axios from 'axios';
import ModelDeploymentDetailModal from '../ModelDeploymentDetail';
import theme from '../../../Theme';

// Mock axios
jest.mock('axios');

// Mock the TestConversationModal component
jest.mock('../TestConversationModal', () => {
  return function MockTestConversationModal() {
    return <div>Test Conversation Modal</div>;
  };
});

describe('ModelDeploymentDetailModal', () => {
  const mockOnClose = jest.fn();
  const mockOnDeploymentStopped = jest.fn();

  const mockDeploymentData = {
    m_name: 'Test Model',
    m_config_name: 'Test Config',
    lb_port: 8080,
    duration: 60,
    engine_name: 'vllm',
    status: 'DEPLOYED',
    autoscaling: true,
    min_copies: 1,
    starting_copies: 2,
    max_copies: 4,
    gpu_allocation: true,
    vram_allocation: 4000000000,
    instances: [
      {
        id: '1',
        host_name: 'localhost',
        listen_port: 8081,
        container_id: 'abc123',
        deployed_at: new Date().toISOString(),
      },
    ],
  };

  beforeEach(() => {
    jest.clearAllMocks();
    axios.get.mockResolvedValue({ data: mockDeploymentData });
  });

  const renderComponent = (props = {}) => {
    const defaultProps = {
      deploymentId: 'test-deployment-id',
      isOpen: true,
      onClose: mockOnClose,
      onDeploymentStopped: mockOnDeploymentStopped,
      ...props,
    };

    return render(
      <ThemeProvider theme={theme}>
        <ModelDeploymentDetailModal {...defaultProps} />
      </ThemeProvider>
    );
  };

  it('renders the modal when open', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Deployment Detail')).toBeInTheDocument();
    });
  });

  it('does not render when isOpen is false', () => {
    renderComponent({ isOpen: false });

    expect(screen.queryByText('Deployment Detail')).not.toBeInTheDocument();
  });

  describe('Close button functionality', () => {
    it('renders close button with proper attributes', async () => {
      renderComponent();

      await waitFor(() => {
        const closeButton = screen.getByLabelText('close');
        expect(closeButton).toBeInTheDocument();
        expect(closeButton).toHaveClass('MuiIconButton-sizeSmall');
      });
    });

    it('calls onClose when close button is clicked', async () => {
      renderComponent();

      await waitFor(() => {
        const closeButton = screen.getByLabelText('close');
        fireEvent.click(closeButton);
        expect(mockOnClose).toHaveBeenCalledTimes(1);
      });
    });

    it('close button is positioned correctly in the modal header', async () => {
      renderComponent();

      await waitFor(() => {
        const closeButton = screen.getByLabelText('close');
        const modalHeader = closeButton.closest('div');

        // Check that the parent has flex layout
        expect(modalHeader).toHaveStyle({
          display: 'flex',
          justifyContent: 'space-between',
        });
      });
    });

    it('close button has correct size attribute', async () => {
      renderComponent();

      await waitFor(() => {
        const closeButton = screen.getByLabelText('close');
        expect(closeButton).toHaveAttribute('class');
        expect(closeButton.className).toMatch(/MuiIconButton-sizeSmall/);
      });
    });
  });

  it('shows loading spinner while fetching data', () => {
    axios.get.mockReturnValueOnce(new Promise(() => {})); // Never resolves
    renderComponent();

    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('displays deployment details when data is loaded', async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Test Model')).toBeInTheDocument();
      expect(screen.getByText('Test Config')).toBeInTheDocument();
      expect(screen.getByText('vllm')).toBeInTheDocument();
    });
  });

  it('handles error state gracefully', async () => {
    const errorMessage = 'Failed to load deployment';
    axios.get.mockRejectedValueOnce(new Error(errorMessage));

    renderComponent();

    await waitFor(() => {
      // Look for the error message in the ErrorComponent
      expect(screen.getByText(`Error: ${errorMessage}`)).toBeInTheDocument();
    });
  });

  it('shows "not found" message when deploymentDetail is null', async () => {
    axios.get.mockResolvedValueOnce({ data: null });

    renderComponent();

    await waitFor(() => {
      expect(screen.getByText('Deployment detail not found.')).toBeInTheDocument();
    });
  });
});
