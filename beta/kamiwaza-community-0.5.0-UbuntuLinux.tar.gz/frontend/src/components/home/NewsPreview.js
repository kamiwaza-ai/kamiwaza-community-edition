import React, { useState, useEffect } from 'react';
import { Typography, Box, Grid, Paper, Link, Chip, Button } from '@mui/material';
import { styled } from '@mui/material/styles';
import { ExpandMore, ExpandLess, CalendarToday } from '@mui/icons-material';
import ReactMarkdown from 'react-markdown';
import axios from 'axios';
import { NEWS_API_URL } from '../../const';

const QuadrantCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  backgroundColor: 'rgba(255, 255, 255, 0.03)',
  border: '1px solid rgba(0, 192, 127, 0.3)',
  borderRadius: theme.spacing(1),
  background: 'linear-gradient(135deg, rgba(0, 192, 127, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%)',
  backdropFilter: 'blur(10px)',
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
  minHeight: '180px',
  display: 'flex',
  flexDirection: 'column',
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  marginBottom: theme.spacing(2),
  fontWeight: 600,
  position: 'relative',
  color: theme.palette.primary.main,
  '&::after': {
    content: '""',
    position: 'absolute',
    bottom: -8,
    left: 0,
    width: 50,
    height: 3,
    backgroundColor: theme.palette.primary.main,
    borderRadius: 2,
  },
}));

const FeaturedBadge = styled(Chip)(({ theme }) => ({
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  fontSize: '0.75rem',
  height: 20,
  marginLeft: theme.spacing(1),
}));

const CategoryChip = styled(Chip)(({ theme }) => ({
  backgroundColor: 'rgba(255, 255, 255, 0.1)',
  color: theme.palette.text.secondary,
  fontSize: '0.7rem',
  height: 18,
  marginRight: theme.spacing(0.5),
}));

const NEWS_PREVIEW_LIMIT = 3;
const CONTENT_PREVIEW_LENGTH = 150;

const CACHE_KEY = 'newsPreviewData';
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes

const NewsPreview = () => {
  const [newsData, setNewsData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [expandedItems, setExpandedItems] = useState({});
  const [expandedQuadrants, setExpandedQuadrants] = useState({});

  useEffect(() => {
    let cachedValid = false;
    const cached = sessionStorage.getItem(CACHE_KEY);
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Date.now() - parsed.timestamp < CACHE_TTL_MS) {
          setNewsData(parsed.data);
          setLoading(false);
          cachedValid = true;
        }
      } catch {
        sessionStorage.removeItem(CACHE_KEY);
      }
    }

    const fetchNews = async () => {
      try {
        const res = await axios.get(`${NEWS_API_URL}/news/news.json`, { timeout: 5000 });
        setNewsData(res.data);
        sessionStorage.setItem(
          CACHE_KEY,
          JSON.stringify({ data: res.data, timestamp: Date.now() })
        );
      } catch (err) {
        console.warn('Failed to fetch news for preview:', err);
      } finally {
        setLoading(false);
      }
    };

    if (!cachedValid) {
      fetchNews();
    }
  }, []);

  if (loading) {
    return <Typography>Loading...</Typography>;
  }

  if (!newsData || !newsData.quadrants) {
    return null;
  }

  const toggleItemExpanded = (itemId) => {
    setExpandedItems(prev => ({ ...prev, [itemId]: !prev[itemId] }));
  };

  const toggleQuadrantExpanded = (quadrantKey) => {
    setExpandedQuadrants(prev => ({ ...prev, [quadrantKey]: !prev[quadrantKey] }));
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const diffTime = today - date;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const renderItems = (items = [], quadrantKey) => (
    <Box sx={{ flex: 1 }}>
      {items.slice(0, expandedQuadrants[quadrantKey] ? items.length : NEWS_PREVIEW_LIMIT).map((item, index) => {
        const isExpanded = expandedItems[item.id];
        const hasLongContent = item.content && item.content.length > CONTENT_PREVIEW_LENGTH;
        const displayContent = hasLongContent && !isExpanded 
          ? item.content.substring(0, CONTENT_PREVIEW_LENGTH) + '...'
          : item.content;

        return (
        <Box key={item.id} sx={{ mb: 2, pb: 1, borderBottom: index < (expandedQuadrants[quadrantKey] ? items.length : Math.min(items.length, NEWS_PREVIEW_LIMIT)) - 1 ? '1px solid rgba(255, 255, 255, 0.1)' : 'none' }}>
          <Box sx={{ display: 'flex', alignItems: 'start', justifyContent: 'space-between', mb: 0.5 }}>
            <Box sx={{ flex: 1 }}>
              <Typography variant="subtitle1" sx={{ fontWeight: 600, fontSize: '0.95rem' }}>
                {item.title}
              </Typography>
              {item.date && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.5 }}>
                  <CalendarToday sx={{ fontSize: '0.75rem', color: 'text.secondary' }} />
                  <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                    {formatDate(item.date)}
                  </Typography>
                </Box>
              )}
            </Box>
            {item.featured && <FeaturedBadge label="Featured" size="small" />}
          </Box>
          {item.content && item.content.trim() && (
            <>
              <Box sx={{ color: 'text.secondary', fontSize: '0.85rem', lineHeight: 1.4, mb: 1 }}>
                <ReactMarkdown
                  components={{
                    p: ({children}) => <Typography variant="body2" sx={{ color: 'inherit', fontSize: 'inherit', mb: 0.5 }}>{children}</Typography>,
                    a: ({children, href}) => <Link href={href} target="_blank" rel="noopener">{children}</Link>,
                    strong: ({children}) => <strong style={{ color: '#00c07f' }}>{children}</strong>,
                  }}
                >
                  {displayContent}
                </ReactMarkdown>
              </Box>
              {hasLongContent && (
                <Button
                  size="small"
                  onClick={() => toggleItemExpanded(item.id)}
                  startIcon={isExpanded ? <ExpandLess /> : <ExpandMore />}
                  sx={{ textTransform: 'none', fontSize: '0.8rem', padding: '2px 8px' }}
                >
                  {isExpanded ? 'Show less' : 'Read more'}
                </Button>
              )}
            </>
          )}
          {item.tags && item.tags.length > 0 && (
            <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 0.5 }}>
              {item.tags.slice(0, 3).map((tag, tagIndex) => (
                <CategoryChip key={tagIndex} label={`#${tag}`} size="small" />
              ))}
            </Box>
          )}
        </Box>
        );
      })}
      {items.length > NEWS_PREVIEW_LIMIT && (
        <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
          <Button
            size="small"
            onClick={() => toggleQuadrantExpanded(quadrantKey)}
            startIcon={expandedQuadrants[quadrantKey] ? <ExpandLess /> : <ExpandMore />}
            sx={{ textTransform: 'none' }}
          >
            {expandedQuadrants[quadrantKey] 
              ? 'Show less' 
              : `Show ${items.length - NEWS_PREVIEW_LIMIT} more`}
          </Button>
          <Link href="/news" underline="hover" sx={{ display: 'flex', alignItems: 'center' }}>
            View all news →
          </Link>
        </Box>
      )}
    </Box>
  );

  const { updates, news, events, general } = newsData.quadrants;

  // Filter quadrants that have content
  const quadrantsWithContent = [
    { key: 'updates', data: updates, title: updates?.title || 'Updates' },
    { key: 'news', data: news, title: news?.title || 'Latest News' },
    { key: 'events', data: events, title: events?.title || 'Events' },
    { key: 'general', data: general, title: general?.title || 'General' }
  ].filter(quadrant => quadrant.data?.items && quadrant.data.items.length > 0);

  // Don't render if no quadrants have content
  if (quadrantsWithContent.length === 0) {
    return null;
  }

  return (
    <Box sx={{ mt: 6 }}>
      <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
        News
      </Typography>
      <Grid container spacing={2}>
        {quadrantsWithContent.map((quadrant) => (
          <Grid item xs={12} md={6} key={quadrant.key}>
            <QuadrantCard>
              <SectionTitle variant="h6">{quadrant.title}</SectionTitle>
              {renderItems(quadrant.data.items, quadrant.key)}
            </QuadrantCard>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default NewsPreview;
