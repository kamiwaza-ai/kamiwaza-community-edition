import React from 'react';
import { render } from '@testing-library/react';
import { ThemeProvider } from '@mui/material/styles';
import { BrowserRouter } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';
import { ServerInfoContext } from './context/ServerInfoContext';
import theme from './Theme';

/**
 * Custom render function that includes all necessary providers
 * @param {React.ReactElement} ui - Component to render
 * @param {Object} options - Additional render options
 * @returns {Object} Render result from @testing-library/react
 */
export const renderWithProviders = (ui, options = {}) => {
  const {
    // Mock auth context value
    authValue = {
      user: null,
      loading: false,
      login: jest.fn(),
      logout: jest.fn(),
      createUser: jest.fn(),
      getWelcomeMessage: jest.fn(() => ''),
      fetchUserData: jest.fn(),
      verifyToken: jest.fn()
    },
    // Mock server info context value  
    serverInfoValue = {
      serverOs: 'linux',
      isLoading: false,
      error: null
    },
    // Router options
    routerProps = {},
    ...renderOptions
  } = options;

  const AllTheProviders = ({ children }) => {
    return (
      <ThemeProvider theme={theme}>
        <BrowserRouter {...routerProps}>
          <AuthContext.Provider value={authValue}>
            <ServerInfoContext.Provider value={serverInfoValue}>
              {children}
            </ServerInfoContext.Provider>
          </AuthContext.Provider>
        </BrowserRouter>
      </ThemeProvider>
    );
  };

  return render(ui, { wrapper: AllTheProviders, ...renderOptions });
};

/**
 * Simple render with just theme provider (for isolated component testing)
 * @param {React.ReactElement} ui - Component to render
 * @param {Object} options - Additional render options
 * @returns {Object} Render result from @testing-library/react
 */
export const renderWithTheme = (ui, options = {}) => {
  const ThemeWrapper = ({ children }) => (
    <ThemeProvider theme={theme}>
      {children}
    </ThemeProvider>
  );

  return render(ui, { wrapper: ThemeWrapper, ...options });
};

/**
 * Mock fetch responses for testing
 */
export const createMockFetch = (mockResponses = {}) => {
  return jest.fn((url, options) => {
    const response = mockResponses[url] || { ok: true, json: () => Promise.resolve({}) };
    return Promise.resolve(response);
  });
};

/**
 * Common test data factories
 */
export const testData = {
  model: {
    id: 'test-model-1',
    name: 'Test Model',
    description: 'A test model for unit testing',
    status: 'active',
    created_at: '2023-01-01T00:00:00Z'
  },
  
  user: {
    id: 'user-1',
    username: 'testuser',
    email: 'test@example.com',
    role: 'user'
  },

  cluster: {
    id: 'cluster-1',
    name: 'Test Cluster',
    status: 'running',
    nodes: 3
  },

  vectordb: {
    id: 'vectordb-1',
    name: 'Test VectorDB',
    type: 'milvus',
    status: 'healthy'
  }
};

// Re-export everything from @testing-library/react
export * from '@testing-library/react';
export { default as userEvent } from '@testing-library/user-event';