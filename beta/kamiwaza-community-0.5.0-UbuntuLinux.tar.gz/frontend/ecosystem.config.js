module.exports = {
  apps: [
    {
      name: 'kamiwaza-frontend',
      script: './process-manager.js',
      instances: 2,
      exec_mode: 'cluster',
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {  // Default environment
        PORT: 3000,
        HOST: '0.0.0.0',
        KAMIWAZA_FRONTEND_ENV: 'development'
      },
      env_production: {
        PORT: 3000,
        HOST: '0.0.0.0',
        KAMIWAZA_FRONTEND_ENV: 'production'
      },
      instance_var: 'INSTANCE_ID',
      exp_backoff_restart_delay: 100,
      kill_timeout: 5000,
    }
  ]
};
