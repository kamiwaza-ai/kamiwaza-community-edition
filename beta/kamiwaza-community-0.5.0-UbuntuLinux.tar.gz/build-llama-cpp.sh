#!/bin/bash

# Read commit from file or env var
LLAMA_COMMIT="${KAMIWAZA_LLAMA_COMMIT:-master}"

# Check if commit is empty
if [[ -z "${LLAMA_COMMIT}" ]]; then
    echo "Error: No commit specified in llamacpp.commit or KAMIWAZA_LLAMA_COMMIT"
    exit 1
fi

set -ex

mkdir -p llamacpp
cd llamacpp

# Function to build llama.cpp
build_llama() {
    local build_dir=$1
    cd "$build_dir"
    git fetch origin
    git checkout $LLAMA_COMMIT
    git branch -D kamiwaza || true
    git checkout -b kamiwaza
    cmake -B build
    cmake --build build --config Release
    cd ..
}

# Check if we need to rebuild
if [ -d "llama.cpp" ]; then
    echo "Existing llama.cpp found. Rebuilding..."
    
    # Move existing directory to old first
    mv llama.cpp llama.cpp_old
    
    # Clone directly into llama.cpp
    git clone https://github.com/ggerganov/llama.cpp.git llama.cpp
    
    # Set up and activate venv
    if [ ! -d "venv" ]; then
        python -m venv venv
    fi
    source venv/bin/activate
    
    # Build in the new directory
    build_llama "llama.cpp"
    
    # Check if build was successful
    if [ -f "llama.cpp/llama-server" -o -f "llama.cpp/build/bin/llama-server" ]; then
        echo "Build successful. Removing old version..."
        rm -rf llama.cpp_old
    else
        echo "Build failed. Restoring old version."
        rm -rf llama.cpp
        mv llama.cpp_old llama.cpp
    fi
else
    echo "No existing llama.cpp found. Performing fresh install..."
    git clone https://github.com/ggerganov/llama.cpp.git
    python -m venv venv
    source venv/bin/activate
    build_llama "llama.cpp"
fi

deactivate || true
