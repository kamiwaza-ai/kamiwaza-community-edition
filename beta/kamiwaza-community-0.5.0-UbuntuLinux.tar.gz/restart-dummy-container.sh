#!/bin/bash
set -euo pipefail

# Source kamiwaza root and common functions
source "$(dirname "$0")/set-kamiwaza-root.sh"

# Source environment variables
if [ -f /etc/kamiwaza/env.sh ]; then
    source /etc/kamiwaza/env.sh
elif [ -f "${KAMIWAZA_ROOT}/env.sh" ]; then
    source "${KAMIWAZA_ROOT}/env.sh"
fi

# Source setup_network.sh to use its functions
source "$(dirname "$0")/setup_network.sh"

# Call the function to recreate dummy service with essential networks
setup_essential_networks
