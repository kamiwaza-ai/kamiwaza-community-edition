
#!/bin/bash
# Read commit from file or env var
LLAMA_COMMIT="${KAMIWAZA_LLAMA_COMMIT:-master}"
# Check if commit is empty
if [[ -z "${LLAMA_COMMIT}" ]]; then
    echo "Error: No commit specified in llamacpp.commit or KAMIWAZA_LLAMA_COMMIT"
    exit 1
fi
set -ex
# Determine script directory and key absolute paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LLAMACPP_DIR="${SCRIPT_DIR}/llamacpp"
LLAMA_SRC_DIR="${LLAMACPP_DIR}/llama.cpp"
# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color
# Logging functions
log() {
    echo -e "${GREEN}[INFO]${NC} $1"
}
warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}
error() {
    echo -e "${RED}[ERROR]${NC} $1"
}
header() {
    echo -e "${BLUE}=== $1 ===${NC}"
}
success() {
    echo -e "${PURPLE}[SUCCESS]${NC} $1"
}
# Function to detect WSL environment
is_wsl() {
    if uname_out="$(uname -a 2>/dev/null)"; then
        if echo "$uname_out" | grep -q "microsoft-standard-WSL2"; then
            return 0  # true
        fi
    fi
    return 1  # false
}

# Function to check oneAPI installation
check_oneapi() {
    if [ -f "/opt/intel/oneapi/setvars.sh" ]; then
        log "Intel oneAPI found"
        return 0
    else
        warn "Intel oneAPI not found at /opt/intel/oneapi/setvars.sh"
        return 1
    fi
}
# Function to build llama.cpp with SYCL (Intel GPU)
build_llama_sycl() {
    local build_dir=$1
    cd "$build_dir"
    log "Building llama.cpp with SYCL support for Intel GPU..."
    # Source oneAPI environment
    source /opt/intel/oneapi/setvars.sh
    # Clean and build with SYCL
    rm -rf build
    mkdir -p build && cd build
    # Configure with SYCL support
    cmake .. -DGGML_SYCL=ON -DCMAKE_C_COMPILER=icx -DCMAKE_CXX_COMPILER=icpx
    # Build with all available cores
    make -j$(nproc)
    cd ..
}

# Function to build llama.cpp (standard)
build_llama_standard() {

    local build_dir=$1
    cd "$build_dir"
    # Set up and activate venv
    if [ ! -d "venv" ]; then
        python -m venv venv
        source venv/bin/activate
    fi
    pip install -r requirements.txt
    log "Building llama.cpp with standard configuration..."
    git fetch origin
    git checkout $LLAMA_COMMIT
    git branch -D kamiwaza || true
    git checkout -b kamiwaza
    cmake -B build
    cmake --build build --config Release
    cd ..
}
# Main build function
build_llama() {
    local build_dir=$1
    local build_type=$2
    case "$build_type" in
        "sycl")
            build_llama_sycl "$build_dir"
            ;;
        "standard")
            build_llama_standard "$build_dir"
            ;;
        *)
            error "Unknown build type: $build_type"
            return 1
            ;;
    esac
}
# Add dependency checks
check_dependencies() {
	local missing=0
	if ! command -v cmake >/dev/null 2>&1; then
		error "cmake is not installed. Please install cmake."
		missing=1
	fi
	if ! command -v make >/dev/null 2>&1; then
		warn "make not found; some generators require it. Install build-essential if missing."
	fi
	if [ "$missing" -ne 0 ]; then
		return 1
	fi
	return 0
}
# Main execution
main() {
    header "Building llama.cpp for Kamiwaza"
    # Ensure dependencies are available
    if ! check_dependencies; then
        error "Missing required dependencies. Install cmake (and make) then rerun."
        exit 1
    fi
    # Check if we're in WSL
    # Source common.sh for GPU detection
    source "${SCRIPT_DIR}/common.sh"
    
    # Determine build type based on environment and hardware
    if is_wsl && [ "$(perform_gpu_detection true)" = "true" ] && check_oneapi; then
        log "WSL with Intel GPU detected, using SYCL build"
        BUILD_TYPE="sycl"
    else
        log "Using standard build"
        BUILD_TYPE="standard"
    fi
    # Ensure working directory exists
    mkdir -p "$LLAMACPP_DIR"
    cd "$LLAMACPP_DIR"
    # Check if we need to rebuild
    if [ -d "$LLAMA_SRC_DIR" ]; then
        log "Existing llama.cpp found. Rebuilding..."
        # Move existing directory to old first
        mv "$LLAMA_SRC_DIR" "${LLAMA_SRC_DIR}_old"
        # Clone directly into llama.cpp absolute path
        git clone https://github.com/ggerganov/llama.cpp.git "$LLAMA_SRC_DIR"
        # Build in the new directory
        if build_llama "$LLAMA_SRC_DIR" "$BUILD_TYPE"; then
            # Check if build was successful
            if [ -f "$LLAMA_SRC_DIR/build/bin/llama-server" ] || [ -f "$LLAMA_SRC_DIR/build/Release/bin/llama-server" ] || [ -f "$LLAMA_SRC_DIR/llama-server" ] || [ -f "$LLAMA_SRC_DIR/bin/llama-server" ]; then
                success "Build successful. Removing old version..."
                rm -rf "${LLAMA_SRC_DIR}_old"
            else
                warn "Build failed. Restoring old version."
                echo "PWD: $(pwd)"
                echo "Checking paths:"
                echo "  $LLAMA_SRC_DIR/build/bin/llama-server: $([ -f \"$LLAMA_SRC_DIR/build/bin/llama-server\" ] && echo \"EXISTS\" || echo \"NOT FOUND\")"
                echo "  $LLAMA_SRC_DIR/build/Release/bin/llama-server: $([ -f \"$LLAMA_SRC_DIR/build/Release/bin/llama-server\" ] && echo \"EXISTS\" || echo \"NOT FOUND\")"
                echo "  $LLAMA_SRC_DIR/llama-server: $([ -f \"$LLAMA_SRC_DIR/llama-server\" ] && echo \"EXISTS\" || echo \"NOT FOUND\")"
                echo "  $LLAMA_SRC_DIR/bin/llama-server: $([ -f \"$LLAMA_SRC_DIR/bin/llama-server\" ] && echo \"EXISTS\" || echo \"NOT FOUND\")"
                echo "Directory contents:"
                ls -la "$LLAMA_SRC_DIR" || echo "Directory not accessible: $LLAMA_SRC_DIR"
                ls -la "$LLAMA_SRC_DIR/bin/" 2>/dev/null || echo "bin directory not accessible"
                ls -la "$LLAMA_SRC_DIR/build/" 2>/dev/null || echo "build directory not accessible"
                rm -rf "$LLAMA_SRC_DIR"
                mv "${LLAMA_SRC_DIR}_old" "$LLAMA_SRC_DIR"
                exit 1
            fi
        else
            warn "Build failed. Restoring old version."
            rm -rf "$LLAMA_SRC_DIR"
            mv "${LLAMA_SRC_DIR}_old" "$LLAMA_SRC_DIR"
            exit 1
        fi
    else
        log "No existing llama.cpp found. Performing fresh install..."
        git clone https://github.com/ggerganov/llama.cpp.git "$LLAMA_SRC_DIR"
        if ! build_llama "$LLAMA_SRC_DIR" "$BUILD_TYPE"; then
            error "Fresh build failed"
            exit 1
        fi
        # Verify build artifacts for fresh install as well
        if [ -f "$LLAMA_SRC_DIR/build/bin/llama-server" ] || [ -f "$LLAMA_SRC_DIR/build/Release/bin/llama-server" ] || [ -f "$LLAMA_SRC_DIR/llama-server" ] || [ -f "$LLAMA_SRC_DIR/bin/llama-server" ]; then
            :
        else
            error "Build finished but llama-server not found."
            exit 1
        fi
    fi
    success "llama.cpp build completed successfully!"
    # Show usage instructions
    echo
    header "Usage Instructions"
    echo
    case "$BUILD_TYPE" in
        "sycl")
            log "For SYCL build (Intel GPU):"
            echo "  1. Source oneAPI: source /opt/intel/oneapi/setvars.sh"
            echo "  2. Run inference: $LLAMA_SRC_DIR/build/bin/llama-cli -m <model.gguf> -p 'Hello' -ngl 999"
            echo "  3. Run benchmark: $LLAMA_SRC_DIR/build/bin/llama-bench -m <model.gguf> -ngl 999"
            ;;
        "standard")
            log "For standard build:"
            echo "  1. Run server: $LLAMA_SRC_DIR/bin/llama-server -m <model.gguf>"
            ;;
    esac
    echo
}
# Run main function
main "$@"
