#!/bin/bash
set -euo pipefail

# Set component-specific log prefix
LOG_PREFIX="TRAEFIK-PRELAUNCH"

# Source the common logging functions
if [ -f "./common-logging.sh" ]; then
    source ./common-logging.sh
else
    # Fallback if common-logging.sh not found
    log_info() { echo "[INFO] $1"; }
    log_warn() { echo "[WARN] $1"; }
    log_error() { echo "[ERROR] $1"; }
    log_success() { echo "[SUCCESS] $1"; }
    log_step() { echo ""; echo "========== $1 =========="; }
fi

log_step "Setting up Traefik certificates"

# Define variables
CERT_DIR="./certs"
DOMAIN="*.default.deployment.kamiwaza.ai"
CERT_FILE="$CERT_DIR/domain.crt"
KEY_FILE="$CERT_DIR/domain.key"
DAYS_VALID=3650
RSA_LENGTH=4096

# Check if the certs directory and the necessary files exist
if [ ! -d "$CERT_DIR" ] || [ ! -f "$CERT_FILE" ] || [ ! -f "$KEY_FILE" ]; then
    log_info "Certificates not found for Traefik, generating new self-signed certificate..."

    # Create certs directory if it doesn't exist
    log_info "Creating certificates directory..."
    mkdir -p "$CERT_DIR"

    if [[ "$OSTYPE" == "darwin"* ]]; then
        chown ${USER}:staff "$CERT_DIR"
    else
        sudo chown ${USER}:${USER} "$CERT_DIR"
    fi
    
    # Generate the private key and self-signed certificate
    log_info "Generating self-signed certificate for domain: $DOMAIN"
    openssl req -newkey rsa:$RSA_LENGTH -nodes -keyout "$KEY_FILE" -x509 -sha256 -days $DAYS_VALID \
    -subj "/C=US/ST=State/L=City/O=Organization/OU=Unit/CN=$DOMAIN" \
    -addext "subjectAltName=DNS:$DOMAIN" \
    -out "$CERT_FILE"
    
    if [ $? -eq 0 ]; then
        log_success "Certificate and key have been generated and stored in $CERT_DIR"
    else
        log_error "Failed to generate certificate"
        exit 1
    fi
else
    log_info "Certificates already exist in $CERT_DIR"
fi

log_success "Traefik certificate setup completed"